'use strict';
// ── 전역 오류 기록: 현장에서 "삐걱거림" 원인 추적용 (관리자 → 시스템 탭) ──
function _logErr(msg){
  try{
    const log=JSON.parse(localStorage.getItem('_errLog')||'[]');
    log.unshift({t:new Date().toISOString().slice(5,16).replace('T',' '),m:String(msg).slice(0,180)});
    localStorage.setItem('_errLog',JSON.stringify(log.slice(0,30)));
  }catch(e){}
}
window.addEventListener('error',e=>{_logErr((e.message||'오류')+' @'+(e.filename||'').split('/').pop()+':'+(e.lineno||''));});
window.addEventListener('unhandledrejection',e=>{_logErr('Promise: '+((e.reason&&e.reason.message)||e.reason||'거부'));});

// ── 앱 버전 (CI 빌드 시 릴리스 태그로 자동 스탬프됨) ──
const APP_VER='v0';
try{document.getElementById('appVerLabel').textContent='설악산 현장관리 '+APP_VER;}catch(e){}

// ── 새 버전 알림: 네이티브 앱에서만, GitHub 최신 릴리스 태그와 비교 ──
function _checkAppUpdate(){
  try{
    const Cap=window.Capacitor;
    if(!Cap||!Cap.isNativePlatform||!Cap.isNativePlatform())return;
    if(!/^v\d{8}-\d{4}$/.test(APP_VER))return; // CI 스탬프 안 된 개발 빌드는 스킵
    const last=parseInt(localStorage.getItem('_updCheckAt')||'0',10);
    if(Date.now()-last<6*3600*1000)return; // 6시간에 한 번만 확인
    fetch('https://api.github.com/repos/109yoon/seoraksan/releases/latest')
      .then(r=>r.ok?r.json():null)
      .then(rel=>{
        // 확인이 실제로 성공했을 때만 6시간 창을 소모(오프라인/실패 시 다음 호출에서 재시도)
        localStorage.setItem('_updCheckAt',String(Date.now()));
        if(!rel||!rel.tag_name)return;
        if(!/^v\d{8}-\d{4}$/.test(rel.tag_name))return; // 형식이 다른 태그는 비교하지 않음(오탐 방지)
        if(rel.tag_name>APP_VER)_showUpdateBanner(rel);
      }).catch(()=>{});
  }catch(e){}
}
function _showUpdateBanner(rel){
  if(document.getElementById('updateBanner'))return;
  const asset=(rel.assets||[]).find(a=>/\.apk$/i.test(a.name));
  const url=(asset&&asset.browser_download_url)||rel.html_url;
  const div=document.createElement('div');
  div.id='updateBanner';
  div.style.cssText='position:fixed;left:10px;right:10px;bottom:14px;z-index:99999;background:#1d6fa5;color:#fff;padding:12px 14px;border-radius:12px;font-size:13px;display:flex;align-items:center;justify-content:space-between;gap:10px;box-shadow:0 4px 14px rgba(0,0,0,.3);';
  div.innerHTML='<span>🆕 새 버전('+rel.tag_name+')이 있습니다</span>';
  const btnWrap=document.createElement('div');
  btnWrap.style.cssText='display:flex;gap:8px;flex-shrink:0;';
  const dlBtn=document.createElement('a');
  dlBtn.textContent='업데이트';
  dlBtn.href=url;
  dlBtn.style.cssText='background:#fff;color:#1d6fa5;padding:6px 12px;border-radius:6px;font-weight:700;text-decoration:none;white-space:nowrap;';
  const closeBtn=document.createElement('button');
  closeBtn.type='button';
  closeBtn.textContent='닫기';
  closeBtn.style.cssText='background:transparent;color:#fff;border:1px solid rgba(255,255,255,.5);padding:6px 10px;border-radius:6px;white-space:nowrap;';
  closeBtn.onclick=function(){div.remove();};
  btnWrap.appendChild(dlBtn);btnWrap.appendChild(closeBtn);
  div.appendChild(btnWrap);
  document.body.appendChild(div);
}
setTimeout(_checkAppUpdate,4000);
// ══════════════════════════════════════════
// DB
// ══════════════════════════════════════════
// ── Firebase 설정 ──
const _FB_CFG={
  apiKey:"AIzaSyACBoT-h2h0aQXYJpPyznc3JBzprEhhUAw",
  authDomain:"seoraksan.firebaseapp.com",
  projectId:"seoraksan",
  storageBucket:"seoraksan.firebasestorage.app",
  messagingSenderId:"457414135264",
  appId:"1:457414135264:web:4103268ba0702a95a12f85"
};
// 기기 간 공유할 키 목록
// _SHARED_COLL: 항목마다 개별 Firestore 문서 (Race Condition 방지)
// facilities: 시설물 다수(표지판 169+)·점검사진 누적으로 단일문서 1MB 한계·동시편집 덮어쓰기 위험 → 건별 문서로 전환
// history: 점검이력은 무제한으로 계속 쌓이는 로그성 데이터라 단일문서 그대로 두면 매 점검마다 전체가 전원에게 재전송됨 → 건별 문서로 전환
const _SHARED_COLL=['rescues','hazards','facilities','history'];
// _SHARED_DOC: 단일 문서에 JSON 배열 저장 (관리자 전용, 동시 쓰기 없음)
const _SHARED_DOC=['alertOps','staff','catFac','catFacMeta','pendingUsers','approvedUsers','deletedKakaoIds','adminOwnerKakaoId','adminApprovalCode','extAgencies','extAgencyCode','extAgencyDisplayName','geminiApiKey','kmaProxyUrl','_acl','loginLog','trailStatus','crisisLevel','weatherBrief','weatherLog','trailLog','sosBlocked'];
// 시설물 레거시(단일문서) 폴백/시드 동기화 상태
let _legacyFacBackup=null; // appData/facilities(구버전)의 백업 — 컬렉션 비었을 때 화면 폴백
let _facSeedReady=false;   // 시설물 첫 스냅샷·레거시 백업 확인 완료(시드 레이스 방지)
let _facMigTried=false;    // 레거시→건별 이관 1회 시도 플래그
const _SHARED=[..._SHARED_COLL,..._SHARED_DOC]; // 하위 호환용
// 1년 이상 지난 구조/위험상황/점검이력 기록은 실시간 동기화 대상에서 빼고, 조회 시에만 1회 불러온다.
// (수백 명이 동시 접속해도 매번 전체 역대기록을 받지 않도록 — id가 Date.now() 기반이라 시간 필터에 그대로 쓸 수 있음)
const _ARCHIVE_COLLS=['rescues','hazards','history'];
const _ARCHIVE_CUTOFF_DAYS=365;
let _fsRecent={},_fsArchive={}; // k별: 실시간 구간 / 1회 조회한 과거 구간
let _archiveLoaded={}; // k별: 과거 구간 로드 완료(또는 시도중) 여부
// 실시간 구간(_fsRecent)+과거 구간(_fsArchive)을 합쳐 _fs[k]/_fsSync[k] 재구성
// (id 중복 시 실시간 구간 우선 — 경계 시점에 양쪽에 다 걸려도 최신 데이터로 통일)
function _rebuildFsColl(k){
  const map=new Map();
  (_fsArchive[k]||[]).forEach(r=>map.set(String(r.id),r));
  (_fsRecent[k]||[]).forEach(r=>map.set(String(r.id),r));
  const list=Array.from(map.values());
  try{list.sort((a,b)=>(Number(b.id)||0)-(Number(a.id)||0));}catch{}
  _fs[k]=list;
  const syncMap=new Map();
  list.forEach(r=>{syncMap.set(String(r.id),JSON.stringify(r));});
  _fsSync[k]=syncMap;
}
// 1년 이전 과거 기록을 1회 조회해 _fsArchive에 채운다(세션당 1회, 조회 시에만 호출)
function _loadArchive(k){
  if(!_ARCHIVE_COLLS.includes(k)||_archiveLoaded[k]||!_fdb)return Promise.resolve();
  _archiveLoaded[k]=true;
  const cutoff=Date.now()-_ARCHIVE_CUTOFF_DAYS*86400000;
  return _fdb.collection(k).where('id','<',cutoff).get().then(snap=>{
    _fsArchive[k]=snap.docs.map(d=>d.data());
    _rebuildFsColl(k);
  }).catch(()=>{_archiveLoaded[k]=false;});
}
var _remoteUpdateTimer=null; // module scope: shared across all Firebase listeners
const _fs={};   // Firestore 인메모리 캐시
let _fdb=null;
let _fst=null;
let _fmsg=null;
let _authReady=false;  // 인증(익명 또는 커스텀 토큰) 성공 여부
let _authErrCode='';   // 인증 실패 코드 (auth/operation-not-allowed 등)
let _authRole='';      // 커스텀 토큰 역할: 'admin' | 'member' | '' (익명/미인증)
let _authKakaoId='';   // 인증된 카카오 ID (커스텀 토큰 발급 시)
let _swReg=null;
// 기기 고유 ID (localStorage 영속, 알림 브로드캐스트 출처 구분용)
const _MY_DEVICE_ID=(function(){
  let id=localStorage.getItem('_deviceId');
  if(!id){id=Date.now().toString(36)+Math.random().toString(36).slice(2);localStorage.setItem('_deviceId',id);}
  return id;
})();
let _maxSharedNotiAt=0,_sharedNotiInited=false;

// 마지막 동기화 상태 스냅샷 (k → Map(id→json)) — DB.g가 캐시 참조를 그대로 반환하므로
// 호출부가 제자리 수정하면 _fs[k]와 새 값이 동일 객체가 되어 비교가 무의미해짐.
// 동기화 시점의 JSON을 따로 보관해 그것과 비교해야 변경이 정확히 감지됨.
const _fsSync={};
// _SHARED_DOC(단일문서 배열)의 동기화 기준 시점 스냅샷 — DB.s/원격 리스너에서만 갱신.
// 호출부가 DB.g 반환값을 push 등으로 제자리 수정해도 이 맵은 영향받지 않으므로,
// "직전 동기화 시점에 있었지만 지금 없는 항목 = 의도적 삭제"를 정확히 구분할 수 있다.
const _fsDocBase={};

// ── 저장 재시도 큐: Firebase 미준비/쓰기 거부 시 localStorage에 보관 후 자동 재전송 ──
// (오프라인 중 쓰기는 Firestore persistence가 자체 보존하므로, 여기서는
//  _fdb가 아직 null인 부팅 직후 호출과 권한 거부 등 하드 실패만 담당)
function _loadSyncQ(){try{return JSON.parse(localStorage.getItem('_syncQ')||'[]');}catch{return[];}}
function _saveSyncQ(q){try{localStorage.setItem('_syncQ',JSON.stringify(q));}catch{}_updateSyncBadge();}
function _updateSyncBadge(){
  const n=_loadSyncQ().length;
  const b=document.getElementById('syncBadge'),c=document.getElementById('syncBadgeN');
  if(b)b.style.display=n?'inline':'none';
  if(c)c.textContent=n;
  _updateHomeNetStatus();
}
// 홈 화면 상단의 항상 보이는 네트워크/동기화 상태 칩 (현장 신호 약한 환경 대비)
function _updateHomeNetStatus(){
  const el=document.getElementById('homeNetStatus');if(!el)return;
  const n=(typeof _loadSyncQ==='function')?_loadSyncQ().length:0;
  if(!navigator.onLine){
    el.textContent='📡 오프라인'+(n?' · 저장 '+n+'건 대기':'');
    el.style.color='#e74c3c';el.style.display='inline';
  }else if(n){
    el.textContent='⏳ 동기화 '+n+'건 ↻';
    el.style.color='#f0a500';el.style.display='inline';
  }else{
    el.style.display='none';
  }
}
let _syncQWarnedAt=0;
function _syncWriteFailed(item){ // item: {key, op:'set'|'del', coll?, id?, doc?, json?}
  const q=_loadSyncQ();
  const i=q.findIndex(x=>x.key===item.key);
  if(i>=0)q[i]=item;else q.push(item); // 같은 문서는 최신 내용으로 교체
  _saveSyncQ(q);
  if(Date.now()-_syncQWarnedAt>30000){
    _syncQWarnedAt=Date.now();
    // 인증이 안 된 상태면 원인을 명확히 안내 (콘솔 익명 인증 누락이 가장 흔함)
    var msg=_authErrCode==='auth/operation-not-allowed'
      ?'⚠️ 동기화 차단: Firebase 익명 인증이 꺼져 있습니다 (관리자 설정 필요)'
      :(!_authReady?'⚠️ 인증 대기 중 — 동기화는 인증 완료 후 자동 재시도':'⚠️ 서버 저장 대기 중 — 연결되면 자동 재시도');
    try{toast(msg);}catch(e){}
  }
}
let _syncQFlushing=false;
// 큐에서 특정 항목 제거 (key+json 동시 일치 — 플러시 중 갱신된 최신본 보호)
function _removeSyncItem(it){
  const cur=_loadSyncQ();const ci=cur.findIndex(x=>x.key===it.key&&x.json===it.json);
  if(ci>=0){cur.splice(ci,1);_saveSyncQ(cur);}
}
function _flushSyncQueue(){
  if(_syncQFlushing||!_fdb)return;
  const q=_loadSyncQ();
  if(!q.length){_updateSyncBadge();return;}
  _syncQFlushing=true;
  (async()=>{
    let ok=0;
    for(const it of q){
      try{
        if(it.doc!==undefined)await _txMergeDoc(it.doc,it.base!==undefined?JSON.parse(it.base):undefined,JSON.parse(it.json)); // 트랜잭션 병합(오프라인 큐도 통째 덮어쓰기 방지)
        else if(it.op==='del')await _fdb.collection(it.coll).doc(it.id).delete();
        else await _txMergeSet(it.coll,it.id,JSON.parse(it.json)); // 트랜잭션 병합(오프라인 변경분 재접속 시 서버 최신본과 합침)
        _removeSyncItem(it);ok++;
      }catch(e){
        // 데이터 신뢰성 최우선 — 실패해도 절대 폐기하지 않고 큐에 보존, 무한 재시도.
        // 단 한 항목의 실패가 뒤 항목을 막지 않도록 break 대신 continue(head-of-line blocking 제거).
        const code=(e&&e.code)||'';
        console.warn('[syncQ] 저장 실패(보존·재시도 예정):',it.key,'code='+code,e&&e.message);
        _markSyncFail(it,code,e&&e.message);
      }
    }
    _syncQFlushing=false;
    if(ok&&!_loadSyncQ().length)try{toast('✅ 대기 변경 '+ok+'건 동기화 완료');}catch(e){}
  })();
}
// 실패 항목에 진단 정보 누적 (시도 횟수·마지막 에러) — 폐기는 하지 않음
function _markSyncFail(it,code,msg){
  const cur=_loadSyncQ();const ci=cur.findIndex(x=>x.key===it.key&&x.json===it.json);
  if(ci>=0){cur[ci]=Object.assign({},cur[ci],{_n:(cur[ci]._n||0)+1,_err:code||'unknown',_errMsg:(msg||'').slice(0,140),_at:Date.now()});_saveSyncQ(cur);}
}
// 대기 항목 상세 — 무엇이/왜 안 되는지 사용자가 직접 확인
function _showSyncQueueInfo(){
  const q=_loadSyncQ();
  if(!q.length){try{toast('대기 중인 변경 없음');}catch(e){}return;}
  const lines=q.map(function(it,i){
    var what=it.doc!==undefined?('문서 '+it.doc):((it.op==='del'?'삭제 ':'저장 ')+it.coll+'/'+it.id);
    var sz=it.json?(' ~'+Math.round(it.json.length/1024)+'KB'):'';
    var tries=it._n?(' · 시도 '+it._n+'회'):'';
    var err=it._err?('\n   사유: '+it._err+(it._errMsg?(' — '+it._errMsg):'')):'';
    return (i+1)+'. '+what+sz+tries+err;
  });
  // 권한 오류(permission-denied)가 끼어 있으면 = member 토큰 만료/누락 → 자동복구 시도 후, 실패 시 재로그인 유도
  var permErr=q.some(function(it){return /permission|insufficient/i.test(it._err||'')||/permission|insufficient/i.test(it._errMsg||'');});
  if(permErr){
    _ensureMemberAuth().then(function(okk){
      if(okk){setTimeout(_flushSyncQueue,400);try{toast('✅ 저장 권한 복구됨 — 동기화 재시도');}catch(e){}}
      else{ if(confirm('저장 권한이 만료된 것 같습니다('+q.length+'건 대기).\n카카오로 다시 로그인하면 즉시 동기화됩니다.\n\n지금 다시 로그인할까요? (데이터는 안전하게 보존됨)')){try{kakaoLogin();}catch(e){}} }
    });
    return;
  }
  alert('서버에 아직 저장되지 못한 변경 '+q.length+'건:\n\n'+lines.join('\n\n')+'\n\n※ 자동으로 계속 재시도하며, 데이터는 이 기기에 안전하게 보존됩니다.\n※ 1000KB(1MB) 이상이면 Firestore 문서 한계로 저장 불가 — 사진을 줄여야 합니다.');
}
function _clearSyncQueue(){
  if(!confirm('서버에 아직 전송되지 않은 변경 '+_loadSyncQ().length+'건을 삭제하시겠습니까?\n(이미 저장된 데이터는 영향 없음)'))return;
  _saveSyncQ([]);
  toast('✅ 대기 항목 삭제됨');
}
window.addEventListener('online',()=>setTimeout(_flushSyncQueue,1500));
setInterval(_flushSyncQueue,45000);
_updateSyncBadge(); // 이전 세션에서 남은 대기 건 표시
// 네트워크 끊김을 동기화 실패 전에 즉시 알림 (대기 큐 배지는 쓰기가 실패해야만 뜸)
function _updateOfflineBadge(){const b=document.getElementById('offlineBadge');if(b)b.style.display=navigator.onLine?'none':'inline';_updateHomeNetStatus();}
window.addEventListener('online',_updateOfflineBadge);
window.addEventListener('offline',_updateOfflineBadge);
_updateOfflineBadge(); // 시작 시 1회 — 오프라인 상태로 켜도 배지가 바로 뜨도록
_updateOfflineBadge();

// 사용자 입력에서 태그 주입 차단: 공유 데이터 저장 시 <,>를 전각 문자로 치환
function _stripTags(v){
  if(typeof v==='string')return v.replace(/</g,'\uFF1C').replace(/>/g,'\uFF1E');
  if(Array.isArray(v))return v.map(_stripTags);
  if(v&&typeof v==='object'){const o={};for(const k in v)o[k]=_stripTags(v[k]);return o;}
  return v;
}
const _SANITIZE_KEYS=['rescues','hazards','pendingUsers'];
// ── 동시편집 병합: 누적 데이터(보고·댓글·타임라인·통과기록)는 합집합 보존, 단일값은 최신(로컬) 우선 ──
function _unionBy(server,local,keyFn){
  const map=new Map();let n=0;
  (server||[]).forEach(x=>{try{map.set(keyFn(x),x);}catch{map.set('_s'+(n++),x);}});
  (local||[]).forEach(x=>{try{map.set(keyFn(x),x);}catch{map.set('_l'+(n++),x);}});
  return [...map.values()];
}
// 로컬 레코드를 서버 최신본과 병합. 누적 배열만 union, 나머지 필드는 로컬 유지.
function _mergeRecord(local,server){
  if(!server||typeof server!=='object')return local;
  const out=Object.assign({},local);
  const fields=[
    ['reports',r=>r&&r.rid?('rid:'+r.rid):((r&&r.repTime||'')+'|'+(r&&r.author||'')+'|'+(r&&r.update||''))],
    ['comments',c=>(c&&c.id!=null)?('id:'+c.id):JSON.stringify(c)],
    ['timetable',e=>JSON.stringify(e)],
    ['wpLog',e=>JSON.stringify(e)],
    ['npsLog',e=>JSON.stringify(e)],
    ['photos',p=>(p&&p.url)?('url:'+p.url):JSON.stringify(p)],
    ['mobilizeResp',m=>(m&&m.name)?('name:'+m.name):JSON.stringify(m)], // 응소 응답(이름별 1건, 본인 응답은 항상 최신 로컬값 우선)
    ['fireTL',e=>JSON.stringify(e)] // 산불 진행 타임라인(등록 후에도 계속 추가됨)
  ];
  fields.forEach(([f,keyFn])=>{
    if(!Array.isArray(local[f])&&!Array.isArray(server[f]))return; // 양쪽 다 없으면 손대지 않음
    out[f]=_unionBy(server[f],local[f],keyFn);
  });
  if(Array.isArray(out.reports))out.reports.sort((a,b)=>String((a&&a.repTime)||'').localeCompare(String((b&&b.repTime)||'')));
  if(Array.isArray(out.fireTL))out.fireTL.sort((a,b)=>String((a&&a.time)||'').localeCompare(String((b&&b.time)||'')));
  // 추가 사고자(victims2): 병합된 보고 중 가장 최신 보고의 값을 신뢰
  // (한쪽 기기가 오프라인 중 작성한 stale 본으로 다른 기기가 추가한 사고자가 덮여 사라지는 것을 방지)
  if(Array.isArray(out.reports)&&out.reports.length){
    const latest=out.reports[out.reports.length-1];
    if(latest&&latest.victims2)out.victims2=latest.victims2;
  }
  // 종료 처리(status:'done')는 한쪽이라도 완료면 유지 — 동시편집으로 완료 처리가 되돌려지지 않게 함
  if(server.status==='done'||local.status==='done')out.status='done';
  // 시설 점검 상태: 두 기기가 같은 시설을 동시 점검하면 더 최근 점검(statusAt 큰 쪽)을 신뢰
  // — 트랜잭션 커밋 순서가 아니라 실제 점검 시각으로 승자를 정해 결과가 뒤바뀌지 않게 함
  if(server.statusAt!=null&&local.statusAt!=null&&server.statusAt>local.statusAt&&server.status){out.status=server.status;out.statusAt=server.statusAt;}
  // 환자 인계 기록은 더 최신 시각 쪽을 유지
  if(server.handover&&(!local.handover||String(server.handover.time||'')>String(local.handover.time||'')))out.handover=server.handover;
  return out;
}
// 건별 문서 1건을 트랜잭션으로 병합 저장(서버 최신본과 누적데이터 합침). 실패 시 reject → 호출부가 큐 보존.
function _txMergeSet(coll,id,localObj){
  const ref=_fdb.collection(coll).doc(id);
  return _fdb.runTransaction(t=>t.get(ref).then(snap=>{
    const merged=_mergeRecord(localObj,snap.exists?snap.data():null);
    t.set(ref,merged);
    return merged;
  }));
}
// 단일문서(JSON 배열) 항목 식별 키 — id 있으면 id, 없으면(문자열 등) 값 자체
function _sdItemKey(x){return(x&&typeof x==='object'&&x.id!=null)?('id:'+x.id):JSON.stringify(x);}
// 3-way 병합(base/local/server): base에는 있었지만 local에 없는 항목은 "의도적 삭제"로
// 보고 복원하지 않는다. base에 없던 항목이 local에 새로 생겼으면 추가, server에만 있는
// (다른 기기가 추가한) 항목은 그대로 보존 — 단순 합집합(union)과 달리 삭제가 안전하게 반영됨.
function _mergeSharedArray(base,local,server){
  const baseIds=new Set((base||[]).map(_sdItemKey));
  const localIds=new Set((local||[]).map(_sdItemKey));
  const removedIds=new Set([...baseIds].filter(id=>!localIds.has(id)));
  const localMap=new Map((local||[]).map(x=>[_sdItemKey(x),x]));
  const out=[];const seen=new Set();
  (server||[]).forEach(x=>{
    const id=_sdItemKey(x);
    if(removedIds.has(id))return; // 로컬에서 의도적으로 삭제한 항목 — 복원하지 않음
    out.push(localMap.has(id)?localMap.get(id):x); // 같은 id면 로컬 버전(수정분) 우선
    seen.add(id);
  });
  (local||[]).forEach(x=>{
    const id=_sdItemKey(x);
    if(!seen.has(id)){out.push(x);seen.add(id);} // 로컬에서 새로 추가된 항목
  });
  return out;
}
// appData/{key} 단일문서를 트랜잭션으로 병합 저장.
// base(직전 동기화 시점 스냅샷)가 있을 때만 3-way 병합 시도 — 여러 기기가 동시에
// 점검이력·가입신청 등을 추가해도 한쪽 기기의 덮어쓰기로 다른 기기의 항목이
// 통째로 사라지지 않는다. base가 없거나 배열이 아니면(딕셔너리/스칼라) 기존처럼 로컬 우선.
function _txMergeDoc(key,base,localVal){
  const ref=_fdb.collection('appData').doc(key);
  return _fdb.runTransaction(t=>t.get(ref).then(snap=>{
    let serverVal=null;
    if(snap.exists){try{serverVal=JSON.parse(snap.data().d);}catch(e){serverVal=null;}}
    const merged=(Array.isArray(localVal)&&Array.isArray(serverVal)&&Array.isArray(base))
      ?_mergeSharedArray(base,localVal,serverVal):localVal;
    t.set(ref,{d:JSON.stringify(merged)});
    return merged;
  }));
}
let _lsQuotaWarned=false; // localStorage 용량 초과 통지 1회 제한 플래그
const DB={
  g(k){
    if(_SHARED.includes(k)) return (_fs[k]!==undefined)?_fs[k]:null;
    try{return JSON.parse(localStorage.getItem('v7_'+k)||'null');}catch{return null;}
  },
  s(k,v){
    if(k==='facilities')_invalidateSignCache();
    if(_SANITIZE_KEYS.includes(k))v=_stripTags(v);
    if(_SHARED_COLL.includes(k)){
      _fs[k]=v||[];
      const prevJson=_fsSync[k]||new Map();
      const newJson=new Map();
      (v||[]).forEach(r=>{newJson.set(String(r.id),JSON.stringify(r));});
      // 새로 추가되거나 변경된 항목만 개별 문서에 저장 (실패 시 재시도 큐)
      newJson.forEach((json,id)=>{
        if(prevJson.get(id)===json)return;
        if(_fdb)_txMergeSet(k,id,JSON.parse(json)).catch(()=>_syncWriteFailed({key:k+'/'+id,op:'set',coll:k,id,json}));
        else _syncWriteFailed({key:k+'/'+id,op:'set',coll:k,id,json});
      });
      // 삭제된 항목 제거
      prevJson.forEach((_,id)=>{
        if(newJson.has(id))return;
        if(_fdb)_fdb.collection(k).doc(id).delete().catch(()=>_syncWriteFailed({key:k+'/'+id,op:'del',coll:k,id}));
        else _syncWriteFailed({key:k+'/'+id,op:'del',coll:k,id});
      });
      _fsSync[k]=newJson;
    }else if(_SHARED_DOC.includes(k)){
      const base=_fsDocBase[k]; // DB.s/원격 리스너에서만 갱신되는 기준 스냅샷(제자리수정 영향 없음)
      _fs[k]=v;_fsDocBase[k]=v;
      const json=JSON.stringify(v);
      if(_fdb)_txMergeDoc(k,base,v).catch(()=>_syncWriteFailed({key:'doc/'+k,doc:k,json,base:JSON.stringify(base===undefined?null:base)}));
      else _syncWriteFailed({key:'doc/'+k,doc:k,json,base:JSON.stringify(base===undefined?null:base)});
    }else{
      try{localStorage.setItem('v7_'+k,JSON.stringify(v));}
      catch(e){ // 저장 공간 초과 등으로 실패 시 조용히 넘어가지 않고 1회 통지
        if(!_lsQuotaWarned){_lsQuotaWarned=true;try{toast('⚠️ 기기 저장 공간 부족 — 일부 설정이 저장되지 않았습니다');}catch(_){}}
      }
    }
  },
  d(k){
    if(_SHARED_COLL.includes(k)){
      const prev=_fs[k]||[];
      _fs[k]=[];
      if(_fdb) prev.forEach(r=>_fdb.collection(k).doc(String(r.id)).delete().catch(()=>_syncWriteFailed({key:k+'/'+r.id,op:'del',coll:k,id:String(r.id)})));
      _fsSync[k]=new Map();
    }else if(_SHARED_DOC.includes(k)){
      _fs[k]=null;
      if(_fdb) _fdb.collection('appData').doc(k).delete().catch(()=>{});
    }else{
      localStorage.removeItem('v7_'+k);
    }
  },
  sync(){} // no-op (이전 코드 호환)
};

function initFirebase(onReady){
  try{
    if(!firebase.apps.length) firebase.initializeApp(_FB_CFG);
    // 익명 인증: Firestore 보안 규칙(request.auth != null)을 적용하기 위한 기반.
    // 인증 성공/실패를 추적하고, 성공 시 대기 큐를 즉시 재전송한다.
    try{
      firebase.auth().onAuthStateChanged(function(u){
        if(u){
          _authReady=true;_authErrCode='';
          // 커스텀 토큰(비익명) 세션이면 새로고침 후에도 클레임에서 역할 복원
          if(!u.isAnonymous){
            u.getIdTokenResult().then(function(r){
              var c=(r&&r.claims)||{};
              if(c.member){
                _authRole=c.admin?'admin':'member';
                _authKakaoId=c.kakaoId||'';
                if(c.admin)localStorage.setItem('_tokenAdmin','1');else localStorage.removeItem('_tokenAdmin');
                try{_markMemberOk();}catch(e){}
              }else{
                // 비익명인데 member 클레임이 없는 비정상 세션 → 카카오로 재발급 시도
                setTimeout(function(){try{_ensureMemberAuth();}catch(e){}},400);
              }
              try{updateUserUI();}catch(e){}
              try{_enforceAccessGate();}catch(e){}
            }).catch(function(){});
          }else{
            // 익명 세션: 카카오 로그인 이력이 있으면 member 토큰으로 자동 승급
            // (새 규칙은 member 클레임 없는 쓰기를 거부하므로, 재로그인 없이 권한 복원)
            setTimeout(function(){try{_ensureMemberAuth();}catch(e){}},500);
          }
          setTimeout(_flushSyncQueue,300); // 인증 완료 → 막혔던 쓰기 즉시 재시도
        }else{
          // 로그인 세션이 전혀 없을 때만 익명 인증으로 폴백.
          // (커스텀 토큰 세션은 위 분기에서 유지되므로 덮어쓰지 않는다.)
          firebase.auth().signInAnonymously().catch(function(e){
            _authErrCode=(e&&e.code)||'auth/unknown';
            // 익명 인증이 콘솔에서 꺼져 있으면 모든 쓰기가 막힌다 → 사용자에게 명확히 안내
            if(_authErrCode==='auth/operation-not-allowed'){
              setTimeout(function(){try{toast('⚠️ Firebase 익명 인증이 꺼져 있어 동기화가 안 됩니다 (관리자: 콘솔에서 익명 로그인 활성화 필요)');}catch(e){}},2500);
            }
          });
        }
      });
    }catch(e){_authErrCode='auth/init-failed';}
    _fdb=firebase.firestore();
    _fdb.enablePersistence().catch(()=>{});
    _fst=firebase.storage();
    try{_fmsg=firebase.messaging();}catch(e){}
    setTimeout(_flushSyncQueue,3000); // 부팅 직후 대기 큐 재전송
    setTimeout(_processPhotoQueue,5000); // 이전 세션 오프라인 사진 이어서 업로드
    setTimeout(_cleanOldSharedNotis,8000); // 세션당 1회: 24h 지난 브로드캐스트 알림 정리(확률 의존 X)
    const totalKeys=_SHARED.length;
    const loaded=new Set();
    function _checkReady(){if(loaded.size===totalKeys){onReady&&onReady();onReady=null;}}
    function _onRemoteUpdate(){
      _checkDeletedUser();updateSummary();
      try{_checkNewJoinerAlert();}catch(e){}
      try{_updateCrisisBanner();}catch(e){}
      clearTimeout(_remoteUpdateTimer);
      _remoteUpdateTimer=setTimeout(function(){
        if(window.curApp==='rescue'){renderResList();try{renderRescueMap();}catch(e){}}
        else if(window.curApp==='inspect'){renderFacList();renderInspectMap();}
        else if(window.curApp==='alert')renderAlertView();
        else if(window.curApp==='stats')renderFullStats();
      },400);
    }
    // ── 컬렉션 리스너: 항목마다 개별 문서 (rescues, hazards) ──
    // rescues/hazards는 최근 1년(_ARCHIVE_CUTOFF_DAYS)만 실시간 구독 — 수백 명 접속해도
    // 매번 전체 역대기록을 받지 않도록(id가 Date.now() 기반이라 그대로 범위 필터 가능).
    // 1년 이전 기록은 조회 시 _loadArchive()로 1회만 불러온다.
    _SHARED_COLL.forEach(k=>{
      const isArchived=_ARCHIVE_COLLS.includes(k);
      const ref=isArchived?_fdb.collection(k).where('id','>=',Date.now()-_ARCHIVE_CUTOFF_DAYS*86400000):_fdb.collection(k);
      ref.onSnapshot(snap=>{
        const docs=snap.docs.map(d=>d.data());
        if(isArchived){
          _fsRecent[k]=docs;
          _rebuildFsColl(k);
        }else{
          _fs[k]=docs;
          try{_fs[k].sort((a,b)=>(Number(b.id)||0)-(Number(a.id)||0));}catch{}
          // 동기화 기준 스냅샷 갱신 (서버 상태 = 마지막 동기화 상태)
          const syncMap=new Map();
          _fs[k].forEach(r=>{syncMap.set(String(r.id),JSON.stringify(r));});
          _fsSync[k]=syncMap;
        }
        // 시설물: 컬렉션이 비어있으면 레거시 단일문서 백업으로 폴백 표시 + 1회 이관 시도
        if(k==='facilities'){
          if(_fs[k].length===0&&_legacyFacBackup&&_legacyFacBackup.length){
            _fs[k]=_legacyFacBackup.slice(); // 화면 폴백(동기화 끊겨도 데이터 안 사라짐)
            if(!_facMigTried){_facMigTried=true;try{DB.s('facilities',_fs[k]);}catch(e){}} // 건별 문서로 이관(실패 시 큐 보존)
          }
          if(loaded.has(k))try{_invalidateSignCache();}catch(e){}
          _facSeedReady=true;
          try{_ensureSignSeed();}catch(e){}
        }
        if(!loaded.has(k)){loaded.add(k);_checkReady();}
        else{_onRemoteUpdate();}
      },()=>{if(k==='facilities'){_facSeedReady=true;try{_ensureSignSeed();}catch(e){}}if(!loaded.has(k)){loaded.add(k);_checkReady();}});
    });
    // ── 단일 문서 리스너: appData/{key} ──
    _SHARED_DOC.forEach(k=>{
      _fdb.collection('appData').doc(k).onSnapshot(snap=>{
        _fs[k]=snap.exists?(()=>{try{return JSON.parse(snap.data().d);}catch{return null;}})():null;
        _fsDocBase[k]=_fs[k]; // 서버 확정 상태 = 다음 쓰기의 병합 기준
        if(!loaded.has(k)){loaded.add(k);_checkReady();}
        else{
          // 원격 업데이트: 표지판/시설 캐시 무효화 후 리렌더 (catFacMeta가 표지판 표시에 영향)
          if(k==='catFacMeta')try{_invalidateSignCache();}catch(e){}
          _onRemoteUpdate();
        }
      },()=>{if(!loaded.has(k)){loaded.add(k);_checkReady();}});
    });
    // ── 시설물 레거시(단일문서) 백업 읽기: 컬렉션 비었을 때 폴백·이관 소스 ──
    _fdb.collection('appData').doc('facilities').get().then(snap=>{
      if(snap.exists){try{const a=JSON.parse(snap.data().d);if(Array.isArray(a)&&a.length)_legacyFacBackup=a;}catch(e){}}
      // 백업 확보 후, 이미 빈 컬렉션 스냅샷을 받았다면 폴백 반영
      if(_legacyFacBackup&&(!_fs['facilities']||_fs['facilities'].length===0)){
        _fs['facilities']=_legacyFacBackup.slice();
        if(!_facMigTried){_facMigTried=true;try{DB.s('facilities',_fs['facilities']);}catch(e){}}
        try{_invalidateSignCache();}catch(e){}
        try{if(window.curApp==='inspect'){renderFacList();renderInspectMap();}}catch(e){}
      }
    }).catch(()=>{});
    // ── 구버전 단일 문서 → 개별 문서 마이그레이션 ──
    // ── 기기 간 알림 브로드캐스트 리스너 (준비 체크에 미포함) ──
    _fdb.collection('sharedNotis').orderBy('at','desc').limit(50)
      .onSnapshot(snap=>{
        if(!_sharedNotiInited){
          // 첫 스냅샷: 현재 최신 ts 기록 → 기존 알림은 무시
          _maxSharedNotiAt=snap.docs.reduce((m,d)=>Math.max(m,d.data().at||0),0);
          _sharedNotiInited=true;
          return;
        }
        snap.docChanges().forEach(ch=>{
          if(ch.type!=='added')return;
          const d=ch.doc.data();
          if((d.at||0)<=_maxSharedNotiAt)return;
          if(d.deviceId===_MY_DEVICE_ID)return; // 내가 보낸 것
          _maxSharedNotiAt=Math.max(_maxSharedNotiAt,d.at||0);
          // 앱 내 벨 알림 추가
          const ns=DB.g('notis')||[];
          ns.unshift({id:d.id||Date.now(),msg:d.msg,ico:d.ico,time:d.timeStr||now(),read:false,link:d.link||null});
          if(ns.length>80)ns.splice(80);
          DB.s('notis',ns);updateBell();
          // OS 시스템 알림 (앱이 백그라운드일 때만)
          _showSystemNoti(d.msg,d.ico);
        });
      },()=>{});
    _migrateLegacyCollections();
    setTimeout(()=>{if(onReady){onReady();onReady=null;}},10000);
  }catch(e){onReady&&onReady();}
}

async function _migrateLegacyCollections(){
  if(!_fdb)return;
  for(const k of _SHARED_COLL){
    try{
      const oldDoc=await _fdb.collection('appData').doc(k).get();
      if(!oldDoc.exists)continue;
      const oldData=JSON.parse(oldDoc.data().d||'[]');
      if(!Array.isArray(oldData)||!oldData.length){
        await _fdb.collection('appData').doc(k).delete();continue;
      }
      // 이미 새 구조에 데이터 있으면 구버전 문서만 삭제
      const existing=await _fdb.collection(k).limit(1).get();
      if(!existing.empty){await _fdb.collection('appData').doc(k).delete();continue;}
      // 배치 마이그레이션 (최대 500건)
      const batch=_fdb.batch();
      oldData.slice(0,500).forEach(r=>batch.set(_fdb.collection(k).doc(String(r.id)),r));
      await batch.commit();
      await _fdb.collection('appData').doc(k).delete();
      console.log(`[마이그레이션] ${k} ${oldData.length}건 개별 문서 이전 완료`);
    }catch(e){console.warn('[마이그레이션 오류]',k,e);}
  }
}

const RES_TYPES={
  '안전사고':{ico:'🤕',pc:'p-acc',color:'#c0392b'},
  '낙석':    {ico:'🪨',pc:'p-rock',color:'#7d3c98'},
  '위험수목':{ico:'🌲',pc:'p-tree',color:'#ca6f1e'},
  '화재':    {ico:'🔥',pc:'p-fire',color:'#a93226'},
  '':    {ico:'🌊',pc:'p-haz', color:'#1a6090'},
  '기타':    {ico:'⚠️',pc:'p-etc', color:'#5d6d7e'},
};

function _ensureSignSeed(){
  var _facs=DB.g('facilities')||[];
  var _hasSign=_facs.some(function(f){return f.type&&f.type.indexOf('다목적위치표지판')>=0;});
  if(_hasSign)return;
  var _seed=[{"id":1,"type":"🪧 다목적위치표지판","name":"01-01 청운정 아래500m","lat":38.173718,"lng":128.480326,"loc":"01-01","elev":219,"status":"ok"},{"id":2,"type":"🪧 다목적위치표지판","name":"01-02 청운정","lat":38.173346,"lng":128.47574,"loc":"01-02","elev":239,"status":"ok"},{"id":3,"type":"🪧 다목적위치표지판","name":"01-03 군량장 아래 300m","lat":38.170381,"lng":128.473421,"loc":"01-03","elev":250,"status":"ok"},{"id":4,"type":"🪧 다목적위치표지판","name":"01-04 (와선대 아래 100m","lat":38.166325,"lng":128.471024,"loc":"01-04","elev":267,"status":"ok"},{"id":5,"type":"🪧 다목적위치표지판","name":"01-05 비선대","lat":38.162865,"lng":128.466413,"loc":"01-05","elev":320,"status":"ok"},{"id":6,"type":"🪧 다목적위치표지판","name":"01-06 설악골 위 100m","lat":38.159572,"lng":128.469408,"loc":"01-06","elev":376,"status":"ok"},{"id":7,"type":"🪧 다목적위치표지판","name":"01-07 잦은바위골","lat":38.155681,"lng":128.470476,"loc":"01-07","elev":418,"status":"ok"},{"id":8,"type":"🪧 다목적위치표지판","name":"01-08 귀면암","lat":38.152346,"lng":128.469876,"loc":"01-08","elev":496,"status":"ok"},{"id":9,"type":"🪧 다목적위치표지판","name":"01-09 병풍교","lat":38.150047,"lng":128.472944,"loc":"01-09","elev":530,"status":"ok"},{"id":10,"type":"🪧 다목적위치표지판","name":"01-10 칠선골 아래 100m","lat":38.146238,"lng":128.473648,"loc":"01-10","elev":600,"status":"ok"},{"id":11,"type":"🪧 다목적위치표지판","name":"01-11 오련폭포","lat":38.143603,"lng":128.474455,"loc":"01-11","elev":660,"status":"ok"},{"id":12,"type":"🪧 다목적위치표지판","name":"01-12 양폭대피소","lat":38.139774,"lng":128.47469,"loc":"01-12","elev":709,"status":"ok"},{"id":13,"type":"🪧 다목적위치표지판","name":"01-13 죽음의 계곡 아래 400m","lat":38.136418,"lng":128.473544,"loc":"01-13","elev":798,"status":"ok"},{"id":14,"type":"🪧 다목적위치표지판","name":"01-14 죽음의 계곡 위 100m","lat":38.13374,"lng":128.469714,"loc":"01-14","elev":883,"status":"ok"},{"id":15,"type":"🪧 다목적위치표지판","name":"01-15 무너미고개 아래","lat":38.135076,"lng":128.46466,"loc":"01-15","elev":1069,"status":"ok"},{"id":16,"type":"🪧 다목적위치표지판","name":"01-16 희운각대피소","lat":38.132853,"lng":128.464842,"loc":"01-16","elev":1095,"status":"ok"},{"id":17,"type":"🪧 다목적위치표지판","name":"01-17 사태골 위 200m","lat":38.13034,"lng":128.461456,"loc":"01-17","elev":1251,"status":"ok"},{"id":18,"type":"🪧 다목적위치표지판","name":"01-18 소청 아래 300m","lat":38.12721,"lng":128.458564,"loc":"01-18","elev":1445,"status":"ok"},{"id":19,"type":"🪧 다목적위치표지판","name":"01-19 소청 위 100m","lat":38.12373,"lng":128.457235,"loc":"01-19","elev":1627,"status":"ok"},{"id":20,"type":"🪧 다목적위치표지판","name":"01-20 중청대피소 위 100m","lat":38.120766,"lng":128.462003,"loc":"01-20","elev":1602,"status":"ok"},{"id":21,"type":"🪧 다목적위치표지판","name":"02-01 금강굴 삼거리 위 50m","lat":38.164229,"lng":128.463435,"loc":"02-01","elev":491,"status":"ok"},{"id":22,"type":"🪧 다목적위치표지판","name":"02-02 제1쉼터","lat":38.165649,"lng":128.462028,"loc":"02-02","elev":634,"status":"ok"},{"id":23,"type":"🪧 다목적위치표지판","name":"02-03 제1쉼터 위 500m","lat":38.16608,"lng":128.457469,"loc":"02-03","elev":794,"status":"ok"},{"id":24,"type":"🪧 다목적위치표지판","name":"02-04 샘터 아래500m","lat":38.163876,"lng":128.452519,"loc":"02-04","elev":935,"status":"ok"},{"id":25,"type":"🪧 다목적위치표지판","name":"02-05 샘터","lat":38.161342,"lng":128.447673,"loc":"02-05","elev":963,"status":"ok"},{"id":26,"type":"🪧 다목적위치표지판","name":"02-06 샘터 위500m","lat":38.161155,"lng":128.44155,"loc":"02-06","elev":1129,"status":"ok"},{"id":27,"type":"🪧 다목적위치표지판","name":"02-07 공룡능선 갈림길","lat":38.158086,"lng":128.437903,"loc":"02-07","elev":1209,"status":"ok"},{"id":28,"type":"🪧 다목적위치표지판","name":"02-08 첫능선200m","lat":38.156006,"lng":128.43436,"loc":"02-08","elev":1178,"status":"ok"},{"id":29,"type":"🪧 다목적위치표지판","name":"02-09 오세암 아래400m","lat":38.153822,"lng":128.431494,"loc":"02-09","elev":1024,"status":"ok"},{"id":30,"type":"🪧 다목적위치표지판","name":"02-10 오세암 위100m","lat":38.153225,"lng":128.430556,"loc":"02-10","elev":963,"status":"ok"},{"id":31,"type":"🪧 다목적위치표지판","name":"02-11 만경대 갈림길 아래 100m","lat":38.151083,"lng":128.427951,"loc":"02-11","elev":884,"status":"ok"},{"id":32,"type":"🪧 다목적위치표지판","name":"02-12 원명암터","lat":38.152069,"lng":128.420109,"loc":"02-12","elev":794,"status":"ok"},{"id":33,"type":"🪧 다목적위치표지판","name":"02-13 첫고개쉼터","lat":38.152974,"lng":128.416565,"loc":"02-13","elev":708,"status":"ok"},{"id":34,"type":"🪧 다목적위치표지판","name":"02-14 샘터 위 300m","lat":38.15252,"lng":128.411329,"loc":"02-14","elev":640,"status":"ok"},{"id":35,"type":"🪧 다목적위치표지판","name":"03-01 나한봉","lat":38.154916,"lng":128.438841,"loc":"03-01","elev":1279,"status":"ok"},{"id":36,"type":"🪧 다목적위치표지판","name":"03-02 제3쉼터, 큰바위정상아래100m","lat":38.153187,"lng":128.441108,"loc":"03-02","elev":1201,"status":"ok"},{"id":37,"type":"🪧 다목적위치표지판","name":"03-03 제4쉼지나서 아래100m","lat":38.150306,"lng":128.443895,"loc":"03-03","elev":1203,"status":"ok"},{"id":38,"type":"🪧 다목적위치표지판","name":"03-04 1275고지 아래100m","lat":38.14833,"lng":128.450044,"loc":"03-04","elev":1217,"status":"ok"},{"id":39,"type":"🪧 다목적위치표지판","name":"03-05 샘터입구 위 200m","lat":38.146088,"lng":128.453457,"loc":"03-05","elev":1105,"status":"ok"},{"id":40,"type":"🪧 다목적위치표지판","name":"03-06 강남대 동판","lat":38.142938,"lng":128.454629,"loc":"03-06","elev":1155,"status":"ok"},{"id":41,"type":"🪧 다목적위치표지판","name":"03-07 신선대 아래 500m","lat":38.140757,"lng":128.45799,"loc":"03-07","elev":1129,"status":"ok"},{"id":42,"type":"🪧 다목적위치표지판","name":"03-08 신선대","lat":38.13874,"lng":128.461976,"loc":"03-08","elev":1214,"status":"ok"},{"id":43,"type":"🪧 다목적위치표지판","name":"03-09 무너미정상아래 400m","lat":38.135323,"lng":128.463904,"loc":"03-09","elev":1094,"status":"ok"},{"id":44,"type":"🪧 다목적위치표지판","name":"04-01 안양암","lat":38.177708,"lng":128.483462,"loc":"04-01","elev":239,"status":"ok"},{"id":45,"type":"🪧 다목적위치표지판","name":"04-02 첫교량 끝","lat":38.180858,"lng":128.479667,"loc":"04-02","elev":276,"status":"ok"},{"id":46,"type":"🪧 다목적위치표지판","name":"04-03 가동 휴게소 화장실","lat":38.183441,"lng":128.476513,"loc":"04-03","elev":306,"status":"ok"},{"id":47,"type":"🪧 다목적위치표지판","name":"04-04 전망대","lat":38.187867,"lng":128.475315,"loc":"04-04","elev":388,"status":"ok"},{"id":48,"type":"🪧 다목적위치표지판","name":"04-05 울산바위 유래간판","lat":38.190873,"lng":128.473491,"loc":"04-05","elev":485,"status":"ok"},{"id":49,"type":"🪧 다목적위치표지판","name":"04-06 매점터,철계단 시점","lat":38.20505556,"lng":128.79797222,"loc":"04-06","elev":585,"status":"ok"},{"id":50,"type":"🪧 다목적위치표지판","name":"05-01 가동 휴게소 아래 100m","lat":38.170065,"lng":128.495219,"loc":"05-01","elev":201,"status":"ok"},{"id":51,"type":"🪧 다목적위치표지판","name":"05-02 나동 휴게소 아래 200m","lat":38.168687,"lng":128.500664,"loc":"05-02","elev":179,"status":"ok"},{"id":52,"type":"🪧 다목적위치표지판","name":"05-03 자살탕","lat":38.165785,"lng":128.501889,"loc":"05-03","elev":247,"status":"ok"},{"id":53,"type":"🪧 다목적위치표지판","name":"05-04 비룡폭포","lat":38.162964,"lng":128.502201,"loc":"05-04","elev":281,"status":"ok"},{"id":54,"type":"🪧 다목적위치표지판","name":"06-01 독주골 갈림길 위 250m","lat":38.087797,"lng":128.448537,"loc":"06-01","elev":480,"status":"ok"},{"id":55,"type":"🪧 다목적위치표지판","name":"06-02 돌계단 끝","lat":38.092245,"lng":128.450126,"loc":"06-02","elev":690,"status":"ok"},{"id":56,"type":"🪧 다목적위치표지판","name":"06-03 제1쉼터 위 200m","lat":38.096467,"lng":128.451558,"loc":"06-03","elev":859,"status":"ok"},{"id":57,"type":"🪧 다목적위치표지판","name":"06-04 끝청갈림길 위 300m","lat":38.098362,"lng":128.454893,"loc":"06-04","elev":903,"status":"ok"},{"id":58,"type":"🪧 다목적위치표지판","name":"06-05 설악폭포","lat":38.103345,"lng":128.456638,"loc":"06-05","elev":999,"status":"ok"},{"id":59,"type":"🪧 다목적위치표지판","name":"06-06 물터위 계단 끝","lat":38.105879,"lng":128.459868,"loc":"06-06","elev":1113,"status":"ok"},{"id":60,"type":"🪧 다목적위치표지판","name":"06-07 제2쉼터 아래 200m","lat":38.108556,"lng":128.459998,"loc":"06-07","elev":1256,"status":"ok"},{"id":61,"type":"🪧 다목적위치표지판","name":"06-08 능선끝","lat":38.113456,"lng":128.460649,"loc":"06-08","elev":1492,"status":"ok"},{"id":62,"type":"🪧 다목적위치표지판","name":"06-09 구대청대피소 아래 420m","lat":38.115969,"lng":128.46315,"loc":"06-09","elev":1573,"status":"ok"},{"id":63,"type":"🪧 다목적위치표지판","name":"07-01 매표소 시발 0.5㎞ 지점","lat":38.077336,"lng":128.442598,"loc":"07-01","elev":355,"status":"ok"},{"id":64,"type":"🪧 다목적위치표지판","name":"07-02 오색석사 아래 200m","lat":38.076182,"lng":128.439941,"loc":"07-02","elev":371,"status":"ok"},{"id":65,"type":"🪧 다목적위치표지판","name":"07-03 독주암, 제2약수터 아래 200m","lat":38.078343,"lng":128.437413,"loc":"07-03","elev":385,"status":"ok"},{"id":66,"type":"🪧 다목적위치표지판","name":"07-04 선녀탕 위100m","lat":38.080587,"lng":128.43512,"loc":"07-04","elev":419,"status":"ok"},{"id":67,"type":"🪧 다목적위치표지판","name":"07-05 매표소 시발 2.5㎞ 지점","lat":38.082892,"lng":128.432072,"loc":"07-05","elev":452,"status":"ok"},{"id":68,"type":"🪧 다목적위치표지판","name":"07-06 12폭포 갈림길","lat":38.083242,"lng":128.430483,"loc":"07-06","elev":462,"status":"ok"},{"id":69,"type":"🪧 다목적위치표지판","name":"08-01 12폭포 아래 500m","lat":38.081944,"lng":128.427122,"loc":"08-01","elev":537,"status":"ok"},{"id":70,"type":"🪧 다목적위치표지판","name":"08-02 12폭포","lat":38.07937,"lng":128.42608,"loc":"08-02","elev":602,"status":"ok"},{"id":71,"type":"🪧 다목적위치표지판","name":"08-03 무명폭포 하향 200m","lat":38.08044,"lng":128.423813,"loc":"08-03","elev":620,"status":"ok"},{"id":72,"type":"🪧 다목적위치표지판","name":"08-04 등선폭포","lat":38.080789,"lng":128.419306,"loc":"08-04","elev":769,"status":"ok"},{"id":73,"type":"🪧 다목적위치표지판","name":"08-05 금강문 시발 2.5km(등선대 정상)","lat":38.083671,"lng":128.417325,"loc":"08-05","elev":956,"status":"ok"},{"id":74,"type":"🪧 다목적위치표지판","name":"08-06 칠형제봉 입구","lat":38.086039,"lng":128.416179,"loc":"08-06","elev":839,"status":"ok"},{"id":75,"type":"🪧 다목적위치표지판","name":"08-07 흘림골매표소 상향 제1교량","lat":38.087871,"lng":128.417377,"loc":"08-07","elev":772,"status":"ok"},{"id":76,"type":"🪧 다목적위치표지판","name":"09-01 첫고개 위 100m","lat":38.100203,"lng":128.409455,"loc":"09-01","elev":1085,"status":"ok"},{"id":77,"type":"🪧 다목적위치표지판","name":"09-02 첫고개 위 100m","lat":38.10358,"lng":128.41206,"loc":"09-02","elev":1299,"status":"ok"},{"id":78,"type":"🪧 다목적위치표지판","name":"09-03 상투바 아래 100m","lat":38.108377,"lng":128.410679,"loc":"09-03","elev":1292,"status":"ok"},{"id":79,"type":"🪧 다목적위치표지판","name":"09-04 샘터","lat":38.110374,"lng":128.410132,"loc":"09-04","elev":1268,"status":"ok"},{"id":80,"type":"🪧 다목적위치표지판","name":"09-05 왕주목 아래 100m","lat":38.112063,"lng":128.410236,"loc":"09-05","elev":1353,"status":"ok"},{"id":81,"type":"🪧 다목적위치표지판","name":"09-06 왕주목 위 400m","lat":38.111282,"lng":128.416645,"loc":"09-06","elev":1324,"status":"ok"},{"id":82,"type":"🪧 다목적위치표지판","name":"09-07 1379봉 아래 100m","lat":38.110274,"lng":128.421674,"loc":"09-07","elev":1391,"status":"ok"},{"id":83,"type":"🪧 다목적위치표지판","name":"09-08 헬기장, 제2전망대","lat":38.109432,"lng":128.427041,"loc":"09-08","elev":1450,"status":"ok"},{"id":84,"type":"🪧 다목적위치표지판","name":"09-09 쉼터아래 500m","lat":38.110071,"lng":128.43061,"loc":"09-09","elev":1421,"status":"ok"},{"id":85,"type":"🪧 다목적위치표지판","name":"09-10 1쉼터","lat":38.112214,"lng":128.437488,"loc":"09-10","elev":1461,"status":"ok"},{"id":86,"type":"🪧 다목적위치표지판","name":"09-11 독주골","lat":38.115139,"lng":128.441708,"loc":"09-11","elev":1452,"status":"ok"},{"id":87,"type":"🪧 다목적위치표지판","name":"09-12 끝청아래 400m","lat":38.11617,"lng":128.448039,"loc":"09-12","elev":1496,"status":"ok"},{"id":88,"type":"🪧 다목적위치표지판","name":"09-13 끝청 위 100m","lat":38.116624,"lng":128.451661,"loc":"09-13","elev":1598,"status":"ok"},{"id":89,"type":"🪧 다목적위치표지판","name":"09-14 중청 정상 아래 300m","lat":38.119302,"lng":128.45463,"loc":"09-14","elev":1596,"status":"ok"},{"id":90,"type":"🪧 다목적위치표지판","name":"10-01 셔틀버스 종점 위 500m","lat":38.175507,"lng":128.372925,"loc":"10-01","elev":452,"status":"ok"},{"id":91,"type":"🪧 다목적위치표지판","name":"10-02 셔틀버스 종점 시발1.0㎞ 지점","lat":38.170978,"lng":128.372351,"loc":"10-02","elev":471,"status":"ok"},{"id":92,"type":"🪧 다목적위치표지판","name":"10-03 셔틀버스 종점 시발1.5㎞ 지점","lat":38.168363,"lng":128.371283,"loc":"10-03","elev":489,"status":"ok"},{"id":93,"type":"🪧 다목적위치표지판","name":"10-04 셔틀버스 종점 시발2.0㎞ 지점","lat":38.169578,"lng":128.375608,"loc":"10-04","elev":519,"status":"ok"},{"id":94,"type":"🪧 다목적위치표지판","name":"10-05 셔틀버스 종점 시발2.5㎞ 지점","lat":38.167891,"lng":128.37936,"loc":"10-05","elev":489,"status":"ok"},{"id":95,"type":"🪧 다목적위치표지판","name":"10-06 대피소 아래 500m","lat":38.164905,"lng":128.376207,"loc":"10-06","elev":494,"status":"ok"},{"id":96,"type":"🪧 다목적위치표지판","name":"10-07 백담대피소","lat":38.160108,"lng":128.374905,"loc":"10-07","elev":502,"status":"ok"},{"id":97,"type":"🪧 다목적위치표지판","name":"10-08 길골 아래 200m","lat":38.157452,"lng":128.375296,"loc":"10-08","elev":504,"status":"ok"},{"id":98,"type":"🪧 다목적위치표지판","name":"10-09 길골 위 300m","lat":38.15628,"lng":128.380897,"loc":"10-09","elev":517,"status":"ok"},{"id":99,"type":"🪧 다목적위치표지판","name":"10-10 셔틀버스 종점 시발5.0㎞ 지점","lat":38.156816,"lng":128.386082,"loc":"10-10","elev":492,"status":"ok"},{"id":100,"type":"🪧 다목적위치표지판","name":"10-11 셔틀버스 종점 시발5.5㎞ 지점","lat":38.153276,"lng":128.389078,"loc":"10-11","elev":505,"status":"ok"},{"id":101,"type":"🪧 다목적위치표지판","name":"10-12 셔틀버스 종점 시발6.0㎞ 지점","lat":38.152989,"lng":128.394159,"loc":"10-12","elev":566,"status":"ok"},{"id":102,"type":"🪧 다목적위치표지판","name":"10-13 영시암 아래 500m","lat":38.152579,"lng":128.399891,"loc":"10-13","elev":554,"status":"ok"},{"id":103,"type":"🪧 다목적위치표지판","name":"10-14 영시암","lat":38.153527,"lng":128.405154,"loc":"10-14","elev":564,"status":"ok"},{"id":104,"type":"🪧 다목적위치표지판","name":"10-15 영시암 위 500m","lat":38.150234,"lng":128.408359,"loc":"10-15","elev":582,"status":"ok"},{"id":105,"type":"🪧 다목적위치표지판","name":"10-16 수렴동대피소 밑 200m","lat":38.146899,"lng":128.411954,"loc":"10-16","elev":598,"status":"ok"},{"id":106,"type":"🪧 다목적위치표지판","name":"10-17 수렴동대피소 위 300m","lat":38.145418,"lng":128.415471,"loc":"10-17","elev":583,"status":"ok"},{"id":107,"type":"🪧 다목적위치표지판","name":"10-18 셔틀버스 종점 시발 9.0㎞ 지점","lat":38.143215,"lng":128.415628,"loc":"10-18","elev":595,"status":"ok"},{"id":108,"type":"🪧 다목적위치표지판","name":"10-19 만수담 아래 500m","lat":38.14128,"lng":128.415185,"loc":"10-19","elev":605,"status":"ok"},{"id":109,"type":"🪧 다목적위치표지판","name":"10-20 만수담","lat":38.138748,"lng":128.416747,"loc":"10-20","elev":639,"status":"ok"},{"id":110,"type":"🪧 다목적위치표지판","name":"10-21 백운동 아래 400m","lat":38.136607,"lng":128.419145,"loc":"10-21","elev":688,"status":"ok"},{"id":111,"type":"🪧 다목적위치표지판","name":"10-22 백운동 위 100m","lat":38.135785,"lng":128.423366,"loc":"10-22","elev":715,"status":"ok"},{"id":112,"type":"🪧 다목적위치표지판","name":"10-23 관음폭포 아래 400m","lat":38.133644,"lng":128.425945,"loc":"10-23","elev":756,"status":"ok"},{"id":113,"type":"🪧 다목적위치표지판","name":"10-24 관음폭포 위 100m","lat":38.132595,"lng":128.430374,"loc":"10-24","elev":832,"status":"ok"},{"id":114,"type":"🪧 다목적위치표지판","name":"10-25 쌍폭","lat":38.131196,"lng":128.433501,"loc":"10-25","elev":901,"status":"ok"},{"id":115,"type":"🪧 다목적위치표지판","name":"10-26 쌍폭 위 500m","lat":38.130203,"lng":128.437931,"loc":"10-26","elev":974,"status":"ok"},{"id":116,"type":"🪧 다목적위치표지판","name":"10-27 사자바위 아래 100m","lat":38.128132,"lng":128.444052,"loc":"10-27","elev":1141,"status":"ok"},{"id":117,"type":"🪧 다목적위치표지판","name":"10-28 봉정암 아래 100m","lat":38.128647,"lng":128.44671,"loc":"10-28","elev":1232,"status":"ok"},{"id":118,"type":"🪧 다목적위치표지판","name":"10-29 소청대피소 아래 300m","lat":38.127557,"lng":128.450982,"loc":"10-29","elev":1387,"status":"ok"},{"id":119,"type":"🪧 다목적위치표지판","name":"10-30 소청대피소 위 200m","lat":38.12611111,"lng":128.45611111,"loc":"10-30","elev":1534,"status":"ok"},{"id":120,"type":"🪧 다목적위치표지판","name":"11-01 사중폭포 위 200m","lat":38.121889,"lng":128.344708,"loc":"11-01","elev":584,"status":"ok"},{"id":121,"type":"🪧 다목적위치표지판","name":"11-02 사중폭포 위 100m","lat":38.125471,"lng":128.343197,"loc":"11-02","elev":785,"status":"ok"},{"id":122,"type":"🪧 다목적위치표지판","name":"11-03 마지막 물터 아래 300m","lat":38.129012,"lng":128.34192,"loc":"11-03","elev":788,"status":"ok"},{"id":123,"type":"🪧 다목적위치표지판","name":"11-04 마지막물터 위 200m","lat":38.131772,"lng":128.344916,"loc":"11-04","elev":890,"status":"ok"},{"id":124,"type":"🪧 다목적위치표지판","name":"11-05 대승령 아래 200m","lat":38.135334,"lng":128.346584,"loc":"11-05","elev":1041,"status":"ok"},{"id":125,"type":"🪧 다목적위치표지판","name":"11-06 대승령→ 남교리 300m","lat":38.138627,"lng":128.342389,"loc":"11-06","elev":1242,"status":"ok"},{"id":126,"type":"🪧 다목적위치표지판","name":"11-07 안산갈림길→ 남교리 300m","lat":38.139779,"lng":128.338168,"loc":"11-07","elev":1353,"status":"ok"},{"id":127,"type":"🪧 다목적위치표지판","name":"11-08 분소 시발 4.0㎞ 지점(능선끝 쉼터)","lat":38.14262,"lng":128.338272,"loc":"11-08","elev":1335,"status":"ok"},{"id":128,"type":"🪧 다목적위치표지판","name":"11-09 마지막물터→ 대승령 300m","lat":38.143772,"lng":128.334077,"loc":"11-09","elev":1212,"status":"ok"},{"id":129,"type":"🪧 다목적위치표지판","name":"11-10 마지막물터→ 남교리 200m","lat":38.147519,"lng":128.332045,"loc":"11-10","elev":1102,"status":"ok"},{"id":130,"type":"🪧 다목적위치표지판","name":"11-11 주목→ 남교리 100m","lat":38.151637,"lng":128.332957,"loc":"11-11","elev":1021,"status":"ok"},{"id":131,"type":"🪧 다목적위치표지판","name":"11-12 감투바위","lat":38.155404,"lng":128.331654,"loc":"11-12","elev":975,"status":"ok"},{"id":132,"type":"🪧 다목적위치표지판","name":"11-13 두문폭포→ 대승령 200m","lat":38.157977,"lng":128.327798,"loc":"11-13","elev":863,"status":"ok"},{"id":133,"type":"🪧 다목적위치표지판","name":"11-14 복숭아탕→ 대승령 200m","lat":38.159973,"lng":128.323186,"loc":"11-14","elev":793,"status":"ok"},{"id":134,"type":"🪧 다목적위치표지판","name":"11-15 무명폭포","lat":38.16166,"lng":128.321206,"loc":"11-15","elev":715,"status":"ok"},{"id":135,"type":"🪧 다목적위치표지판","name":"11-16 제6교량→ 대승령 100m","lat":38.164666,"lng":128.318731,"loc":"11-16","elev":678,"status":"ok"},{"id":136,"type":"🪧 다목적위치표지판","name":"11-17 너래반석→ 남교리 200m","lat":38.171418,"lng":128.314666,"loc":"11-17","elev":540,"status":"ok"},{"id":137,"type":"🪧 다목적위치표지판","name":"11-18 응봉폭포","lat":38.174361,"lng":128.312035,"loc":"11-18","elev":476,"status":"ok"},{"id":138,"type":"🪧 다목적위치표지판","name":"11-19 제5교량","lat":38.17541,"lng":128.307736,"loc":"11-19","elev":430,"status":"ok"},{"id":139,"type":"🪧 다목적위치표지판","name":"11-20 4교량→ 남교리 200m","lat":38.174627,"lng":128.305625,"loc":"11-20","elev":419,"status":"ok"},{"id":140,"type":"🪧 다목적위치표지판","name":"11-21 추모비→ 남교리 100m","lat":38.175862,"lng":128.303593,"loc":"11-21","elev":368,"status":"ok"},{"id":141,"type":"🪧 다목적위치표지판","name":"11-22 남교리매표소→ 대승령 300m","lat":38.179465,"lng":128.301717,"loc":"11-22","elev":341,"status":"ok"},{"id":142,"type":"🪧 다목적위치표지판","name":"12-09 대승령 위100m","lat":38.136837,"lng":128.347365,"loc":"12-09","elev":1235,"status":"ok"},{"id":143,"type":"🪧 다목적위치표지판","name":"12-10 백담대피소 시발 5.0㎞ 지점","lat":38.135458,"lng":128.350726,"loc":"12-10","elev":1198,"status":"ok"},{"id":144,"type":"🪧 다목적위치표지판","name":"12-11 백담대피소 시발 5.5㎞ 지점","lat":38.135027,"lng":128.356094,"loc":"12-11","elev":1304,"status":"ok"},{"id":145,"type":"🪧 다목적위치표지판","name":"12-12 백담대피소 시발 6.0㎞ 지점","lat":38.131322,"lng":128.357709,"loc":"12-12","elev":1269,"status":"ok"},{"id":146,"type":"🪧 다목적위치표지판","name":"12-13 백담대피소 시발 6.5㎞ 지점","lat":38.128851,"lng":128.359585,"loc":"12-13","elev":1274,"status":"ok"},{"id":147,"type":"🪧 다목적위치표지판","name":"12-14 1408고지","lat":38.128235,"lng":128.364041,"loc":"12-14","elev":1233,"status":"ok"},{"id":148,"type":"🪧 다목적위치표지판","name":"12-15 백담대피소 시발 7.5㎞ 지점","lat":38.124532,"lng":128.377693,"loc":"12-15","elev":1339,"status":"ok"},{"id":149,"type":"🪧 다목적위치표지판","name":"12-16 백담대피소 시발 8.0㎞ 지점","lat":38.123467,"lng":128.382941,"loc":"12-16","elev":1389,"status":"ok"},{"id":150,"type":"🪧 다목적위치표지판","name":"12-17 백담대피소 시발 8.5㎞ 지점","lat":38.123319,"lng":128.387724,"loc":"12-17","elev":1471,"status":"ok"},{"id":151,"type":"🪧 다목적위치표지판","name":"12-18 백담대피소 시발 9.0㎞ 지점","lat":38.124021,"lng":128.393508,"loc":"12-18","elev":1314,"status":"ok"},{"id":152,"type":"🪧 다목적위치표지판","name":"12-19 백담대피소 시발 9.5㎞ 지점","lat":38.122416,"lng":128.397052,"loc":"12-19","elev":1445,"status":"ok"},{"id":153,"type":"🪧 다목적위치표지판","name":"12-20 백담대피소 시발 10.0㎞ 지점","lat":38.119884,"lng":128.398954,"loc":"12-20","elev":1492,"status":"ok"},{"id":154,"type":"🪧 다목적위치표지판","name":"12-21 백담대피소 시발 10.5㎞ 지점","lat":38.116487,"lng":128.401664,"loc":"12-21","elev":1384,"status":"ok"},{"id":155,"type":"🪧 다목적위치표지판","name":"12-22 백담대피소 시발 11.0㎞ 지점","lat":38.114141,"lng":128.406223,"loc":"12-22","elev":1278,"status":"ok"},{"id":156,"type":"🪧 다목적위치표지판","name":"13-01 오세암 시발 0.5km 지점","lat":38.148634,"lng":128.43165,"loc":"13-01","elev":865,"status":"ok"},{"id":157,"type":"🪧 다목적위치표지판","name":"13-02 오세암 시발 1.0km 지점","lat":38.146721,"lng":128.435845,"loc":"13-02","elev":891,"status":"ok"},{"id":158,"type":"🪧 다목적위치표지판","name":"13-03 오세암 시발 1.5km 지점","lat":38.145281,"lng":128.439232,"loc":"13-03","elev":919,"status":"ok"},{"id":159,"type":"🪧 다목적위치표지판","name":"13-04 고갯마루 쉼터","lat":38.143017,"lng":128.444416,"loc":"13-04","elev":970,"status":"ok"},{"id":160,"type":"🪧 다목적위치표지판","name":"13-05 가야동계곡 사거리","lat":38.141041,"lng":128.445433,"loc":"13-05","elev":858,"status":"ok"},{"id":161,"type":"🪧 다목적위치표지판","name":"13-06 오세암 시발 3.0km 지점","lat":38.137665,"lng":128.445745,"loc":"13-06","elev":936,"status":"ok"},{"id":162,"type":"🪧 다목적위치표지판","name":"13-07 오세암 시발 3.5km 지점","lat":38.132538,"lng":128.446319,"loc":"13-07","elev":1045,"status":"ok"},{"id":163,"type":"🪧 다목적위치표지판","name":"14-01 곰배골지킴터 상단 400m","lat":38.0190743,"lng":128.40738772,"loc":"14-01","elev":632,"status":"ok"},{"id":164,"type":"🪧 다목적위치표지판","name":"14-02 곰배골지킴터 상단 700m","lat":38.01985338,"lng":128.41045271,"loc":"14-02","elev":652,"status":"ok"},{"id":165,"type":"🪧 다목적위치표지판","name":"14-03 곰배골지킴터 상단 1.2km","lat":38.0206789,"lng":128.4155566,"loc":"14-03","elev":720,"status":"ok"},{"id":166,"type":"🪧 다목적위치표지판","name":"14-04 곰배골지킴터 상단 1.7km","lat":38.02159347,"lng":128.42066956,"loc":"14-04","elev":785,"status":"ok"},{"id":167,"type":"🪧 다목적위치표지판","name":"14-05 곰배골지킴터 상단 2.2km","lat":38.02233403,"lng":128.42556115,"loc":"14-05","elev":856,"status":"ok"},{"id":168,"type":"🪧 다목적위치표지판","name":"14-06 곰배골지킴터 상단 2.8km","lat":38.02326768,"lng":128.43052776,"loc":"14-06","elev":940,"status":"ok"},{"id":169,"type":"🪧 다목적위치표지판","name":"14-07 곰배골지킴터 상단 3.2km","lat":38.02692511,"lng":128.43100905,"loc":"14-07","elev":1089,"status":"ok"},{"id":170,"type":"🪧 다목적위치표지판","name":"08-08","lat":38.088614,"lng":128.421311,"loc":"08-08","elev":0,"status":"ok"},{"id":171,"type":"🪧 다목적위치표지판","name":"12-01 흑선동계곡비탐","lat":38.153952,"lng":128.375739,"loc":"12-01","elev":0,"status":"ok"},{"id":172,"type":"🪧 다목적위치표지판","name":"12-02 흑선동계곡비탐","lat":38.153951,"lng":128.372482,"loc":"12-02","elev":0,"status":"ok"},{"id":173,"type":"🪧 다목적위치표지판","name":"12-03 흑선동계곡비탐","lat":38.15045,"lng":128.368105,"loc":"12-03","elev":0,"status":"ok"},{"id":174,"type":"🪧 다목적위치표지판","name":"12-05 흑선동계곡비탐","lat":38.148019,"lng":128.359142,"loc":"12-05","elev":0,"status":"ok"},{"id":175,"type":"🪧 다목적위치표지판","name":"12-06 흑선동계곡비탐","lat":38.145115,"lng":128.355129,"loc":"12-06","elev":0,"status":"ok"},{"id":176,"type":"🪧 다목적위치표지판","name":"12-07 흑선동계곡비탐","lat":38.142191,"lng":128.352446,"loc":"12-07","elev":0,"status":"ok"},{"id":177,"type":"🪧 다목적위치표지판","name":"12-08 흑선동계곡비탐","lat":38.139514,"lng":128.349736,"loc":"12-08","elev":0,"status":"ok"}];
  var _maxId=_facs.reduce(function(mx,f){return Math.max(mx,Number(f.id)||0);},0);
  var _seeded=_seed.map(function(s,i){return Object.assign({},s,{id:_maxId+1+i});});
  DB.s('facilities',_facs.concat(_seeded));
}
function initDB(){
  // 더미 직원 데이터 정리
  const _existStaff=DB.g('staff');
  if(!_existStaff||(_existStaff.length&&['손경완','김택찬','염원종','김종식','나진영','양지석','윤태종'].some(n=>_existStaff.some(s=>s.name===n)))){
    DB.s('staff',[]);
  }
  if(!DB.g('catFac'))     DB.s('catFac',['🪧 다목적위치표지판','📍 장소','🛤️ 데크/계단','🌉 교량','🏠 대피소','🛡️ 안전난간','🪵 목재계단','🚿 계곡시설']);
  // 카테고리 마이그레이션: 위치표지판 제거, 장소 추가
  (function(){var c=DB.g('catFac');if(!c)return;var c2=c.filter(function(x){return x!=='🪧 위치표지판';});if(!c2.includes('📍 장소'))c2.splice(1,0,'📍 장소');if(c2.length!==c.length||!c.includes('📍 장소'))DB.s('catFac',c2);})();
  // 이모지 없는 카테고리명 마이그레이션 (catFac + facilities + catFacMeta)
  (function(){var map={'분소':'🏠 분소','암빙벽':'🧗 암빙벽'};var c=DB.g('catFac');if(c){var changed=false;var c2=c.map(function(x){return map[x]?(changed=true,map[x]):x;});if(changed)DB.s('catFac',c2);}var facs=DB.g('facilities');if(facs){var fc=false;var f2=facs.map(function(f){if(map[f.type]){fc=true;return Object.assign({},f,{type:map[f.type]});}return f;});if(fc)DB.s('facilities',f2);}var m=DB.g('catFacMeta')||{};Object.keys(map).forEach(function(old){if(m[old]){m[map[old]]=m[old];delete m[old];}});DB.s('catFacMeta',m);})();
  // 탐방지원센터 분리 마이그레이션
  (function(){
    var c=DB.g('catFac')||[];var meta=DB.g('catFacMeta')||{};var changed=false;
    // 1) 결합된 카테고리명(분소+탐방지원센터) 처리: 분소만 남기고 탐방지원센터 분리
    var c2=[];c.forEach(function(x){
      if(x.includes('탐방지원센터')&&x.includes('분소')){
        var boso=x.replace(/\/?탐방지원센터\/?/g,'').trim()||'🏠 분소';
        if(!c2.some(function(v){return v===boso;}))c2.push(boso);
        changed=true;
      } else {c2.push(x);}
    });
    // 2) 탐방지원센터 단독 카테고리 없으면 추가
    if(!c2.some(function(x){return x.includes('탐방지원센터');})){c2.push('🛖 탐방지원센터');changed=true;}
    // 3) 이모지 없는 '탐방지원센터' → '🛖 탐방지원센터'
    c2=c2.map(function(x){if(x==='탐방지원센터'){changed=true;return '🛖 탐방지원센터';}return x;});
    if(changed)DB.s('catFac',c2);
    // 4) facilities type도 동일하게 수정
    var facs=DB.g('facilities');if(facs){var fc=false;var f2=facs.map(function(f){
      if(f.type&&f.type.includes('탐방지원센터')&&f.type.includes('분소')){fc=true;return Object.assign({},f,{type:'🛖 탐방지원센터'});}
      if(f.type==='탐방지원센터'){fc=true;return Object.assign({},f,{type:'🛖 탐방지원센터'});}
      return f;});if(fc)DB.s('facilities',f2);}
    // 5) catFacMeta 키 이전
    if(meta['탐방지원센터']){meta['🛖 탐방지원센터']=meta['탐방지원센터'];delete meta['탐방지원센터'];DB.s('catFacMeta',meta);}
  })();
  // catFacMeta 초기화 (재난지도 표시 여부 + 관리자 전용 여부)
  (function(){var m=DB.g('catFacMeta')||{};var changed=false;var def={'🪧 다목적위치표지판':{rescue:true,adminOnly:false},'📍 장소':{rescue:true,adminOnly:true},'🏠 대피소':{rescue:true,adminOnly:false}};Object.keys(def).forEach(function(k){if(!m[k]){m[k]=def[k];changed=true;}});if(changed)DB.s('catFacMeta',m);})();
  // 사찰 카테고리 마이그레이션: catFac 목록에서 암/사로 끝나는 항목 제거하고 🛕 사찰로 통합 (1회성)
  (function(){
    var TEMPLE='🛕 사찰';
    var isTemple=function(s){var t=s.replace(/^[\s\S]*\s/,'');return /암$|사$/.test(t);};
    var c=DB.g('catFac')||[];var cm=false;
    // 사찰 항목 없으면 추가
    if(!c.includes(TEMPLE)){c.push(TEMPLE);cm=true;}
    // 암/사로 끝나는 catFac 항목 제거 (카테고리 목록만 정리, 시설물 타입은 건드리지 않음)
    var c2=c.filter(function(x){if(x===TEMPLE)return true;var name=x.replace(/^[^\s]+\s/,'');if(isTemple(name)){cm=true;return false;}return true;});
    if(cm)DB.s('catFac',c2);
  })();
  // 다목적위치표지판 시드: 표지판이 하나도 없으면 1회 주입 (null·빈배열·전체삭제 모두 복원)
  if(!_fdb||_facSeedReady)_ensureSignSeed(); // 시드 레이스 방지 + 중복 시드 IIFE 제거(일원화)
  if(!DB.g('rescues'))    DB.s('rescues',[]);
  if(!DB.g('hazards'))    DB.s('hazards',[]);
  if(!DB.g('history'))    DB.s('history',[]);
  if(!DB.g('alertOps'))   DB.s('alertOps',[]);
  if(!DB.g('notis'))         DB.s('notis',[]);
  if(!DB.g('notiSetting'))   DB.s('notiSetting',{});
  _ensureNotiDefaults();
  if(!DB.g('currentUser'))   DB.s('currentUser',{name:'',dept:'',rank:'',kakao:null});
}

// ══════════════════════════════════════════
// 유틸
// ══════════════════════════════════════════
const pad=n=>String(n).padStart(2,'0');
// 생년월일(YYYY...) → 만 나이(연도 기준). 값 없으면 '' 반환
function _ageFromBirth(b){if(!b)return '';const y=parseInt(String(b).slice(0,4));const cy=new Date().getFullYear();if(isNaN(y)||y<1900||y>cy)return '';return cy-y;}
// 생년월일 텍스트 입력 자동 포매팅: 숫자만 입력 → YYYY-MM-DD 삽입
function _fmtBirth(el){
  const c=el.selectionStart;
  let v=el.value.replace(/\D/g,'').slice(0,8);
  let fmt='';
  if(v.length>4)fmt=v.slice(0,4)+'-'+v.slice(4);else fmt=v;
  if(v.length>6)fmt=v.slice(0,4)+'-'+v.slice(4,6)+'-'+v.slice(6);
  el.value=fmt;
  try{el.setSelectionRange(c+(fmt.length-el.value.length+1>0?1:0),c+(fmt.length-el.value.length+1>0?1:0));}catch(e){}
}
function now(){const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+' '+pad(d.getHours())+':'+pad(d.getMinutes());}
function _debounce(fn,ms){let t;return function(...a){clearTimeout(t);t=setTimeout(()=>fn.apply(this,a),ms);};}
// '2026-06-12 14:30' → '2시간 13분 경과' (골든타임 표시용)
function _elapsedStr(dateStr){
  try{
    const t=new Date(String(dateStr).replace(' ','T'));
    let m=Math.floor((Date.now()-t.getTime())/60000);
    if(isNaN(m)||m<0)return'';
    const d=Math.floor(m/1440);m-=d*1440;const h=Math.floor(m/60);m-=h*60;
    return(d?d+'일 ':'')+(h?h+'시간 ':'')+m+'분 경과';
  }catch(e){return'';}
}
function today(){return now().slice(0,10);}
// 진행중 경과시간 라이브 갱신: '.js-elapsed[data-d]' 요소의 텍스트를 주기적으로 다시 계산.
// (경과시간은 분 단위라 30초 간격이면 충분 — 새로고침 없이 자동으로 시간이 올라감)
function _tickElapsed(){
  try{
    document.querySelectorAll('.js-elapsed[data-d]').forEach(function(el){
      var v=_elapsedStr(el.getAttribute('data-d'));
      if(v)el.textContent='⏱ '+v;
    });
  }catch(e){}
}
if(!window._elapsedTimer)window._elapsedTimer=setInterval(_tickElapsed,30000);
function nowDT(){
  const d=new Date();
  return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes());
}
var _toastTimer=null;
function toast(m,dur){const t=document.getElementById('toast');t.textContent=m;t.classList.add('on');clearTimeout(_toastTimer);
  // 중요 메시지(실패·경고·오류)는 자동으로 4초간 표시 — 놓치지 않도록
  if(dur===undefined){dur=(/실패|오류|⚠️|에러|불가|없습니다|권한/.test(String(m)))?4000:2200;}
  _toastTimer=setTimeout(()=>t.classList.remove('on'),dur);}
// 되돌리기 스낵바: 삭제 등 위험 작업 후 일정 시간 안에 취소 가능. onUndo=취소 시, onCommit=시간 경과 후 실제 확정.
let _undoTimer=null,_undoCommit=null;
function _undoToast(msg,onUndo,onCommit,dur=5000){
  const bar=document.getElementById('undoBar');if(!bar){onCommit&&onCommit();return;}
  // 직전 대기중인 확정이 있으면 먼저 실행(중첩 방지)
  if(_undoCommit){try{_undoCommit();}catch(e){}_undoCommit=null;}
  clearTimeout(_undoTimer);
  document.getElementById('undoBarMsg').textContent=msg;
  bar.style.display='flex';
  _undoCommit=onCommit||null;
  const close=()=>{bar.style.display='none';};
  document.getElementById('undoBarBtn').onclick=()=>{
    clearTimeout(_undoTimer);_undoCommit=null;close();
    try{onUndo&&onUndo();}catch(e){}
  };
  _undoTimer=setTimeout(()=>{close();_undoCommit=null;try{onCommit&&onCommit();}catch(e){}},dur);
}
function closeDB(){document.querySelectorAll('.dbcard').forEach(c=>c.classList.remove('on'));}
function closeM(id){document.getElementById(id).classList.remove('on');}
// 모달 배경(backdrop) 클릭 시 닫기
document.querySelectorAll('.modal').forEach(m=>{
  if(m.id==='modalUser')return; // 필수입력 검증 때문에 별도처리
  m.addEventListener('click',function(e){if(e.target===this)closeM(this.id);});
});
// ── 오프라인 사진 업로드 큐 (IndexedDB 영속 — 앱 재시작에도 유지) ──
const _offlinePhotoQueue=[];
function _photoIDB(){
  return new Promise((ok,no)=>{
    const rq=indexedDB.open('seorak_photoQ',1);
    rq.onupgradeneeded=()=>{rq.result.createObjectStore('q',{keyPath:'id'});};
    rq.onsuccess=()=>ok(rq.result);rq.onerror=()=>no(rq.error);
  });
}
async function _photoQPut(item){
  try{const db=await _photoIDB();const tx=db.transaction('q','readwrite');tx.objectStore('q').put(item);}catch(e){}
}
async function _photoQDel(id){
  try{const db=await _photoIDB();const tx=db.transaction('q','readwrite');tx.objectStore('q').delete(id);}catch(e){}
}
async function _photoQAll(){
  try{
    const db=await _photoIDB();
    return await new Promise((ok)=>{
      const rq=db.transaction('q','readonly').objectStore('q').getAll();
      rq.onsuccess=()=>ok(rq.result||[]);rq.onerror=()=>ok([]);
    });
  }catch(e){return[];}
}
// 제출 시 호출: 업로드 대기 중(pending)인 미리보기 사진을 저장된 레코드에 연결
function _registerPendingPhoto(pid,dest){
  const it=_offlinePhotoQueue.find(x=>x.pid===pid&&!x.dest);
  if(!it)return;
  it.dest=dest;
  _photoQPut({id:it.id,pid:it.pid,file:it.file,dest});
}
// 업로드 완료된 URL을 레코드 필드에 반영
function _applyPhotoDest(dest,url){
  if(!dest)return;
  const arr=DB.g(dest.key)||[];const i=arr.findIndex(x=>x.id===dest.id);
  if(i<0)return;
  if(dest.append){
    if(!arr[i][dest.field])arr[i][dest.field]=[];
    arr[i][dest.field].push({url,time:now(),by:dest.by||''});
  }else{
    arr[i][dest.field]=url;
  }
  DB.s(dest.key,arr);
}
async function _processPhotoQueue(){
  if(!navigator.onLine||!_fst)return;
  // 메모리 큐 + IDB 복원분 합치기 (재시작 후에도 이어서 업로드)
  const idb=await _photoQAll();
  idb.forEach(d=>{if(!_offlinePhotoQueue.some(x=>x.id===d.id))_offlinePhotoQueue.push(d);});
  if(!_offlinePhotoQueue.length)return;
  toast('🌐 대기 중인 사진 '+_offlinePhotoQueue.length+'장 업로드 중...');
  const items=_offlinePhotoQueue.splice(0);
  let ok=0;
  for(const item of items){
    try{
      const url=await uploadImageToStorage(item.file,'photos/'+(item.pid||'queued'));
      if(item.dest)_applyPhotoDest(item.dest,url);
      const prev=item.pid?document.getElementById(item.pid):null;
      if(prev){prev.dataset.url=url;const img=prev.querySelector('img');if(img)img.src=url;prev.querySelector('.up-badge')?.remove();}
      _photoQDel(item.id);ok++;
    }catch(e){_offlinePhotoQueue.push(item);} // 실패 → 큐 유지
  }
  if(ok)toast('✅ 사진 '+ok+'장 업로드 완료');
}
window.addEventListener('online',()=>setTimeout(_processPhotoQueue,2000));
// ── 이미지 압축 (긴 축 1200px, 82% JPEG) ─────────
async function _compressImage(file,maxPx=1200,quality=0.82){
  if(file.size<300*1024)return file; // 300KB 이하 압축 생략
  return new Promise(resolve=>{
    const img=new Image();
    img.onload=()=>{
      URL.revokeObjectURL(img.src);
      let w=img.width,h=img.height;
      if(w<=maxPx&&h<=maxPx&&file.size<800*1024){resolve(file);return;}
      if(w>h){if(w>maxPx){h=Math.round(h*maxPx/w);w=maxPx;}}
      else{if(h>maxPx){w=Math.round(w*maxPx/h);h=maxPx;}}
      const c=document.createElement('canvas');c.width=w;c.height=h;
      c.getContext('2d').drawImage(img,0,0,w,h);
      c.toBlob(b=>resolve(b||file),'image/jpeg',quality);
    };
    img.onerror=()=>resolve(file);
    img.src=URL.createObjectURL(file);
  });
}
async function uploadImageToStorage(file,path){
  if(!_fst)throw new Error('Storage 미초기화');
  const ref=_fst.ref().child(path+'/'+Date.now()+'_'+(file.name||'photo').replace(/[^a-zA-Z0-9._-]/g,'_'));
  const snap=await ref.put(file);
  return await snap.ref.getDownloadURL();
}
// dataset.url이 'pending'이면 빈 문자열 반환
const _photoUrl=id=>{const u=document.getElementById(id)?.dataset?.url||'';return u==='pending'?'':u;};
async function prevImg(inp,pid){
  if(!inp.files||!inp.files[0])return;
  const file=inp.files[0];
  const prev=document.getElementById(pid);
  const objUrl=URL.createObjectURL(file);
  prev.innerHTML=`<img src="${objUrl}" style="opacity:.75">`;
  prev.dataset.url='';
  const compressed=await _compressImage(file);
  if(!navigator.onLine){
    prev.innerHTML=`<img src="${objUrl}"><div class="up-badge" style="font-size:10px;color:#e67e22;background:rgba(0,0,0,.75);padding:2px 6px;border-radius:4px;margin-top:3px;text-align:center;">📵 연결 시 자동 업로드</div>`;
    prev.dataset.url='pending';
    const qItem={id:Date.now()+'_'+pid,file:compressed,pid};
    _offlinePhotoQueue.push(qItem);
    _photoQPut(qItem); // 제출 전이라도 보존 (제출 시 dest 연결됨)
    return;
  }
  // 업로드 완료 전 제출되어도 사진이 유실되지 않도록 큐에 등록(제출 시 _registerPendingPhoto로 dest 연결).
  prev.dataset.url='pending';
  const qItem={id:Date.now()+'_'+pid,file:compressed,pid};
  _offlinePhotoQueue.push(qItem);
  prev.innerHTML=`<img src="${objUrl}" style="opacity:.6"><div class="up-badge" style="font-size:10px;color:#4fa8d0;background:rgba(0,0,0,.75);padding:2px 6px;border-radius:4px;margin-top:3px;text-align:center;">업로드 중...</div>`;
  try{
    const url=await uploadImageToStorage(compressed,'photos/'+pid);
    prev.dataset.url=url;
    prev.innerHTML=`<img src="${url}">`;
    // 업로드 도중 사용자가 이미 제출했으면(dest 연결됨) 저장된 레코드에 URL 반영
    const qi=_offlinePhotoQueue.find(x=>x.id===qItem.id);
    if(qi&&qi.dest)_applyPhotoDest(qi.dest,url);
    const qidx=_offlinePhotoQueue.findIndex(x=>x.id===qItem.id);
    if(qidx>=0)_offlinePhotoQueue.splice(qidx,1);
    try{_photoQDel(qItem.id);}catch(e){}
  }catch(e){
    // 실패해도 큐에 보존 → 연결 복구 시 자동 재시도(제출돼 있으면 레코드에 자동 반영)
    prev.innerHTML=`<img src="${objUrl}"><div class="up-badge" style="font-size:10px;color:#e67e22;background:rgba(0,0,0,.75);padding:2px 6px;border-radius:4px;margin-top:3px;text-align:center;">⚠️ 업로드 대기 — 자동 재시도</div>`;
    try{_photoQPut(qItem);}catch(_){}
    toast('⚠️ 사진 업로드 실패 — 연결 시 자동 재시도');
  }
}
function fillSel(id,arr){document.getElementById(id).innerHTML=arr.map(v=>`<option value="${v}">${v}</option>`).join('');}
const SC=s=>s==='ok'?'#27ae60':s==='warn'?'#e67e22':'#c0392b';
const SL=s=>s==='ok'?'양호':s==='warn'?'보수필요':'파손위험';
function getAuthor(){const u=DB.g('currentUser')||{};return u.name||'미지정';}
function getSelPills(id){return [...document.querySelectorAll(`#${id} .pill.on`)].map(p=>p.textContent);}
function tPill(el){el.classList.toggle('on');}
function sPill(el,wrId){document.querySelectorAll(`#${wrId} .pill`).forEach(p=>p.classList.remove('on'));el.classList.add('on');
  // 음주 버튼 → hidden input 동기화
  if(wrId==='alcPills'){const val=el.textContent.replace(/[🚫⚠️🍺]/g,'').trim();const h=document.getElementById('r_alc');if(h)h.value=val;}
}
// 여러 핀 그룹의 선택(.on) 일괄 해제
function _resetPills(...ids){ids.forEach(id=>document.querySelectorAll(`#${id} .pill`).forEach(p=>p.classList.remove('on')));}
function chkIllegal(sel){
  document.getElementById('fineWrap').style.display=sel.value.includes('비법정')?'block':'none';
  const pw=document.getElementById('permitWrap');
  if(pw) pw.style.display=(sel.value==='암벽'||sel.value==='빙벽')?'block':'none';
  const clw=document.getElementById('climbLocWrap');
  if(clw){
    const isClimb=sel.value==='암벽'||sel.value==='빙벽';
    clw.style.display=isClimb?'block':'none';
    if(isClimb){
      const locs=sel.value==='암벽'?_ROCK_LOCS:_ICE_LOCS;
      const curVal=(document.getElementById('r_loc')?.value||'').trim();
      clw.innerHTML=`<span class="fl">📍 ${sel.value} 위치 선택</span><div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:6px;" id="climbLocBtns">${locs.map(l=>`<button class="tog-btn${curVal===l?' on':''}" onclick="selClimbLoc('${l.replace(/'/g,"\\'")}',this)">${l}</button>`).join('')}</div>`;
    }
  }
}
function selClimbLoc(loc,btn){
  const inp=document.getElementById('r_loc');
  if(inp){inp.value=loc;autoGenTitle();}
  // Scope to the clicked button's own group — #climbLocBtns can exist in two modals
  const grp=btn?btn.parentElement:document.getElementById('climbLocBtns');
  if(grp)grp.querySelectorAll('.tog-btn').forEach(b=>b.classList.remove('on'));
  if(btn)btn.classList.add('on');
}
function chkPermit(sel){document.getElementById('permitNote').style.display=sel.value==='허가자 있음'?'block':'none';}
let _companionCount=(window._companionCount)||0;
function addCompanion(){
  _companionCount++;
  const list=document.getElementById('companionList');
  if(!list)return;
  const idx=list.children.length;
  const div=document.createElement('div');
  div.className='companion-item';
  div.dataset.idx=idx;
  div.style.cssText='background:#060d1a;border-radius:8px;padding:10px;margin-bottom:6px;border:1px solid rgba(255,255,255,.07);';
  div.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;"><span style="font-size:11px;color:#4fa8d0;font-weight:700;">동반자 ${idx+1}</span><button onclick="this.closest('.companion-item').remove();renumberCompanions()" style="background:rgba(192,57,43,.15);color:#c0392b;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;">삭제</button></div>
  <div class="frow"><div class="fg"><span class="fl">성명</span><input type="text" class="fi comp-name" placeholder="이름"></div><div class="fg"><span class="fl">연락처</span><input type="tel" class="fi comp-tel" placeholder="연락처"></div></div>`;
  list.appendChild(div);
}
function removeCompanion(idx){
  const items=document.querySelectorAll('#companionList .companion-item');
  if(items[idx])items[idx].remove();
  renumberCompanions();
}
function renumberCompanions(){
  document.querySelectorAll('#companionList .companion-item').forEach((el,i)=>{
    const label=el.querySelector('span');
    if(label)label.textContent='동반자 '+(i+1);
    el.dataset.idx=i;
  });
}
function getCompanions(){
  return [...document.querySelectorAll('#companionList .companion-item')].map(el=>({
    name:el.querySelector('.comp-name')?.value||'',
    tel:el.querySelector('.comp-tel')?.value||''
  })).filter(c=>c.name||c.tel);
}
// 추가 사고자(다수 사상자) — 기본 사고자(vName 등)는 유지하고 추가분만 배열로 보관
const _V2_SEV=['','KTAS 1 (소생)','KTAS 2 (긴급)','KTAS 3 (응급)','KTAS 4 (준응급)','KTAS 5 (비응급)'];
function _victim2CardHtml(v){
  v=v||{};
  const sevOpts=_V2_SEV.map(o=>`<option value="${o}"${(v.severity||'')===o?' selected':''}>${o||'중증도 선택'}</option>`).join('');
  const genOpts=['알수없음','남','여'].map(o=>`<option${(v.gender||'알수없음')===o?' selected':''}>${o}</option>`).join('');
  return `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;"><span style="font-size:11px;color:#e9897e;font-weight:700;">🧑 추가 사고자</span><button onclick="this.closest('.victim2-item').remove()" style="background:rgba(192,57,43,.15);color:#c0392b;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;">삭제</button></div>
  <div class="frow"><div class="fg"><span class="fl">성명</span><input type="text" class="fi v2-name" placeholder="이름" value="${(v.name||'').replace(/"/g,'&quot;')}"></div><div class="fg"><span class="fl">성별</span><select class="fsel v2-gender">${genOpts}</select></div></div>
  <div class="frow"><div class="fg"><span class="fl">나이</span><input type="number" inputmode="numeric" class="fi v2-age" placeholder="세" value="${v.age||''}"></div><div class="fg"><span class="fl">중증도</span><select class="fsel v2-sev">${sevOpts}</select></div></div>
  <div class="fg"><span class="fl">부상/상태</span><input type="text" class="fi v2-note" placeholder="예: 우측 발목 골절, 의식 명료" value="${(v.note||'').replace(/"/g,'&quot;')}"></div>`;
}
function addVictim2(){
  const list=document.getElementById('victim2List');if(!list)return;
  const div=document.createElement('div');
  div.className='victim2-item';
  div.style.cssText='background:#060d1a;border-radius:8px;padding:10px;margin-bottom:6px;border:1px solid rgba(231,76,60,.15);';
  div.innerHTML=_victim2CardHtml({});
  list.appendChild(div);
}
function getVictims2(){
  return [...document.querySelectorAll('#victim2List .victim2-item')].map(el=>({
    name:el.querySelector('.v2-name')?.value||'',
    gender:el.querySelector('.v2-gender')?.value||'',
    age:el.querySelector('.v2-age')?.value||'',
    severity:el.querySelector('.v2-sev')?.value||'',
    note:el.querySelector('.v2-note')?.value||''
  })).filter(v=>v.name||v.note||v.age);
}
function _victims2Str(arr){
  return (arr||[]).map(v=>[v.name||'미상',v.gender&&v.gender!=='알수없음'?v.gender:'',v.age?v.age+'세':'',v.severity,v.note].filter(Boolean).join(' · ')).join(' / ');
}
function chkNation(sel){
  const wrap=document.getElementById('r_vNatWrap_extra');
  if(wrap)wrap.style.display=sel.value==='외국인'?'block':'none';
  autoGenTitle();
}

// ══════════════════════════════════════════
// 알림
// ══════════════════════════════════════════
// ── 알림 카테고리(세분화) ── def: 기본 켜짐 여부 / push: OS 푸시 여부(false면 앱 내 종만)
const NOTI_GROUPS=[
  {title:'🚨 현장 위험상황·구조', items:[
    {k:'안전사고',l:'안전사고',sub:'실족·추락·부상',def:true,push:true},
    {k:'낙석',l:'낙석',sub:'낙석 발생',def:true,push:true},
    {k:'위험수목',l:'위험수목',sub:'쓰러짐·낙목',def:true,push:true},
    {k:'화재',l:'화재·산불',sub:'산불·시설 화재',def:true,push:true},
    {k:'기타',l:'기타 위험',sub:'기타 위험상황',def:true,push:true},
    {k:'rescue_mobilize',l:'응소 요청',sub:'야간·산불 응소·재알림',def:true,push:true},
    {k:'progress',l:'진행중 경과 알림',sub:'장시간 미종료 리마인더',def:true,push:true},
    {k:'rescue_update',l:'추가보고·댓글',sub:'구조 추가보고·댓글',def:false,push:false},
    {k:'rescue_close',l:'상황 종료',sub:'구조 상황 종료',def:false,push:false},
  ]},
  {title:'🏗️ 시설물 점검', items:[
    {k:'fac_bad',l:'위험 시설물',sub:'파손 심각 등록',def:true,push:true},
    {k:'fac_warn',l:'보수 필요',sub:'보수필요 판정',def:false,push:false},
  ]},
  {title:'🌀 재난대응 (특보·위기경보)', items:[
    {k:'op_start',l:'특보운영 시작',sub:'특보운영 개시',def:true,push:true},
    {k:'op_change',l:'특보 상향·하향',sub:'단계 변경·추가 발령',def:true,push:true},
    {k:'op_end',l:'특보운영 종료',sub:'운영 종료',def:true,push:true},
    {k:'op_kma',l:'기상특보 수신',sub:'기상청 자동 특보',def:true,push:true},
    {k:'crisis',l:'재난위기경보',sub:'관심·주의·경계·심각',def:true,push:true},
    {k:'trail',l:'탐방로 통제',sub:'구간 통제·개방',def:true,push:true},
    {k:'weather',l:'기상 브리핑',sub:'정기 기상 브리핑',def:true,push:false},
  ]},
];
const NOTI_PUSH=(()=>{const m={};NOTI_GROUPS.forEach(g=>g.items.forEach(it=>{m[it.k]=it.push;}));return m;})();
// 신규 카테고리를 기존 사용자 설정에 기본값으로 보강
function _ensureNotiDefaults(){
  const s=DB.g('notiSetting')||{};let ch=false;
  NOTI_GROUPS.forEach(g=>g.items.forEach(it=>{if(s[it.k]===undefined){s[it.k]=it.def;ch=true;}}));
  if(ch)DB.s('notiSetting',s);
  return s;
}
function pushNoti(msg,ico,type='info',link=null,pushCat=null){
  const s=DB.g('notiSetting')||{};if(type!=='info'&&s[type]===false)return;
  // pushCat 미지정 시: 카테고리 정의에 push:false면 OS 푸시 끔(앱 내 종만)
  if(pushCat===null)pushCat=(NOTI_PUSH[type]===false)?'info':type;
  const id=Date.now();
  const ns=DB.g('notis')||[];ns.unshift({id,msg,ico,time:now(),read:false,link});
  if(ns.length>80)ns.splice(80);DB.s('notis',ns);updateBell();
  // 꺼진 폰까지 OS 푸시 (중요 알림만, 받는 사람별 알림설정 적용)
  _sendFcmPush('설악산 현장관리',msg,pushCat||type,link);
  // 기기 간 Firestore 브로드캐스트
  if(_fdb){
    _fdb.collection('sharedNotis').doc(String(id)).set({
      id,msg,ico,type:type||'info',link:link||null,
      at:id,timeStr:now(),deviceId:_MY_DEVICE_ID
    }).catch(()=>{});
  }
}
function _cleanOldSharedNotis(){
  if(!_fdb)return;
  const cutoff=Date.now()-24*60*60*1000;
  // 한 번에 최대 100건만 삭제(여러 기기가 동시에 돌려도 부담 적게) — 200명 동시접속 시 폭주 방지
  _fdb.collection('sharedNotis').where('at','<',cutoff).limit(100).get()
    .then(snap=>snap.docs.forEach(d=>d.ref.delete())).catch(()=>{});
}
function _showSystemNoti(body,ico){
  if(document.visibilityState==='visible')return; // 앱 보이는 중이면 불필요
  if(typeof Notification==='undefined'||Notification.permission!=='granted')return; // 인앱 브라우저 등 Notification 미지원 환경 보호
  const title='설악산 현장관리 '+(ico||'🔔');
  if(_swReg){
    _swReg.showNotification(title,{body,icon:'icons/icon-192.png',vibrate:[200,100,200]});
  }else if('Notification' in window){
    try{new Notification(title,{body});}catch(e){}
  }
}
function toggleHiContrast(){
  const on=document.body.classList.toggle('hi-contrast');
  localStorage.setItem('_hiContrast',on?'1':'');
  const btn=document.getElementById('hiContrastBtn');
  if(btn)btn.style.opacity=on?'1':'.5';
  toast(on?'🌞 야외 고대비 모드 켜짐':'🌙 고대비 모드 꺼짐');
}
// VAPID 키 설정 후 FCM 토큰 등록 (Firebase Console > Project Settings > Cloud Messaging > Web Push 인증서)
const _FCM_VAPID=''; // ← 여기에 Firebase Console에서 발급한 VAPID 키 입력
const _FCM_PUSH_URL='https://script.google.com/macros/s/AKfycbwp4JWCBkLC-LlSqiPOmyUEIO3uhv9w0ReJhEaJcXvlK0NWWwIrEK3Jo-DTaBWRHqJW/exec';
const _FCM_PUSH_SECRET='설악산119';
async function _initFCM(){
  if(!_fmsg||!_fdb||!_swReg||typeof Notification==='undefined'||Notification.permission!=='granted'||!_FCM_VAPID)return;
  try{
    const token=await _fmsg.getToken({vapidKey:_FCM_VAPID,serviceWorkerRegistration:_swReg});
    if(token)_saveFcmToken(token,'web');
  }catch(e){}
}

// ══ 네이티브 푸시 (Capacitor / 안드로이드 APK) ══
// 웹 VAPID와 달리 OS 차원 푸시 → 앱이 완전히 꺼져 있어도 수신.
let _pnListenersSet=false;
async function _initNativePush(){
  const Cap=window.Capacitor;
  if(!Cap||!Cap.isNativePlatform||!Cap.isNativePlatform())return; // 웹은 _initFCM 사용
  const PN=Cap.Plugins&&Cap.Plugins.PushNotifications;
  if(!PN)return;
  try{
    // 긴급 알림 채널(안드로이드 8+, 헤드업 표시)
    if(PN.createChannel){try{await PN.createChannel({id:'seoraksan_alerts',name:'긴급 알림',description:'구조·위험상황 푸시',importance:5,visibility:1,vibration:true,sound:'default'});}catch(e){}}
    let perm=await PN.checkPermissions();
    if(perm.receive!=='granted')perm=await PN.requestPermissions();
    if(perm.receive!=='granted')return;
    if(!_pnListenersSet){
      _pnListenersSet=true;
      PN.addListener('registration',t=>{_saveFcmToken(t.value,'android');});
      PN.addListener('registrationError',()=>{});
      PN.addListener('pushNotificationActionPerformed',act=>{
        const d=(act.notification&&act.notification.data)||{};
        if(d.app){try{goNotiLink({app:d.app,tab:d.tab?+d.tab:0,id:d.id||null});}catch(e){}}
      });
    }
    await PN.register();
  }catch(e){}
}
// 네이티브(APK)에서 알림 권한처럼 위치 권한도 최초 실행 시 자동으로 요청.
// AndroidManifest에 위치 권한이 선언돼 있으면 Capacitor WebView가
// navigator.geolocation 호출 시 OS 권한창을 띄운다.
// (@capacitor/geolocation 플러그인은 play-services-location의 구버전 Kotlin이
//  KGP와 충돌해 릴리스 빌드를 깨뜨려 사용하지 않음)
function _initNativeLocationPerm(){
  const Cap=window.Capacitor;
  if(!Cap||!Cap.isNativePlatform||!Cap.isNativePlatform())return; // 웹은 화면 하단 배너로 요청
  if(!navigator.geolocation)return;
  if(localStorage.getItem('_locPermAsked'))return;
  localStorage.setItem('_locPermAsked','1');
  navigator.geolocation.getCurrentPosition(()=>{},()=>{},{enableHighAccuracy:true,timeout:15000});
}
let _fcmTokenCache=null;
function _saveFcmToken(token,platform){
  if(!token)return;
  _fcmTokenCache={token,platform:platform||'web'};   // Firebase 준비 전이면 캐시 후 재시도
  if(!_fdb)return;
  const u=DB.g('currentUser')||{};
  _fdb.collection('fcmTokens').doc(_MY_DEVICE_ID).set({
    token,userId:u.id||'',name:u.name||'',
    notiSetting:DB.g('notiSetting')||{},platform:_fcmTokenCache.platform,updatedAt:Date.now()
  },{merge:true}).catch(()=>{});
}
function _flushFcmToken(){if(_fcmTokenCache)_saveFcmToken(_fcmTokenCache.token,_fcmTokenCache.platform);}
// 알림 설정 변경 시 내 토큰 문서에도 반영 (받는 사람별 필터용)
function _updateFcmTokenSettings(){
  if(!_fdb)return;
  _fdb.collection('fcmTokens').doc(_MY_DEVICE_ID).set(
    {notiSetting:DB.g('notiSetting')||{},updatedAt:Date.now()},{merge:true}
  ).catch(()=>{});
}
// 중요 알림을 꺼진 폰까지 발송 (Apps Script 경유). cat=알림설정 키, 'info'면 발송 안 함.
async function _sendFcmPush(title,body,cat,link){
  if(!_fdb)return;
  const url=_FCM_PUSH_URL||(DB.g('fcmPushUrl')||'').trim();
  if(!url||!cat||cat==='info')return;
  try{
    const snap=await _fdb.collection('fcmTokens').get();
    const targets=[];
    snap.forEach(d=>{
      const v=d.data()||{};
      if(!v.token||d.id===_MY_DEVICE_ID)return;        // 내 폰엔 안 보냄
      if(((v.notiSetting||{})[cat])===false)return;     // 그 사람이 끈 알림
      targets.push({id:d.id,token:v.token});
    });
    if(!targets.length)return;
    const res=await fetch(url,{
      method:'POST',
      headers:{'content-type':'text/plain;charset=utf-8'}, // Apps Script preflight 회피
      body:JSON.stringify({
        secret:_FCM_PUSH_SECRET||(DB.g('fcmPushSecret')||''),title,body,
        data:link?{app:link.app||'',tab:String(link.tab||''),id:String(link.id||'')}:{},
        tokens:targets.map(t=>t.token)
      })
    });
    const out=await res.json().catch(()=>({}));
    if(out&&Array.isArray(out.invalid)){                // 무효 토큰 정리
      out.invalid.forEach(tok=>{
        const hit=targets.find(t=>t.token===tok);
        if(hit)_fdb.collection('fcmTokens').doc(hit.id).delete().catch(()=>{});
      });
    }
  }catch(e){}
}
function updateBell(){
  const cnt=(DB.g('notis')||[]).filter(n=>!n.read).length;
  ['bellCnt','bellCntHome'].forEach(id=>{const e=document.getElementById(id);if(!e)return;e.textContent=cnt>9?'9+':cnt;e.classList.toggle('on',cnt>0);});
}
function openNoti(){
  const ns=DB.g('notis')||[];
  document.getElementById('notiList').innerHTML=ns.length
    ?ns.map(n=>{
      const hasLink=n.link&&n.link.app;
      const linkStr=hasLink?`goNotiLink(${JSON.stringify(n.link).replace(/"/g,"'")})`:'';
      return `<div class="ni ${n.read?'read':'unread'}" style="${hasLink?'cursor:pointer;':''}" ${hasLink?`onclick="${linkStr}"`:''}  >
        <div style="position:relative;flex-shrink:0;">
          <div class="ni-ico">${n.ico}</div>
          ${n.read?'':'<div style="position:absolute;top:-2px;right:-2px;width:7px;height:7px;background:#e05050;border-radius:50%;border:1.5px solid #0b1c30;"></div>'}
        </div>
        <div style="flex:1;min-width:0;">
          <div class="ni-msg">${_esc(n.msg)}</div>
          <div class="ni-t">${n.time}${hasLink?' · <span style="color:#4fa8d0;font-size:10px;">탭하여 이동 →</span>':''}</div>
        </div>
      </div>`;
    }).join('')
    :'<div class="noti-empty">✅ 새 알림 없음</div>';
  DB.s('notis',(ns).map(n=>({...n,read:true})));updateBell();
  document.getElementById('notiPanel').classList.add('on');document.getElementById('notiBg').classList.add('on');
}
function goNotiLink(link){
  closeNoti();
  if(!link||!link.app) return;
  openApp(link.app);
  if(link.tab) setTimeout(()=>switchTab(link.tab,document.getElementById('nv'+link.tab)),200);
  if(link.id) setTimeout(()=>{
    if(link.app==='rescue') openResPopup(link.id,'rescue');
    else if(link.app==='inspect') openFacDetail(link.id);
  },300);
}
function closeNoti(){document.getElementById('notiPanel').classList.remove('on');document.getElementById('notiBg').classList.remove('on');}
function markAllRead(){DB.s('notis',(DB.g('notis')||[]).map(n=>({...n,read:true})));updateBell();openNoti();}
function clearNotis(){DB.s('notis',[]);updateBell();closeNoti();toast('🗑️ 알림 삭제');}

// ══════════════════════════════════════════
// 카카오맵
// ══════════════════════════════════════════
let mapI,mapR,iOvs=[],rOvs=[],iEls=[],rEls=[],myOv=null,mapIType='hybrid',mapRType='hybrid';
function _pinSz(level,off){
  const o=off||0;
  if(level<=3) return {sz:30+o,fs:13,bw:2,  numFs:11,numPad:'2px 5px'};
  if(level<=4) return {sz:26+o,fs:11,bw:2,  numFs:10,numPad:'2px 4px'};
  if(level<=5) return {sz:22+o,fs:9, bw:1.5,numFs:9, numPad:'2px 3px'};
  if(level<=6) return {sz:18+o,fs:8, bw:1.5,numFs:8, numPad:'1px 3px'};
  if(level<=7) return {sz:14+o,fs:6, bw:1,  numFs:7, numPad:'1px 2px'};
  if(level<=8) return {sz:11+o,fs:5, bw:1,  numFs:6, numPad:'1px 2px'};
  if(level<=9) return {sz:8+o, fs:3, bw:0.5,numFs:6, numPad:'1px 2px'};
  if(level<=10)return {sz:7+o, fs:3, bw:0.5,numFs:5, numPad:'0px 2px'};
  if(level<=11)return {sz:6+o, fs:2, bw:0.5,numFs:0, numPad:'0px 1px'};
  return              {sz:5+o, fs:2, bw:0.5,numFs:0, numPad:'0px 1px'};
}
function _scaleOvs(els,level,off){
  const s=_pinSz(level,off);
  els.forEach(el=>{
    if(!el)return;
    if(el.classList.contains('mpin')||el.classList.contains('mpin-sm')){
      el.style.width=s.sz+'px';el.style.height=s.sz+'px';
      el.style.fontSize=s.fs+'px';el.style.borderWidth=s.bw+'px';
    } else if(el.classList.contains('mpin-num')){
      if(s.numFs===0){el.style.display='none';}
      else{el.style.display='';el.style.fontSize=s.numFs+'px';el.style.padding=s.numPad;}
    } else if(el.classList.contains('res-chip-og')){
      // 진행중 사고 칩: 축소(레벨↑)면 아이콘만 작게, 확대(레벨↓)면 전체 칩
      const span=el.querySelector('span');
      if(level>=7){ // 축소: 아이콘만 원형
        if(span)span.style.display='none';
        el.style.padding=level>=9?'1px 3px':'2px 4px';
        el.style.fontSize=(level>=9?9:11)+'px';el.style.borderRadius='50%';
      } else { // 확대: 전체 칩(유형 텍스트 표시)
        if(span)span.style.display='';
        el.style.padding=level<=4?'3px 9px 3px 7px':'2px 7px 2px 6px';
        el.style.fontSize=(level<=4?11:10)+'px';el.style.borderRadius='11px';
      }
    }
  });
}
// ── 경량 커스텀 클러스터: 커스텀 오버레이를 화면 픽셀 격자로 묶어 개수 버블 표시 ──
// items: [{ov, lat, lng}] — 단독은 그대로 표시, 같은 격자 2개 이상이면 멤버 숨기고 개수 버블
function _clusterByPixels(map,items,cellPx,onClick,cls){
  const out=[];
  let proj;try{proj=map.getProjection();}catch(e){proj=null;}
  if(!proj){items.forEach(it=>{try{it.ov.setMap(map);}catch(e){}});return out;}
  const cells=new Map();
  items.forEach(it=>{
    if(!(it.lat&&it.lng)){try{it.ov.setMap(map);}catch(e){}return;}
    let pt;try{pt=proj.pointFromCoords(new kakao.maps.LatLng(it.lat,it.lng));}catch(e){pt=null;}
    if(!pt){try{it.ov.setMap(map);}catch(e){}return;}
    const key=Math.floor(pt.x/cellPx)+'_'+Math.floor(pt.y/cellPx);
    if(!cells.has(key))cells.set(key,[]);
    cells.get(key).push(it);
  });
  cells.forEach(group=>{
    if(group.length<2){group.forEach(it=>{try{it.ov.setMap(map);}catch(e){}});return;}
    group.forEach(it=>{try{it.ov.setMap(null);}catch(e){}});
    let lat=0,lng=0;group.forEach(it=>{lat+=it.lat;lng+=it.lng;});lat/=group.length;lng/=group.length;
    const el=document.createElement('div');
    el.className='map-cluster'+(cls?' '+cls:'');el.textContent=group.length;
    el.addEventListener('click',e=>{e.stopPropagation();onClick&&onClick(lat,lng);});
    const ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(lat,lng),content:el,clickable:true,zIndex:6});
    ov.setMap(map);out.push(ov);
  });
  return out;
}
function _clusterZoom(map,lat,lng){
  try{map.setLevel(Math.max(1,map.getLevel()-2),{anchor:new kakao.maps.LatLng(lat,lng)});}
  catch(e){try{map.setCenter(new kakao.maps.LatLng(lat,lng));map.setLevel(Math.max(1,map.getLevel()-2));}catch(e2){}}
}
// 구조 지도: 사고/위험 '상황' 핀만 클러스터 (다목적위치표지판 등 시설물은 제외)
var _rClusterOvs=[],_rEvItems=[];
function _reclusterRescue(){
  if(!mapR)return;
  _rClusterOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_rClusterOvs=[];
  // 종료/위험만 클러스터링(개수 버블). 진행중은 절대 합치지 않고 개별 칩으로 항상 표시.
  const others=_rEvItems.filter(it=>!it.noClus);
  _rClusterOvs=_clusterByPixels(mapR,others,52,(la,ln)=>_clusterZoom(mapR,la,ln),'');
  _rEvItems.filter(it=>it.noClus).forEach(it=>{try{it.ov.setMap(mapR);}catch(e){}});
}
// 시설물 점검 지도: 시설물 핀 클러스터
var _iClusterOvs=[],_iItems=[];
function _reclusterInspect(){
  if(!mapI)return;
  _iClusterOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_iClusterOvs=[];
  // 줌 아웃일수록 셀을 키워 더 적극적으로 묶음 → 멀리서 볼 때 핀 수 급감, 지도 부드러움
  let lv=9;try{lv=mapI.getLevel();}catch(e){}
  const cell=lv>=10?80:lv>=8?64:lv>=6?52:44;
  _iClusterOvs=_clusterByPixels(mapI,_iItems,cell,(la,ln)=>_clusterZoom(mapI,la,ln),'fac');
}
const DC={lat:38.1328,lng:128.4107};
// HTML/attribute escaping for user-generated content
function _esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function _escq(s){return String(s==null?'':s).replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'&quot;').replace(/</g,'&lt;');}
function _haversine(lat1,lng1,lat2,lng2){
  var R=6371000,r=Math.PI/180;
  var dL=(lat2-lat1)*r,dG=(lng2-lng1)*r;
  var a=Math.sin(dL/2)*Math.sin(dL/2)+Math.cos(lat1*r)*Math.cos(lat2*r)*Math.sin(dG/2)*Math.sin(dG/2);
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}
var _cachedRescueSigns=null,_cachedFullSigns=null;
function _invalidateSignCache(){
  _cachedRescueSigns=null;_cachedFullSigns=null;
  // Clear facility overlay pool so it rebuilds with fresh data on next render
  _rFacPool.forEach(entry=>{try{entry.ov.setMap(null);}catch(e){}});
  _rFacPool.clear();
}
function _nearestSign(lat,lng){
  if(!_cachedRescueSigns){
    var _m=DB.g('catFacMeta')||{};
    _cachedRescueSigns=(DB.g('facilities')||[]).filter(function(f){
      return f.lat&&f.lng&&f.type&&(_m[f.type]||{}).rescue;
    });
  }
  var best=null,bestD=Infinity;
  _cachedRescueSigns.forEach(function(f){var d=_haversine(lat,lng,f.lat,f.lng);if(d<bestD){bestD=d;best=f;}});
  if(!best||bestD>3000)return null;
  var label=best.type.includes('다목적위치표지판')
    ?(best.name.match(/\d[\d\-]*\d|\d/)||[best.name.slice(0,6)])[0]
    :best.name;
  var dist=bestD<1000?Math.round(bestD)+'m':((bestD/1000).toFixed(1)+'km');
  return label+' 인근 '+dist;
}
function initMaps(){
  function doInit(){
    if(mapR&&mapI)return; // Guard: don't recreate if already initialized
    const c=new kakao.maps.LatLng(DC.lat,DC.lng),opt={center:c,level:9};
    mapI=new kakao.maps.Map(document.getElementById('mapInspect'),opt);
    mapR=new kakao.maps.Map(document.getElementById('mapRescue'),opt);
    mapI.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
    mapR.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
    kakao.maps.event.addListener(mapI,'click',closeDB);
    kakao.maps.event.addListener(mapR,'click',closeDB);
    var _saveMapCenterTimer=null;
    function saveMapCenter(){
      try{
        var lat,lng;
        const mapEl=document.getElementById('mapRescue');
        const h=mapEl.offsetHeight||mapEl.clientHeight;
        if(h>0){
          const coord=mapR.getProjection().coordsFromContainerPoint(new kakao.maps.Point(mapEl.offsetWidth/2,h/2));
          lat=coord.getLat();lng=coord.getLng();
        }else{
          const c=mapR.getCenter();lat=c.getLat();lng=c.getLng();
        }
        window._lastCrosshairCoord={lat,lng};
        const cd=document.getElementById('rescueCoords');
        if(cd)cd.innerHTML=lat.toFixed(5)+', '+lng.toFixed(5);
        clearTimeout(_saveMapCenterTimer);
        _saveMapCenterTimer=setTimeout(function(){
          const _s=_nearestSign(lat,lng);
          if(cd)cd.innerHTML=lat.toFixed(5)+', '+lng.toFixed(5)+(_s?'<br><span style="color:#f0c040;font-size:9.5px;">📍 '+_s+'</span>':'');
          _updateZoneBadge(lat,lng,'rescueZoneBadge');
        },300);
      }catch(e){}
    }
    kakao.maps.event.addListener(mapR,'center_changed',saveMapCenter);
    saveMapCenter();
    function saveInspectCenter(){
      try{
        const mapEl=document.getElementById('mapInspect');
        const h=mapEl.offsetHeight||mapEl.clientHeight;
        if(h>0){
          const coord=mapI.getProjection().coordsFromContainerPoint(new kakao.maps.Point(mapEl.offsetWidth/2,h/2));
          window._lastInspectCrosshairCoord={lat:coord.getLat(),lng:coord.getLng()};
          const ci=document.getElementById('inspectCoords');
          if(ci)ci.textContent=coord.getLat().toFixed(5)+', '+coord.getLng().toFixed(5);
          return;
        }
      }catch(e){}
      const c=mapI.getCenter();window._lastInspectCrosshairCoord={lat:c.getLat(),lng:c.getLng()};
      const ci=document.getElementById('inspectCoords');
      if(ci)ci.textContent=c.getLat().toFixed(5)+', '+c.getLng().toFixed(5);
    }
    kakao.maps.event.addListener(mapI,'center_changed',saveInspectCenter);
    saveInspectCenter();
    // 줌 레벨에 따른 핀 크기 자동 조절
    kakao.maps.event.addListener(mapR,'zoom_changed',()=>{_scaleOvs(rEls,mapR.getLevel(),5);try{_reclusterRescue();}catch(e){}});
    kakao.maps.event.addListener(mapI,'zoom_changed',()=>{_scaleOvs(iEls,mapI.getLevel(),1);try{_reclusterInspect();}catch(e){}});
    if(window._hideLoading)setTimeout(window._hideLoading,600);
  }
  if(window._KR){doInit();return;}
  window._KCB=doInit;
  // 12초 지나도 SDK가 준비 안 되면(도메인 미등록·네트워크 차단 등) 빈 화면 대신
  // 안내 문구 + 새로고침 버튼 표시 (기존엔 아무 표시 없이 그냥 빈 화면이었음)
  if(!window._mapFallbackTimer){
    window._mapFallbackTimer=setTimeout(function(){
      if(mapR&&mapI)return;
      var html='<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:#7a9cb8;font-size:13px;text-align:center;padding:20px;gap:8px;">'+
        '<div>⚠️ 지도를 불러올 수 없습니다</div>'+
        '<div style="font-size:11px;color:#4a7090;">네트워크 연결을 확인해주세요</div>'+
        '<button onclick="location.reload()" style="margin-top:4px;background:#1d6fa5;color:#fff;border:none;padding:8px 16px;border-radius:8px;font-size:12px;cursor:pointer;">새로고침</button>'+
        '</div>';
      ['mapInspect','mapRescue'].forEach(function(id){
        var el=document.getElementById(id);
        if(el)el.innerHTML=html;
      });
    },12000);
  }
}
function rMaps(){
  // 지도 컨테이너 크기를 부모에 맞게 강제 설정
  ['mapRescue','mapInspect'].forEach(id=>{
    const el=document.getElementById(id);
    if(el){el.style.width='100%';el.style.height='100%';}
  });
  setTimeout(()=>{
    try{if(mapI){mapI.relayout();}}catch(e){}
    try{if(mapR){mapR.relayout();}}catch(e){}
  },150);
}
function toggleMapType(m){
  if(m==='inspect'){mapIType=mapIType==='hybrid'?'roadmap':'hybrid';mapI.setMapTypeId(mapIType==='hybrid'?kakao.maps.MapTypeId.HYBRID:kakao.maps.MapTypeId.ROADMAP);}
  else{mapRType=mapRType==='hybrid'?'roadmap':'hybrid';mapR.setMapTypeId(mapRType==='hybrid'?kakao.maps.MapTypeId.HYBRID:kakao.maps.MapTypeId.ROADMAP);}
  toast(m==='inspect'?(mapIType==='hybrid'?'위성':'일반'):(mapRType==='hybrid'?'위성':'일반'));
}
function gpsTo(mode){
  if(!navigator.geolocation){toast('⚠️ GPS 미지원');return;}
  toast('📍 GPS 수신 중...');
  navigator.geolocation.getCurrentPosition(p=>{
    const ll=new kakao.maps.LatLng(p.coords.latitude,p.coords.longitude);
    const m=mode==='inspect'?mapI:mapR;
    m.setCenter(ll);m.setLevel(4);
    // 하단 탭바 높이만큼 보정: GPS 점이 십자선 위치에 오도록 아래로 pan
    const bnavEl=document.getElementById('bnav');
    const bnavH=(bnavEl&&bnavEl.style.display!=='none')?bnavEl.offsetHeight:0;
    if(bnavH>0){setTimeout(()=>{try{m.panBy(0,Math.round(bnavH/2));}catch(e){}},50);}
    if(myOv)myOv.setMap(null);
    const el=document.createElement('div');
    el.style.cssText='width:18px;height:18px;border-radius:50%;background:#4fa8d0;border:3px solid #fff;box-shadow:0 0 10px rgba(79,168,208,.8),0 2px 6px rgba(0,0,0,.5);';
    myOv=new kakao.maps.CustomOverlay({position:ll,content:el});myOv.setMap(m);
    toast('✅ 내 위치');
  },()=>toast('⚠️ GPS 실패. 위치 권한 확인'),{enableHighAccuracy:true,timeout:15000,maximumAge:10000});
}
function gpsFromMap(id,mode){
  try{const m=mode==='inspect'?mapI:mapR;const c=m.getCenter();const lat=c.getLat(),lng=c.getLng();document.getElementById(id).value=lat.toFixed(5)+', '+lng.toFixed(5);toast('🗺️ 지도 중심 좌표');if(id==='hz_gps')_updateHazMiniMap(lat,lng);}
  catch(e){toast('⚠️ 지도를 먼저 여세요');}
}
function gpsFromPhone(id){
  if(!navigator.geolocation){toast('⚠️ GPS 미지원');return;}
  navigator.geolocation.getCurrentPosition(p=>{const lat=p.coords.latitude,lng=p.coords.longitude;document.getElementById(id).value=lat.toFixed(5)+', '+lng.toFixed(5);toast('📍 현재 위치');if(id==='hz_gps')_updateHazMiniMap(lat,lng);},()=>toast('⚠️ GPS 실패'),{enableHighAccuracy:true,timeout:15000,maximumAge:10000});
}

// ══════════════════════════════════════════
// 네비게이션
// ══════════════════════════════════════════
let curApp='';
function showV(id){document.querySelectorAll('.view').forEach(v=>v.classList.remove('on'));document.getElementById(id).classList.add('on');}
// ══ 본부 상황판 ══════════════════════════
let _boardTimer=null;
function openBoard(){
  showV('v-board');
  document.getElementById('appHdr').style.display='none';
  document.getElementById('bnav').style.display='none';
  // 상세 패널 닫고 목록 표시 상태로 초기화
  _boardDetailId=null;
  const _bd=document.getElementById('boardDetail');if(_bd)_bd.style.display='none';
  const _bb=document.getElementById('boardBody');if(_bb)_bb.style.display='';
  setTimeout(_initBoardMap,250);
  renderBoard();
  clearInterval(_boardTimer);
  _boardTimer=setInterval(()=>{
    if(!document.getElementById('v-board').classList.contains('on')){clearInterval(_boardTimer);return;}
    renderBoard();
  },10000);
  history.pushState({view:'board'},'','');
}
function closeBoard(){clearInterval(_boardTimer);goHome();}

// 상황판 지도: 진행중 구조/위험 핀 표시
let _boardMap=null,_boardOvs=[],_boardResizeBound=false;
function _initBoardMap(){
  const el=document.getElementById('boardMap');
  if(!el||!window._KR)return;
  if(!_boardMap){
    try{
      _boardMap=new kakao.maps.Map(el,{center:new kakao.maps.LatLng(DC.lat,DC.lng),level:9});
      _boardMap.setMapTypeId(kakao.maps.MapTypeId.HYBRID); // HYBRID: 위성+벡터 — 타일 이음새가 벡터 레이어로 덮여 세로줄 없음
    }catch(e){console.warn('boardMap',e);return;}
  }else{
    _boardMap.relayout();
  }
  // 창 크기 변경(모니터 회전·해상도 변경) 시 relayout
  if(!_boardResizeBound){
    _boardResizeBound=true;
    window.addEventListener('resize',()=>{try{if(_boardMap&&document.getElementById('v-board').classList.contains('on'))_boardMap.relayout();}catch(e){}});
  }
  _renderBoardPins(true); // 최초 1회만 전체 범위에 맞춤
  setTimeout(()=>{try{_boardMap&&_boardMap.relayout();}catch(e){}},200);
}
function _renderBoardPins(fit){
  if(!_boardMap)return;
  _boardOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_boardOvs=[];
  const bounds=new kakao.maps.LatLngBounds();let n=0;
  (DB.g('rescues')||[]).filter(r=>r.status==='ongoing'&&r.lat&&r.lng).forEach(r=>{
    const ti=RES_TYPES[r.type]||RES_TYPES['기타'];
    const el=document.createElement('div');
    el.innerHTML=`<div style="display:flex;flex-direction:column;align-items:center;cursor:pointer;">
      <div style="background:#c0392b;border:2px solid #fff;border-radius:50%;width:34px;height:34px;display:flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 2px 8px rgba(0,0,0,.6);animation:blink 1.2s infinite;">${ti.ico}</div>
      <div style="margin-top:3px;background:rgba(10,22,38,.92);border:1px solid rgba(192,57,43,.5);color:#e0edf8;border-radius:8px;padding:2px 8px;font-size:11px;font-weight:700;white-space:nowrap;box-shadow:0 1px 5px rgba(0,0,0,.5);">${_esc(r.title)}</div></div>`;
    el.onclick=()=>_boardFocus(r.id);
    const pos=new kakao.maps.LatLng(r.lat,r.lng);
    const ov=new kakao.maps.CustomOverlay({position:pos,content:el,yAnchor:1,zIndex:5,clickable:true});
    ov.setMap(_boardMap);_boardOvs.push(ov);bounds.extend(pos);n++;
    // 팀 현재 위치 칩
    (r.teams||[]).forEach((t,ti2)=>{
      const cur=(t.wps||[])[t.wpIdx];
      if(!cur||!cur.lat||!cur.lng)return;
      const col=TEAM_COLORS[ti2%TEAM_COLORS.length];
      const tel=document.createElement('div');
      tel.innerHTML=`<div style="background:${col};border:1.5px solid #fff;color:#fff;border-radius:11px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap;box-shadow:0 1px 4px rgba(0,0,0,.5);">${_teamIco(t)} ${_shortTeamName(t.name)}</div>`;
      const tpos=new kakao.maps.LatLng(cur.lat,cur.lng);
      const tov=new kakao.maps.CustomOverlay({position:tpos,content:tel,yAnchor:-0.2,zIndex:6});
      tov.setMap(_boardMap);_boardOvs.push(tov);bounds.extend(tpos);
    });
  });
  (DB.g('hazards')||[]).filter(h=>h.lat&&h.lng&&(!h.hazStatus||h.hazStatus==='미조치'||h.hazStatus==='조치중')).forEach(h=>{
    const el=document.createElement('div');
    el.innerHTML=`<div style="background:#e67e22;border:2px solid #fff;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:14px;box-shadow:0 2px 6px rgba(0,0,0,.6);">⚠️</div>`;
    const pos=new kakao.maps.LatLng(h.lat,h.lng);
    const ov=new kakao.maps.CustomOverlay({position:pos,content:el,yAnchor:1,zIndex:4});
    ov.setMap(_boardMap);_boardOvs.push(ov);bounds.extend(pos);n++;
  });
  // 🆘 조난·사고자 위치 (실시간) — 가장 눈에 띄게
  (_sosPings||[]).forEach(p=>{
    if(!p.lat||!p.lng)return;
    const el=document.createElement('div');
    el.innerHTML=`<div style="display:flex;flex-direction:column;align-items:center;cursor:pointer;">
      <div style="background:#c0392b;border:2.5px solid #ffe14d;border-radius:50%;width:34px;height:34px;display:flex;align-items:center;justify-content:center;font-size:16px;box-shadow:0 0 0 3px rgba(231,76,60,.4),0 2px 8px rgba(0,0,0,.6);animation:blink 1s infinite;">🆘</div>
      <div style="margin-top:3px;background:rgba(10,22,38,.92);border:1.5px solid #ffe14d;color:#fff;border-radius:8px;padding:2px 8px;font-size:11px;font-weight:800;white-space:nowrap;box-shadow:0 1px 5px rgba(0,0,0,.5);">🆘 ${_esc(p.name||'조난·사고자')}</div></div>`;
    el.onclick=()=>{try{_boardMap.setCenter(new kakao.maps.LatLng(p.lat,p.lng));_boardMap.setLevel(4);}catch(e){}};
    const pos=new kakao.maps.LatLng(p.lat,p.lng);
    const ov=new kakao.maps.CustomOverlay({position:pos,content:el,yAnchor:1,zIndex:9,clickable:true});
    ov.setMap(_boardMap);_boardOvs.push(ov);bounds.extend(pos);n++;
  });
  // 다목적위치표지판 핀 (번호 표시, 작은 레이블)
  (DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판')&&f.lat&&f.lng).forEach(f=>{
    const code=(f.name.match(/\d[\d\-]*\d|\d/)||[f.name.slice(0,6)])[0];
    const el=document.createElement('div');
    el.innerHTML=`<div style="background:rgba(10,30,55,.85);border:1px solid rgba(79,168,208,.6);color:#7dd3fa;border-radius:5px;padding:1px 5px;font-size:9px;font-weight:700;white-space:nowrap;box-shadow:0 1px 3px rgba(0,0,0,.5);cursor:default;">${_esc(code)}</div>`;
    const pos=new kakao.maps.LatLng(f.lat,f.lng);
    const ov=new kakao.maps.CustomOverlay({position:pos,content:el,yAnchor:1,zIndex:2});
    ov.setMap(_boardMap);_boardOvs.push(ov);
  });
  // fit=true(최초 열 때)만 지도 범위 자동맞춤. 자동갱신 시엔 사용자가 보고있는 위치·줌 유지(깜빡임·이동 방지)
  if(fit){
    if(n>1){try{_boardMap.setBounds(bounds,60,60,60,60);}catch(e){}}
    else if(n===1){try{_boardMap.setCenter(bounds.getSouthWest());_boardMap.setLevel(6);}catch(e){}}
  }
}
// 상황판 카드/핀 클릭 → 해당 구조로 지도 이동
function _boardFocus(id){
  const r=(DB.g('rescues')||[]).find(x=>x.id===id);
  if(!r||!_boardMap||!r.lat||!r.lng)return;
  try{_boardMap.setCenter(new kakao.maps.LatLng(r.lat,r.lng));_boardMap.setLevel(5);}catch(e){}
}
// 상황판 위험상황 카드/핀 클릭 → 해당 위험상황으로 지도 이동
function _boardFocusHaz(id){
  const h=(DB.g('hazards')||[]).find(x=>x.id===id);
  if(!h||!_boardMap||!h.lat||!h.lng){toast('⚠️ 좌표 없음');return;}
  try{_boardMap.setCenter(new kakao.maps.LatLng(h.lat,h.lng));_boardMap.setLevel(5);}catch(e){}
}
// 상황판 상단 토글: 'rescue'=진행중 구조 카드 / 'hazard'=미조치 위험상황 카드
let _boardView='rescue';
function setBoardView(v){_boardView=v;renderBoard();}
// 상황판 우측: 타임라인/보고서 상세를 사이드 패널에 표시 (컴퓨터 화면 유지)
let _boardDetailId=null;
function _boardOpenDetail(id,mode){
  const r=(DB.g('rescues')||[]).find(x=>x.id===id);
  if(!r)return;
  _boardDetailId=id;
  document.getElementById('boardBody').style.display='none';
  const det=document.getElementById('boardDetail');
  det.style.display='flex';
  // 상세 컨텐츠 영역을 맨 위로 스크롤
  const dc=document.getElementById('boardDetailContent');if(dc)dc.scrollTop=0;
  // repContent를 비워 id 충돌 방지
  const rc=document.getElementById('repContent');if(rc)rc.innerHTML='';
  _boardFocus(id);
  renderTimeline(r,mode,'boardDetailContent');
  // 상황판 푸터: 모달이 상황판에 가리므로 종료 버튼만 노출 (상세 편집은 앱에서)
  const ft=document.getElementById('boardDetailFooter');
  if(ft){
    if(r.status==='ongoing'){
      ft.innerHTML=`<button class="btn-submit" style="width:100%;background:#0d5040;color:#fff;" onclick="selResId=${r.id};curResId=${r.id};endSit();">✅ 상황 종료</button>`;
    }else{
      ft.innerHTML='<div style="text-align:center;font-size:12px;color:#27ae60;padding:6px;">✅ 상황 종료됨</div>';
    }
  }
}
function _boardCloseDetail(){
  _boardDetailId=null;
  const det=document.getElementById('boardDetail');
  if(det)det.style.display='none';
  const c=document.getElementById('boardDetailContent');if(c)c.innerHTML='';
  const f=document.getElementById('boardDetailFooter');if(f)f.innerHTML='';
  const bb=document.getElementById('boardBody');if(bb)bb.style.display='';
  renderBoard();
}
// 구조 위치 라벨: 장소명 > 가장 가까운 표지판 > 좌표 > 미상
function _resLocLabel(r){
  if(r.location&&r.location.trim())return _esc(r.location.trim());
  if(r.lat&&r.lng){
    try{const s=_nearestSign(r.lat,r.lng);if(s)return _esc(s);}catch(e){}
    return (+r.lat).toFixed(4)+', '+(+r.lng).toFixed(4);
  }
  return '위치 미상';
}
function renderBoard(){
  const clock=document.getElementById('boardClock');
  if(clock){const d=new Date();clock.textContent=pad(d.getHours())+':'+pad(d.getMinutes());}
  const body=document.getElementById('boardBody');if(!body)return;
  const res=DB.g('rescues')||[];
  const ongoing=res.filter(r=>r.status==='ongoing');
  const haz=(DB.g('hazards')||[]).filter(h=>!h.hazStatus||h.hazStatus==='미조치'||h.hazStatus==='조치중');
  const hazUnhandled=haz.filter(h=>!h.hazStatus||h.hazStatus==='미조치').length; // 손도 안 댄 미조치 — 강조 대상
  const _td=today();
  const todayList=res.filter(r=>(r.date||'').slice(0,10)===_td).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
  const recentList=res.filter(r=>(r.date||'').slice(0,10)!==_td).sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,15);
  const stageLbl=['출발','이동중','환자조우','하산'];
  const stageCol=['rgba(255,255,255,.45)','#4fa8d0','#f0a500','#27ae60'];
  const aops=DB.g('alertOps')||[];
  const activeOp=aops.find(o=>!o.closedAt);
  const opRespCnt=activeOp?(activeOp.responders||[]).length:0;
  const ts=DB.g('trailStatus')||{};
  const trailCtrlCnt=Object.values(ts).filter(v=>v.status==='통제').length;
  const trailWarnCnt=Object.values(ts).filter(v=>v.status==='주의').length;
  const trailActive=_boardView==='trail';
  const rescueActive=_boardView==='rescue', hazActive=_boardView==='hazard', alertActive=_boardView==='alert';
  let html='';
  // 요약 스트립 (클릭 시 하단 카드 영역 전환)
  html+=`<div style="display:flex;gap:10px;margin-bottom:16px;">
    <div onclick="setBoardView('rescue')" style="flex:1;background:${ongoing.length?'rgba(192,57,43,.12)':'rgba(39,174,96,.08)'};border:1px solid ${rescueActive?(ongoing.length?'rgba(192,57,43,.9)':'rgba(39,174,96,.75)'):(ongoing.length?'rgba(192,57,43,.4)':'rgba(39,174,96,.25)')};border-radius:12px;padding:12px 16px;text-align:center;cursor:pointer;transition:all .15s;${rescueActive?'box-shadow:inset 0 0 0 2px rgba(192,57,43,.3);':''}">
      <div style="font-size:30px;font-weight:900;color:${ongoing.length?'#e05050':'#27ae60'};">${ongoing.length}</div>
      <div style="font-size:12px;color:${rescueActive?'#e0edf8':'rgba(255,255,255,.5)'};font-weight:${rescueActive?'700':'400'};">🚨 진행중 구조${rescueActive?' ▾':''}</div>
    </div>
    <div onclick="setBoardView('hazard')" style="position:relative;flex:1;background:${hazUnhandled?'rgba(231,76,60,.12)':'rgba(230,126,34,.08)'};border:1px solid ${hazActive?(hazUnhandled?'rgba(231,76,60,.9)':'rgba(230,126,34,.9)'):(hazUnhandled?'rgba(231,76,60,.5)':'rgba(230,126,34,.25)')};border-radius:12px;padding:12px 16px;text-align:center;cursor:pointer;transition:all .15s;${hazActive?'box-shadow:inset 0 0 0 2px rgba(230,126,34,.3);':''}">
      ${hazUnhandled?`<span style="position:absolute;top:6px;right:6px;background:#e74c3c;color:#fff;font-size:10px;font-weight:800;border-radius:10px;padding:1px 7px;box-shadow:0 0 0 2px rgba(231,76,60,.25);animation:blink 1.2s infinite;">미조치 ${hazUnhandled}</span>`:''}
      <div style="font-size:30px;font-weight:900;color:${hazUnhandled?'#e05050':'#e67e22'};">${haz.length}</div>
      <div style="font-size:12px;color:${hazActive?'#e0edf8':'rgba(255,255,255,.5)'};font-weight:${hazActive?'700':'400'};">⚠️ 미조치 위험상황${hazActive?' ▾':''}</div>
    </div>
    <div onclick="setBoardView('alert')" style="flex:1;background:${activeOp?'rgba(79,168,208,.12)':'rgba(39,174,96,.08)'};border:1px solid ${alertActive?(activeOp?'rgba(79,168,208,.9)':'rgba(39,174,96,.75)'):(activeOp?'rgba(79,168,208,.45)':'rgba(39,174,96,.25)')};border-radius:12px;padding:12px 16px;text-align:center;cursor:pointer;transition:all .15s;${alertActive?'box-shadow:inset 0 0 0 2px rgba(79,168,208,.3);':''}">
      <div style="font-size:30px;font-weight:900;color:${activeOp?'#4fa8d0':'#27ae60'};">${activeOp?opRespCnt:0}</div>
      <div style="font-size:12px;color:${alertActive?'#e0edf8':'rgba(255,255,255,.5)'};font-weight:${alertActive?'700':'400'};">🌀 ${activeOp?'특보 응소':'특보운영'}${alertActive?' ▾':''}</div>
    </div>
  </div>
  ${trailCtrlCnt||trailWarnCnt?`<div onclick="setBoardView('trail')" style="display:flex;align-items:center;gap:12px;background:rgba(231,76,60,.1);border:1px solid ${trailActive?'rgba(231,76,60,.85)':'rgba(231,76,60,.35)'};border-radius:12px;padding:10px 16px;margin-bottom:10px;cursor:pointer;">
    <div style="font-size:26px;font-weight:900;color:#e74c3c;">${trailCtrlCnt}</div>
    <div>
      <div style="font-size:13px;font-weight:800;color:#e0edf8;">🚧 탐방로 통제 중${trailActive?' ▾':''}</div>
      <div style="font-size:11px;color:#ff9e80;margin-top:2px;">통제 ${trailCtrlCnt}구간${trailWarnCnt?' · 주의 '+trailWarnCnt+'구간':''}</div>
    </div>
  </div>`:''}`;
  if(trailActive){
    const zones=[...new Set(SEORAK_TRAILS.map(t=>t.zone))];
    html+=`<div style="background:#0a1626;border:1.5px solid rgba(231,76,60,.4);border-radius:14px;padding:16px 18px;">
      <div style="font-size:16px;font-weight:900;color:#e74c3c;margin-bottom:12px;">🚧 탐방로 통제 현황</div>`;
    zones.forEach(z=>{
      const zTrails=SEORAK_TRAILS.filter(t=>t.zone===z);
      html+=`<div style="font-size:10px;color:#5a7e98;font-weight:800;letter-spacing:.5px;margin:8px 0 4px;">${z.toUpperCase()}</div>`;
      zTrails.forEach(t=>{
        const st=(ts[t.id]||{}).status||'개방';
        const col=TRAIL_STATUS_COLORS[st]||'#27ae60';
        html+=`<div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-top:1px solid rgba(255,255,255,.04);">
          <span style="width:8px;height:8px;border-radius:50%;background:${col};flex-shrink:0;box-shadow:0 0 6px ${col}66;"></span>
          <span style="font-size:12px;color:${st==='개방'?'rgba(255,255,255,.55)':'#e0edf8'};flex:1;">${_esc(t.name)}</span>
          <span style="font-size:11px;font-weight:800;color:${col};">${st}</span>
        </div>`;
      });
    });
    html+=`</div>`;
  } else if(alertActive){
    if(!activeOp){
      html+=`<div style="text-align:center;padding:50px 0 30px;font-size:17px;color:rgba(255,255,255,.3);">✅ 진행중인 특보운영 없음</div>`;
    } else {
      const al=_opAlerts(activeOp);
      const chips=al.map(a=>`<span style="display:inline-block;font-size:13px;font-weight:800;color:#7dd3fa;background:rgba(79,168,208,.14);border:1px solid rgba(79,168,208,.3);border-radius:7px;padding:4px 10px;margin:0 5px 5px 0;">${_esc(a.type)} ${_stageShort(a.stage)}</span>`).join('');
      const elp=_elapsedStr(activeOp.startedAt);
      const resps=activeOp.responders||[];
      const groupRows=ALERT_GROUPS.map(g=>{
        const locs=g.stations.map(s=>s.loc);
        const list=resps.filter(r=>locs.includes(r.loc||'사무소'));
        return {name:g.name,ico:g.ico,cnt:list.length,names:list.map(r=>_esc(r.name)).join(', ')};
      });
      const reps=(activeOp.reports||[]).slice().sort((a,b)=>(b.at||0)-(a.at||0)).slice(0,6);
      html+=`<div style="background:#0a1626;border:1.5px solid rgba(79,168,208,.4);border-radius:14px;padding:16px 18px;margin-bottom:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:11px;">
          <span style="font-size:18px;font-weight:900;color:#7dd3fa;"><span class="ao-pulse" style="display:inline-block;vertical-align:middle;margin-right:5px;"></span>특보운영 중</span>
          ${elp?`<span class="js-elapsed" data-d="${_esc(activeOp.startedAt)}" style="font-size:15px;font-weight:800;color:#f0a500;font-family:monospace;">⏱ ${elp}</span>`:''}
        </div>
        <div style="margin-bottom:13px;">${chips||'<span style="font-size:12px;color:#456a85;">발령된 특보 없음</span>'}</div>
        <div style="font-size:13px;color:#9bbdd4;font-weight:700;margin-bottom:4px;">👤 분소별 응소 (총 ${resps.length}명)</div>
        ${groupRows.map(gr=>`<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-top:1px solid rgba(255,255,255,.05);">
          <span style="font-size:13px;font-weight:700;color:#cfe2f2;min-width:118px;flex-shrink:0;">${gr.ico} ${_esc(gr.name)}</span>
          <span style="font-size:14px;font-weight:800;color:${gr.cnt?'#5dbf8a':'rgba(255,255,255,.22)'};min-width:42px;flex-shrink:0;">${gr.cnt}명</span>
          <span style="font-size:12px;color:#7a9cb8;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${gr.names||'-'}</span>
        </div>`).join('')}
        ${(()=>{
          // 체류인원 요약 — 대피소(shelter) 위치만 집계
          const shelterLocs=new Set(ALERT_STATIONS.filter(s=>s.shelter).map(s=>s.loc));
          const occMap={};(activeOp.occupancy||[]).filter(o=>shelterLocs.has(o.loc||'')).forEach(o=>{const k=o.loc;if(!occMap[k]||(o.at||0)>(occMap[k].at||0))occMap[k]=o;});
          const occEntries=Object.entries(occMap);
          if(!occEntries.length)return'';
          const totalV=occEntries.reduce((s,[,o])=>s+(o.visitors||0),0);
          return`<div style="font-size:13px;color:#9bbdd4;font-weight:700;margin:13px 0 4px;">⛺ 대피소 체류인원 (탐방객 총 ${totalV}명)</div>
          ${occEntries.map(([loc,o])=>`<div style="display:flex;gap:8px;font-size:12px;padding:4px 0;border-top:1px solid rgba(255,255,255,.04);">
            <span style="color:#5a7e98;min-width:100px;flex-shrink:0;">${_esc(_stationLabel(loc))}</span>
            <span style="color:#7ec8a0;font-weight:700;">직원 ${o.staff??'-'}명</span>
            <span style="color:#a8cdf5;font-weight:700;">탐방객 ${o.visitors??'-'}명</span>
            <span style="color:#4a7090;font-size:10px;">${(o.time||'').slice(11,16)}</span>
          </div>`).join('')}`;
        })()}
        ${reps.length?`<div style="font-size:13px;color:#9bbdd4;font-weight:700;margin:13px 0 4px;">📊 최근 관측 (누적)</div>
          ${reps.map(r=>`<div style="display:flex;gap:10px;font-size:12px;padding:4px 0;border-top:1px solid rgba(255,255,255,.04);">
            <span style="color:#5a7e98;min-width:96px;flex-shrink:0;">${_esc(_stationLabel(r.loc))}</span>
            <span style="color:#7a9cb8;min-width:46px;flex-shrink:0;">${_esc((r.time||'').slice(11,16))}</span>
            <span style="color:#cfe2f2;font-weight:700;">${r.snow!=null&&r.snow!==''?'❄️ '+_esc(r.snow)+'cm  ':''}${r.rain!=null&&r.rain!==''?'🌧️ '+_esc(r.rain)+'mm':''}</span>
          </div>`).join('')}`:''}
        ${(()=>{
          // 탐방로 통제 현황 요약
          const ts=DB.g('trailStatus')||{};
          const ctrl=SEORAK_TRAILS.filter(t=>(ts[t.id]||{}).status==='통제');
          const warn=SEORAK_TRAILS.filter(t=>(ts[t.id]||{}).status==='주의');
          if(!ctrl.length&&!warn.length)return'';
          return`<div style="font-size:13px;color:#e67e22;font-weight:700;margin:13px 0 4px;">🚧 탐방로 통제 ${ctrl.length}구간${warn.length?' · 주의 '+warn.length+'구간':''}</div>
          ${ctrl.map(t=>`<div style="font-size:11px;color:#ff9e80;padding:2px 0;">🔴 통제 — ${_esc(t.name)}</div>`).join('')}
          ${warn.map(t=>`<div style="font-size:11px;color:#ffa040;padding:2px 0;">🟠 주의 — ${_esc(t.name)}</div>`).join('')}`;
        })()}
        <button onclick="closeBoard();openApp('alert');" style="width:100%;margin-top:13px;padding:9px;border-radius:9px;border:1px solid rgba(79,168,208,.35);background:rgba(79,168,208,.1);color:#4fa8d0;font-size:13px;font-weight:700;cursor:pointer;">🌀 특보운영 상세 열기</button>
      </div>`;
    }
  } else if(hazActive){
    if(!haz.length){
      html+=`<div style="text-align:center;padding:50px 0 30px;font-size:17px;color:rgba(255,255,255,.3);">✅ 미조치 위험상황 없음</div>`;
    }
    haz.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')).forEach(h=>{
      const hasCoord=!!(h.lat&&h.lng);
      html+=`<div onclick="_boardFocusHaz(${h.id})" style="background:#0a1626;border:1.5px solid rgba(230,126,34,.35);border-radius:14px;padding:13px 16px;margin-bottom:10px;cursor:pointer;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
          <div style="font-size:16px;font-weight:800;color:#e0edf8;">${h.hazType?.split(' ')[0]||'⚠️'} ${_esc((h.hazType||'위험상황').replace(/^\S+\s/,''))||'위험상황'}</div>
          <span style="flex-shrink:0;font-size:11px;font-weight:800;color:#e67e22;background:rgba(230,126,34,.14);border-radius:6px;padding:3px 8px;">${_esc(h.hazStatus||'미조치')}</span>
        </div>
        <div style="font-size:13px;color:#7aa8c8;margin-top:5px;">📍 ${_esc(h.loc||'위치 미상')}${h.danger?' · '+_esc(h.danger):''}${h.date?' · '+h.date:''}</div>
        ${h.desc?`<div style="font-size:12px;color:#7a9cb8;margin-top:6px;line-height:1.5;">${_esc((h.desc||'').slice(0,80))}${(h.desc||'').length>80?'…':''}</div>`:''}
        ${!hasCoord?`<div style="font-size:11px;color:rgba(255,255,255,.3);margin-top:6px;">좌표 없음 — 지도 이동 불가</div>`:''}
      </div>`;
    });
  } else {
  if(!ongoing.length){
    html+=`<div style="text-align:center;padding:50px 0 30px;font-size:17px;color:rgba(255,255,255,.3);">✅ 진행중인 구조 상황 없음</div>`;
  }
  ongoing.forEach(r=>{
    const elp=_elapsedStr(r.date);
    const ti=RES_TYPES[r.type]||RES_TYPES['기타'];
    const lastLog=(r.wpLog||[]).slice(-1)[0];
    html+=`<div style="background:#0a1626;border:1.5px solid rgba(192,57,43,.35);border-radius:14px;padding:14px 16px;margin-bottom:12px;">
      <div onclick="_boardFocus(${r.id})" style="cursor:pointer;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:6px;margin-bottom:4px;">
          <div style="font-size:18px;font-weight:800;color:#e0edf8;">${ti.ico} ${_esc(r.title)}</div>
          ${elp?`<div class="js-elapsed" data-d="${_esc(r.date)}" style="font-size:16px;font-weight:800;color:#f0a500;font-family:monospace;">⏱ ${elp}</div>`:''}
        </div>
        <div style="font-size:13px;color:#7aa8c8;margin-bottom:12px;">${_esc(r.type)} · ${_esc(_resLocLabel(r))} · ${r.date}</div>
        ${(r.teams&&r.teams.length)?r.teams.map((t,ti2)=>{
          const col=TEAM_COLORS[ti2%TEAM_COLORS.length];
          const si=_teamStageIdx(t);
          const done=_teamDone(t);
          const total=Math.max(t.wps.length-1,1);
          const pct=Math.round((t.wpIdx/total)*100);
          const cur=t.wps[t.wpIdx]||{};
          const curName=(cur.code?cur.code+' ':'')+(cur.name||'').slice(0,16);
          return `<div style="display:flex;align-items:center;gap:12px;padding:7px 0;border-top:1px solid rgba(255,255,255,.05);">
            <span style="font-size:14px;font-weight:800;color:${col};flex-shrink:0;min-width:110px;">${_teamIco(t)} ${_esc(t.name)}</span>
            <div style="flex:1;height:8px;background:rgba(255,255,255,.07);border-radius:4px;overflow:hidden;"><div style="height:100%;width:${pct}%;background:${col};border-radius:4px;"></div></div>
            <span style="font-size:12px;color:rgba(255,255,255,.68);flex-shrink:0;min-width:130px;">📍 ${_esc(curName||'-')}</span>
            <span style="font-size:12px;font-weight:800;color:${done?'#27ae60':stageCol[si]};flex-shrink:0;">${done?'✓ 완료':stageLbl[si]}</span>
          </div>`;
        }).join(''):'<div style="font-size:12px;color:rgba(255,255,255,.3);padding:6px 0;">출동팀 미편성</div>'}
        <div style="display:flex;justify-content:space-between;margin-top:8px;font-size:12px;color:#7aa8c8;">
          <span>${lastLog?`최근: ${lastLog.time} ${_esc(lastLog.teamName)} ${_esc(lastLog.code||'')} 통과`:''}</span>
          <span>${r.handover&&r.handover.to?`🤝 인계: ${_esc(r.handover.to)}`:''}</span>
        </div>
        ${(r.teams&&r.teams.length>0&&r.teams.every(t=>_teamDone(t)))?`<div style="background:rgba(39,174,96,.12);border:1px solid rgba(39,174,96,.35);border-radius:8px;padding:8px 12px;margin-top:8px;text-align:center;font-size:13px;font-weight:800;color:#27ae60;">🏁 전 팀 완료 — 상황 종료 대기중</div>`:''}
      </div>
      <div style="display:flex;gap:7px;margin-top:11px;padding-top:10px;border-top:1px solid rgba(255,255,255,.07);">
        <button onclick="_boardOpenDetail(${r.id},'advanced')" style="flex:1;padding:8px 0;border-radius:9px;border:1px solid rgba(79,168,208,.35);background:rgba(79,168,208,.1);color:#4fa8d0;font-size:12px;font-weight:700;cursor:pointer;">📍 타임라인</button>
        <button onclick="_boardOpenDetail(${r.id},'write')" style="flex:1;padding:8px 0;border-radius:9px;border:1px solid rgba(79,168,208,.2);background:rgba(79,168,208,.06);color:#7abcd4;font-size:12px;font-weight:700;cursor:pointer;">📄 보고서</button>
      </div>
    </div>`;
  });
  }
  // ── 하단: 사고 목록 (뷰와 무관하게 항상 표시) ──
  const _accRow=r=>{
    const og=r.status==='ongoing';
    const ti=RES_TYPES[r.type]||RES_TYPES['기타'];
    const dd=(r.date||'').slice(5,10), tm=(r.date||'').slice(11,16);
    return `<div onclick="_boardOpenDetail(${r.id},'${og?'advanced':'write'}')" style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:rgba(255,255,255,.02);border-radius:8px;margin-bottom:4px;font-size:12px;cursor:pointer;border-left:3px solid ${og?'#e05050':'#27ae60'};">
      <span style="flex-shrink:0;font-size:9px;font-weight:800;color:${og?'#e05050':'#27ae60'};background:${og?'rgba(224,80,80,.12)':'rgba(39,174,96,.12)'};border-radius:5px;padding:2px 6px;">${og?'진행중':'종료'}</span>
      <span style="flex:1;color:rgba(255,255,255,.7);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${ti.ico} ${_esc(r.title)}</span>
      <span style="flex-shrink:0;color:#6a93b5;font-family:monospace;">${dd} ${tm}</span>
    </div>`;
  };
  if(alertActive){
    // 특보 뷰 하단: 분소별 누적 관측 + 최근 종료된 특보운영
    if(activeOp){
      const cum={};
      (activeOp.reports||[]).forEach(r=>{
        const loc=r.loc||'사무소';if(!cum[loc])cum[loc]={snow:0,rain:0};
        if(r.snow!=null&&r.snow!=='')cum[loc].snow+=parseFloat(r.snow)||0;
        if(r.rain!=null&&r.rain!=='')cum[loc].rain+=parseFloat(r.rain)||0;
      });
      const locs=Object.keys(cum);
      html+=`<div style="margin-top:20px;font-size:12px;color:#8ab0c8;font-weight:700;margin-bottom:6px;">📈 누적 관측 (분소별)</div>`;
      if(!locs.length){
        html+=`<div style="padding:10px 12px;background:rgba(255,255,255,.02);border-radius:8px;font-size:12px;color:rgba(255,255,255,.42);">관측 보고 없음</div>`;
      } else {
        locs.forEach(loc=>{const c=cum[loc];
          html+=`<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:rgba(255,255,255,.02);border-radius:8px;margin-bottom:4px;font-size:12px;border-left:3px solid #4fa8d0;">
            <span style="flex:1;color:rgba(255,255,255,.7);">${_esc(_stationLabel(loc))}</span>
            <span style="color:#cfe2f2;font-weight:700;">${c.snow?'❄️ '+c.snow.toFixed(1)+'cm  ':''}${c.rain?'🌧️ '+c.rain.toFixed(1)+'mm':''}${(!c.snow&&!c.rain)?'-':''}</span>
          </div>`;
        });
      }
    }
    const closedOps=aops.filter(o=>o.closedAt).sort((a,b)=>(b.startedAtMs||0)-(a.startedAtMs||0)).slice(0,6);
    if(closedOps.length){
      html+=`<div style="margin-top:18px;font-size:12px;color:#8ab0c8;font-weight:700;margin-bottom:6px;">📜 최근 종료된 특보운영 <span style="color:#5a7e98;font-weight:400;">(${closedOps.length}건)</span></div>`;
      closedOps.forEach(o=>{const al=_opAlerts(o);const lbl=al.map(a=>_esc(a.type)+_stageShort(a.stage)).join(', ')||'특보';
        html+=`<div onclick="openAlertHistory(${o.id})" style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:rgba(255,255,255,.02);border-radius:8px;margin-bottom:4px;font-size:12px;cursor:pointer;border-left:3px solid #5d82a0;">
          <span style="flex:1;color:rgba(255,255,255,.6);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">🌀 ${lbl}</span>
          <span style="flex-shrink:0;color:#6a93b5;font-family:monospace;">${(o.startedAt||'').slice(5,10)}~${(o.closedAt||'').slice(5,10)}</span>
        </div>`;
      });
    }
  } else if(hazActive){
    // 위험 뷰 하단: 조치완료된 위험상황
    const doneHaz=(DB.g('hazards')||[]).filter(h=>h.hazStatus&&h.hazStatus!=='미조치'&&h.hazStatus!=='조치중').sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,15);
    html+=`<div style="margin-top:20px;font-size:12px;color:rgba(255,255,255,.35);font-weight:700;margin-bottom:6px;">✅ 조치완료 위험상황 <span style="color:rgba(255,255,255,.25);font-weight:400;">(${doneHaz.length}건)</span></div>`;
    if(!doneHaz.length){
      html+=`<div style="padding:10px 12px;background:rgba(255,255,255,.02);border-radius:8px;font-size:12px;color:rgba(255,255,255,.3);">조치완료된 위험상황 없음</div>`;
    } else {
      doneHaz.forEach(h=>{
        html+=`<div onclick="_boardFocusHaz(${h.id})" style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:rgba(255,255,255,.02);border-radius:8px;margin-bottom:4px;font-size:12px;cursor:pointer;border-left:3px solid #27ae60;">
          <span style="flex-shrink:0;font-size:9px;font-weight:800;color:#27ae60;background:rgba(39,174,96,.12);border-radius:5px;padding:2px 6px;">${_esc(h.hazStatus)}</span>
          <span style="flex:1;color:rgba(255,255,255,.7);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${h.hazType?.split(' ')[0]||'⚠️'} ${_esc((h.hazType||'위험상황').replace(/^\S+\s/,''))||'위험상황'} · ${_esc(h.loc||'위치미상')}</span>
          <span style="flex-shrink:0;color:#6a93b5;font-family:monospace;">${(h.date||'').slice(5,10)}</span>
        </div>`;
      });
    }
  } else {
    // 구조 뷰 하단: 오늘/최근 사고 목록
    html+=`<div style="margin-top:20px;font-size:12px;color:rgba(255,255,255,.35);font-weight:700;margin-bottom:6px;">📋 오늘 사고 목록 <span style="color:rgba(255,255,255,.25);font-weight:400;">(${_td} · ${todayList.length}건)</span></div>`;
    if(!todayList.length){
      html+=`<div style="padding:10px 12px;background:rgba(255,255,255,.02);border-radius:8px;font-size:12px;color:rgba(255,255,255,.3);">오늘 접수된 사고 없음</div>`;
    }else{
      todayList.forEach(r=>{html+=_accRow(r);});
    }
    if(recentList.length){
      html+=`<div style="margin-top:18px;font-size:12px;color:rgba(255,255,255,.35);font-weight:700;margin-bottom:6px;">🕑 최근 사고 목록 <span style="color:rgba(255,255,255,.25);font-weight:400;">(최신순 ${recentList.length}건)</span></div>`;
      recentList.forEach(r=>{html+=_accRow(r);});
    }
  }
  html+=`<div style="text-align:center;margin-top:18px;font-size:10px;color:rgba(255,255,255,.18);">10초마다 자동 갱신 · ${APP_VER}</div>`;
  body.innerHTML=html;
  if(_boardMap)_renderBoardPins();
}

function goHome(){
  const ov=document.getElementById('adminLoginOverlay');
  if(ov)ov.style.display='none';
  showV('v-home');
  document.getElementById('appHdr').style.display='none';
  document.getElementById('bnav').style.display='none';
  closeDB();updateSummary();
  history.pushState({view:'home'},'','');
}
function viewOnMap(lat,lng){
  openApp('rescue');
  setTimeout(function(){
    try{
      if(mapR){mapR.setCenter(new kakao.maps.LatLng(lat,lng));mapR.setLevel(4);}
      renderRescueMap();
    }catch(e){}
  },200);
}
function openApp(mode){
  if(isExternal()&&['inspect','stats','admin','settings','alert'].includes(mode)){toast('⚠️ 외부기관 계정은 해당 메뉴에 접근할 수 없습니다');return;}
  // 작성 폼에서 다른 메뉴로 이동: 미저장 입력은 임시저장만 남기고 작성모드 해제
  if(window._reportMode==='form'){try{_saveDraftNow();}catch(e){}window._reportMode='';clearInterval(_draftAutoTimer);}
  curApp=mode;
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('on'));
  document.getElementById('appHdr').style.display='block';
  const bn=document.getElementById('bnav');
  function setNv(){[1,2,3].forEach(i=>document.getElementById('nv'+i).classList.remove('on'));document.getElementById('nv1').classList.add('on');}
  if(mode==='rescue'){
    document.getElementById('topTitle').textContent='재난/구조 관리';
    document.getElementById('nvl2').textContent='목록';
    // 세션 첫 진입: 기본 필터를 '진행중'으로 (현재 사고만 먼저 보여줌 — 이후 🚨구조/진행중 버튼으로 조절)
    if(!window._resStatusDefaulted){window._resStatusDefaulted=true;resStatusF=new Set(['진행중']);_persistFilters();}
    showV('v-rescue-map');bn.style.display='flex';setNv();updateRescueCross();
    history.pushState({view:mode},'','');
    rMaps();setTimeout(()=>{try{renderRescueMap();if(mapR&&!window._mapRInited){window._mapRInited=true;mapR.setCenter(new kakao.maps.LatLng(DC.lat,DC.lng));mapR.setLevel(9);}}catch(e){renderResList();}},200);
  } else if(mode==='inspect'){
    document.getElementById('topTitle').textContent='시설물 점검';
    document.getElementById('nvl2').textContent='목록';
    showV('v-inspect-map');bn.style.display='flex';setNv();updateInspectCross();
    history.pushState({view:mode},'','');
    rMaps();setTimeout(()=>{try{renderInspectMap();if(mapI&&!window._mapIInited){window._mapIInited=true;mapI.setCenter(new kakao.maps.LatLng(DC.lat,DC.lng));mapI.setLevel(9);}}catch(e){renderFacList();}},200);
  } else if(mode==='alert'){
    document.getElementById('topTitle').textContent='특보운영';
    _alertTab=1; // 진입 시 항상 목록 탭부터
    bn.style.display='none';showV('v-alert');history.pushState({view:mode},'','');renderAlertView();
  } else if(mode==='admin'){
    // 관리자 카카오 계정은 비밀번호 생략: ①소유자 ②허용목록(_acl) 관리자 ③토큰 admin 클레임
    const _au=DB.g('currentUser')||{};
    const _owner=DB.g('adminOwnerKakaoId');
    const _aclAdmin=!!(_au.kakaoId&&_getAcl().admins.indexOf(String(_au.kakaoId))>=0);
    if((_au.kakaoId&&_owner&&String(_au.kakaoId)===String(_owner))||_aclAdmin||isAdminUser()){
      localStorage.setItem('_adminAuthed','1');
    }
    if(localStorage.getItem('_adminAuthed')!=='1'){
      const ov=document.getElementById('adminLoginOverlay');
      ov.style.display='flex';
      setTimeout(()=>document.getElementById('adminLoginPw').focus(),200);
      return;
    }
    // 이미 인증된 기기에서 소유자 미등록이면 현재 카카오 계정을 소유자로 등록
    if(_au.kakaoId&&!_owner)DB.s('adminOwnerKakaoId',String(_au.kakaoId));
    document.getElementById('topTitle').textContent='관리자 전용';
    bn.style.display='none';showV('v-admin');history.pushState({view:mode},'','');admTab('ctrl',document.querySelector('.adm-tab'));
  } else if(mode==='settings'){
    document.getElementById('topTitle').textContent='내 설정';
    bn.style.display='none';showV('v-settings');history.pushState({view:mode},'','');_settingsTab='info';document.getElementById('stab-info').classList.add('on');document.getElementById('stab-noti').classList.remove('on');document.getElementById('stab-info-sec').classList.add('on');document.getElementById('stab-noti-sec').classList.remove('on');renderSettings();
  } else if(mode==='stats'){
    document.getElementById('topTitle').textContent='전체 통계';
    bn.style.display='none';showV('v-stats');history.pushState({view:mode},'','');renderFullStats();
  }
}
function switchTab(idx,el){
  if(isExternal()&&idx!==1){toast('⚠️ 외부기관 계정은 지도만 이용 가능합니다');return;}
  [1,2,3].forEach(i=>document.getElementById('nv'+i).classList.remove('on'));if(el)el.classList.add('on');closeDB();
  if(curApp==='rescue'){
    if(idx===1){showV('v-rescue-map');rMaps();updateRescueCross();try{renderRescueMap();}catch(e){}} // 복귀 시 핀 최신화
    else{if(_rFocusResId)exitFocusMode();if(idx===2){showV('v-rescue-list');renderResList();}else{showV('v-rescue-stats');renderRescueStats();}}
  } else if(curApp==='inspect'){
    if(idx===1){showV('v-inspect-map');rMaps();updateInspectCross();try{renderInspectMap();}catch(e){}}
    else if(idx===2){showV('v-inspect-list');renderFacList();}
    else{showV('v-inspect-stats');renderInspectStats();}
  }
}

// ══════════════════════════════════════════
// 인증 (로그인 / 게스트 / 로그아웃)
// ══════════════════════════════════════════


// 변경이력
const _CL=[
  {ver:'v1.2',date:'2026.05.15',summary:'카카오 로그인·팀기능 개선·타임라인 자동선택 등 6건',items:['카카오 로그인 / 게스트 / 개발자 모드','공단 초동 출동팀 자동체크 (본인 이름)','추가팀 복수 지원 (추가1팀·2팀·3팀)','소방 유관기관 동적 추가 기능','타임라인 누가 항목 자동선택','환동해산악구조대 당직팀 자동계산']},
  {ver:'v1.1',date:'2026.05.10',summary:'타임라인 개편·유관기관 추가·APK 자동화·버그 수정',items:['구조 타임라인 카테고리 정리','유관기관 출동 섹션 추가','APK 빌드 자동화 (GitHub Actions)','무한 로그인 버그 수정']},
  {ver:'v1.0',date:'2026.05.01',summary:'설악산 현장관리 앱 최초 출시',items:['설악산 현장관리 앱 최초 출시','재난/구조 접수 및 보고 기능','시설물 점검 관리','설악위키 기능','카카오 지도 연동']},
];
function openChangelog(){
  const m=document.getElementById('changelogModal');
  if(!m) return;
  document.getElementById('changelogBody').innerHTML=_CL.map((v,i)=>`
    <div style="margin-bottom:5px;border-radius:10px;border:1px solid rgba(255,255,255,.07);overflow:hidden;">
      <div onclick="toggleCL(${i})" style="display:flex;align-items:center;gap:8px;padding:10px 12px;cursor:pointer;background:#0d1f35;user-select:none;">
        <span style="background:#1a4a6e;color:#4fa8d0;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;flex-shrink:0;">${v.ver}</span>
        <span style="font-size:10px;color:#4a7090;flex-shrink:0;">${v.date}</span>
        <span style="font-size:10px;color:#7a9cb8;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${v.summary}</span>
        <span id="clArr${i}" style="color:#4a7090;font-size:11px;flex-shrink:0;transition:transform .2s;">▾</span>
      </div>
      <div id="clBody${i}" style="display:none;padding:8px 12px 10px;background:#080f1c;">
        ${v.items.map(it=>`<div style="font-size:11px;color:#b8d4e8;padding:2px 0 2px 4px;">· ${it}</div>`).join('')}
      </div>
    </div>`).join('');
  m.style.display='flex';
}
function toggleCL(i){
  const b=document.getElementById('clBody'+i);
  const a=document.getElementById('clArr'+i);
  if(!b) return;
  const open=b.style.display==='block';
  b.style.display=open?'none':'block';
  if(a) a.style.transform=open?'':'rotate(-180deg)';
}
function closeChangelog(){
  const m=document.getElementById('changelogModal');
  if(m){m.style.display='none';}
}

// 추가팀 복수 지원
let _extraTeams=[]; // [{teamName, members:[]}]
const _ROCK_LOCS=['천화대','흑범길','염라길','석주길','적벽','장군봉','삼형제길','유선대','울산암벽','하나되는길','돌잔치길','나들이길','소토왕골암장','한편의시를위한길','솜다리의추억','경원대길','4인의우정길','별을따는소년들','미륵장군봉','몽유도원도','아갈바위','칠형제봉'];
const _ICE_LOCS=['토왕성폭포','두줄폭포','형제폭포','50m/100m폭포','건폭포','소승폭포','실폭포'];

// ── ZZ-NN 구역 관리 체계 ─────────────────────────────────
// lat/lng: 각 구역 탐방로 중심점 (실측 후 수정 권장)
// ── 표지판 번호(ZZ-NN) 기준 거점 마스터 테이블 ───────────────
// 형식: ZZ → [[max_NN, primary_base, alt_base?], ...]
// nn <= max_NN 인 첫 번째 규칙 적용
const SIGN_BASE_TABLE = {
  '01': [[99, '소공원']],
  '02': [[7,  '소공원'], [99, '백담']],
  '03': [[1,  '소공원'], [4,  '소공원','백담'], [99, '소공원','백담']],
  '04': [[99, '소공원']],
  '05': [[99, '소공원']],
  '06': [[99, '남설악']],
  '07': [[3,  '약수터'], [99, '용소']],
  '08': [[3,  '용소'],   [99, '흘림골']],
  '09': [[99, '한계령']],
  '10': [[99, '백담']],
  '11': [[10, '한계산성'], [99, '남교리']],
  '12': [[8,  '한계산성'], [99, '백담']],
  '13': [[4,  '소공원'],   [99, '백담']],
  '14': [[99, '점봉산']],
};

// 구역 참조명 (표시 보조용 — 라우팅 결정에 사용 안 함)
const ZONE_NAMES = {
  '01':'천불동계곡','02':'천불동→대청봉','03':'공룡능선',
  '04':'소공원 서측','05':'신흥사·비선대','06':'오색',
  '07':'주전골','08':'흘림골','09':'한계령 방면',
  '10':'백담계곡','11':'장수대·한계령','12':'한계산성·백담 분기',
  '13':'귀때기청봉','14':'점봉산',
};
// 위치필터 칩 라벨: '01 (천불동계곡)'
function _zoneLbl(z){return ZONE_NAMES[z]?z+' ('+ZONE_NAMES[z]+')':z;}
// 시설물이 해당 존(zz)에 속하는지: 코드(NN-?? 또는 NN) prefix로 판정 (substring 오매칭 방지)
function _facInZone(f,z){
  const c=((f&&(f.loc||''))||'').trim()||(((f&&f.name)||'').match(/^\d+-\d+/)||[''])[0];
  return c.startsWith(z+'-')||c===z;
}

// 표지판 코드(ZZ-NN) → 거점 {primary, alt} 반환 ← 모든 라우팅의 단일 진입점
function getBaseForSign(signCode){
  var m=(signCode||'').match(/^(\d{2})-(\d{2,3})$/);
  if(!m)return null;
  var zz=m[1], nn=parseInt(m[2]);
  var rules=SIGN_BASE_TABLE[zz];
  if(!rules)return null;
  for(var i=0;i<rules.length;i++){
    if(nn<=rules[i][0])return{primary:rules[i][1],alt:rules[i][2]||null};
  }
  return null;
}

// GPS → 가장 가까운 표지판 전체 정보 반환
function _nearestSignFull(lat,lng){
  if(!_cachedFullSigns){
    _cachedFullSigns=(DB.g('facilities')||[]).filter(function(f){
      return f.lat&&f.lng&&f.name&&f.type&&f.type.indexOf('다목적위치표지판')>=0;
    });
  }
  var best=null,bestD=Infinity;
  _cachedFullSigns.forEach(function(f){var d=_haversine(lat,lng,f.lat,f.lng);if(d<bestD){bestD=d;best=f;}});
  if(!best||bestD>5000)return null;
  var code=(best.name.match(/^\d{2}-\d{2,3}/)||[best.name.slice(0,6)])[0];
  var zm=code.match(/^(\d{2})-/);
  return{code:code,name:best.name,dist:Math.round(bestD),zoneName:zm?ZONE_NAMES[zm[1]]||'':''};
}


// Zone 뱃지: "ZZ-NN → 거점명 (Xm)" 표지판 코드 최우선
function _updateZoneBadge(lat,lng,elId){
  var el=document.getElementById(elId);if(!el)return;
  var s=_nearestSignFull(lat,lng);
  if(!s){el.style.display='none';return;}
  var base=getBaseForSign(s.code);
  var baseName=base?((SEORAK_BASES[base.primary]||{}).name||base.primary):'관리자 확인 필요';
  var shortBase=baseName.replace('탐방지원센터','센터').replace('설악산국립공원사무소','사무소');
  var label=s.code+' → '+shortBase;
  if(base&&base.alt){var altName=((SEORAK_BASES[base.alt]||{}).name||base.alt).replace('탐방지원센터','센터');label+=' / '+altName+' 선택';}
  if(s.dist!==null)label+=' ('+s.dist+'m)';
  el.textContent=label;el.style.display='block';
}

// 하위 호환: getZoneId — 표지판 코드에서 ZZ 추출
function getZoneId(lat,lng){
  var s=_nearestSignFull(lat,lng);
  if(s){var m=(s.code||'').match(/^(\d{2})-/);if(m)return m[1];}
  return null;
}

// 하위 호환: getBestBase — getBaseForSign 위임
function getBestBase(zz,nn){
  var code=String(parseInt(zz)||0).padStart(2,'0')+'-'+String(parseInt(nn)||1).padStart(2,'0');
  return getBaseForSign(code)||{primary:'소공원'};
}


const SEORAK_BASES = {
  '소공원':   {name:'소공원탐방지원센터',      lat:38.1724, lng:128.4794},
  '백담':     {name:'백담탐방지원센터',        lat:38.1501, lng:128.3897},
  '남설악':   {name:'남설악탐방지원센터',      lat:38.0242, lng:128.5124},
  '용소':     {name:'용소탐방지원센터',        lat:38.0430, lng:128.5295},
  '흘림골':   {name:'흘림골탐방지원센터',      lat:38.0477, lng:128.5824},
  '약수터':   {name:'오색약수탐방지원센터',    lat:38.0310, lng:128.5215},
  '한계령':   {name:'한계령탐방지원센터',      lat:38.0703, lng:128.3143},
  '한계산성': {name:'한계산성분소',            lat:38.0929, lng:128.3157},
  '남교리':   {name:'남교리탐방지원센터',      lat:38.1037, lng:128.3587},
  '점봉산':   {name:'점봉산탐방지원센터',      lat:38.0913, lng:128.5621},
  '공단':     {name:'설악산국립공원사무소',    lat:38.2064, lng:128.4638},
  '대청':     {name:'대청봉대피소',           lat:38.1195, lng:128.4649},
};
const _SOKCHO_HOSP = {name:'속초의료원', lat:38.2080, lng:128.5866};

// 과/분소 → 출발 허브
const DEPT_HUBS = {
  '행정과':       '공단',
  '재난안전과':   '공단',
  '탐방시설과':   '공단',
  '자원보전과':   '공단',
  '특수산악구조대':'소공원',
  '대청분소':     '대청',
  '백담분소':     '백담',
  '오색분소':     '남설악',
  '한계산성분소': '한계산성',
  '점봉산분소':   '점봉산',
};

// 현재 사용자의 허브 좌표 반환
function getMyHub() {
  const u=DB.g('currentUser')||{};
  const key=DEPT_HUBS[u.dept||'']||'공단';
  return SEORAK_BASES[key]||SEORAK_BASES['공단'];
}


function _showHeliInfo(lat,lng){
  const coords=lat.toFixed(5)+', '+lng.toFixed(5);
  if(navigator.clipboard){
    navigator.clipboard.writeText(coords).then(function(){toast('🚁 헬기 좌표 복사: '+coords);}).catch(function(){toast('🚁 GPS: '+coords);});
  } else { toast('🚁 GPS: '+coords); }
}

// 구조 팝업용 출동/하산/대피/헬기 버튼 HTML 생성 (산악 특화)
function _buildResRouteHtml(data){
  const locStr=(data.location||data.title||'');
  const locM=locStr.match(/(\d{2})-(\d{2,3})/);
  let signCode=locM?locM[0]:null;
  if(!signCode&&data.lat&&data.lng){
    const s=_nearestSignFull(data.lat,data.lng);
    if(s)signCode=s.code;
  }
  const baseInfo=signCode?getBaseForSign(signCode):null;
  const pb=baseInfo?SEORAK_BASES[baseInfo.primary]:null;
  const ab=baseInfo&&baseInfo.alt?SEORAK_BASES[baseInfo.alt]:null;
  const hub=getMyHub();
  const hasGPS=!!(data.lat&&data.lng);
  const bs='flex:1;min-width:0;padding:9px 5px;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;border:none;min-height:42px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;';
  const sn=s=>s?s.replace('탐방지원센터','').replace('설악산국립공원사무소','사무소').replace('분소','분소').slice(0,7):'';

  // 출동: 출발기지→사고 기지 정보 표시 + 사고지점 좌표 복사
  const dispatch=pb?`<button onclick="_showDispatchInfo('${hub?hub.name:''}','${pb.name}',${hasGPS?data.lat:pb.lat},${hasGPS?data.lng:pb.lng})" style="${bs}background:rgba(79,168,208,.18);color:#4fa8d0;border:1px solid rgba(79,168,208,.35);">🚗 출동<span style="font-size:9px;font-weight:400;opacity:.7;">${sn(pb.name)}</span></button>`:'';
  // 하산: 표지판 기준 하산 경로 안내 (텍스트)
  const descent=signCode?`<button onclick="_showDescentInfo('${signCode}')" style="${bs}background:rgba(39,174,96,.12);color:#5dbf8a;border:1px solid rgba(39,174,96,.25);">🥾 하산<span style="font-size:9px;font-weight:400;opacity:.7;">경로안내</span></button>`:
    (hasGPS?`<button onclick="_showHeliInfo(${data.lat},${data.lng})" style="${bs}background:rgba(39,174,96,.12);color:#5dbf8a;border:1px solid rgba(39,174,96,.25);">📋 좌표복사<span style="font-size:9px;font-weight:400;opacity:.7;">하산용</span></button>`:''
  );
  // 대피: 속초의료원 연락처 + 좌표 복사
  const evac=`<button onclick="_showEvacInfo(${hasGPS?data.lat:0},${hasGPS?data.lng:0})" style="${bs}background:rgba(230,126,34,.12);color:#e67e22;border:1px solid rgba(230,126,34,.25);">🚑 대피<span style="font-size:9px;font-weight:400;opacity:.7;">속초의료원</span></button>`;
  const heli=hasGPS?`<button onclick="_showHeliInfo(${data.lat},${data.lng})" style="${bs}background:rgba(108,79,168,.15);color:#b89af0;border:1px solid rgba(108,79,168,.3);">🚁 헬기<span style="font-size:9px;font-weight:400;opacity:.7;">좌표복사</span></button>`:'';

  const zm=signCode?(signCode.match(/^(\d{2})-/)||[])[1]:null;
  const zoneName=zm?(ZONE_NAMES[zm]||''):'';
  const signLabel=signCode?`<div style="font-size:10px;color:#3a6a8a;margin-bottom:5px;padding:0 2px;">📍 ${signCode}${zoneName?' · '+zoneName:''}${pb?' → '+sn(pb.name):''}${ab?` <span style="color:#e0a840;font-size:9px;">/ ${sn(ab.name)}</span>`:''}</div>`:
    (hasGPS?`<div style="font-size:10px;color:#e05050;margin-bottom:5px;padding:0 2px;">⚠️ 표지판 코드 없음</div>`:'');

  const btns=[dispatch].filter(Boolean); // 좌표복사·대피·헬기 버튼 제거(요청) — 출동 정보만 유지
  if(!btns.length&&!signLabel)return'';
  return signLabel+(btns.length?`<div style="display:flex;gap:5px;">${btns.join('')}</div>`:'');
}

// 출동 정보 팝업 (산악: 기지명 + 사고지점 좌표 복사)
function _showDispatchInfo(hubName,pbName,lat,lng){
  const coords=lat&&lng?lat.toFixed(5)+', '+lng.toFixed(5):'';
  const msg=(hubName?hubName+'에서 출발\n':'')+'담당: '+pbName+(coords?'\n사고지점: '+coords:'');
  if(coords&&navigator.clipboard){
    navigator.clipboard.writeText(coords).then(()=>toast('🚗 출동 — 좌표복사: '+coords)).catch(()=>alert(msg));
  }else{alert(msg);}
}

// 하산 경로 안내 (SIGN_BASE_TABLE 기반 텍스트)
function _showDescentInfo(signCode){
  const baseInfo=getBaseForSign(signCode);
  if(!baseInfo){toast('⚠️ 경로 정보 없음: '+signCode);return;}
  const pb=SEORAK_BASES[baseInfo.primary];
  const ab=baseInfo.alt?SEORAK_BASES[baseInfo.alt]:null;
  let msg='📍 현위치: '+signCode+'\n🏠 하산 기지: '+(pb?pb.name:baseInfo.primary);
  if(ab)msg+='\n   또는: '+ab.name;
  const zm=(signCode.match(/^(\d{2})-/)||[])[1];
  if(zm&&ZONE_NAMES[zm])msg+='\n🗺️ 구역: '+ZONE_NAMES[zm];
  msg+='\n\n무전으로 위치 보고 후 담당 기지에 연락하세요.';
  alert(msg);
}

// 대피 정보 (속초의료원 연락처 + 환자 좌표 복사)
function _showEvacInfo(lat,lng){
  const coords=lat&&lng?lat.toFixed(5)+', '+lng.toFixed(5):'';
  const msg='🚑 속초의료원\n📞 033-630-6000\n\n응급후송 시 헬기 이착륙장 확보 후\n119 또는 담당 기지에 연락하세요.'+(coords?'\n\n환자 GPS: '+coords:'');
  if(coords&&navigator.clipboard){
    navigator.clipboard.writeText(coords).then(()=>alert(msg)).catch(()=>alert(msg));
  }else{alert(msg);}
}

let _extraTeamCollapsed=[];
let _extraTeamOtherOpen=[];
let _extraTeamOtherFilter=[];
let _initTeamMembers=[]; // 초동 출동팀 선택 인원 (추가팀 비활성화용)
function initExtraTeams(prefill){
  _extraTeams=(prefill&&prefill.extraTeams)?prefill.extraTeams.map(t=>({...t})):[];
  _extraTeamCollapsed=_extraTeams.map(()=>false);
  _extraTeamOtherOpen=_extraTeams.map(()=>false);
  _extraTeamOtherFilter=_extraTeams.map(()=>'');
  renderExtraTeams();
}
function removeExtraTeam(idx){
  _extraTeams.splice(idx,1);
  _extraTeamCollapsed.splice(idx,1);
  _extraTeamOtherOpen.splice(idx,1);
  _extraTeamOtherFilter.splice(idx,1);
  renderExtraTeams();
}
function setExtraTeamOtherFilter(ti,dept){
  _extraTeamOtherFilter[ti]=dept;
  renderExtraTeams();
}
function renderExtraTeams(){
  const wrap=document.getElementById('extraTeamsWrap');
  if(!wrap) return;
  const allMembers=getTeamMembers();
  const deptMap={};allMembers.forEach(s=>{deptMap[s.name]=s.dept;});
  const availDepts=[...new Set(allMembers.map(s=>s.dept).filter(Boolean))];
  wrap.innerHTML=_extraTeams.map((t,ti)=>{
    const collapsed=!!_extraTeamCollapsed[ti];
    const filt=_extraTeamOtherFilter[ti]||'전체';
    const byDept={};
    t.members.forEach(n=>{const d=deptMap[n]||'';if(!byDept[d])byDept[d]=[];byDept[d].push(n);});
    const summaryParts=Object.keys(byDept).map(d=>
      `<b style="color:#7ec8a0;">${d?_esc(DEPT_SHORT[d]||d):''} ${_esc(byDept[d].join(', '))}</b>`
    );
    const summaryHtml=t.members.length===0
      ?'<span style="color:#4a7090;">(미선택)</span>'
      :summaryParts.join(' · ');
    const filtered=filt==='전체'?allMembers:allMembers.filter(s=>s.dept===filt);
    return `<div style="margin-bottom:8px;padding:10px;background:#060d1a;border-radius:8px;border:1px solid rgba(126,200,163,.2);">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:${collapsed?0:8}px;">
        ${collapsed
          ?`<span style="font-size:11px;flex:1;">${summaryHtml}</span>`
          :`<input type="text" value="${_esc(t.teamName)}" oninput="_extraTeams[${ti}].teamName=this.value"
              style="flex:1;background:transparent;border:none;border-bottom:1px solid rgba(126,200,163,.3);color:#7ec8a0;font-size:12px;font-weight:700;outline:none;padding:2px 0;">`}
        ${collapsed
          ?`<button onclick="editExtraTeam(${ti})" style="background:rgba(79,168,208,.12);border:1px solid rgba(79,168,208,.25);color:#4fa8d0;border-radius:6px;font-size:11px;padding:4px 10px;cursor:pointer;">✏️ 수정</button>`
          :`<button onclick="removeExtraTeam(${ti})" style="background:rgba(192,57,43,.1);border:none;color:#c0392b;font-size:11px;padding:3px 8px;border-radius:5px;cursor:pointer;">삭제</button>`}
      </div>
      ${collapsed?'':`
        ${t.members.length?`<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px;">
          ${t.members.map(n=>`<div style="background:rgba(126,200,163,.15);color:#7ec8a0;border:1px solid rgba(126,200,163,.3);border-radius:20px;font-size:10px;font-weight:700;padding:3px 8px;display:flex;align-items:center;gap:4px;">${_esc(n)}<span onclick="toggleExtraTeamMemberByName(${ti},'${_escq(n)}')" style="cursor:pointer;color:#c0392b;font-size:12px;line-height:1;">×</span></div>`).join('')}
        </div>`:''}
        ${availDepts.length>1?`<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px;">
          ${['전체',...availDepts].map(d=>`<div onclick="setExtraTeamOtherFilter(${ti},'${_escq(d)}')" style="padding:3px 9px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;${d===filt?'background:#1a4a6e;color:#4fa8d0;':'background:#0b1c30;color:#4a7090;border:1px solid #1a3a5a;'}">${_esc(d)}</div>`).join('')}
        </div>`:''}
        ${filtered.length?`<div class="chk-grid">
          ${filtered.map(s=>{
            const inThis=t.members.includes(s.name);
            const takenElsewhere=!inThis&&((_initTeamMembers||[]).includes(s.name)||_extraTeams.some((et,ei)=>ei!==ti&&et.members.includes(s.name)));
            return `<div class="chk-item${inThis?' on':''}${takenElsewhere?' disabled':''}"
              onclick="${takenElsewhere?'':(`toggleExtraTeamMember(${ti},\\'${_escq(s.name)}\\',this)`)}"
              style="${takenElsewhere?'opacity:.35;cursor:not-allowed;':''}">
              <div class="chk-box${inThis?' on':''}"></div>
              <span class="chk-txt">${_esc(s.name)}<span style="font-size:9px;color:#4a7090;margin-left:3px;">${_esc(s.rank)}${takenElsewhere?' (배정됨)':''}</span></span>
            </div>`;
          }).join('')}
        </div>`:'<div style="font-size:11px;color:#4a7090;padding:6px 0;">가입된 인원 없음</div>'}
        <button onclick="confirmExtraTeam(${ti})" style="width:100%;margin-top:10px;padding:8px;background:rgba(79,168,208,.1);border:1px solid rgba(79,168,208,.3);color:#4fa8d0;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">✅ 확인</button>
      `}
    </div>`;
  }).join('');
}
function confirmExtraTeam(ti){
  _extraTeamCollapsed[ti]=true;
  renderExtraTeams();
}
function editExtraTeam(ti){
  _extraTeamCollapsed[ti]=false;
  renderExtraTeams();
}
function toggleExtraTeamMember(teamIdx,name,el){
  el.classList.toggle('on');
  el.querySelector('.chk-box').classList.toggle('on',el.classList.contains('on'));
  const t=_extraTeams[teamIdx];
  if(!t) return;
  if(el.classList.contains('on')){
    if(!t.members.includes(name)) t.members.push(name);
  } else {
    t.members=t.members.filter(n=>n!==name);
  }
}
function toggleExtraTeamMemberByName(ti,name){
  const t=_extraTeams[ti];if(!t)return;
  t.members=t.members.filter(n=>n!==name);
  renderExtraTeams();
}
function getExtraTeams(){ return _extraTeams.filter(t=>t.members.length>0); }

// 폼 미니맵 (1보·위험상황 공용) — 카카오맵 SDK가 늦게 로드돼도 재시도하여 반영
let _miniMaps={};
function _updateMiniMapEl(containerId,lat,lng,_retry){
  if(!window._KR){
    if((_retry||0)<15)setTimeout(()=>_updateMiniMapEl(containerId,lat,lng,(_retry||0)+1),300);
    return;
  }
  const el=document.getElementById(containerId);
  if(!el)return;
  const pos=new kakao.maps.LatLng(lat,lng);
  let mm=_miniMaps[containerId];
  if(!mm){
    try{
      el.style.display='block';
      const map=new kakao.maps.Map(el,{center:pos,level:5});
      map.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
      // 십자선 핀
      const pin=document.createElement('div');
      pin.innerHTML=`<div style="display:flex;flex-direction:column;align-items:center;"><div style="background:#c0392b;border:2px solid #fff;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:11px;box-shadow:0 2px 6px rgba(0,0,0,.6);">🚨</div><div style="width:2px;height:8px;background:#c0392b;"></div></div>`;
      const marker=new kakao.maps.CustomOverlay({position:pos,content:pin,yAnchor:1,zIndex:4});
      marker.setMap(map);
      _miniMaps[containerId]={map,marker};
    }catch(e){console.warn('miniMap',e);}
  }else{
    try{
      el.style.display='block';
      mm.map.setCenter(pos);
      if(mm.marker)mm.marker.setPosition(pos);
    }catch(e){}
  }
}
// ── 구조 폼 인라인 위치 미니맵: 중앙 십자선 + 표지판 + 드래그로 좌표·사고장소 자동갱신 ──
let _formMap=null,_formMapSignsAdded=false;
function _addFormMapSigns(){
  if(_formMapSignsAdded||!_formMap)return;
  const signs=(DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판')&&f.lat&&f.lng);
  if(!signs.length)return; // 아직 로딩 전이면 다음 갱신 때 다시 시도
  signs.forEach(f=>{
    const m=(f.name||'').match(/^\d{1,2}-\d{1,3}/);
    const code=m?m[0]:(f.name||'').slice(0,5);
    const d=document.createElement('div');
    d.style.cssText='background:rgba(8,18,36,.82);border:1px solid rgba(125,211,250,.45);border-radius:5px;padding:1px 4px;font-size:9px;font-weight:700;color:#7dd3fa;font-family:monospace;pointer-events:none;white-space:nowrap;';
    d.textContent=code;
    new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(f.lat,f.lng),content:d,zIndex:2}).setMap(_formMap);
  });
  _formMapSignsAdded=true;
}
function _updateFormMiniMap(lat,lng){
  if(!window._KR){ setTimeout(()=>_updateFormMiniMap(lat,lng),300); return; }
  const el=document.getElementById('r_loc_mini_map');
  if(!el)return;
  el.style.display='block';
  const pos=new kakao.maps.LatLng(lat,lng);
  if(!_formMap){
    try{
      el.style.position='relative';
      _formMap=new kakao.maps.Map(el,{center:pos,level:4});
      _formMap.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
      // 중앙 고정 십자선 (지도를 움직여 중심점=선택 위치)
      const cross=document.createElement('div');
      cross.style.cssText='position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:5;pointer-events:none;width:36px;height:36px;';
      cross.innerHTML='<div style="position:absolute;left:50%;top:0;width:2px;height:100%;background:rgba(231,76,60,.9);transform:translateX(-50%);"></div><div style="position:absolute;top:50%;left:0;height:2px;width:100%;background:rgba(231,76,60,.9);transform:translateY(-50%);"></div><div style="position:absolute;left:50%;top:50%;width:11px;height:11px;border:2px solid #fff;border-radius:50%;background:rgba(231,76,60,.75);transform:translate(-50%,-50%);box-shadow:0 0 6px rgba(0,0,0,.7);"></div>';
      el.appendChild(cross);
      _addFormMapSigns();
      // 드래그 → 중심 좌표·사고장소 자동 갱신 (디바운스)
      let _ft=null;
      kakao.maps.event.addListener(_formMap,'center_changed',function(){
        const c=_formMap.getCenter(),la=c.getLat(),ln=c.getLng();
        const cd=document.getElementById('r_minimap_coords');if(cd)cd.textContent=la.toFixed(5)+', '+ln.toFixed(5);
        clearTimeout(_ft);
        _ft=setTimeout(function(){
          const g=document.getElementById('r_gps');if(g)g.value=la.toFixed(5)+', '+ln.toFixed(5);
          _autoFillLoc(la,ln);
          const st=document.getElementById('r_gps_status');if(st)st.textContent='✅ 지도 중심으로 위치 지정됨';
        },280);
      });
    }catch(e){console.warn('formMap',e);return;}
  }else{
    try{el.style.display='block';_formMap.relayout();_formMap.setCenter(pos);_addFormMapSigns();}catch(e){}
  }
}
function initFormMiniMap(lat,lng){
  // 폼 재렌더 시 이전 지도 인스턴스 폐기 (DOM이 새로 생성되므로)
  _formMap=null;_formMapSignsAdded=false;
  const el=document.getElementById('r_loc_mini_map');
  if(el){el.style.display='none';el.innerHTML='';}
  if(lat&&lng){
    const v=(+lat).toFixed(5)+', '+(+lng).toFixed(5);
    const cd=document.getElementById('r_minimap_coords');if(cd)cd.textContent=v;
    const st=document.getElementById('r_gps_status');if(st)st.textContent='✅ 위치 확인 — 🗺 지도를 드래그해 조정';
    setTimeout(()=>_updateFormMiniMap(+lat,+lng),200);
  }
}
function _updateHazMiniMap(lat,lng){_updateMiniMapEl('hz_loc_mini_map',lat,lng);}
function initHazMiniMap(){
  delete _miniMaps['hz_loc_mini_map'];
  const el=document.getElementById('hz_loc_mini_map');
  if(el)el.style.display='none';
}
const syncHazMapFromInput=_debounce(function(){
  const v=(document.getElementById('hz_gps')?.value||'').split(',');
  if(v.length===2){
    const lat=parseFloat(v[0]),lng=parseFloat(v[1]);
    if(!isNaN(lat)&&!isNaN(lng))_updateHazMiniMap(lat,lng);
  }
},400);
function gpsToFormMap(){
  if(!navigator.geolocation){toast('⚠️ GPS 미지원');return;}
  const btn=document.getElementById('gpsFormBtn');
  const st=document.getElementById('r_gps_status');
  if(btn)btn.textContent='📡 수신중...';
  if(st)st.textContent='GPS 신호 수신 중...';
  navigator.geolocation.getCurrentPosition(pos=>{
    const lat=pos.coords.latitude,lng=pos.coords.longitude,acc=pos.coords.accuracy;
    const v=lat.toFixed(5)+', '+lng.toFixed(5);
    const gpsEl=document.getElementById('r_gps');if(gpsEl)gpsEl.value=v;
    const cd=document.getElementById('r_minimap_coords');if(cd)cd.textContent=v;
    if(btn)btn.textContent='📡 GPS';
    if(st)st.textContent='✅ 현재 위치'+(acc<50?' (±'+Math.round(acc)+'m)':'')+ ' — 🗺 지도에서 조정 가능';
    _autoFillLoc(lat,lng);
    _updateFormMiniMap(lat,lng);
    toast('📍 현재 위치'+(acc<50?' (±'+Math.round(acc)+'m)':''));
  },err=>{
    if(btn)btn.textContent='📡 GPS';
    if(st)st.textContent=err.code===1?'⚠️ 위치 권한이 거부됨 — 설정에서 허용 후 재시도':'⚠️ GPS 신호 없음 — 🗺 지도에서 직접 선택하세요';
    toast(err.code===1?'⚠️ 위치 권한 거부됨':'⚠️ GPS 신호 없음');
  },{enableHighAccuracy:true,timeout:15000,maximumAge:0});
}
const syncFormMapFromInput=_debounce(function(){
  const v=(document.getElementById('r_gps')?.value||'').split(',');
  if(v.length===2){
    const lat=parseFloat(v[0]),lng=parseFloat(v[1]);
    if(!isNaN(lat)&&!isNaN(lng)){
      const cd=document.getElementById('r_minimap_coords');if(cd)cd.textContent=lat.toFixed(5)+', '+lng.toFixed(5);
      _autoFillLoc(lat,lng);
      _updateFormMiniMap(lat,lng);
    }
  }
},400);
function _autoFillLoc(lat,lng){
  var el=document.getElementById('r_loc');
  if(!el)return;
  if(el.dataset.userEdited)return;
  var s=_nearestSign(lat,lng);
  if(s){el.value=s;autoGenTitle();return;}
  // 폴백: 카카오 역지오코딩으로 행정구역명 입력
  try{
    var gc=new kakao.maps.services.Geocoder();
    gc.coord2RegionCode(lng,lat,function(res,st){
      if(st===kakao.maps.services.Status.OK&&el&&!el.value.trim()){
        var r=(res||[]).find(function(x){return x.region_type==='H';})||res[0];
        if(r){el.value=r.address_name||'';autoGenTitle();}
      }
    });
  }catch(e){}
}

// 장소구분 토글
function selLoctype(val){
  document.getElementById('r_loctype').value=val;
  document.querySelectorAll('#loctypeBtns .tog-btn').forEach(b=>b.classList.toggle('on',b.dataset.val===val));
  chkIllegal({value:val});autoGenTitle();
}
// 신고자 토글
function selHasRep(val){
  document.getElementById('r_hasRep').value=val;
  document.querySelectorAll('#hasRepBtns .tog-btn').forEach(b=>b.classList.toggle('on',b.dataset.val===val));
  document.getElementById('reporterWrap').style.display=val==='y'?'block':'none';
}
// 동반자 토글
function selHasComp(val){
  document.getElementById('r_hasComp').value=val;
  document.querySelectorAll('#hasCompBtns .tog-btn').forEach(b=>b.classList.toggle('on',b.dataset.val===val));
  document.getElementById('companionWrap').style.display=val==='y'?'block':'none';
}

// 부상 현황
let _injuries=[];
let _injType='',_injPart='',_injSide='';
const _BILATERAL_PARTS=['어깨','팔꿈치','손목','손','무릎','발목','발'];
// 부위 선택 불필요한 전신 상태
const _SYSTEMIC_TYPES=['심정지','저체온증','익수','탈진/탈수','기타(전신)'];
function initInjuries(prefill){
  _injuries=(prefill&&prefill.injuries)||[];
  _injType='';_injPart='';_injSide='';
  renderInjuries();
}
function selInjType(el,type){
  document.querySelectorAll('#injTypePills .pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');_injType=type;
  // 전신 상태면 부위/좌우 숨김
  const partWrap=document.getElementById('injPartWrap');
  const sw=document.getElementById('injSideWrap');
  const isSys=_SYSTEMIC_TYPES.includes(type);
  if(partWrap) partWrap.style.display=isSys?'none':'block';
  if(sw) sw.style.display='none';
  if(isSys){_injPart='전신';_injSide='';}
  else{_injPart='';_injSide='';document.querySelectorAll('#injPartPills .pill').forEach(p=>p.classList.remove('on'));}
}
function selInjPart(el,part){
  document.querySelectorAll('#injPartPills .pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');_injPart=part;_injSide='';
  document.querySelectorAll('#injSidePills .pill').forEach(p=>p.classList.remove('on'));
  const sw=document.getElementById('injSideWrap');
  if(sw) sw.style.display=_BILATERAL_PARTS.includes(part)?'block':'none';
}
function selInjSide(el,side){
  document.querySelectorAll('#injSidePills .pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');_injSide=side;
}
function addInjury(){
  if(!_injType){toast('부상 유형을 선택하세요');return;}
  if(!_injPart){toast('부상 부위를 선택하세요');return;}
  _injuries.push({type:_injType,part:_injPart,side:_injSide});
  _injType='';_injPart='';_injSide='';
  document.querySelectorAll('#injTypePills .pill,#injPartPills .pill,#injSidePills .pill').forEach(p=>p.classList.remove('on'));
  const pw=document.getElementById('injPartWrap');if(pw)pw.style.display='block';
  const sw=document.getElementById('injSideWrap');if(sw)sw.style.display='none';
  renderInjuries();
}
function removeInjury(i){_injuries.splice(i,1);renderInjuries();}
function renderInjuries(){
  const el=document.getElementById('injuryList');
  if(!el) return;
  if(!_injuries.length){el.innerHTML='';return;}
  el.innerHTML=_injuries.map((a,i)=>`
    <div style="display:flex;align-items:center;gap:6px;padding:6px 10px;background:#0b1c30;border-radius:7px;margin-bottom:4px;border:1px solid rgba(79,168,208,.1);">
      <span style="font-size:12px;flex:1;color:#e0edf8;font-weight:600;">${a.type}${a.part&&a.part!=='전신'?' '+a.part:''}${a.side?' '+a.side:''}</span>
      <button onclick="removeInjury(${i})" style="background:none;border:none;color:#c0392b;font-size:15px;cursor:pointer;padding:0 2px;">×</button>
    </div>`).join('');
}

// 기상 특보
let _weatherAlerts=[];
let _wAlertType='';
let _wAlertLevel='';
function initWAlerts(prefill){
  const existing=(prefill&&prefill.weatherAlert)||'';
  _weatherAlerts=[];
  if(existing){
    existing.split(',').forEach(s=>{
      s=s.trim();if(!s)return;
      const lvs=['특보','경보','주의보'];
      for(const lv of lvs){if(s.endsWith(lv)){_weatherAlerts.push({type:s.slice(0,-lv.length),level:lv});return;}}
      _weatherAlerts.push({type:s,level:''});
    });
  } else {
    // 신규 보고 + 진행 중 특보운영(주의보·경보)이 있으면 그 특보를 자동 기록
    try{
      const _op=(DB.g('alertOps')||[]).find(o=>!o.closedAt);
      if(_op){
        const _al=(_op.alerts&&_op.alerts.length)?_op.alerts:(typeof _opAlerts==='function'?_opAlerts(_op):[]);
        const _seen={};
        _al.forEach(a=>{
          const st=a.stage||'';let lv='';
          if(st.indexOf('주의보')>=0)lv='주의보';
          else if(st.indexOf('경보')>=0||st.indexOf('Ⅲ')>=0)lv='경보';
          else return; // 예비특보 등은 자동 기록 제외
          const key=(a.type||'')+lv;if(_seen[key])return;_seen[key]=1;
          _weatherAlerts.push({type:a.type||'',level:lv});
        });
      }
    }catch(e){}
  }
  _wAlertType='';_wAlertLevel='';
  renderWAlerts();
}
function selWAlertType(el,type){
  document.querySelectorAll('#wAlertTypePills .pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');_wAlertType=type;
}
function selWAlertLevel(el,level){
  document.querySelectorAll('#wAlertLevelPills .pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');_wAlertLevel=level;
}
function addWAlert(){
  if(!_wAlertType){toast('종류를 선택하세요');return;}
  if(!_wAlertLevel){toast('단계를 선택하세요');return;}
  _weatherAlerts.push({type:_wAlertType,level:_wAlertLevel});
  _wAlertType='';_wAlertLevel='';
  document.querySelectorAll('#wAlertTypePills .pill,#wAlertLevelPills .pill').forEach(p=>p.classList.remove('on'));
  renderWAlerts();
}
function removeWAlert(i){_weatherAlerts.splice(i,1);renderWAlerts();}
function renderWAlerts(){
  const el=document.getElementById('wAlertList');
  if(!el) return;
  if(!_weatherAlerts.length){el.innerHTML='';return;}
  el.innerHTML=_weatherAlerts.map((a,i)=>`
    <div style="display:flex;align-items:center;gap:6px;padding:6px 10px;background:#0b1c30;border-radius:7px;margin-bottom:4px;border:1px solid rgba(79,168,208,.1);">
      <span style="font-size:12px;flex:1;color:#e0edf8;font-weight:600;">${a.type}${a.level}</span>
      <button onclick="removeWAlert(${i})" style="background:none;border:none;color:#c0392b;font-size:15px;cursor:pointer;padding:0 2px;">×</button>
    </div>`).join('');
}
function getWeatherAlertStr(){return _weatherAlerts.map(a=>a.type+a.level).join(', ');}

// 유관기관 동적 (카테고리+기관명+인원수)
let _fireAgencies=[]; // [{cat, name, count}]
let _agSelectedCat='';
let _agSubLoc='';
let _agSubType='';
function initFireAgencies(prefill){
  const raw=(prefill&&prefill.agencies&&prefill.agencies.fireAgencies)||[];
  // 이전 포맷({name}) → 새 포맷({cat,name,count}) 호환
  _fireAgencies=raw.map(a=>typeof a==='string'?{cat:'🚒 소방',name:a,count:0}:{cat:a.cat||'🏢 기타',name:a.name||'',count:a.count||0});
  _agSelectedCat='';_agSubLoc='';_agSubType='';
  renderFireAgencies();
}
function removeFireAgency(idx){
  _fireAgencies.splice(idx,1);
  renderFireAgencies();
}
function renderFireAgencies(){
  const el=document.getElementById('fireAgencyList');
  if(!el) return;
  if(!_fireAgencies.length){el.innerHTML='';return;}
  el.innerHTML=_fireAgencies.map((a,i)=>`
    <div style="display:flex;align-items:center;gap:6px;padding:7px 10px;background:#0b1c30;border-radius:7px;margin-bottom:4px;border:1px solid rgba(79,168,208,.1);">
      <span style="font-size:10px;color:#4a7090;flex-shrink:0;">${_esc(a.cat)}</span>
      <span style="font-size:12px;flex:1;color:#e0edf8;font-weight:600;">${_esc(a.name)}</span>
      ${a.count?`<span style="font-size:11px;color:#7a9cb8;flex-shrink:0;">${_esc(a.count)}명</span>`:''}
      <button onclick="removeFireAgency(${i})" style="background:none;border:none;color:#c0392b;font-size:15px;cursor:pointer;padding:0 2px;">×</button>
    </div>`).join('');
}

// 환동해산악구조대 당직팀 계산 (기준: 2026-05-15 = 2팀, 9시~익일9시)
function getHwandonghaTeam(){
  const now=new Date();
  const ref=new Date(now);
  if(ref.getHours()<9) ref.setDate(ref.getDate()-1);
  ref.setHours(0,0,0,0);
  const base=new Date('2026-05-15T00:00:00');
  const dayDiff=Math.round((ref-base)/(24*3600*1000));
  return [2,3,1][((dayDiff%3)+3)%3];
}

// 야간(18시~익일9시) 시간대 여부 — 구조출동 응소 선택 UI 노출 기준
function _isOffHours(){
  const h=new Date().getHours();
  return h>=18||h<9;
}

// 유관기관 데이터 수집
function getAgencies(){
  return {
    hwandongha: document.getElementById('agHwChk')?.classList.contains('on')||false,
    hwTeam: parseInt(document.getElementById('hwTeamSel')?.value||'1'),
    hwMemberCount: parseInt(document.getElementById('hwMemberCount')?.value||'5'),
    fireAgencies: _fireAgencies,
  };
}

// 타임라인 누가 pill 선택
function selTTActor(el,actor){
  el.classList.toggle('on');
}

// ══════════════════════════════════════════
// 작성자 관리
// ══════════════════════════════════════════
function _renderStaffQuickPick(){
  // 가입/작성자 설정 시 기존 직원 이름을 노출하지 않는다(개인정보·사칭 방지). 각자 직접 입력.
  const wrap=document.getElementById('staffQuickPick');
  if(wrap)wrap.style.display='none';
}
function openChangeUser(){
  const u=DB.g('currentUser')||{};
  const authType=DB.g('authType');
  const isKakao=authType==='kakao';
  const notApproved=isKakao&&u.approvalStatus!=='approved';
  const titleEl=document.getElementById('modalUserTitle');
  if(titleEl)titleEl.textContent=notApproved?'🆕 가입 신청':'👤 작성자 설정';
  // 승인코드 폐지 — 입력란 항상 숨김(승인은 관리자 멤버 지정으로만)
  const codeWrap=document.getElementById('uCodeWrap');
  if(codeWrap)codeWrap.style.display='none';
  document.getElementById('uNameIn').value=u.realName||u.name||'';
  const ds=document.getElementById('uDeptIn');if(ds)ds.value=u.dept||'';
  document.querySelectorAll('#rankPills .pill').forEach(p=>p.classList.remove('on'));
  if(u.rank){document.querySelectorAll('#rankPills .pill').forEach(p=>{if(p.textContent===u.rank)p.classList.add('on');});}
  const banner=document.getElementById('kakaoUserBanner');
  if(banner)banner.style.display=(u.kakaoId||u.kakaoImg)?'block':'none';
  _renderStaffQuickPick();
  document.getElementById('modalUser').classList.add('on');
}
async function _sha256(str){
  const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
async function doAdminLogin(){
  const pw=(document.getElementById('adminLoginPw').value||'').trim();
  if(!pw){toast('⚠️ 비밀번호를 입력하세요');return;}
  // 관리자 비밀번호 (해시 비교) — 기존 마스터 비밀번호도 비상용으로 유지
  const _ADMIN_PH='5ea963a2abe59fd456f6b4b2bcb7b095acdc2fbf8f3a460f949a5649187cb211';
  const _MASTER_PH='21fe2594c32497629b4b6e5da35e3e8d613f4453c29e3c6db6d68de6f1892894';
  const pwH=await _sha256(pw);
  if(pwH===_ADMIN_PH||pwH===_MASTER_PH){
    localStorage.setItem('_adminAuthed','1');
    const _cu=DB.g('currentUser')||{};
    if(_cu.kakaoId)DB.s('adminOwnerKakaoId',String(_cu.kakaoId));
    document.getElementById('adminLoginOverlay').style.display='none';
    document.getElementById('adminLoginPw').value='';
    var _g=document.getElementById('approvalGate');if(_g)_g.style.display='none'; // 관리자는 게이트 통과
    openApp('admin');
    try{setTimeout(_autoSeedAccidents,1500);}catch(e){} // 관리자 로그인 시 과거 안전사고 1회 자동 반영

  }else{
    toast('❌ 비밀번호가 틀렸습니다');
    document.getElementById('adminLoginPw').value='';
    document.getElementById('adminLoginPw').focus();
  }
}
function adminLogout(){
  localStorage.removeItem('_adminAuthed');
  goHome();
  toast('관리자 로그아웃');
}
function isAdminUser(){
  // 토큰 admin 클레임(허용목록 기반) 또는 기존 비밀번호 인증(전환기 폴백) 둘 다 인정
  return localStorage.getItem('_adminAuthed')==='1'
      || localStorage.getItem('_tokenAdmin')==='1'
      || _authRole==='admin';
}
// ── 멤버십(접근권한) 판정 — _acl 단일 기준 ──
// 멤버/관리자만 앱 사용 가능. 외부기관은 별도 경로(자체 제한)라 통과시킨다.
function _isMember(){
  if(isExternal&&typeof isExternal==='function'&&isExternal())return true; // 외부기관: 자체 제한 적용
  if(isAdminUser())return true;
  if(_authRole==='member'||_authRole==='admin')return true;   // 토큰 클레임
  if(localStorage.getItem('_memberOk')==='1')return true;      // 이전에 멤버 확인됨(오프라인 보호)
  var u=DB.g('currentUser')||{};
  if(u.kakaoId){var acl=_getAcl();var id=String(u.kakaoId);if(acl.members.indexOf(id)>=0||acl.admins.indexOf(id)>=0)return true;}
  return false;
}
// 멤버 확인 시 호출 — 오프라인 재방문에도 잠기지 않도록 플래그 저장
function _markMemberOk(){try{localStorage.setItem('_memberOk','1');}catch(e){}}
// 접근 게이트: 카카오 로그인 + 프로필 완료 + 멤버 아님 → 전체 차단 화면 표시
function _enforceAccessGate(){
  var gate=document.getElementById('approvalGate');if(!gate)return;
  var authType=(typeof _resolveAuthType==='function')?_resolveAuthType():'';
  var u=DB.g('currentUser')||{};
  var isKakao=authType==='kakao';
  var profileDone=!!(u.dept&&u.rank&&(u.realName||u.name));
  // 카카오 사용자가 프로필까지 끝냈는데 멤버가 아니면 차단. 그 외(미로그인·외부·프로필 미완)는 각 흐름이 처리.
  if(isKakao&&profileDone&&!_isMember()){
    var idEl=document.getElementById('approvalGateId');
    if(idEl)idEl.innerHTML='이름: <b style="color:#cfe2f2;">'+_esc(u.realName||u.name||'-')+'</b> · '+_esc(u.dept||'')+'<br>내 카카오 ID: <b style="color:#cfe2f2;">'+(u.kakaoId||_authKakaoId||'?')+'</b><br><span style="color:#5a8aaa;">이 ID를 관리자에게 전달하면 승인됩니다</span>';
    gate.style.display='flex';
    return true; // 차단됨
  }
  gate.style.display='none';
  return false;
}
// "승인 확인" 버튼 — 토큰 재발급 후 멤버면 게이트 해제
function _recheckApproval(){
  toast('승인 상태 확인 중...');
  _ensureMemberAuth().then(function(ok){
    if(ok||_isMember()){
      _markMemberOk();
      document.getElementById('approvalGate').style.display='none';
      try{updateUserUI();}catch(e){}
      try{goHome();}catch(e){}
      toast('✅ 승인 확인됨 — 환영합니다');
    }else{
      toast('⚠️ 아직 승인되지 않았습니다. 관리자에게 요청하세요');
    }
  });
}
function saveUser(){
  const name=document.getElementById('uNameIn').value.trim();
  if(!name){toast('⚠️ 이름을 입력해주세요');return;}
  const dept=document.getElementById('uDeptIn').value;
  const rank=getSelPills('rankPills')[0]||'';
  if(!dept){toast('⚠️ 소속 과/분소를 선택해주세요');return;}
  if(!rank){toast('⚠️ 직위를 선택해주세요');return;}
  const existing=DB.g('currentUser')||{};
  // 승인은 관리자가 직원 탭에서 '멤버' 지정으로만 부여(승인코드 제거). 여기선 프로필만 저장.
  const saved={...existing,realName:name,name,dept,rank};
  DB.s('currentUser',saved);
  _notifyNewJoiner(saved);
  window._requireProfile=false;
  window._needsCode=false;
  closeM('modalUser');
  updateUserUI();
  toast('✅ 저장: '+name);
  try{renderSettings();}catch(e){}
  // 프로필 저장 완료 → 멤버 승인 여부 확인(미승인이면 대기 화면)
  try{_enforceAccessGate();}catch(e){}
}
function _notifyNewJoiner(u){
  const all=DB.g('pendingUsers')||[];
  const uid=String(u.kakaoId||u.name||Date.now());
  const prev=all.find(function(p){return p.id===uid;});
  const status=u.approvalStatus||(prev&&prev.approvalStatus)||'pending';
  const filtered=all.filter(function(p){return p.id!==uid;});
  filtered.push({
    id:uid,realName:u.realName,name:u.name,dept:u.dept,rank:u.rank,
    kakaoId:u.kakaoId||null,kakaoImg:u.kakaoImg||null,
    approvalStatus:status,
    submittedAt:(prev&&prev.submittedAt)||Date.now(),
    seen:(prev&&prev.seen)||false
  });
  DB.s('pendingUsers',filtered);
}

function _renderPendingList(){
  var list=(DB.g('pendingUsers')||[]).slice().reverse().slice(0,20);
  if(!list.length)return'<div style="font-size:11px;color:#4a7090;padding:8px 0;">새 가입자 없음</div>';
  return list.map(function(u){return'<div style="background:#060d1a;border:1px solid rgba(79,168,208,.15);border-radius:8px;padding:10px;margin-bottom:7px;'+(u.seen?'opacity:.55':'')+'">'+(!u.seen?'<div style="font-size:9px;color:#4fa8d0;font-weight:700;margin-bottom:4px;">NEW</div>':'')+
    '<div style="font-size:12px;color:#e0edf8;font-weight:700;">'+_esc(u.realName||u.name)+' <span style="font-weight:400;color:#7a9cb8;">· '+_esc(u.dept||'')+' · '+_esc(u.rank||'')+'</span></div>'+
    '<div style="font-size:10px;color:#4a7090;margin-top:2px;">닉네임: '+_esc(u.name)+' · '+(u.submittedAt?new Date(u.submittedAt).toLocaleDateString('ko-KR'):'')+' 가입</div>'+
    '<button onclick="_markSeen(\''+_escq(u.id)+'\')" style="margin-top:6px;background:rgba(79,168,208,.1);color:#4fa8d0;border:1px solid rgba(79,168,208,.2);padding:5px 10px;border-radius:6px;font-size:10px;cursor:pointer;">확인 완료</button>'+
  '</div>';}).join('');
}
function _markSeen(id){
  var list=DB.g('pendingUsers')||[];
  var idx=list.findIndex(function(p){return p.id===id;});
  if(idx>=0){list[idx].seen=true;DB.s('pendingUsers',list);}
  renderAdmSys();
}
function _getUnseenCount(){
  return(DB.g('pendingUsers')||[]).filter(function(p){return!p.seen;}).length;
}
// 아직 승인(_acl 등록) 안 된 가입 신청자 목록
function _pendingNotApproved(){
  var acl=_getAcl();
  return(DB.g('pendingUsers')||[]).filter(function(u){
    if((u.approvalStatus||'pending')==='approved')return false;
    var id=String(u.kakaoId||'');
    if(id&&(acl.members.indexOf(id)>=0||acl.admins.indexOf(id)>=0))return false; // 이미 멤버/관리자
    return true;
  });
}
// 홈 관리자 버튼 배지(미승인 신청 건수) 갱신
function _updateAdminBadge(n){
  var b=document.getElementById('admBadge');if(!b)return;
  if(n>0){b.textContent=n>99?'99+':String(n);b.style.display='block';}
  else b.style.display='none';
}
// 관리자 기기: 새 가입 신청이 들어오면 알림(첫 동기화 배치는 배지만, 이후 신규만 토스트)
var _joinerAlertInited=false;
function _checkNewJoinerAlert(){
  var pend=_pendingNotApproved();
  if(!isAdminUser()){_updateAdminBadge(0);return;}
  _updateAdminBadge(pend.length);
  var alerted={};try{alerted=JSON.parse(localStorage.getItem('_joinerAlerted')||'{}');}catch(e){}
  var fresh=pend.filter(function(u){return!alerted[String(u.id)];});
  if(fresh.length){
    fresh.forEach(function(u){alerted[String(u.id)]=1;});
    try{localStorage.setItem('_joinerAlerted',JSON.stringify(alerted));}catch(e){}
    if(_joinerAlertInited){ // 첫 로드 폭주 방지: 초기 동기화분은 알림 생략
      var names=fresh.map(function(u){return u.realName||u.name||'신규';}).join(', ');
      toast('🔔 새 멤버 승인 요청: '+names);
      try{_showSystemNoti('새 멤버 승인 요청: '+names+' — 직원 탭에서 멤버 지정','🔔');}catch(e){}
    }
  }
  _joinerAlertInited=true;
}
// 외부기관 관리 행 HTML
function _extAgencyRowsHtml(){
  return _getExtAgencies().map(function(a){
    return `<div class="extAgRow" style="display:flex;gap:6px;margin-bottom:6px;align-items:center;">
      <input class="fi extAgName" value="${_esc(a.name||'')}" placeholder="기관명 (예: 설악산악구조대)" style="flex:1.4;font-size:12px;">
      <input class="fi extAgCode" value="${_esc((a.code||'').toUpperCase())}" placeholder="코드" style="flex:1;font-family:monospace;font-size:13px;letter-spacing:1px;">
      <button onclick="this.closest('.extAgRow').remove()" style="background:rgba(192,57,43,.12);color:#c0392b;border:none;border-radius:7px;padding:8px 10px;font-size:13px;cursor:pointer;flex-shrink:0;">✕</button>
    </div>`;
  }).join('');
}
function addExtAgencyRow(){
  const wrap=document.getElementById('extAgencyListWrap');if(!wrap)return;
  const div=document.createElement('div');
  div.className='extAgRow';div.style.cssText='display:flex;gap:6px;margin-bottom:6px;align-items:center;';
  div.innerHTML=`<input class="fi extAgName" value="" placeholder="기관명 (예: 설악산악구조대)" style="flex:1.4;font-size:12px;">
    <input class="fi extAgCode" value="" placeholder="코드" style="flex:1;font-family:monospace;font-size:13px;letter-spacing:1px;">
    <button onclick="this.closest('.extAgRow').remove()" style="background:rgba(192,57,43,.12);color:#c0392b;border:none;border-radius:7px;padding:8px 10px;font-size:13px;cursor:pointer;flex-shrink:0;">✕</button>`;
  wrap.appendChild(div);
  const ni=div.querySelector('.extAgName');if(ni)ni.focus();
}
function saveExtAgencies(){
  const rows=[...document.querySelectorAll('#extAgencyListWrap .extAgRow')];
  const list=[];const seen={};
  for(const r of rows){
    const _n=r.querySelector('.extAgName');const name=(_n?_n.value:'').trim();
    const _c=r.querySelector('.extAgCode');const code=(_c?_c.value:'').trim().toUpperCase();
    if(!name&&!code)continue; // 빈 행 무시
    if(!name||!code){toast('⚠️ 기관명과 코드를 모두 입력하세요');return;}
    if(seen[code]){toast('⚠️ 코드 중복: '+code);return;}
    seen[code]=1;list.push({name,code});
  }
  if(!list.length){toast('⚠️ 최소 1개 기관을 등록하세요');return;}
  DB.s('extAgencies',list);
  // 구버전 키도 첫 기관으로 동기화 (타임라인 등 잔존 참조 호환)
  DB.s('extAgencyDisplayName',list[0].name);
  DB.s('extAgencyCode',list[0].code);
  toast('✅ 외부기관 '+list.length+'곳 저장됨');
}
function saveGeminiKey(){
  const _gk=document.getElementById('geminiKeyInp');const key=(_gk?_gk.value:'').trim();
  if(!key){toast('⚠️ API 키를 입력하세요');return;}
  DB.s('geminiApiKey',key);
  toast('✅ Gemini API 키 저장됨');
}
function saveKmaProxy(){
  const _kp=document.getElementById('kmaProxyInp');let url=(_kp?_kp.value:'').trim();
  if(url&&!/^https?:\/\//.test(url)){toast('⚠️ https:// 로 시작하는 주소를 입력하세요');return;}
  url=url.replace(/\/+$/,''); // 끝 슬래시 제거
  DB.s('kmaProxyUrl',url);
  _weatherFetched=false;_wDetailCache=null; // 캐시 비우고 다음 조회부터 적용
  try{fetchWeather();}catch(e){}
  toast(url?'✅ 기상청 프록시 저장됨 — 날씨 새로고침':'✅ 프록시 해제됨');
}
function saveFcmCfg(){
  const _fu=document.getElementById('fcmUrlInp');const url=(_fu?_fu.value:'').trim();
  const _fs=document.getElementById('fcmSecInp');const sec=(_fs?_fs.value:'').trim();
  DB.s('fcmPushUrl',url);DB.s('fcmPushSecret',sec);
  toast('✅ 푸시 설정 저장됨');_refreshFcmStatus();
}
async function _refreshFcmStatus(){
  const el=document.getElementById('fcmStatus');if(!el)return;
  const customUrl=(DB.g('fcmPushUrl')||'').trim();
  const url=_FCM_PUSH_URL||customUrl; // 내장값 우선
  const Cap=window.Capacitor,native=!!(Cap&&Cap.isNativePlatform&&Cap.isNativePlatform());
  let line=native?'📱 이 기기: 네이티브(APK) — 푸시 수신 가능':'🌐 이 기기: 웹 브라우저 — 앱이 열려 있을 때만 알림';
  line+=`<br>발송기: ${url?(customUrl?'✅ 설정됨 (직접 지정)':'✅ 자동 (내장)'):'❌ 미설정'}`;
  if(_fdb){
    try{
      const snap=await _fdb.collection('fcmTokens').get();
      let me=false;snap.forEach(d=>{if(d.id===_MY_DEVICE_ID)me=true;});
      line+=`<br>등록된 기기: <b>${snap.size}대</b>${me?' (내 기기 포함 ✅)':' — 내 기기 미등록, 알림 권한을 허용하세요'}`;
    }catch(e){line+='<br>등록 기기 조회 실패';}
  }
  el.innerHTML=line;
}
// 관리자가 직접 작성한 내용으로 전 직원에게 푸시 발송
async function sendCustomPush(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const url=_FCM_PUSH_URL||(DB.g('fcmPushUrl')||'').trim();
  if(!url){toast('⚠️ 발송기 URL 미설정');return;}
  const title=(document.getElementById('pushTitleInp')?.value||'설악산 현장관리').trim()||'설악산 현장관리';
  const body=(document.getElementById('pushBodyInp')?.value||'').trim();
  if(!body){toast('⚠️ 보낼 내용을 입력하세요');document.getElementById('pushBodyInp')?.focus();return;}
  if(!confirm('전 직원에게 푸시를 발송합니다.\n\n제목: '+title+'\n내용: '+body+'\n\n발송할까요?'))return;
  toast('📨 푸시 발송 중…');
  try{
    const snap=await _fdb.collection('fcmTokens').get();
    const tokens=[];snap.forEach(d=>{const v=d.data()||{};if(v.token)tokens.push(v.token);});
    if(!tokens.length){toast('⚠️ 등록된 기기가 없습니다');return;}
    const res=await fetch(url,{method:'POST',headers:{'content-type':'text/plain;charset=utf-8'},
      body:JSON.stringify({secret:_FCM_PUSH_SECRET||(DB.g('fcmPushSecret')||''),title,body,data:{app:'home'},tokens})});
    const out=await res.json().catch(()=>({}));
    if(out.error){toast('❌ 발송기 오류: '+out.error);}
    else{
      toast(`✅ ${out.sent||0}대 발송 완료${out.invalid&&out.invalid.length?` · 무효 ${out.invalid.length}`:''}`);
      const b=document.getElementById('pushBodyInp');if(b)b.value='';
    }
  }catch(e){toast('❌ 발송 실패: '+e.message);}
}

function updateUserUI(){
  const u=DB.g('currentUser')||{};
  const ne=document.getElementById('myName');
  const se=document.getElementById('mySub');
  const av=document.getElementById('myAvatar');
  if(ne)ne.textContent=u.name||'작성자를 선택하세요';
  const parts=[];if(u.dept)parts.push(u.dept);if(u.rank)parts.push(u.rank);
  const authType=DB.g('authType');
  if(se)se.textContent=parts.join(' · ')||'탭하여 설정';
  // 아바타: 카카오 프로필 사진 or 이니셜
  if(av){
    if(u.kakaoImg){
      av.innerHTML=`<img src="${_esc(u.kakaoImg)}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.parentElement.textContent='👤'">`;
    } else {
      const initial=u.name?u.name.charAt(0):'👤';
      av.textContent=initial;
    }
  }
  // 외부기관 모드: 제한된 메뉴 표시
  const ext=authType==='external';
  document.body.classList.toggle('ext-mode',ext);
}

// ══════════════════════════════════════════
// 재난/구조 — 지도
// ══════════════════════════════════════════
let selResId=null,curResId=null,resFilter='전체';
let resTypeF=new Set(),resStatusF=new Set();
let _resListTab='all'; // 'all'|'rescue'|'haz'
// ── 필터 상태 유지: 화면 전환·앱 재시작 후에도 마지막 필터 복원 ──
function _persistFilters(){
  try{
    localStorage.setItem('_filt_v1',JSON.stringify({
      resType:[...resTypeF],resStatus:[...resStatusF],resTab:_resListTab,
      facStatus:(typeof facMapStatusF!=='undefined'?[...facMapStatusF]:[]),
      facType:(typeof facMapTypeF!=='undefined'?[...facMapTypeF]:[]),
      facLoc:(typeof facMapLocF!=='undefined'?[...facMapLocF]:[]),
      facSort:(typeof facListSort!=='undefined'?facListSort:'default')
    }));
  }catch(e){}
}
function _restoreFilters(){
  try{
    const j=JSON.parse(localStorage.getItem('_filt_v1')||'{}');
    if(j.resType)resTypeF=new Set(j.resType);
    if(j.resStatus)resStatusF=new Set(j.resStatus);
    if(j.resTab)_resListTab=j.resTab;
    if(typeof facMapStatusF!=='undefined'&&j.facStatus)facMapStatusF=new Set(j.facStatus);
    if(typeof facMapTypeF!=='undefined'&&j.facType)facMapTypeF=new Set(j.facType);
    if(typeof facMapLocF!=='undefined'&&j.facLoc)facMapLocF=new Set(j.facLoc);
    if(typeof facListSort!=='undefined'&&j.facSort)facListSort=j.facSort;
  }catch(e){}
}
function _resDefaultDates(){const t=today();const f=new Date();f.setMonth(f.getMonth()-1);return{from:f.toISOString().slice(0,10),to:t};}
const _rd=_resDefaultDates();
let resDateFrom=_rd.from,resDateTo=_rd.to;
let resFacCatH=new Set(),resFacCatF=new Set();
const _RES_DEFAULT_CATS=['🏠 분소','🛖 탐방지원센터','🪧 다목적위치표지판','🏠 대피소'];
// Facility overlay pool: created once, show/hide on filter changes
var _rFacPool=new Map(); // String(id) → {ov, el, type, lat, lng}
var _rEvOvs=[],_rEvEls=[]; // event overlays only (rescues + hazards)
var _rTeamOvs=[],_rTeamEls=[],_rTeamConnLines=[]; // team position markers + connector lines
var _rFocusResId=null; // currently focused rescue id (focus mode)
var _rFocusPolylines=[]; // route polylines for focus mode
var _rRouteCache={}; // cacheKey → {path,duration,distance,fallback}
var _rRouteInfo={}; // {resId:[{carMin,carKm,walkMin,walkKm},...]}}
function _buildRFacEl(f){
  const el=document.createElement('div');el.className='mpin-num';
  if(f.type.includes('다목적위치표지판')){
    const code=(f.name.match(/\d[\d\-]*\d|\d/)||[f.name.slice(0,6)])[0];
    el.textContent=code;el.title=f.name;
    el.onclick=e=>{e.stopPropagation();toast('📍 '+f.name);};
  }else if(f.type.includes('장소')){
    el.style.cssText='background:rgba(20,10,40,.88);border-color:rgba(180,100,255,.7);color:#d4a0ff;';
    el.textContent=f.name;el.title=f.name;
    el.onclick=e=>{e.stopPropagation();toast('📍 '+f.name+(f.loc?' ('+f.loc+')':''));};
  }else if(f.type.includes('대피소')){
    el.style.cssText='background:rgba(8,30,20,.88);border-color:rgba(39,174,96,.7);color:#7de8a8;';
    el.textContent=f.name;el.title=f.name;
    el.onclick=e=>{e.stopPropagation();toast('🏠 '+f.name+(f.loc?' ('+f.loc+')':''));};
  }else{
    el.style.cssText='background:rgba(20,20,40,.88);border-color:rgba(150,150,200,.7);color:#c8c8e8;';
    el.textContent=f.name;el.title=f.name;
    el.onclick=e=>{e.stopPropagation();toast(f.type.split(' ')[0]+' '+f.name+(f.loc?' ('+f.loc+')':''));};
  }
  return el;
}
function _syncRFacPool(){
  if(!mapR)return;
  const _rm=DB.g('catFacMeta')||{};
  const all=(DB.g('facilities')||[]).filter(f=>f.lat&&f.lng&&f.type&&(_rm[f.type]||{}).rescue);
  const validIds=new Set(all.map(f=>String(f.id)));
  // Remove pool entries whose facility was deleted or lost rescue status
  _rFacPool.forEach((entry,id)=>{
    if(!validIds.has(id)){try{entry.ov.setMap(null);}catch(e){}_rFacPool.delete(id);}
  });
  // Add only genuinely new entries — no lat/lng comparison to avoid float precision mismatches
  all.forEach(f=>{
    if(_rFacPool.has(String(f.id)))return;
    const el=_buildRFacEl(f);
    const ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(f.lat,f.lng),content:el,clickable:true});
    _rFacPool.set(String(f.id),{ov,el,type:f.type});
  });
  _applyRFacFilter();
}
function _applyRFacFilter(){
  if(!mapR)return;
  // Pool already guarantees rescue=true — only apply the user's category show/hide filter
  const facEls=[];
  _rFacPool.forEach(entry=>{
    const t=entry.type;
    const show=_RES_DEFAULT_CATS.includes(t)?!resFacCatH.has(t):resFacCatF.has(t);
    entry.ov.setMap(show?mapR:null);
    if(show)facEls.push(entry.el);
  });
  rOvs=[..._rEvOvs,...[..._rFacPool.values()].map(e=>e.ov)];
  rEls=[..._rEvEls,...facEls];
  if(mapR)_scaleOvs(rEls,mapR.getLevel(),5);
}
function _resDateOk(dateStr){
  if(!resDateFrom&&!resDateTo)return true;
  const d=(dateStr||'').slice(0,10);
  if(resDateFrom&&d<resDateFrom)return false;
  if(resDateTo&&d>resDateTo)return false;
  return true;
}
function renderRescueMap(){
  if(!mapR)return;
  // Clear event overlays only — facility pool is reused
  _rEvOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_rEvOvs=[];_rEvEls=[];
  // Clear team markers + connector lines
  _rTeamOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_rTeamOvs=[];_rTeamEls=[];
  _rTeamConnLines.forEach(p=>{try{p.setMap(null);}catch(e){}});_rTeamConnLines=[];
  _updateResFilterPanels();
  const _showRes=resTypeF.size===0||resTypeF.has('🚨구조');
  const _showHaz=resTypeF.size===0||resTypeF.has('⚠️위험상황');
  const _stOkRes=s=>resStatusF.size===0||(resStatusF.has('진행중')&&s==='ongoing')||(resStatusF.has('종료')&&s==='done');
  const _stOkHaz=s=>{const active=!s||s==='미조치'||s==='조치중';return resStatusF.size===0||(resStatusF.has('진행중')&&active)||(resStatusF.has('종료')&&!active);};
  // 구조 이력 핀
  const _resAll=DB.g('rescues')||[];
  // 하루·유형별 사고 번호: 같은 날 같은 유형이 2건 이상이면 '안전사고1·2·3…' 부여 (전 상태 통산)
  const _dtg={};_resAll.forEach(x=>{const k=(x.type||'')+'|'+((x.date||'').slice(0,10));(_dtg[k]=_dtg[k]||[]).push(x);});
  Object.values(_dtg).forEach(g=>g.sort((a,b)=>(a.id||0)-(b.id||0)));
  const _accNum=r=>{const k=(r.type||'')+'|'+((r.date||'').slice(0,10));const g=_dtg[k]||[];return g.length<2?(r.type||'사고'):(r.type||'사고')+(g.findIndex(x=>x.id===r.id)+1);};
  if(_showRes)_resAll.forEach(r=>{
    if(!r.lat||!r.lng)return;
    if(!_stOkRes(r.status))return;
    if(!_resDateOk(r.date))return;
    const isOg=r.status==='ongoing';const ti=RES_TYPES[r.type]||RES_TYPES['기타'];
    const el=document.createElement('div');
    if(isOg){
      // 진행중: 클러스터 없이 개별 — 읽기 쉬운 빨간 칩(아이콘+유형+당일번호)
      el.className='res-chip-og';
      el.innerHTML=`${ti.ico} <span>${_esc(_accNum(r))}</span>`;
    }else{
      el.className=`mpin ${ti.pc} p-done`;el.innerHTML=ti.ico;
    }
    el.dataset.ev='1';
    el.dataset.rid=String(r.id);
    let _ts=null;
    el.addEventListener('touchstart',e=>{_ts={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});
    el.addEventListener('touchend',e=>{
      if(!_ts)return;const dx=e.changedTouches[0].clientX-_ts.x,dy=e.changedTouches[0].clientY-_ts.y;_ts=null;
      if(Math.abs(dx)<8&&Math.abs(dy)<8){e.stopPropagation();e.preventDefault();
        if(isOg&&r.teams&&r.teams.length)enterFocusMode(r.id);else openResPopup(r.id,'rescue');}
    });
    el.addEventListener('click',e=>{e.stopPropagation();
      if(isOg&&r.teams&&r.teams.length)enterFocusMode(r.id);else openResPopup(r.id,'rescue');});
    const ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(r.lat,r.lng),content:el,clickable:true,zIndex:isOg?8:3});
    ov._lat=r.lat;ov._lng=r.lng;ov._noClus=isOg; // 진행중 구조는 클러스터 제외 + 최상단
    ov.setMap(mapR);_rEvOvs.push(ov);_rEvEls.push(el);
  });
  // 위험상황 핀
  if(_showHaz)(DB.g('hazards')||[]).forEach(h=>{
    if(!h.lat||!h.lng)return;
    if(!_stOkHaz(h.hazStatus))return;
    if(!_resDateOk(h.date))return;
    const done=h.hazStatus&&h.hazStatus!=='미조치'&&h.hazStatus!=='조치중';
    const el=document.createElement('div');el.className=`mpin p-haz${done?' p-done':''}`;el.innerHTML='⚠️';
    let _ts=null;
    el.addEventListener('touchstart',e=>{_ts={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});
    el.addEventListener('touchend',e=>{if(!_ts)return;const dx=e.changedTouches[0].clientX-_ts.x,dy=e.changedTouches[0].clientY-_ts.y;_ts=null;if(Math.abs(dx)<8&&Math.abs(dy)<8){e.stopPropagation();e.preventDefault();openResPopup(h.id,'hazard');}});
    el.addEventListener('click',e=>{e.stopPropagation();openResPopup(h.id,'hazard');});
    const ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(h.lat,h.lng),content:el,clickable:true});
    ov._lat=h.lat;ov._lng=h.lng;
    ov.setMap(mapR);_rEvOvs.push(ov);_rEvEls.push(el);
  });
  // 사고/위험 상황 핀 클러스터링 (밀집 시 개수 버블로 묶음 — 시설물은 제외)
  _rEvItems=_rEvOvs.map(ov=>({ov,lat:ov._lat,lng:ov._lng,noClus:ov._noClus}));
  try{_reclusterRescue();}catch(e){}
  // 🆘 조난자 위치 핀 (클러스터 제외, 최상단, 맥동)
  try{_drawSosPins();}catch(e){}
  // 팀 위치 마커: 진행중 구조 팀의 현재 위치
  _rebuildTeamChips();
  // 시설물: 풀 동기화 후 필터 적용 (DOM 재생성 없이 show/hide)
  _syncRFacPool();
  // Focus mode: apply dimming to non-focused overlays
  if(_rFocusResId){
    _applyFocusDim();
    _drawFocusRoutes(_rFocusResId);
  }
  updateSummary();
}

// ══════════════════════════════════════════
// 포커스 모드: 사고 탭 → 팀 경로 + 진행 패널
// ══════════════════════════════════════════
const TEAM_COLORS=['#4fa8d0','#27ae60','#e67e22','#9b59b6'];
// 지도 칩용 팀 이름 축약: 특수산악구조대 1팀 → 특구대 1팀
function _shortTeamName(n){
  let s=String(n||'');
  Object.entries(DEPT_SHORT).forEach(([k,v])=>{s=s.split(k).join(v);});
  s=s.replace('탐방지원센터','센터');
  return s.length>10?s.slice(0,10)+'…':s;
}
function _teamIco(t){return t.type==='heli'?'🚁':t.type==='vehicle'?'🚐':'🥾';}

// 진행중 구조의 팀 위치 칩 마커를 모두 지우고 다시 그림
function _rebuildTeamChips(){
  _rTeamOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_rTeamOvs=[];_rTeamEls=[];
  _rTeamConnLines.forEach(p=>{try{p.setMap(null);}catch(e){}});_rTeamConnLines=[];
  if(!mapR)return;
  (DB.g('rescues')||[]).filter(r=>r.status==='ongoing'&&r.teams&&r.teams.length).forEach(rescue=>{
    rescue.teams.forEach((team,ti)=>{
      const cur=team.wps&&team.wps[team.wpIdx>=0?team.wpIdx:0];
      if(!cur||!cur.lat||!cur.lng)return;
      const typeIco=_teamIco(team);
      const col=TEAM_COLORS[ti%TEAM_COLORS.length];
      const el=document.createElement('div');
      el.className='team-chip';
      el.style.borderColor=col;el.style.color=col;
      el.innerHTML=`${typeIco} <span>${_shortTeamName(team.name)}</span>`;
      el.dataset.ev='1';el.dataset.rid=String(rescue.id);
      let _ts=null;
      el.addEventListener('touchstart',e=>{_ts={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});
      el.addEventListener('touchend',ev=>{if(!_ts)return;const dx=ev.changedTouches[0].clientX-_ts.x,dy=ev.changedTouches[0].clientY-_ts.y;_ts=null;if(Math.abs(dx)<8&&Math.abs(dy)<8){ev.stopPropagation();ev.preventDefault();enterFocusMode(rescue.id);}});
      el.addEventListener('click',ev=>{ev.stopPropagation();enterFocusMode(rescue.id);});
      const ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(cur.lat,cur.lng),content:el,clickable:true,yAnchor:1.5,zIndex:4});
      ov.setMap(mapR);_rTeamOvs.push(ov);_rTeamEls.push(el);
      // 팀 위치 → 사고 위치 점선 연결 (연관성 표시)
      if(rescue.lat&&rescue.lng){
        try{
          const conn=new kakao.maps.Polyline({
            path:[new kakao.maps.LatLng(cur.lat,cur.lng),new kakao.maps.LatLng(rescue.lat,rescue.lng)],
            strokeWeight:2,strokeColor:'#ffffff',strokeOpacity:.65,strokeStyle:'shortdot',zIndex:2
          });
          conn.setMap(mapR);_rTeamConnLines.push(conn);
        }catch(e){}
      }
    });
  });
}

function _haversineKm(lat1,lng1,lat2,lng2){
  const R=6371,dLat=(lat2-lat1)*Math.PI/180,dLng=(lng2-lng1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}
function _fmtMin(min){
  if(min<60)return Math.round(min)+'분';
  const h=Math.floor(min/60),m=Math.round(min%60);
  return h+'시간'+(m>0?' '+m+'분':'');
}

async function _fetchCarRoute(key,fromLat,fromLng,toLat,toLng){
  if(_rRouteCache[key])return _rRouteCache[key];
  try{
    const url='https://apis-navi.kakaomobility.com/v1/directions?origin='+fromLng+','+fromLat+'&destination='+toLng+','+toLat+'&priority=RECOMMEND';
    const resp=await fetch(url,{headers:{'Authorization':'KakaoAK 4ba2cd810d516a4f336d4dee5fa5eba5'}});
    if(!resp.ok)throw new Error('HTTP '+resp.status);
    const d=await resp.json();
    const route=d.routes&&d.routes[0];
    if(!route||route.result_code!==0)throw new Error('no route');
    const sum=route.summary;
    const path=[];
    (route.sections||[]).forEach(sec=>{
      (sec.roads||[]).forEach(road=>{
        const vx=road.vertexes||[];
        for(let i=0;i+1<vx.length;i+=2)path.push(new kakao.maps.LatLng(vx[i+1],vx[i]));
      });
    });
    const result={path,duration:Math.round((sum.duration||0)/60),distance:+((sum.distance||0)/1000).toFixed(1),fallback:false};
    _rRouteCache[key]=result;
    return result;
  }catch(e){
    const km=+(_haversineKm(fromLat,fromLng,toLat,toLng)*1.35).toFixed(1);
    const result={path:null,duration:Math.round(km/45*60),distance:km,fallback:true};
    _rRouteCache[key]=result;
    return result;
  }
}

// 🚗 X분 X.Xkm · 🚶 X시간 X분 X.Xkm 형식 문자열
function _routeInfoStr(info,showWalk){
  const car=info.carMin!=null?(info.fallback?'🚗 약 ':'🚗 ')+_fmtMin(info.carMin)+' '+info.carKm+'km':'🚗 계산중…';
  const walk=showWalk&&info.walkKm?' · 🚶 '+_fmtMin(info.walkMin)+' '+info.walkKm+'km':'';
  return car+walk;
}

function _renderFocusPanelRouteInfo(resId){
  const infos=_rRouteInfo[resId]||[];
  infos.forEach((info,ti)=>{
    const el=document.getElementById('rinfo-'+resId+'-'+ti);
    if(!el||!info)return;
    el.textContent=_routeInfoStr(info,true);
    el.style.color=info.fallback?'rgba(240,192,64,.55)':'rgba(240,192,64,.85)';
  });
}

function _getBaseByName(name){
  return Object.values(SEORAK_BASES).find(b=>b.name===name)||null;
}
// 도로 접근 가능한 거점 중 사고지점에서 가장 가까운 곳 (대피소 등 도보전용 제외)
function _nearestBase(lat,lng){
  if(!(lat&&lng))return null;
  let best=null,bd=Infinity;
  Object.values(SEORAK_BASES).forEach(b=>{
    if(/대피소/.test(b.name||''))return; // 대청봉대피소 등 차량 진입 불가 → 제외
    if(!(b.lat&&b.lng))return;
    const d=_haversineKm(lat,lng,b.lat,b.lng);
    if(d<bd){bd=d;best=b;}
  });
  return best?Object.assign({},best,{distKm:bd}):null;
}

function _applyFocusDim(){
  const fid=String(_rFocusResId);
  // Event markers: dim if not the focused rescue
  _rEvEls.forEach(el=>{
    const isMe=el.dataset&&el.dataset.rid===fid;
    el.style.opacity=isMe?'1':'0.12';
  });
  // Team markers: dim if not the focused rescue
  _rTeamEls.forEach(el=>{
    const rid=el.dataset&&el.dataset.rid;
    el.style.opacity=rid===fid?'1':'0.12';
  });
  // Facility pool: dim all
  _rFacPool.forEach(entry=>{entry.el.style.opacity='0.12';});
}

function _clearFocusDim(){
  _rEvEls.forEach(el=>{el.style.opacity='';});
  _rTeamEls.forEach(el=>{el.style.opacity='';});
  _rFacPool.forEach(entry=>{entry.el.style.opacity='';});
}

function _clearFocusPolylines(){
  _rFocusPolylines.forEach(p=>{try{p.setMap(null);}catch(e){}});
  _rFocusPolylines=[];
}

function _drawFocusRoutes(resId){
  _clearFocusPolylines();
  if(!mapR||!resId)return;
  const rescue=(DB.g('rescues')||[]).find(r=>r.id===resId);
  if(!rescue||!rescue.teams)return;
  const bounds=new kakao.maps.LatLngBounds();
  if(rescue.lat&&rescue.lng)bounds.extend(new kakao.maps.LatLng(rescue.lat,rescue.lng));
  if(!_rRouteInfo[resId])_rRouteInfo[resId]=[];

  rescue.teams.forEach((team,ti)=>{
    const col=TEAM_COLORS[ti%TEAM_COLORS.length];
    const wps=team.wps||[];
    if(!wps.length)return;
    const baseWp=wps.find(w=>w.isBase);
    const baseCoords=baseWp?_getBaseByName(baseWp.name):null;
    const trailPts=wps.filter(w=>!w.isBase&&w.lat&&w.lng);
    if(!trailPts.length)return;

    // Walk distance: 상행 구간만 합산 (하산은 역순 중복이므로 제외) × 등산로 보정계수
    const ascPts=trailPts.filter(w=>!w.descent);
    let walkKm=0;
    for(let i=1;i<ascPts.length;i++)walkKm+=_haversineKm(ascPts[i-1].lat,ascPts[i-1].lng,ascPts[i].lat,ascPts[i].lng);
    walkKm=+(walkKm*1.45).toFixed(1);
    const walkMin=Math.round(walkKm/2.5*60);
    _rRouteInfo[resId][ti]={carMin:null,carKm:null,walkMin,walkKm,fallback:true};

    // Car segment: draw dashed placeholder immediately, then fetch actual road geometry
    if(baseCoords){
      const tp0=trailPts[0];
      const placeholder=new kakao.maps.Polyline({
        path:[new kakao.maps.LatLng(baseCoords.lat,baseCoords.lng),new kakao.maps.LatLng(tp0.lat,tp0.lng)],
        strokeWeight:3,strokeColor:'#f0c040',strokeOpacity:.5,strokeStyle:'shortdash',map:mapR
      });
      _rFocusPolylines.push(placeholder);
      bounds.extend(new kakao.maps.LatLng(baseCoords.lat,baseCoords.lng));
      bounds.extend(new kakao.maps.LatLng(tp0.lat,tp0.lng));

      // Base label
      const baseLbl=document.createElement('div');
      baseLbl.style.cssText='background:rgba(10,20,40,.9);border:1px solid #f0c040;border-radius:8px;padding:2px 7px;font-size:10px;font-weight:700;color:#f0c040;white-space:nowrap;pointer-events:none;';
      baseLbl.textContent='🏠 '+(baseWp.name||'').replace('탐방지원센터','').replace('설악산국립공원사무소','공단사무소').slice(0,8);
      const baseOv=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(baseCoords.lat,baseCoords.lng),content:baseLbl,yAnchor:1.5,zIndex:5});
      baseOv.setMap(mapR);_rFocusPolylines.push(baseOv);

      // Async: fetch actual car route
      const cacheKey=baseCoords.lat+','+baseCoords.lng+'>'+tp0.lat+','+tp0.lng;
      _fetchCarRoute(cacheKey,baseCoords.lat,baseCoords.lng,tp0.lat,tp0.lng).then(result=>{
        if(_rFocusResId!==resId||!mapR)return;
        if(_rRouteInfo[resId]&&_rRouteInfo[resId][ti]){
          _rRouteInfo[resId][ti].carMin=result.duration;
          _rRouteInfo[resId][ti].carKm=result.distance;
          _rRouteInfo[resId][ti].fallback=result.fallback;
        }
        if(!result.fallback&&result.path&&result.path.length>1){
          try{placeholder.setMap(null);}catch(e){}
          const roadLine=new kakao.maps.Polyline({
            path:result.path,strokeWeight:4,strokeColor:'#f0c040',strokeOpacity:.9,strokeStyle:'solid',map:mapR
          });
          _rFocusPolylines.push(roadLine);
        }else{
          // Fallback: show dashed line at full opacity
          try{placeholder.setStrokeOpacity(.75);}catch(e){}
        }
        _renderFocusPanelRouteInfo(resId);
      });
    }

    // Walk segment: 흰 점선(경로 윤곽) + 팀 색상 실선 (시인성 향상)
    if(trailPts.length>=2){
      const walkPath=trailPts.map(w=>new kakao.maps.LatLng(w.lat,w.lng));
      // 흰 점선 밑 레이어 — 배경 대비용
      const whiteLine=new kakao.maps.Polyline({
        path:walkPath,strokeWeight:7,strokeColor:'#ffffff',strokeOpacity:.22,strokeStyle:'solid',map:mapR
      });
      _rFocusPolylines.push(whiteLine);
      // 팀 색상 실선 위 레이어
      const walkLine=new kakao.maps.Polyline({
        path:walkPath,strokeWeight:4,strokeColor:col,strokeOpacity:.92,strokeStyle:'solid',map:mapR
      });
      _rFocusPolylines.push(walkLine);
      walkPath.forEach(p=>bounds.extend(p));

      // 각 표지판 위치에 점 마커 + 번호 라벨 (하산 중복 좌표는 1회만)
      const curWpIdx=team.wpIdx>=0?team.wpIdx:0;
      const seenPos=new Set();
      wps.forEach((w,wi)=>{
        if(w.isBase||!w.lat||!w.lng)return;
        const isCur=wi===curWpIdx;
        const key=w.lat.toFixed(6)+','+w.lng.toFixed(6);
        if(seenPos.has(key)&&!isCur)return;
        seenPos.add(key);
        const isPassed=wi<curWpIdx;
        const dotEl=document.createElement('div');
        if(isCur){
          dotEl.style.cssText=`width:14px;height:14px;border-radius:50%;background:${col};border:2.5px solid #fff;box-shadow:0 0 0 3px ${col}55,0 0 12px ${col}99;animation:wpPulse 1.4s ease-in-out infinite;pointer-events:none;`;
        }else{
          dotEl.style.cssText=`width:9px;height:9px;border-radius:50%;background:${isPassed?col+'99':'rgba(255,255,255,.6)'};border:1.5px solid ${isPassed?col:'rgba(255,255,255,.85)'};pointer-events:none;`;
        }
        const dotOv=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(w.lat,w.lng),content:dotEl,zIndex:isCur?7:6});
        dotOv.setMap(mapR);_rFocusPolylines.push(dotOv);
        // 표지판 번호 라벨: 전체 표시 (현재·사고지점은 강조, 나머지는 작게)
        if(w.code||w.isTarget||w.isHosp){
          const lbl=document.createElement('div');
          const _nm=(w.name||'').replace(/^\d{2}-\d{2}\s*/,'').trim();  // 이름 앞 코드 중복 제거
          const txt=w.isHosp?'🏥 '+w.name:(w.code||'')+((isCur||w.isTarget)&&_nm&&_nm!==w.code?' '+_nm.slice(0,8):'');
          if(isCur||w.isTarget||w.isHosp){
            const bc=isCur?col:w.isHosp?'#27ae60':'#e05050';
            lbl.style.cssText=`background:rgba(8,18,36,.93);border:1.5px solid ${bc};border-radius:7px;padding:2px 6px;font-size:10px;font-weight:700;color:${bc};white-space:nowrap;pointer-events:none;`;
          }else{
            lbl.style.cssText='background:rgba(8,18,36,.78);border:1px solid rgba(255,255,255,.25);border-radius:5px;padding:1px 4px;font-size:9px;font-weight:600;color:rgba(255,255,255,.82);white-space:nowrap;pointer-events:none;font-family:monospace;';
          }
          lbl.textContent=txt;
          const lblOv=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(w.lat,w.lng),content:lbl,yAnchor:1.9,zIndex:isCur?8:5});
          lblOv.setMap(mapR);_rFocusPolylines.push(lblOv);
        }
      });
    }else if(trailPts.length===1){
      bounds.extend(new kakao.maps.LatLng(trailPts[0].lat,trailPts[0].lng));
    }

    // (팀 이름 라벨은 팀 칩이 같은 자리에 이미 표시되므로 별도 라벨 생략)
  });

  _focusBounds=bounds;
  _fitFocusBounds();
}
// 포커스 모드: 하단 패널에 경로가 가리지 않도록 패널 높이만큼 아래 여백을 줘서 맞춤
let _focusBounds=null;
function _fitFocusBounds(){
  if(!mapR||!_focusBounds)return;
  const panel=document.getElementById('focusModePanel');
  const mapEl=document.getElementById('mapRescue');
  const mh=(mapEl&&mapEl.offsetHeight)||window.innerHeight||600;
  let bpad=Math.round(mh*0.42); // 패널 미표시 시 기본값
  if(panel&&panel.classList.contains('on')&&panel.offsetHeight>0){
    bpad=Math.min(panel.offsetHeight+24,Math.round(mh*0.72)); // 패널 높이 + 여유 (과도 방지 상한)
  }
  try{mapR.setBounds(_focusBounds,50,40,bpad,40);}catch(e){}
}

let _fpTeamOpen=new Set(); // 펼쳐진 팀 카드 인덱스
function _fpToggleTeam(ti){_fpTeamOpen.has(ti)?_fpTeamOpen.delete(ti):_fpTeamOpen.add(ti);if(_rFocusResId)_renderFocusPanel(_rFocusResId);}

function _renderFocusPanel(resId){
  const panel=document.getElementById('focusModePanel');
  const titleEl=document.getElementById('focusPanelTitle');
  const teamsEl=document.getElementById('focusPanelTeams');
  if(!panel||!titleEl||!teamsEl)return;
  const rescue=(DB.g('rescues')||[]).find(r=>r.id===resId);
  if(!rescue){exitFocusMode();return;}
  const _elp=_elapsedStr(rescue.date);
  titleEl.innerHTML='🔴 '+_esc(rescue.title)+(_elp?` <span class="js-elapsed" data-d="${_esc(rescue.date)}" style="color:#f0a500;font-size:10px;font-weight:700;">⏱ ${_elp}</span>`:'');
  const teams=rescue.teams||[];
  // 보고서·타임라인 버튼 (상단 고정)
  const actionBtns=`<div style="display:flex;gap:6px;margin-bottom:10px;">
    <button onclick="selResId=${resId};curResId=${resId};viewReport();" style="flex:1;padding:7px 0;border-radius:8px;border:1px solid rgba(79,168,208,.3);background:rgba(79,168,208,.1);color:#4fa8d0;font-size:11px;font-weight:700;cursor:pointer;">📄 보고서</button>
    <button onclick="selResId=${resId};curResId=${resId};viewTimeline();" style="flex:1;padding:7px 0;border-radius:8px;border:1px solid rgba(79,168,208,.3);background:rgba(79,168,208,.1);color:#4fa8d0;font-size:11px;font-weight:700;cursor:pointer;">📍 타임라인</button>
    <button onclick="selResId=${resId};curResId=${resId};endSit();" style="flex:none;padding:7px 10px;border-radius:8px;border:1px solid rgba(39,174,96,.3);background:rgba(39,174,96,.08);color:#27ae60;font-size:11px;font-weight:700;cursor:pointer;">✅ 종료</button>
  </div>`;
  if(!teams.length){
    teamsEl.innerHTML=actionBtns+'<div style="font-size:11px;color:rgba(255,255,255,.35);text-align:center;padding:12px 0;">팀 없음 — 타임라인에서 팀 생성</div>';
    panel.classList.add('on');return;
  }
  const stagePal=[
    {c:'rgba(255,255,255,.4)',label:'출발'},
    {c:'#4fa8d0',label:'이동중'},
    {c:'#f0a500',label:'환자조우'},
    {c:'#27ae60',label:'하산'},
  ];
  const rInfos=_rRouteInfo[resId]||[];
  const teamCards=teams.map((team,ti)=>{
    const col=TEAM_COLORS[ti%TEAM_COLORS.length];
    const si=_teamStageIdx(team);
    const pal=stagePal[si]||stagePal[3];
    const typeIco=_teamIco(team);
    const total=Math.max(team.wps.length-1,1);
    const pct=Math.round((team.wpIdx/total)*100);
    const atEnd=team.wpIdx>=team.wps.length-1;
    const curWp=team.wps[team.wpIdx]||team.wps[0]||{};
    const curName=(curWp.code?curWp.code+' ':'')+(curWp.name||'').replace(/^\d{2}-\d{2}\s*/,'').slice(0,14);
    const info=rInfos[ti];
    const baseWp=team.wps.find(w=>w.isBase);
    const hasBase=baseWp&&_getBaseByName(baseWp.name);
    const tps=team.wps.filter(w=>!w.isBase&&w.lat&&w.lng);
    let routeStr='';
    if(hasBase){
      const body=info?_routeInfoStr(info,tps.length>1):'🚗 계산중…'+(tps.length>1?' · 🚶 …':'');
      routeStr=`<div id="rinfo-${resId}-${ti}" style="font-size:10px;color:rgba(240,192,64,${info?'.65':'.45'});margin-top:5px;padding-top:5px;border-top:1px solid rgba(255,255,255,.05);">${body}</div>`;
    }
    const isOpen=_fpTeamOpen.has(ti);
    // 세부정보: 구성원 + 경유지 목록
    let detailHtml='';
    if(isOpen){
      const mems=(team.members||[]);
      const memStr=mems.length?mems.map(m=>_esc(m)).join(' · '):'<span style="opacity:.4;">구성원 미입력</span>';
      const wpList=team.wps.map((w,wi)=>{
        const stIco=w.status==='passed'?'✅':w.status==='active'?'▶':w.status==='skipped'?'⏭':'⬜';
        const nm=(w.code?w.code+' ':'')+_esc((w.name||'-').replace(/^\d{2}-\d{2}\s*/,''));
        const timeStr=w.passedAt?` <span style="color:rgba(255,255,255,.3);font-size:9px;">${w.passedAt.slice(11,16)}</span>`:'';
        const flag=w.isBase?'🏠':w.isTarget?'🚨':w.descent?'🔽':'';
        return`<div style="display:flex;align-items:center;gap:5px;padding:2px 0;${wi===team.wpIdx?'background:rgba(79,168,208,.07);border-radius:4px;margin:0 -3px;padding:2px 3px;':''}"><span style="font-size:10px;flex-shrink:0;">${stIco}</span><span style="font-size:10px;color:rgba(255,255,255,.7);flex:1;">${flag?flag+' ':''} ${nm}</span>${timeStr}</div>`;
      }).join('');
      detailHtml=`<div style="margin-top:7px;padding-top:7px;border-top:1px solid rgba(255,255,255,.07);">
        <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:3px;">👥 구성원</div>
        <div style="font-size:11px;color:rgba(255,255,255,.65);margin-bottom:7px;">${memStr}</div>
        <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:3px;">📍 경유지</div>
        <div style="font-size:10px;line-height:1.8;">${wpList||'<span style="opacity:.4;">경유지 없음</span>'}</div>
        ${rescue.handover&&rescue.handover.team===team.name?`<div style="margin-top:5px;font-size:10px;color:#27ae60;">🤝 인계: ${_esc(rescue.handover.to)}</div>`:''}
      </div>`;
    }
    const hasDescent=team.wps.some(w=>w.descent);
    const actionBtn=(()=>{
      if(atEnd&&curWp.isTarget&&!hasDescent)return`<button onclick="_focusDescentTeam(${resId},${ti})" style="background:rgba(39,174,96,.15);border:1px solid rgba(39,174,96,.4);color:#27ae60;border-radius:7px;padding:4px 11px;font-size:11px;font-weight:700;cursor:pointer;">${team.type==='heli'?'🏥 이송':'🔽 하산'}</button>`;
      if(atEnd)return`<span style="font-size:10px;color:#27ae60;font-weight:700;">✓ ${hasDescent?(team.type==='heli'?'이송 완료':'하산 완료'):'완료'}</span>`;
      const canReturn=!hasDescent&&team.wpIdx>0&&!curWp.isTarget;
      return`${canReturn?`<button onclick="_focusReturnTeam(${resId},${ti})" style="background:rgba(230,126,34,.1);border:1px solid rgba(230,126,34,.3);color:#e67e22;border-radius:7px;padding:4px 8px;font-size:11px;font-weight:600;cursor:pointer;">↩️</button>`:''}<button onclick="_focusPassTeam(${resId},${ti})" style="background:rgba(79,168,208,.15);border:1px solid rgba(79,168,208,.35);color:#4fa8d0;border-radius:7px;padding:4px 12px;font-size:11px;font-weight:700;cursor:pointer;">▶ 통과</button>`;
    })();
    return `<div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:10px 11px;margin-bottom:8px;">
      <div onclick="_fpToggleTeam(${ti})" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;cursor:pointer;user-select:none;">
        <span style="font-size:12px;font-weight:800;color:${col};">${typeIco} ${_esc(team.name)}</span>
        <div style="display:flex;align-items:center;gap:6px;">
          <span style="font-size:10px;font-weight:700;color:${pal.c};background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);padding:2px 8px;border-radius:10px;">${pal.label}</span>
          <span style="font-size:11px;color:rgba(255,255,255,.3);">${isOpen?'▾':'▸'}</span>
        </div>
      </div>
      <div style="height:5px;background:rgba(255,255,255,.07);border-radius:3px;overflow:hidden;margin-bottom:6px;">
        <div style="height:100%;width:${pct}%;background:${col};border-radius:3px;transition:width .4s;"></div>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;">
        <span style="font-size:10px;color:rgba(255,255,255,.4);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">📍 ${_esc(curName||'-')} · ${team.wpIdx}/${total}</span>
        <span style="display:flex;gap:5px;flex-shrink:0;">${actionBtn}</span>
      </div>
      ${routeStr}
      ${detailHtml}
    </div>`;
  }).join('');
  teamsEl.innerHTML=actionBtns+teamCards;
  // 전 팀 완료 배너
  if(teams.length>0&&teams.every(t=>_teamDone(t))){
    teamsEl.innerHTML+=`<div style="background:rgba(39,174,96,.12);border:1.5px solid rgba(39,174,96,.45);border-radius:12px;padding:14px 16px;margin-top:4px;text-align:center;">
      <div style="font-size:13px;font-weight:800;color:#27ae60;margin-bottom:6px;">🏁 전 팀 하산/이송 완료</div>
      <div style="font-size:11px;color:rgba(255,255,255,.45);margin-bottom:10px;">상황을 종료하시겠습니까?</div>
      <button onclick="selResId=${resId};curResId=${resId};endSit();" style="background:rgba(39,174,96,.2);border:1px solid rgba(39,174,96,.55);color:#27ae60;border-radius:8px;padding:8px 0;font-size:12px;font-weight:700;cursor:pointer;width:100%;">✅ 상황 종료</button>
    </div>`;
  }
  panel.classList.add('on');
}


function enterFocusMode(resId){
  if(!resId)return;
  _rFocusResId=resId;
  _rebuildTeamChips();
  _applyFocusDim();
  _drawFocusRoutes(resId);
  _renderFocusPanel(resId);
  // Close existing popup
  const popup=document.getElementById('resPopup');if(popup)popup.classList.remove('on');
  // 패널 슬라이드업(.3s) 후 실제 패널 높이로 경로 재맞춤 → 하단 가림 방지
  setTimeout(_fitFocusBounds,360);
}

function exitFocusMode(){
  _rFocusResId=null;
  _fpTeamOpen.clear();
  _clearFocusPolylines();
  _clearFocusDim();
  const panel=document.getElementById('focusModePanel');
  if(panel)panel.classList.remove('on');
}

function _focusPassTeam(resId,teamIdx){
  const _res=DB.g('rescues')||[];const _ri=_res.findIndex(x=>x.id===resId);
  if(_ri<0)return;
  const team=(_res[_ri].teams||[])[teamIdx];
  if(!team)return;
  const next=team.wpIdx+1;
  if(next>=team.wps.length){toast('✅ 경로 끝 — 통과할 지점 없음');return;}
  const passedWp=team.wps[team.wpIdx];
  if(passedWp){passedWp.status='passed';passedWp.passedAt=now();}
  team.wps[next].status='active';
  team.wpIdx=next;
  if(!_res[_ri].wpLog)_res[_ri].wpLog=[];
  const _d=new Date();
  _res[_ri].wpLog.push({time:_d.getHours().toString().padStart(2,'0')+':'+_d.getMinutes().toString().padStart(2,'0'),teamName:team.name,code:(passedWp&&passedWp.code)||'',wpName:(passedWp&&passedWp.name)||''});
  DB.s('rescues',_res);
  // Sync in-memory _tlTeams if same rescue is open in timeline
  if(_tlWpResId===resId&&_tlTeams[teamIdx]){
    _tlTeams[teamIdx]=Object.assign({},team,{collapsed:_tlTeams[teamIdx].collapsed});
    if(_tlSelTeam===teamIdx){_tlWps=_tlTeams[teamIdx].wps;_tlWpIdx=_tlTeams[teamIdx].wpIdx;}
  }
  const curWp=team.wps[next]||{};
  const wpLabel=(curWp.code?curWp.code+' ':'')+(curWp.name||'').slice(0,12);
  toast('✅ '+team.name+': '+(wpLabel||'통과'));
  if(next>=team.wps.length-1&&team.wps[next]&&team.wps[next].descent)_promptHandover(resId,team);
  _renderFocusPanel(resId);
  _checkAllTeamsDone(resId);
  try{_clearFocusPolylines();_drawFocusRoutes(resId);}catch(e){}
  _rebuildTeamChips();
  _applyFocusDim();
}

// 포커스 패널: 팀 데이터 변경 공통 처리 (DB 저장 + 타임라인 동기화 + 재렌더)
function _focusMutateTeam(resId,teamIdx,mutate){
  const _res=DB.g('rescues')||[];const _ri=_res.findIndex(x=>x.id===resId);
  if(_ri<0)return;
  const team=(_res[_ri].teams||[])[teamIdx];
  if(!team)return;
  if(!mutate(team))return;
  DB.s('rescues',_res);
  if(_tlWpResId===resId&&_tlTeams[teamIdx]){
    _tlTeams[teamIdx]=Object.assign({},team,{collapsed:_tlTeams[teamIdx].collapsed});
    if(_tlSelTeam===teamIdx){_tlWps=_tlTeams[teamIdx].wps;_tlWpIdx=_tlTeams[teamIdx].wpIdx;}
  }
  _renderFocusPanel(resId);
  try{_clearFocusPolylines();_drawFocusRoutes(resId);}catch(e){}
  _rebuildTeamChips();
  _applyFocusDim();
}

function _focusDescentTeam(resId,teamIdx){
  _focusMutateTeam(resId,teamIdx,team=>{
    if(!_appendDescentWps(team)){toast('⚠️ 환자 조우 후 가능');return false;}
    toast(team.type==='heli'?'🏥 '+team.name+': 병원 이송 시작':'🔽 '+team.name+': 하산 시작');
    return true;
  });
}

function _focusReturnTeam(resId,teamIdx){
  const _res=DB.g('rescues')||[];const _ri=_res.findIndex(x=>x.id===resId);
  const team=_ri>=0?(_res[_ri].teams||[])[teamIdx]:null;
  if(!team)return;
  if(!confirm(team.name+' 복귀(하산)시킬까요? 남은 상행 구간은 취소됩니다.'))return;
  _focusMutateTeam(resId,teamIdx,t=>{
    if(!_appendReturnWps(t)){toast('⚠️ 복귀 불가 상태');return false;}
    toast('↩️ '+t.name+': 복귀 경로 생성');
    return true;
  });
}

// ══════════════════════════════════════════
// 재난 목록 + 필터
// ══════════════════════════════════════════
function setResListTab(tab){
  _resListTab=tab;_persistFilters();
  ['all','rescue','haz'].forEach(t=>{
    const btn=document.getElementById('resListTab_'+t);
    if(!btn)return;
    const isOn=t===tab;
    const cols={all:['rgba(79,168,208,.35)','rgba(79,168,208,.15)','#4fa8d0'],rescue:['rgba(192,57,43,.4)','rgba(192,57,43,.18)','#e05050'],haz:['rgba(230,126,34,.4)','rgba(230,126,34,.18)','#e67e22']};
    const [bc,bg,col]=cols[t];
    btn.style.borderColor=isOn?bc:'rgba(255,255,255,.1)';
    btn.style.background=isOn?bg:'transparent';
    btn.style.color=isOn?col:'rgba(255,255,255,.3)';
  });
  renderResList();
}
let _resSearchQ='';
const _renderResListDebounced=_debounce(()=>renderResList(),250);
function onResSearch(v){
  _resSearchQ=(v||'').trim().toLowerCase();
  const clr=document.getElementById('resSearchClear');
  if(clr)clr.style.display=_resSearchQ?'block':'none';
  _renderResListDebounced();
}
function clearResSearch(){
  _resSearchQ='';
  const inp=document.getElementById('resSearchInput');if(inp)inp.value='';
  const clr=document.getElementById('resSearchClear');if(clr)clr.style.display='none';
  renderResList();
}
function _resMatchSearch(r){
  if(!_resSearchQ)return true;
  const hay=[r.title,r.vName,r.location,r.loc,r.author,r.type,r.hazType,r.cause,r.extAgency,r.repName]
    .filter(Boolean).join(' ').toLowerCase();
  return hay.includes(_resSearchQ);
}
let _resListLimit=50,_resListSig='';
function _moreResList(){_resListLimit+=50;renderResList();}
function renderResList(){
  const res=DB.g('rescues')||[];const haz=DB.g('hazards')||[];
  _updateResFilterPanels();
  const _showRes=(_resListTab==='all'||_resListTab==='rescue')&&(resTypeF.size===0||resTypeF.has('🚨구조'));
  const _showHaz=(_resListTab==='all'||_resListTab==='haz')&&(resTypeF.size===0||resTypeF.has('⚠️위험상황'));
  const _stOkRes=s=>resStatusF.size===0||(resStatusF.has('진행중')&&s==='ongoing')||(resStatusF.has('종료')&&s==='done');
  const _stOkHaz=s=>{const active=!s||s==='미조치'||s==='조치중';return resStatusF.size===0||(resStatusF.has('진행중')&&active)||(resStatusF.has('종료')&&!active);};
  const _dateOkL=d=>_resDateOk(d);
  // 필터·검색·탭이 바뀌면 페이지 한도를 처음(50)으로 리셋. '더 보기' 재호출 땐 유지.
  const _sig=_resListTab+'|'+[...resTypeF].join()+'|'+[...resStatusF].join()+'|'+resDateFrom+'|'+resDateTo+'|'+(_resSearchQ||'');
  if(_sig!==_resListSig){_resListSig=_sig;_resListLimit=50;}
  let cards=[];
  const _hdr=(txt,col)=>`<div style="display:flex;align-items:center;gap:7px;margin:4px 2px 7px;"><span style="font-size:11px;font-weight:800;color:${col};letter-spacing:.3px;">${txt}</span><div style="flex:1;height:1px;background:linear-gradient(90deg,${col}44,transparent);"></div></div>`;
  // 🆘 조난·사고자 위치 수신 — 별도 sos 컬렉션이라 목록 최상단에 노출(아직 사고 미등록 건만)
  if(_resListTab!=='haz'&&(_sosPings||[]).length){
    const _regIds=new Set((res||[]).map(r=>r.sosId).filter(Boolean));
    const _open=(_sosPings||[]).filter(p=>p.lat&&p.lng&&!_regIds.has(p.id)).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if(_open.length){
      cards.push(_hdr('🆘 위치 수신 (미등록) '+_open.length,'#ffd24d'));
      _open.forEach(p=>{
        const mm=Math.round((Date.now()-(p.ts||0))/60000);
        cards.push(`<div class="lcard" onclick="_sosPinPopup('${p.id}')" style="position:relative;border-left:3px solid #ffe14d;">
          <div class="lico" style="background:#c0392b;border:none;color:#fff;">🆘</div>
          <div class="linfo">
            <div class="lname">🆘 ${_esc(p.name||'익명')} <span style="font-size:9px;color:#8ab4cc;font-weight:400;">±${p.acc||'?'}m · ${mm}분 전</span></div>
            ${_sosForeignBadge(p)?`<div style="margin-top:2px;">${_sosForeignBadge(p)}</div>`:''}
            ${p.msg?`<div class="lmeta" style="margin-top:2px;color:#cfe2f2;">${_esc(p.msg)}</div>`:''}
            <div class="lmeta" style="margin-top:2px;font-family:monospace;">${(+p.lat).toFixed(5)}, ${(+p.lng).toFixed(5)}</div>
            <button onclick="event.stopPropagation();sosToRescue('${p.id}')" style="margin-top:6px;padding:6px 12px;background:rgba(231,76,60,.15);border:1px solid rgba(231,76,60,.45);color:#ff6b5e;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;">🚨 구조 사고로 등록</button>
          </div>
        </div>`);
      });
    }
  }
  // 진행중 구조를 상단에 별도 그룹으로 모아 일일 운영 시인성 강화
  if(_showRes){
    const _rescues=res.filter(r=>_stOkRes(r.status)&&_dateOkL(r.date)&&_resMatchSearch(r)).slice().reverse();
    const _og=_rescues.filter(r=>r.status==='ongoing');
    const _dn=_rescues.filter(r=>r.status!=='ongoing');
    const _mkCard=r=>{
      const isOg=r.status==='ongoing';const ti=RES_TYPES[r.type]||RES_TYPES['기타'];
      const hasCoord=!!(r.lat&&r.lng);
      return `<div class="lcard" onclick="openResListDetail(${r.id})" style="position:relative;border-left:3px solid ${isOg?'#e74c3c':'#27ae60'};">
        <div class="lico" style="background:${isOg?ti.color:'#1a3a1a'};border:none;color:#fff;">${ti.ico}</div>
        <div class="linfo">
          <div class="lname">🚨 ${_esc(r.title)}</div>
          ${(r.extAgency||(r.mobilize&&r.mobilize.length))?`<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:3px;">
            ${r.extAgency?`<span style="font-size:9px;background:rgba(255,120,30,.18);color:#f08050;border:1px solid rgba(255,120,30,.35);border-radius:9px;padding:1px 7px;font-weight:700;">🚒 ${_esc(r.extAgency)}</span>`:''}
            ${(r.mobilize&&r.mobilize.length)?`<span style="font-size:9px;background:rgba(231,76,60,.18);color:#e74c3c;border:1px solid rgba(231,76,60,.4);border-radius:9px;padding:1px 7px;font-weight:700;">🚨 ${_esc(r.mobilize.join('·'))}</span>${_mobilizeCompactBadge(r)}`:''}
          </div>`:''}
          <div class="lmeta" style="margin-top:3px;">${_esc(r.type)} · ${r.date} · 사고자 ${_esc(r.vName||'미상')}${(r.victims2&&r.victims2.length)?` <span style="color:#e9897e;font-weight:700;">외 ${r.victims2.length}명</span>`:''}</div>
          ${hasCoord?`<button onclick="event.stopPropagation();viewOnMap(${r.lat},${r.lng})" style="margin-top:6px;padding:6px 12px;background:rgba(79,168,208,.12);border:1px solid rgba(79,168,208,.35);color:#4fa8d0;border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;">🗺️ 지도보기</button>`:''}
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;align-self:flex-start;flex-shrink:0;">
          <span class="lbadge" style="background:${isOg?'rgba(231,76,60,.22)':'rgba(39,174,96,.2)'};color:${isOg?'#ff6b5e':'#3ad17a'};">${isOg?'진행중':'종료'}</span>
          ${isOg&&_elapsedStr(r.date)?`<span class="js-elapsed" data-d="${_esc(r.date)}" style="font-size:10px;font-weight:700;color:#f0a500;white-space:nowrap;">⏱ ${_elapsedStr(r.date)}</span>`:''}
        </div>
      </div>`;
    };
    if(_og.length)cards.push(_hdr('🔴 진행중 작전 '+_og.length,'#ff6b5e'),..._og.map(_mkCard));
    if(_dn.length)cards.push(_hdr('✅ 종료 '+_dn.length,'#3ad17a'),..._dn.map(_mkCard));
  }
  if(_showHaz){
    cards=cards.concat((haz.filter(h=>_stOkHaz(h.hazStatus)&&_dateOkL(h.date)&&_resMatchSearch(h))).slice().reverse().map(h=>{
      const done=h.hazStatus&&h.hazStatus!=='미조치'&&h.hazStatus!=='조치중';
      const hasCoord=!!(h.lat&&h.lng);
      return `<div class="haz-card ${done?'haz-removed':''}" onclick="openHazDetail(${h.id})" style="border-left:3px solid ${done?'#27ae60':'#e67e22'};">
        <div style="display:flex;align-items:center;gap:10px;">
          <div style="font-size:22px;">${h.hazType?.split(' ')[0]||'⚠️'}</div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:13px;color:#e0edf8;font-weight:600;">${_esc(h.hazType||'위험상황')} · ${_esc(h.loc||'-')}${(h.mobilize&&h.mobilize.length)?` <span style="font-size:9px;background:rgba(231,76,60,.18);color:#e74c3c;border:1px solid rgba(231,76,60,.4);border-radius:9px;padding:1px 6px;font-weight:700;vertical-align:middle;">🚨 ${_esc(h.mobilize.join('·'))}</span>${_mobilizeCompactBadge(h)}`:''}</div>
            <div style="font-size:11px;color:#8ab4cc;margin-top:3px;">${h.dt||'-'} · ${_esc(h.danger||'-')} · ${_esc(h.author||'-')}</div>
            <div style="font-size:11px;color:#7a9cb8;margin-top:2px;">${_esc((h.desc||'').slice(0,40))}${(h.desc||'').length>40?'...':''}</div>
            ${hasCoord?`<button onclick="event.stopPropagation();viewOnMap(${h.lat},${h.lng})" style="margin-top:5px;padding:4px 10px;background:rgba(230,126,34,.12);border:1px solid rgba(230,126,34,.35);color:#e67e22;border-radius:7px;font-size:11px;font-weight:600;cursor:pointer;">🗺️ 지도보기</button>`:''}
          </div>
          <span class="lbadge ${done?'haz-badge-done':'haz-badge-active'}" style="align-self:flex-start;flex-shrink:0;">${_esc(h.hazStatus||'미조치')}</span>
        </div>
      </div>`;
    }));
  }
  const _tot=cards.length;
  let html=cards.slice(0,_resListLimit).join('');
  if(_tot>_resListLimit){
    html+=`<button onclick="_moreResList()" style="width:100%;margin-top:8px;padding:11px;border-radius:10px;border:1px solid rgba(79,168,208,.3);background:rgba(79,168,208,.08);color:#4fa8d0;font-size:13px;font-weight:700;cursor:pointer;">▾ 더 보기 (${_tot-_resListLimit}건 더)</button>`;
  }
  document.getElementById('resListWrap').innerHTML=html||'<div class="empty"><div class="empty-ico">📋</div><div class="empty-txt">해당 항목 없음</div><button onclick="resetResFilter()" style="margin-top:10px;padding:7px 16px;background:rgba(79,168,208,.12);border:1px solid rgba(79,168,208,.35);color:#4fa8d0;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">🔄 필터 초기화</button></div>';
}

// ══════════════════════════════════════════
// 재난 통계
// ══════════════════════════════════════════
// 평균 대응시간 분석 카드 (타임라인 타임스탬프 기반)
function _buildRespTimeCard(res){
  // 각 구조별 주요 시점 추출
  const arr=(res||[]).map(r=>{
    const t0=_parseDT(r.date);
    let tEnc=null,tDesc=null,tDone=null;
    (r.timetable||[]).forEach(e=>{
      const t=_parseDT(e.time);if(!t)return;
      const s=e.stage||'';
      if(/조우/.test(s)&&(!tEnc||t<tEnc))tEnc=t;
      if(/하산|이송|복귀/.test(s)&&(!tDesc||t<tDesc))tDesc=t;
      if(/처치완료|상황종료|완료/.test(s)&&(!tDone||t>tDone))tDone=t;
    });
    const tHand=_parseDT(r.handover&&r.handover.time);
    return {t0,tEnc,tDesc,tHand,tDone};
  });
  const avg=list=>{const v=list.filter(x=>x!=null&&x>=0&&x<48*60);return v.length?Math.round(v.reduce((a,b)=>a+b,0)/v.length):null;};
  const diffMin=(a,b)=>(a!=null&&b!=null&&b>=a)?Math.round((b-a)/60000):null;
  const encMins=arr.map(x=>diffMin(x.t0,x.tEnc));
  const careMins=arr.map(x=>diffMin(x.tEnc,x.tHand||x.tDone||x.tDesc));
  const totMins=arr.map(x=>diffMin(x.t0,x.tHand||x.tDone));
  const fmt=m=>m==null?'-':(m>=60?Math.floor(m/60)+'시간 '+(m%60)+'분':m+'분');
  const aEnc=avg(encMins),aCare=avg(careMins),aTot=avg(totMins);
  const nEnc=encMins.filter(x=>x!=null).length,nCare=careMins.filter(x=>x!=null).length,nTot=totMins.filter(x=>x!=null).length;
  if(!nEnc&&!nCare&&!nTot)return '';
  const cell=(label,val,n,col)=>`<div style="background:#060d1a;border-radius:8px;padding:9px 6px;text-align:center;">
    <div style="font-size:15px;font-weight:800;color:${col};line-height:1.2;">${fmt(val)}</div>
    <div style="font-size:9px;color:#7a9cb8;margin-top:3px;">${label}</div>
    <div style="font-size:8px;color:#3a6a8a;margin-top:1px;">n=${n}</div>
  </div>`;
  return `<div class="scard"><div class="stitle">⏱ 평균 대응시간</div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;">
      ${cell('신고→환자조우',aEnc,nEnc,'#4fa8d0')}
      ${cell('환자조우→인계',aCare,nCare,'#e67e22')}
      ${cell('신고→상황종료',aTot,nTot,'#27ae60')}
    </div>
    <div style="font-size:9px;color:#3a6a8a;margin-top:7px;line-height:1.5;">※ 타임라인에 기록된 시각 기준. 단계 기록이 있는 건만 집계(n)됩니다.</div>
  </div>`;
}
function renderRescueStats(){
  document.getElementById('topTitle').textContent='재난/구조 관리';
  if(!window._rescueStatTab)window._rescueStatTab='rescue';
  const tab=window._rescueStatTab;
  const rsTabR=document.getElementById('rsTabRescue');
  const rsTabH=document.getElementById('rsTabHaz');
  if(rsTabR&&rsTabH){
    rsTabR.style.background=tab==='rescue'?'#3d0a0a':'#1a0a0a';
    rsTabR.style.color=tab==='rescue'?'#ff7070':'#e05050';
    rsTabH.style.background=tab==='haz'?'#3d1f00':'#1a1000';
    rsTabH.style.color=tab==='haz'?'#ffaa44':'#e67e22';
  }
  const res=DB.g('rescues')||[];const haz=DB.g('hazards')||[];
  const mon=today().slice(0,7);
  const safeMax=obj=>Math.max(...Object.values(obj),1);
  const hbar=(k,v,max,col='#4fa8d0')=>{
    const pct=Math.round(v/max*100);
    return `<div style="display:flex;align-items:center;gap:5px;margin-bottom:5px;">
      <div style="width:64px;font-size:9px;color:#9bbdd4;text-align:right;flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${k}</div>
      <div style="flex:1;height:8px;background:rgba(255,255,255,.06);border-radius:4px;overflow:hidden;">
        <div style="height:100%;width:${pct}%;background:${col};border-radius:4px;"></div>
      </div>
      <div style="width:22px;font-size:9px;color:${col};font-weight:700;text-align:right;flex-shrink:0;">${v}</div>
    </div>`;
  };
  const mini=(l,v,col='#e0edf8')=>`<div style="background:#060d1a;border-radius:7px;padding:6px 4px;text-align:center;"><div style="font-size:15px;font-weight:800;color:${col};line-height:1.2;">${v}</div><div style="font-size:8px;color:#3a6a8a;margin-top:1px;">${l}</div></div>`;
  const chartCard=(title,obj,col)=>{
    const entries=Object.entries(obj).sort((a,b)=>b[1]-a[1]);
    if(!entries.length)return '';
    const mx=safeMax(obj);
    return `<div class="scard"><div class="stitle">${title}</div>${entries.map(([k,v])=>hbar(k,v,mx,col)).join('')}</div>`;
  };
  const w=document.getElementById('rescueStatsWrap');
  // 엑셀 다운로드 카드: 날짜 범위 선택
  if(!window._statExpFrom){const d=new Date();window._statExpFrom=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-01';}
  if(!window._statExpTo)window._statExpTo=today();
  const expCard=`<div class="scard" style="border-color:rgba(39,174,96,.25);">
    <div class="stitle" style="color:#27ae60;">📥 엑셀 다운로드</div>
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
      <input type="date" value="${window._statExpFrom}" onchange="window._statExpFrom=this.value"
        style="flex:1;background:#060d1a;border:1px solid rgba(255,255,255,.12);color:#b8d4e8;border-radius:7px;padding:7px 8px;font-size:12px;color-scheme:dark;">
      <span style="font-size:11px;color:#3a6a8a;flex-shrink:0;">~</span>
      <input type="date" value="${window._statExpTo}" onchange="window._statExpTo=this.value"
        style="flex:1;background:#060d1a;border:1px solid rgba(255,255,255,.12);color:#b8d4e8;border-radius:7px;padding:7px 8px;font-size:12px;color-scheme:dark;">
    </div>
    <button onclick="downloadStatsExcel('${tab}')"
      style="width:100%;padding:9px;border-radius:8px;background:rgba(39,174,96,.13);border:1px solid rgba(39,174,96,.4);color:#27ae60;font-size:12px;font-weight:700;cursor:pointer;">
      📥 ${tab==='rescue'?'구조보고':'위험상황'} 자료 다운로드 (.csv)
    </button>
  </div>`;
  if(tab==='rescue'){
    const injMap={},sevMap={},cauMap={},methodMap={},ageMap={},timeMap={'새벽(0-6시)':0,'오전(6-12시)':0,'오후(12-18시)':0,'저녁(18-24시)':0},genderMap={},loctypeMap={},weatherMap={};
    res.forEach(r=>{
      (r.injuryParts||[]).forEach(p=>{injMap[p]=(injMap[p]||0)+1;});
      if(r.severity)sevMap[r.severity]=(sevMap[r.severity]||0)+1;
      if(r.cause)cauMap[r.cause]=(cauMap[r.cause]||0)+1;
      (r.rescueMethod||[]).forEach(m=>{methodMap[m]=(methodMap[m]||0)+1;});
      if(r.vGender&&r.vGender!=='알수없음')genderMap[r.vGender]=(genderMap[r.vGender]||0)+1; // 미상은 차트에서 제외(타 화면과 일관)
      if(r.loctype)loctypeMap[r.loctype]=(loctypeMap[r.loctype]||0)+1;
      if(r.weather)weatherMap[r.weather]=(weatherMap[r.weather]||0)+1;
      {let age=r.vBirth?_ageFromBirth(r.vBirth):(r.vAge!=null&&r.vAge!==''?parseInt(r.vAge):'');if(age!==''&&!isNaN(age)){const ag=age<20?'10대 이하':age<30?'20대':age<40?'30대':age<50?'40대':age<60?'50대':age<70?'60대':'70대+';ageMap[ag]=(ageMap[ag]||0)+1;}}
      // 발생 시각: r.date("YYYY-MM-DD HH:MM" 또는 "...THH:MM")에서 시(時) 추출 (r.time 필드는 존재하지 않음)
      {const _tm=(r.date||'').match(/[ T](\d{1,2}):/);if(_tm){const h=parseInt(_tm[1],10);if(h<6)timeMap['새벽(0-6시)']++;else if(h<12)timeMap['오전(6-12시)']++;else if(h<18)timeMap['오후(12-18시)']++;else timeMap['저녁(18-24시)']++;}}
    });
    // 구조 월별 추이 (최근 6개월)
    const rMonMap={};
    res.forEach(r=>{if(r.date){const m=r.date.slice(0,7);rMonMap[m]=(rMonMap[m]||0)+1;}});
    const rMonSorted=Object.fromEntries(Object.entries(rMonMap).sort((a,b)=>a[0].localeCompare(b[0])).slice(-6));
    // 평균 대응시간 분석
    const respCard=_buildRespTimeCard(res);
    w.innerHTML=`
      ${expCard}
      <div class="scard">
        <div class="stitle">🚨 구조보고 현황</div>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px;">
          ${mini('전체',res.length)}
          ${mini('진행중',res.filter(r=>r.status==='ongoing').length,'#e05050')}
          ${mini('종료',res.filter(r=>r.status==='done').length,'#27ae60')}
          ${mini('이번달',res.filter(r=>r.date&&r.date.startsWith(mon)).length,'#4fa8d0')}
        </div>
      </div>
      <div class="scard">
        <div class="stitle">🔥 사고 다발 구간 (히트맵)</div>
        <div id="heatMapEl" style="width:100%;height:280px;border-radius:9px;overflow:hidden;background:#060d1a;"></div>
        <div id="heatTopList" style="margin-top:8px;"></div>
      </div>
      ${respCard}
      ${chartCard('📈 월별 구조 발생 (최근 6개월)',rMonSorted,'#e05050')}
      ${chartCard('⏰ 발생 시간대',timeMap,'#4fa8d0')}
      ${chartCard('👤 연령대',ageMap,'#9b59b6')}
      ${chartCard('⚧ 성별',genderMap,'#3498db')}
      ${chartCard('🚑 구조유형',Object.fromEntries(Object.keys(RES_TYPES).map(t=>[t,res.filter(r=>r.type===t).length]).filter(([,v])=>v)),'#e05050')}
      ${chartCard('⚡ 사고원인',cauMap,'#e67e22')}
      ${chartCard('🦵 부상부위',injMap,'#c0392b')}
      ${chartCard('🩺 중증도',sevMap,'#8e44ad')}
      ${chartCard('🛟 구조방법',methodMap,'#27ae60')}
      ${chartCard('📍 장소구분',loctypeMap,'#1abc9c')}
      ${chartCard('🌤 날씨',weatherMap,'#f39c12')}
    `;
    setTimeout(()=>_renderHeatMap('rescue'),120);
  } else {
    const typMap={},statusMap={},monMap={};
    haz.forEach(h=>{
      if(h.hazType)typMap[h.hazType]=(typMap[h.hazType]||0)+1;
      if(h.hazStatus)statusMap[h.hazStatus]=(statusMap[h.hazStatus]||0)+1;
      if(h.date){const m=h.date.slice(0,7);monMap[m]=(monMap[m]||0)+1;}
    });
    const monSorted=Object.fromEntries(Object.entries(monMap).sort((a,b)=>a[0].localeCompare(b[0])).slice(-6));
    w.innerHTML=`
      ${expCard}
      <div class="scard">
        <div class="stitle">⚠️ 위험상황 현황</div>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px;">
          ${mini('전체',haz.length)}
          ${mini('미조치',haz.filter(h=>h.hazStatus==='미조치').length,'#e05050')}
          ${mini('조치중',haz.filter(h=>h.hazStatus==='조치중').length,'#e67e22')}
          ${mini('완료',haz.filter(h=>h.hazStatus&&h.hazStatus!=='미조치'&&h.hazStatus!=='조치중').length,'#27ae60')}
        </div>
      </div>
      <div class="scard">
        <div class="stitle">🔥 사고 다발 구간 (히트맵)</div>
        <div id="heatMapEl" style="width:100%;height:280px;border-radius:9px;overflow:hidden;background:#060d1a;"></div>
        <div id="heatTopList" style="margin-top:8px;"></div>
      </div>
      ${chartCard('🪨 위험 유형',typMap,'#e67e22')}
      ${chartCard('📋 처리 현황',statusMap,'#3498db')}
      ${chartCard('📅 월별 발생 (최근 6개월)',monSorted,'#9b59b6')}
    `;
    setTimeout(()=>_renderHeatMap('haz'),120);
  }
}

// 통계 자료 엑셀(CSV) 다운로드: 날짜 범위 필터
// ── 사고 다발 구간 히트맵: 표지판 코드 기준으로 집계 (GPS 없어도 포함) ──
function _renderHeatMap(tab){
  const el=document.getElementById('heatMapEl');
  if(!el||!window._KR)return;
  const allData=(tab==='haz'?(DB.g('hazards')||[]):(DB.g('rescues')||[]));
  if(!allData.length){el.innerHTML='<div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:11px;color:rgba(255,255,255,.25);">기록 없음</div>';return;}

  // 표지판 코드 맵 구성 (01-05 → {lat,lng,name})
  const facs=DB.g('facilities')||[];
  const signMap={};
  facs.filter(f=>f.type&&f.type.includes('다목적위치표지판')&&f.lat&&f.lng).forEach(f=>{
    const m=(f.name||'').match(/^(\d{2}-\d{2})/);
    if(m)signMap[m[1]]={lat:f.lat,lng:f.lng,code:m[1],name:f.name};
  });

  // 집계: 표지판 코드 우선, 없으면 위치 텍스트 코드, 없으면 GPS 250m 격자
  const CELL=0.0025;
  const bins={}; // key → {latSum,lngSum,latN,n,code,label}
  allData.forEach(x=>{
    let key,code=null;
    // 1) GPS → 가장 가까운 표지판 코드로 snap (1km 이내)
    if(x.lat&&x.lng&&Object.keys(signMap).length){
      let bestCode=null,bestD=Infinity;
      Object.values(signMap).forEach(s=>{const d=_haversineKm(x.lat,x.lng,s.lat,s.lng);if(d<bestD){bestD=d;bestCode=s.code;}});
      if(bestCode&&bestD<1){code=bestCode;key='s_'+code;}
    }
    // 2) 위치 텍스트에서 XX-XX 코드 추출 (GPS 없거나 1km 밖)
    if(!key){
      const m=(x.location||'').match(/(\d{2}-\d{2})/);
      if(m){code=m[1];key='s_'+code;}
    }
    // 3) GPS만 있고 표지판 없는 구역 → 250m 격자
    if(!key&&x.lat&&x.lng){key='g_'+Math.round(x.lat/CELL)+'_'+Math.round(x.lng/CELL);}
    if(!key)return; // GPS도 없고 코드도 없으면 제외
    if(!bins[key])bins[key]={latSum:0,lngSum:0,latN:0,n:0,code};
    if(x.lat&&x.lng){bins[key].latSum+=x.lat;bins[key].lngSum+=x.lng;bins[key].latN++;}
    bins[key].n++;
  });

  // 각 bin의 대표 좌표: GPS 평균 → 표지판 좌표 → null
  const cells=Object.values(bins).map(b=>{
    let lat=b.latN>0?b.latSum/b.latN:null,lng=b.latN>0?b.lngSum/b.latN:null;
    const s=b.code&&signMap[b.code];
    if(!lat&&s){lat=s.lat;lng=s.lng;} // GPS 없는 기록만 있는 경우 표지판 좌표 사용
    const label=b.code?b.code+(s&&s.name?' '+s.name.replace(/^\d{2}-\d{2}\s*/,'').slice(0,8):'')
                :(lat?lat.toFixed(4)+','+lng.toFixed(4):'?');
    return {lat,lng,n:b.n,label};
  }).filter(c=>c.lat&&c.lng).sort((a,b)=>b.n-a.n);

  if(!cells.length){el.innerHTML='<div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:11px;color:rgba(255,255,255,.25);">좌표·위치 정보 없음</div>';return;}
  try{
    const map=new kakao.maps.Map(el,{center:new kakao.maps.LatLng(38.13,128.43),level:8});
    map.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
    const bounds=new kakao.maps.LatLngBounds();
    const colOf=n=>n>=5?'#c0392b':n>=3?'#e74c3c':n>=2?'#e67e22':'#f1c40f';
    cells.forEach(c=>{
      const pos=new kakao.maps.LatLng(c.lat,c.lng);
      bounds.extend(pos);
      new kakao.maps.Circle({
        center:pos,radius:140+Math.min(c.n,8)*45,
        fillColor:colOf(c.n),fillOpacity:.42,strokeWeight:1,strokeColor:colOf(c.n),strokeOpacity:.6,map
      });
      const lbl=document.createElement('div');
      lbl.style.cssText='font-size:11px;font-weight:800;color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.9);pointer-events:none;';
      lbl.textContent=c.n;
      new kakao.maps.CustomOverlay({position:pos,content:lbl,zIndex:3}).setMap(map);
    });
    if(cells.length>1)map.setBounds(bounds,30);else map.setCenter(new kakao.maps.LatLng(cells[0].lat,cells[0].lng));
  }catch(e){}
  // TOP 5 순위
  const top=document.getElementById('heatTopList');
  if(top){
    top.innerHTML=cells.slice(0,5).map((c,i)=>`<div style="display:flex;align-items:center;gap:7px;padding:3px 0;">
      <span style="font-size:9px;font-weight:800;color:${i===0?'#e74c3c':'#9bbdd4'};width:14px;">${i+1}</span>
      <span style="font-size:11px;color:#b8d4e8;flex:1;">${c.label}</span>
      <span style="font-size:10px;font-weight:700;color:${c.n>=3?'#e74c3c':'#e67e22'};">${c.n}건</span>
    </div>`).join('');
  }
}

function downloadStatsExcel(tab){
  const from=window._statExpFrom||'';
  const to=window._statExpTo||'';
  if(from&&to&&from>to){toast('⚠️ 시작일이 종료일보다 늦습니다');return;}
  const inRange=d=>{
    const ds=(d||'').slice(0,10);
    if(!ds)return false;
    if(from&&ds<from)return false;
    if(to&&ds>to)return false;
    return true;
  };
  // CSV 셀 이스케이프: 쉼표/따옴표/줄바꿈 처리
  const esc=v=>{
    const s=String(v==null?'':v);
    return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;
  };
  let headers=[],rows=[],fname='';
  if(tab==='rescue'){
    const res=(DB.g('rescues')||[]).filter(r=>inRange(r.date));
    if(!res.length){toast('⚠️ 해당 기간에 구조보고가 없습니다');return;}
    headers=['날짜','시간','제목','구조유형','상태','위치','장소구분','위도','경도','사고자명','성별','출생연도','국적','중증도','부상부위','사고원인','구조방법','날씨','사고자수','추가사고자','초동팀','출동팀','작성자'];
    rows=res.map(r=>[
      (r.date||'').slice(0,10), r.time||(r.date||'').slice(11,16), r.title||'', r.type||'',
      r.status==='ongoing'?'진행중':'종료', r.location||'', r.loctype||'',
      r.lat||'', r.lng||'',
      r.vName||'', r.vGender||'', r.vBirth?String(r.vBirth).slice(0,4):'', r.vNation||r.vNationality||'',
      r.severity||'', (r.injuryParts||[]).join('/'), r.cause||'', (r.rescueMethod||[]).join('/'), r.weather||'',
      1+((r.victims2||[]).length),
      (r.victims2||[]).map(v=>[v.name||'미상',v.severity,v.note].filter(Boolean).join(' ')).join(' / '),
      (r.members||[]).join('/'),
      (r.teams||[]).map(t=>t.name+((t.members&&t.members.length)?'('+t.members.join('·')+')':'')).join('/'),
      r.author||''
    ]);
    fname='구조보고_'+(from||'전체')+'_'+(to||'전체')+'.csv';
  }else{
    const haz=(DB.g('hazards')||[]).filter(h=>inRange(h.date));
    if(!haz.length){toast('⚠️ 해당 기간에 위험상황이 없습니다');return;}
    headers=['날짜','위험유형','처리현황','위치','위도','경도','내용','작성자'];
    rows=haz.map(h=>[
      (h.date||'').slice(0,10), h.hazType||'', h.hazStatus||'미조치', h.loc||h.location||'',
      h.lat||'', h.lng||'', h.desc||h.memo||'', h.author||''
    ]);
    fname='위험상황_'+(from||'전체')+'_'+(to||'전체')+'.csv';
  }
  // UTF-8 BOM: 엑셀에서 한글 깨짐 방지
  const csv='\uFEFF'+[headers,...rows].map(row=>row.map(esc).join(',')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download=fname;
  document.body.appendChild(a);a.click();
  setTimeout(()=>{document.body.removeChild(a);URL.revokeObjectURL(url);},300);
  toast('📥 '+rows.length+'건 다운로드 완료');
}


// ══════════════════════════════════════════
// 팝업 & 상황 종료
// ══════════════════════════════════════════
function _popRow(ico,val){return val?`<div style="display:flex;gap:5px;margin-bottom:3px;"><span style="color:#4a7090;flex-shrink:0;">${ico}</span><span style="color:#c0d8ec;font-size:11px;">${_esc(val)}</span></div>`:'';}
function openResPopup(id,type='rescue'){
  const data=type==='rescue'?(DB.g('rescues')||[]).find(x=>x.id===id):(DB.g('hazards')||[]).find(x=>x.id===id);if(!data)return;
  selResId=id;
  if(type==='rescue'){
    const isOg=data.status==='ongoing';const ti=RES_TYPES[data.type]||RES_TYPES['기타'];
    const totalPh=(data.reports||[]).length+1;
    document.getElementById('resPopTitle').textContent=ti.ico+' '+data.title;
    // 빈값/미상 필터 헬퍼
    const _skip=v=>{if(!v)return true;const s=String(v).trim();return !s||s==='-'||['미상','없음','모르겠음','알수없음','미정','해당없음','기타'].includes(s);};
    const _arr=v=>(Array.isArray(v)?v:typeof v==='string'?[v]:[]).filter(x=>!_skip(x));
    const row=_popRow;
    const d=data;
    const rows=[
      row('📅',d.date),
      row('📍',[d.location,d.loctype].filter(x=>!_skip(x)).join(' · ')||''),
      row('🌤',(!_skip(d.weather)?d.weather:'')+(!_skip(d.weatherAlert)?' '+d.weatherAlert:'')||''),
      row('👤',[!_skip(d.vName)?d.vName:'',(!_skip(d.vBirth)?_ageFromBirth(d.vBirth)+'세':''),(!_skip(d.vGender)&&d.vGender!=='알수없음'?d.vGender:''),(!_skip(d.vNation)&&d.vNation!=='알수없음'?d.vNation:'')].filter(Boolean).join(' · ')||''),
      row('🩺',!_skip(d.severity)?d.severity:''),
      row('👥',(d.victims2&&d.victims2.length)?('추가 사고자 '+d.victims2.length+'명: '+_victims2Str(d.victims2)):''),
      row('⚡',!_skip(d.cause)?d.cause:''),
      row('🦵',_arr(d.injuryParts).join(', ')),
      row('🚑',_arr(d.rescueMethod).join(', ')),
      row('🚨',_arr(d.mobilize).length?'응소: '+_arr(d.mobilize).join(', '):''),
      row('🏥',!_skip(d.hospital)&&d.hospital!=='미정'?d.hospital:''),
      row('🍺',!_skip(d.alcohol)&&d.alcohol!=='알수없음'?'음주: '+d.alcohol:''),
    ].filter(Boolean).join('');
    document.getElementById('resPopMeta').innerHTML=`
      <div style="display:flex;gap:5px;margin-bottom:6px;align-items:center;">
        <span style="font-size:10px;padding:2px 7px;border-radius:9px;font-weight:700;background:${isOg?'rgba(192,57,43,.2)':'rgba(39,174,96,.15)'};color:${isOg?'#e05050':'#27ae60'};">${isOg?'진행중':'종료'}</span>
        <span style="font-size:10px;color:#4a7090;">${totalPh}보 기록</span>
        <span style="font-size:10px;color:#3a6a8a;">${_esc(d.type)}</span>
      </div>
      ${rows||'<div style="color:#4a7090;font-size:11px;">상세 정보 없음</div>'}`;
    document.getElementById('btnViewRep').style.display='block';
    document.getElementById('btnViewTl').style.display=type==='rescue'?'block':'none';
    const rEl=document.getElementById('resPopRoutes');
    if(rEl){const rh=_buildResRouteHtml(data);rEl.innerHTML=rh;rEl.style.display=rh?'block':'none';}
  } else {
    document.getElementById('resPopTitle').textContent='⚠️ '+data.hazType+' 위험상황';
    const _skip=v=>{if(!v)return true;const s=String(v).trim();return !s||s==='-'||['미상','없음','알수없음','미정'].includes(s);};
    const row=_popRow;
    const d=data;
    document.getElementById('resPopMeta').innerHTML=[
      row('📍',!_skip(d.loc)?d.loc:''),
      row('⚠️',!_skip(d.danger)?d.danger:''),
      row('📋',!_skip(d.hazStatus)?d.hazStatus:''),
      row('🚨',(d.mobilize&&d.mobilize.length)?'응소: '+d.mobilize.join(', '):''),
      row('👤',!_skip(d.author)?d.author:''),
    ].filter(Boolean).join('')||'<div style="color:#4a7090;font-size:11px;">상세 정보 없음</div>';
    document.getElementById('btnViewRep').style.display='none';
    document.getElementById('btnViewTl').style.display='none';
    const rEl2=document.getElementById('resPopRoutes');if(rEl2)rEl2.style.display='none';
  }
  document.getElementById('facPopup').classList.remove('on');
  document.getElementById('resPopup').classList.add('on');
}

function openHazDetail(id){
  const h=(DB.g('hazards')||[]).find(x=>x.id===id);if(!h)return;
  let ov=document.getElementById('hazDetailOv');
  if(!ov){ov=document.createElement('div');ov.id='hazDetailOv';document.body.appendChild(ov);}
  ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;display:flex;align-items:flex-end;';
  ov.innerHTML=`<div style="background:#040a16;border-radius:14px 14px 0 0;width:100%;max-height:80vh;max-height:80dvh;overflow:hidden;display:flex;flex-direction:column;border-top:.5px solid rgba(230,126,34,.3);">
    <div style="padding:14px 16px 10px;display:flex;align-items:center;justify-content:space-between;border-bottom:.5px solid rgba(255,255,255,.07);flex-shrink:0;">
      <span style="font-size:13px;font-weight:700;color:#e0edf8;">${_esc(h.hazType||'위험상황')}</span>
      <button onclick="document.getElementById('hazDetailOv').style.display='none'" style="background:none;border:none;color:rgba(255,255,255,.5);font-size:20px;cursor:pointer;padding:0 4px;line-height:1;">×</button>
    </div>
    <div style="overflow-y:auto;flex:1;padding:12px 14px;">
      <div style="font-size:12px;color:#b8d4e8;line-height:1.8;">
        ${h.leadAgency?`주관기관: <b style="color:#3ad17a;">🌲 ${_esc(h.leadAgency)}</b><br>`:''}
        위치: <b>${_esc(h.loc||'-')}</b><br>
        시각: ${_esc(h.dt||'-')}<br>
        위험도: ${_esc(h.danger||'-')}<br>
        상태: <b style="color:${h.hazStatus==='미조치'?'#e05050':(h.hazStatus==='조치중'?'#e67e22':'#27ae60')};">${_esc(h.hazStatus||'-')}</b><br>
        작성: ${_esc(h.author||'-')}
        ${h.desc?`<br><br>${_esc(h.desc)}`:''}
      </div>
      <div style="margin-top:12px;">
        <div style="font-size:11px;color:#7a9cb8;font-weight:700;margin-bottom:6px;">상태 변경</div>
        <div style="display:flex;gap:6px;">
          ${['미조치','조치중','제거 완료','통제중'].map(st=>{
            const on=(h.hazStatus||'미조치')===st;
            const col=st==='미조치'?'#e05050':(st==='조치중'?'#e67e22':'#27ae60');
            return `<button onclick="_setHazStatus(${h.id},'${st}')" style="flex:1;padding:7px 2px;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;border:1.5px solid ${on?col:'rgba(255,255,255,.12)'};background:${on?col+'22':'transparent'};color:${on?col:'rgba(255,255,255,.45)'};">${st}</button>`;
          }).join('')}
        </div>
      </div>
      ${(h.statusLog&&h.statusLog.length)?`<div style="margin-top:12px;">
        <div style="font-size:11px;color:#7a9cb8;font-weight:700;margin-bottom:6px;">📋 상태 이력</div>
        ${h.statusLog.slice().reverse().map(s=>`<div style="display:flex;gap:8px;font-size:11px;padding:4px 0;border-top:1px solid rgba(255,255,255,.05);">
          <span style="color:#6a93b5;font-family:monospace;flex-shrink:0;">${_esc((s.at||'').slice(5,16))}</span>
          <span style="color:${s.status==='미조치'?'#e05050':(s.status==='조치중'?'#e67e22':'#27ae60')};font-weight:700;flex:1;">${_esc(s.status)}</span>
          <span style="color:#5a7e98;flex-shrink:0;">${_esc(s.by||'-')}</span>
        </div>`).join('')}
      </div>`:''}
      ${_mobilizeBlockHtml('hazards',h)}
      ${_hazFireTLHtml(h)}
    </div>
  </div>`;
  ov.onclick=e=>{if(e.target===ov)ov.style.display='none';};
}
function _setHazStatus(id,st){
  const haz=DB.g('hazards')||[];const idx=haz.findIndex(x=>x.id===id);if(idx===-1)return;
  if((haz[idx].hazStatus||'미조치')===st){toast('이미 '+st+' 상태입니다');return;}
  if(!haz[idx].statusLog)haz[idx].statusLog=[{status:haz[idx].hazStatus||'미조치',at:haz[idx].dt||now(),by:haz[idx].author||'-'}];
  haz[idx].hazStatus=st;
  haz[idx].statusLog.push({status:st,at:now(),by:(typeof getAuthor==='function'?getAuthor():'')||haz[idx].author||'-'});
  DB.s('hazards',haz);
  toast('✅ 상태 변경: '+st);
  openHazDetail(id); // 상세 갱신
  try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}try{updateSummary();}catch(e){}
  if(document.getElementById('v-board')&&document.getElementById('v-board').classList.contains('on')){try{renderBoard();}catch(e){}}
}

// ══════════════════════════════════════════
// 구조 보고서 (1보 ~ n보 타임라인)
// ══════════════════════════════════════════
function updateRescueCross(){
  const el=document.getElementById('rescueCross');if(!el)return;
  const bnavEl=document.getElementById('bnav');
  const bnavH=(bnavEl&&bnavEl.style.display!=='none')?bnavEl.offsetHeight:0;
  el.style.top='calc(50% - '+Math.round(bnavH/2)+'px)';
}
function updateInspectCross(){
  const el=document.getElementById('inspectCross');if(!el)return;
  const bnavEl=document.getElementById('bnav');
  const bnavH=(bnavEl&&bnavEl.style.display!=='none')?bnavEl.offsetHeight:0;
  el.style.top='calc(50% - '+Math.round(bnavH/2)+'px)';
}
function openNewRescue(){
  curResId=null;
  // 마지막으로 저장된 십자선 중앙 좌표 우선 사용
  let gpsPre=window._lastCrosshairCoord||null;
  if(!gpsPre&&mapR){
    try{
      const mapEl=document.getElementById('mapRescue');
      const proj=mapR.getProjection();
      const coord=proj.coordsFromContainerPoint(new kakao.maps.Point(mapEl.offsetWidth/2,mapEl.offsetHeight/2));
      gpsPre={lat:coord.getLat(),lng:coord.getLng()};
    }catch(e){
      const c=mapR.getCenter();gpsPre={lat:c.getLat(),lng:c.getLng()};
    }
  }
  document.getElementById('topTitle').textContent='신규 구조 접수 (1보)';
  document.getElementById('bnav').style.display='none';
  showV('v-report');renderPhaseBar(0,1);render1BoForm(gpsPre);
  if(gpsPre&&gpsPre.lat)_autoFillLoc(gpsPre.lat,gpsPre.lng);
  setTimeout(_maybeOfferDraftRestore,300); // 임시저장 복구 제안
}
function addPhase(){
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===selResId);if(!r)return;
  curResId=selResId;
  const phaseNum=(r.reports||[]).length+1;
  document.getElementById('topTitle').textContent=r.title+' (추가 보고)';
  document.getElementById('bnav').style.display='none';
  showV('v-report');closeDB();
  renderPhaseBar(phaseNum,phaseNum+1);
  // 이전 보 데이터: 이전 보고가 있으면 그것, 없으면 1보(r)
  const prevReport=r.reports&&r.reports.length>0?r.reports[r.reports.length-1]:null;
  // prefill: 1보 기본 정보 + 이전 보 변경사항 합쳐서
  const prefill={
    ...r,
    ...(prevReport||{}),
    _phaseNum: phaseNum+1,
    title: r.title,
    date: now().replace(' ','T'),
    timetable: r.timetable||[],
  };
  render1BoForm(prefill);
}



function submitNBoFromForm(){
  const res=DB.g('rescues')||[];const idx=res.findIndex(x=>x.id===curResId);if(idx===-1)return;
  if(!res[idx].reports)res[idx].reports=[];
  const members=[...document.querySelectorAll('#memChkGrid .chk-grid .chk-box.on')].map(b=>{
    const txt=b.closest('.chk-item')?.querySelector('.chk-txt');
    return txt?txt.textContent.trim().split(' ')[0]:'';
  }).filter(Boolean);
  const extraMembers=[..._extraDispatch];
  const phaseData={
    rid: 'r'+Date.now().toString(36)+Math.random().toString(36).slice(2,6), // 보고 고유 id(동시편집 병합 키)
    repTime: now(),
    type: document.getElementById('r_type')?.value||res[idx].type,
    date: document.getElementById('r_accdt')?.value?.replace('T',' ')||now(),
    weather: getSelPills('weatherPills')[0]||res[idx].weather||'',
    weatherAlert: getWeatherAlertStr(),
    location: document.getElementById('r_loc')?.value||res[idx].location,
    loctype: document.getElementById('r_loctype')?.value||res[idx].loctype,
    vName: document.getElementById('r_vName')?.value||res[idx].vName,
    vTel: document.getElementById('r_vTel')?.value||res[idx].vTel||'',
    vNation: document.getElementById('r_vNat')?.value||res[idx].vNation,
    vNationality: document.getElementById('r_vNationality')?.value||res[idx].vNationality||'',
    companions: getCompanions().length?getCompanions():res[idx].companions||[],
    victims2: getVictims2().length?getVictims2():res[idx].victims2||[],
    vGender: document.getElementById('r_vGender')?.value||res[idx].vGender,
    vBirth: document.getElementById('r_vBirth')?.value||res[idx].vBirth||'',
    vAddr: document.getElementById('r_vAddr')?.value||res[idx].vAddr||'',
    vDisease: document.getElementById('r_vDis')?.value||res[idx].vDisease||'',
    vAllergy: document.getElementById('r_vAll')?.value||res[idx].vAllergy||'',
    vMeds: document.getElementById('r_vMed')?.value||res[idx].vMeds||'',
    severity: getSelPills('sevPills')[0]||res[idx].severity,
    vitals: _collectVitals(),
    injuryParts: getSelPills('injParts'),
    injuryTypes: getSelPills('injTypes'),
    cause: document.getElementById('r_cause')?.value||res[idx].cause,
    situation: document.getElementById('r_sit')?.value||'',
    alcohol: document.getElementById('r_alc')?.value||'없음',
    alcAmount: document.getElementById('r_alcAmount')?.value||'',
    injuries: _injuries,
    rescueMethod: getSelPills('rescMeth'),
    members,
    extraTeams: getExtraTeams(),
    agencies: getAgencies(),
    r119: document.getElementById('r_119')?.value||res[idx].r119||'',
    equipment: document.getElementById('r_equip')?.value||res[idx].equipment||'',
    hospital: document.getElementById('r_hosp')?.value||res[idx].hospital,
    dispatch: document.getElementById('r_disp')?.value||'',
    arrival: document.getElementById('r_arr')?.value||'',
    completion: document.getElementById('r_comp')?.value||'',
    distance: document.getElementById('r_dist')?.value||'',
    author: document.getElementById('r_author')?.value||getAuthor(),
    extra: document.getElementById('r_extra')?.value||'',
    timetable: _ttInlineEntries||[],
    extraMembers: extraMembers||[],
    victimChange: '변화없음',
    update: '',
  };
  // 전보와 차이 자동 요약
  const prev=res[idx].reports.length>0?res[idx].reports[res[idx].reports.length-1]:res[idx];
  const diffs=[];
  if(phaseData.severity&&phaseData.severity!==prev.severity)diffs.push(`중증도 ${prev.severity||'-'}→${phaseData.severity}`);
  if(phaseData.hospital!==prev.hospital)diffs.push(`후송: ${phaseData.hospital}`);
  if(phaseData.situation&&phaseData.situation!==prev.situation)diffs.push(phaseData.situation.slice(0,40));
  if(_ttInlineEntries.length)diffs.push(`타임라인 ${_ttInlineEntries.length}건 추가`);
  phaseData.update=diffs.join(' · ')||'상태 유지';
  // 타임라인 저장
  if(_ttInlineEntries.length){
    if(!res[idx].timetable)res[idx].timetable=[];
    res[idx].timetable=[...res[idx].timetable,..._ttInlineEntries];
  }
  // 추가 사고자: N보에서 입력했으면 메인 레코드에 반영(표시 일관성)
  if(phaseData.victims2&&phaseData.victims2.length)res[idx].victims2=phaseData.victims2;
  res[idx].reports.push(phaseData);
  DB.s('rescues',res);
  _ttInlineEntries=[];
  const phaseNum=res[idx].reports.length;
  pushNoti(`📋 추가 보고: ${res[idx].title}`,'📋','rescue_update',{app:'rescue',tab:2,id:res[idx].id});
  toast('✅ 추가 보고 저장 완료');
  renderPhaseBar(phaseNum-1,phaseNum);
  renderTimeline(res[idx],'brief');
}
function viewFullPrev(){
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===curResId);if(!r)return;
  const phNum=(r.reports||[]).length;
  const prev=phNum>0?r.reports[phNum-1]:null;
  document.getElementById('prevRepTitle').textContent=phNum>0?`${phNum}보 전체 내용`:'1보 전체 내용';
  if(prev){
    document.getElementById('prevRepContent').innerHTML=`<div style="font-size:12px;color:#7a9cb8;line-height:2;">
      <b>보고 시간:</b> ${_esc(prev.repTime)}<br><b>상황 내용:</b> ${_esc(prev.update||'-')}<br>
      <b>부상자 상태:</b> ${_esc(prev.victimChange||'-')}<br><b>추가 대원:</b> ${_esc(prev.addMem||'-')}<br><b>작성자:</b> ${_esc(prev.author||'-')}
    </div>`;
  } else {
    document.getElementById('prevRepContent').innerHTML=`<div style="font-size:12px;color:#7a9cb8;line-height:2;">
      <b>유형:</b> ${_esc(r.type)}<br><b>발생:</b> ${r.date}<br><b>위치:</b> ${_esc(r.location||'-')}<br>
      <b>사고자:</b> ${_esc(r.vName||'미상')} / ${(r.vGender&&r.vGender!=='알수없음')?_esc(r.vGender):'-'}<br><b>중증도:</b> ${_esc(r.severity||'-')}<br>
      <b>부상부위:</b> ${_esc((r.injuryParts||[]).join(', ')||'-')}<br><b>구조방법:</b> ${_esc((r.rescueMethod||[]).join(', ')||'-')}
    </div>`;
  }
  document.getElementById('modalPrevReport').classList.add('on');
}
function viewAllTimeline(){closeM('modalAddPhase');viewReport();}
function viewReport(){
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===selResId);if(!r)return;
  curResId=selResId;
  document.getElementById('topTitle').textContent=r.title+' 보고서';
  document.getElementById('bnav').style.display='none';
  document.getElementById('phaseBar').innerHTML='';
  showV('v-report');closeDB();
  renderTimeline(r,'write');
}
function viewTimeline(){
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===selResId);if(!r)return;
  curResId=selResId;
  document.getElementById('topTitle').textContent=r.title;
  document.getElementById('bnav').style.display='none';
  document.getElementById('phaseBar').innerHTML='';
  showV('v-report');closeDB();
  renderTimeline(r,'advanced');
}
function renderPhaseBar(active,total){
  document.getElementById('phaseBar').innerHTML=Array.from({length:total},(_,i)=>
    `<div class="ph ${i<active?'done':i===active?'active':''}"><div class="ph-dot"></div>${i+1}보</div>`).join('');
}
// 현재 보고서 ID 기억
let _curViewResId=null;
let _tlViewMode='advanced'; // legacy compat
let _tlMode='advanced'; // 'advanced'|'write'
let _tlWps=[];       // pointer to selected team's wps
let _tlWpIdx=0;
let _tlWpResId=null;
let _tlVehicle=false;
let _tlAnimating=false;
let _tlTeams=[];
let _tlSelTeam=0;
let _tlMiniMapInst=null;
// team builder state
let _tlBuilding=false;
let _tlBuildType=null;     // 'nps'|'agency'
let _tlBuildMembers=[];
let _tlBuildOtherOpen=false;
let _tlBuildAgencyType='소방';

function _hideRepFooter(){const f=document.getElementById('rep1BoFooter');if(f)f.style.display='none';}

function _renderCreateBtnsHtml(){
  return `<div style="display:flex;gap:8px;margin-bottom:10px;">
    <button onclick="startTlBuild('nps')" style="flex:1;padding:11px 6px;border-radius:9px;background:rgba(79,168,208,.1);border:1px solid rgba(79,168,208,.3);color:#4fa8d0;font-size:12px;font-weight:700;cursor:pointer;">+ 공단 팀생성</button>
    <button onclick="startTlBuild('agency')" style="flex:1;padding:11px 6px;border-radius:9px;background:rgba(126,200,163,.08);border:1px solid rgba(126,200,163,.25);color:#7ec8a0;font-size:12px;font-weight:700;cursor:pointer;">+ 유관기관 팀생성</button>
  </div>`;
}

function _renderBuildPanelHtml(){
  const user=DB.g('currentUser')||{};
  const myDept=user.dept||'';
  const all=getTeamMembers();
  const mine=all.filter(s=>!myDept||s.dept===myDept);
  const others=all.filter(s=>myDept&&s.dept&&s.dept!==myDept);
  const byDept={};others.forEach(s=>{if(!byDept[s.dept])byDept[s.dept]=[];byDept[s.dept].push(s);});
  function chip(s){
    const on=_tlBuildMembers.includes(s.name);
    return `<div onclick="toggleTlBuildMember('${s.name.replace(/'/g,"\\'")}',this)" style="cursor:pointer;background:${on?'rgba(126,200,163,.2)':'rgba(255,255,255,.04)'};color:${on?'#7ec8a0':'rgba(255,255,255,.45)'};border:1px solid ${on?'rgba(126,200,163,.4)':'rgba(255,255,255,.12)'};border-radius:20px;font-size:10px;font-weight:700;padding:4px 10px;">${s.name}${s.rank?` <span style="font-size:8px;opacity:.7;">${s.rank}</span>`:''}</div>`;
  }
  if(_tlBuildType==='nps'){
    const _autoName=(myDept||'공단')+' '+(_tlTeams.filter(t=>t.id&&t.id.startsWith('nps_')).length+1)+'팀';
    return `<div style="background:#0b1c30;border-radius:10px;padding:12px;border:.5px solid rgba(79,168,208,.3);margin-bottom:10px;">
      <div style="font-size:11px;color:#4fa8d0;font-weight:700;margin-bottom:10px;">🥾 공단 팀생성</div>
      <input id="tlBuildNameInput" type="text" class="fi" placeholder="${_autoName}" style="width:100%;box-sizing:border-box;margin-bottom:10px;">
      ${myDept?`<div style="font-size:10px;color:#4a7090;font-weight:600;margin-bottom:5px;">📂 ${myDept}</div>`:''}
      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;">
        ${mine.length?mine.map(chip).join(''):'<span style="font-size:10px;color:rgba(255,255,255,.25);">직원 정보 없음</span>'}
      </div>
      ${others.length?`<button id="tlOtherDeptsBtn" onclick="toggleTlOtherDepts()" style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.5);border-radius:7px;padding:4px 10px;font-size:10px;font-weight:600;cursor:pointer;margin-bottom:6px;">추가인원 ▼</button>
        <div id="tlOtherDeptsWrap" style="display:none;">
          ${Object.entries(byDept).map(([dept,members])=>`<div style="margin-bottom:8px;"><div style="font-size:10px;color:#4a7090;font-weight:600;margin-bottom:4px;">📂 ${dept}</div><div style="display:flex;flex-wrap:wrap;gap:5px;">${members.map(chip).join('')}</div></div>`).join('')}
        </div>`:''}
      <div style="display:flex;gap:7px;margin-top:10px;">
        <button onclick="cancelTlBuild()" style="flex:1;padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,.12);background:transparent;color:rgba(255,255,255,.45);font-size:12px;font-weight:600;cursor:pointer;">취소</button>
        <button onclick="confirmTlBuild()" style="flex:2;padding:8px;border-radius:8px;background:rgba(79,168,208,.18);border:1px solid rgba(79,168,208,.4);color:#4fa8d0;font-size:12px;font-weight:700;cursor:pointer;">확인</button>
      </div>
    </div>`;
  } else {
    // 유관기관 팀생성 — 특수구조대 제거, 환동해(소방) 분리, 산림청=헬기, 인원 입력
    // 기관별 기본 인원: 소방구급 2, 환동해 5, 나머지 지정 없음
    const hw=getHwandonghaTeam();
    const agTypes=[
      {k:'소방',l:'🚒 소방',sub:'속초소방서',mem:0},
      {k:'소방(구급)',l:'🚑 소방구급',sub:'구급대 기본 2명',mem:2},
      {k:'소방(환동해)',l:'🔴 환동해',sub:`환동해특수대응단 기본 5명 (오늘 ${hw}팀)`,mem:5,hwTeam:hw},
      {k:'경찰',l:'👮 경찰',sub:'속초경찰서·양양경찰서',mem:0},
      {k:'산림청(헬기)',l:'🚁 산림청헬기',sub:'산림청 헬기 출동(드문 경우)',mem:0},
      {k:'기타',l:'➕ 기타',sub:'타 기관',mem:0},
    ];
    const sel=agTypes.find(a=>a.k===_tlBuildAgencyType)||agTypes[0];
    function agChip(ag){
      const on=_tlBuildAgencyType===ag.k;
      return `<div onclick="_selAgType('${ag.k.replace(/'/g,"\\'")}',${ag.mem||0})" class="tl-ag-chip"
        style="cursor:pointer;background:${on?'rgba(126,200,163,.2)':'rgba(255,255,255,.04)'};
        color:${on?'#7ec8a0':'rgba(255,255,255,.45)'};
        border:1px solid ${on?'rgba(126,200,163,.4)':'rgba(255,255,255,.12)'};
        border-radius:10px;font-size:11px;font-weight:700;padding:5px 9px;line-height:1.3;text-align:center;">
        ${ag.l}${ag.hwTeam?`<br><span style="font-size:9px;opacity:.75;">현재 ${ag.hwTeam}팀</span>`:''}
      </div>`;
    }
    return `<div style="background:#0b1c30;border-radius:10px;padding:12px;border:.5px solid rgba(126,200,163,.3);margin-bottom:10px;">
      <div style="font-size:11px;color:#7ec8a0;font-weight:700;margin-bottom:10px;">🚒 유관기관 팀생성</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:10px;">
        ${agTypes.map(agChip).join('')}
      </div>
      ${sel.sub?`<div style="font-size:10px;color:#5a8aa0;margin-bottom:8px;">${_esc(sel.sub)}</div>`:''}
      <div style="display:flex;gap:7px;margin-bottom:10px;">
        <div style="flex:2;"><input id="tlBuildNameInput" type="text" class="fi" value="${_esc(sel.l.replace(/[🚒🚑🔴👮🚁➕]/g,'').trim())}" placeholder="팀 이름" style="width:100%;box-sizing:border-box;"></div>
        <div style="flex:1;"><input id="tlBuildMemCount" type="number" inputmode="numeric" class="fi" value="${sel.mem||''}" placeholder="인원 수" min="0" max="99" style="width:100%;box-sizing:border-box;"></div>
      </div>
      <div style="display:flex;gap:7px;">
        <button onclick="cancelTlBuild()" style="flex:1;padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,.12);background:transparent;color:rgba(255,255,255,.45);font-size:12px;font-weight:600;cursor:pointer;">취소</button>
        <button onclick="confirmTlBuild()" style="flex:2;padding:8px;border-radius:8px;background:rgba(126,200,163,.15);border:1px solid rgba(126,200,163,.35);color:#7ec8a0;font-size:12px;font-weight:700;cursor:pointer;">확인</button>
      </div>
    </div>`;
  }
}
function _selAgType(k,defaultMem){
  _tlBuildAgencyType=k;
  const ba=document.getElementById('tlBuildArea');
  if(ba)ba.innerHTML=_renderBuildPanelHtml();
  setTimeout(()=>{const mc=document.getElementById('tlBuildMemCount');if(mc&&defaultMem)mc.value=defaultMem;},0);
}

function startTlBuild(type){
  _tlBuilding=true;_tlBuildType=type;_tlBuildMembers=[];_tlBuildOtherOpen=false;
  _tlBuildAgencyType='소방';
  const ba=document.getElementById('tlBuildArea');
  if(ba)ba.innerHTML=_renderBuildPanelHtml();
}

function cancelTlBuild(){
  _tlBuilding=false;
  const ba=document.getElementById('tlBuildArea');
  if(ba)ba.innerHTML=_renderCreateBtnsHtml();
}

function toggleTlBuildMember(name,el){
  const idx=_tlBuildMembers.indexOf(name);
  if(idx>=0){
    _tlBuildMembers.splice(idx,1);
    el.style.background='rgba(255,255,255,.04)';el.style.color='rgba(255,255,255,.45)';el.style.borderColor='rgba(255,255,255,.12)';
  }else{
    _tlBuildMembers.push(name);
    el.style.background='rgba(126,200,163,.2)';el.style.color='#7ec8a0';el.style.borderColor='rgba(126,200,163,.4)';
  }
}

function toggleTlOtherDepts(){
  _tlBuildOtherOpen=!_tlBuildOtherOpen;
  const wrap=document.getElementById('tlOtherDeptsWrap');
  const btn=document.getElementById('tlOtherDeptsBtn');
  if(wrap)wrap.style.display=_tlBuildOtherOpen?'block':'none';
  if(btn)btn.textContent=(_tlBuildOtherOpen?'추가인원 ▲':'추가인원 ▼');
}

function confirmTlBuild(){
  const r=getRes(_tlWpResId);if(!r){toast('⚠️ 구조 정보 없음');return;}
  const nameEl=document.getElementById('tlBuildNameInput');
  const facs=DB.g('facilities')||[];
  if(_tlBuildType==='nps'){
    if(!_tlBuildMembers.length){toast('⚠️ 팀원을 선택하세요');return;}
    const _user=DB.g('currentUser')||{};
    const _dept=_user.dept||'공단';
    const _npsNum=_tlTeams.filter(t=>t.id&&t.id.startsWith('nps_')).length+1;
    const name=(nameEl&&nameEl.value.trim())||(_dept+' '+_npsNum+'팀');
    const route=_buildRoute(r,facs);
    const wps=route.map(w=>({...w,status:w.isBase?'active':'pending'}));
    _tlTeams.push({id:'nps_'+Date.now(),name,type:'foot',members:_tlBuildMembers.slice(),wpIdx:0,wps,collapsed:false,createdAt:new Date().toISOString()});
  }else{
    const memCount=parseInt(document.getElementById('tlBuildMemCount')?.value||'0')||0;
    // 환동해는 3교대 — 오늘 당직팀 번호를 팀명에 반영해 현장 혼선 방지
    const hw=getHwandonghaTeam();
    const _defNames={'소방(환동해)':`환동해 ${hw}팀`,'소방(구급)':'소방 구급대','소방':'소방','경찰':'경찰','산림청(헬기)':'산림청 헬기','기타':'유관기관'};
    const name=(nameEl&&nameEl.value.trim())||_defNames[_tlBuildAgencyType]||_tlBuildAgencyType;
    // 산림청(헬기)·헬기 포함 시 헬기 경로 / 차량은 소방·경찰·구급·환동해
    const isHeli=_tlBuildAgencyType.includes('헬기')||_tlBuildAgencyType.includes('산림청');
    const isVehicle=!isHeli&&['소방','소방(구급)','소방(환동해)','경찰'].some(k=>_tlBuildAgencyType===k||_tlBuildAgencyType.startsWith(k));
    const type=isHeli?'heli':isVehicle?'vehicle':'foot';
    const route=isHeli
      ?[{code:'',name:'헬기 기지',isBase:true,status:'active'},{code:'',name:r.location||'사고지점',lat:r.lat||null,lng:r.lng||null,isTarget:true,status:'pending'}]
      :_buildRoute(r,facs).map(w=>({...w,status:w.isBase?'active':'pending'}));
    // requestedAt=출동요청 시각(생성시점), arrivedAt=현장도착(별도 기록)
    _tlTeams.push({id:'agency_'+Date.now(),name,type,agType:_tlBuildAgencyType,hwTeam:_tlBuildAgencyType==='소방(환동해)'?hw:null,memberCount:memCount,requestedAt:now(),arrivedAt:null,wpIdx:0,wps:route,collapsed:false,createdAt:new Date().toISOString()});
  }
  const newIdx=_tlTeams.length-1;
  _tlSelTeam=newIdx;_tlWps=_tlTeams[newIdx].wps;_tlWpIdx=0;
  _tlBuilding=false;
  _persistTeams(); // save to Firestore so rescue map can show team positions
  _rerenderTlFull();
  // init minimap if first team with coords
  const wpsForMap=_tlTeams[newIdx].wps;
  if(wpsForMap.some(w=>w.lat&&w.lng)){
    const mm=document.getElementById('tlMiniMap');
    if(!mm){
      const mapWrap=document.getElementById('tlMiniMapWrap');
      if(mapWrap)mapWrap.style.display='block';
    }
    setTimeout(()=>_initTlMiniMap(wpsForMap),150);
  }
}





function _initTlMiniMap(wps,curPos){
  const el=document.getElementById('tlMiniMap');
  if(!el||!window._KR)return;
  if(!curPos){try{curPos=(_tlTeams[_tlSelTeam]||{}).curPos||null;}catch(e){}}
  const pts=wps.filter(w=>w.lat&&w.lng);
  if(!pts.length){el.innerHTML='<div style="text-align:center;font-size:10px;color:rgba(255,255,255,.25);padding:12px;">위치 좌표 없음</div>';return;}
  // 진행률 계산 — 현재 통과 표지판 인덱스 기준
  const team=_tlTeams[_tlSelTeam]||{};
  const wpIdx=team.wpIdx||0;
  const total=wps.length-1; // 거점 제외 목표까지
  const pct=total>0?Math.min(100,Math.round(wpIdx/total*100)):0;
  const remaining=total-wpIdx; // 앞으로 통과할 표지판 수
  // 진행률 헤더 갱신
  const progEl=document.getElementById('tlMiniMapProg');
  if(progEl)progEl.innerHTML=`<span style="color:#4fa8d0;font-weight:900;">${pct}%</span> 진행 · 앞으로 표지판 <b>${remaining}</b>개`;
  try{
    const center=pts[Math.floor(pts.length/2)];
    const map=new kakao.maps.Map(el,{center:new kakao.maps.LatLng(center.lat,center.lng),level:6});
    map.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
    _tlMiniMapInst=map;
    const bounds=new kakao.maps.LatLngBounds();
    // 경로선만 표시 (핀 최소화)
    if(pts.length>1){
      const full=pts.map(w=>new kakao.maps.LatLng(w.lat,w.lng));
      const vehIdx=pts.findIndex(w=>w.byVehicle);
      new kakao.maps.Polyline({path:full,strokeWeight:5,strokeColor:'#ffffff',strokeOpacity:.18,strokeStyle:'solid',map}).setMap(map);
      if(vehIdx>0){
        if(full.slice(vehIdx).length>1)new kakao.maps.Polyline({path:full.slice(vehIdx),strokeWeight:3,strokeColor:'#4fa8d0',strokeOpacity:.9,strokeStyle:'solid',map}).setMap(map);
        new kakao.maps.Polyline({path:[full[vehIdx-1],full[vehIdx]],strokeWeight:3.5,strokeColor:'#e74c3c',strokeOpacity:.85,strokeStyle:'dash',map}).setMap(map);
      }else{
        new kakao.maps.Polyline({path:full,strokeWeight:3,strokeColor:'#4fa8d0',strokeOpacity:.9,strokeStyle:'solid',map}).setMap(map);
      }
    }
    // ① 거점(출발) 핀
    const base=pts.find(w=>w.isBase);
    if(base){const ll=new kakao.maps.LatLng(base.lat,base.lng);bounds.extend(ll);const d=document.createElement('div');d.innerHTML=`<div style="background:#27ae60;color:#fff;border-radius:10px;padding:2px 8px;font-size:9px;font-weight:800;white-space:nowrap;box-shadow:0 1px 4px rgba(0,0,0,.5);">🏠 ${_esc(base.name||'거점')}</div>`;new kakao.maps.CustomOverlay({position:ll,content:d,yAnchor:1.5}).setMap(map);}
    // ② 현재 통과 중인 표지판 핀 (필수)
    const curWp=wps[wpIdx];
    if(curWp&&curWp.lat&&curWp.lng&&!curWp.isBase){
      const ll=new kakao.maps.LatLng(curWp.lat,curWp.lng);bounds.extend(ll);
      const d=document.createElement('div');
      d.innerHTML=`<div style="background:#f39c12;color:#fff;border-radius:10px;padding:3px 9px;font-size:10px;font-weight:900;white-space:nowrap;box-shadow:0 2px 6px rgba(0,0,0,.5);border:2px solid #fff;">📍 ${_esc(curWp.code||curWp.name)} ▶</div>`;
      new kakao.maps.CustomOverlay({position:ll,content:d,yAnchor:1.5,zIndex:9}).setMap(map);
    }
    // ③ 환자 위치 핀 (필수)
    const target=wps.find(w=>w.isTarget);
    if(target&&target.lat&&target.lng){
      const ll=new kakao.maps.LatLng(target.lat,target.lng);bounds.extend(ll);
      const d=document.createElement('div');
      d.innerHTML=`<div style="background:#c0392b;color:#fff;border-radius:10px;padding:3px 9px;font-size:10px;font-weight:900;white-space:nowrap;box-shadow:0 2px 8px rgba(192,57,43,.7);border:2px solid #fff;">🚨 ${_esc(target.code||target.name||'환자')}</div>`;
      new kakao.maps.CustomOverlay({position:ll,content:d,yAnchor:1.5,zIndex:10}).setMap(map);
    }
    // 실제 현위치 GPS 마커
    if(curPos&&curPos.lat&&curPos.lng){
      const cll=new kakao.maps.LatLng(curPos.lat,curPos.lng);bounds.extend(cll);
      const cc=document.createElement('div');
      cc.innerHTML=`<div style="width:14px;height:14px;border-radius:50%;background:#2d7dff;border:2.5px solid #fff;box-shadow:0 0 0 5px rgba(45,125,255,.3);"></div>`;
      new kakao.maps.CustomOverlay({position:cll,content:cc,yAnchor:.5,zIndex:11}).setMap(map);
    }
    if(pts.length>1)map.setBounds(bounds,50);
  }catch(e){console.warn('tlMiniMap',e);}
}

// ── Zone-based trail routing ──
function _buildRoute(r,facs){
  if((r.loctype||'')!=='법정탐방로')return[];
  const lm=(r.location||'').match(/(\d+)-(\d+)/);
  if(!lm)return[];
  const zone=parseInt(lm[1]),code=parseInt(lm[2]);
  const wm={};
  (facs||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판')).forEach(f=>{
    const m=(f.name||'').match(/^(\d+)-(\d+)/);
    if(m)wm[`${m[1]}-${m[2]}`]={code:`${m[1]}-${m[2]}`,zone:parseInt(m[1]),num:parseInt(m[2]),name:f.name,lat:f.lat,lng:f.lng};
  });
  function seg(z,from,to){
    const res=[],zs=String(z).padStart(2,'0');
    for(let i=from;i<=Math.min(to,50);i++){const k=`${zs}-${String(i).padStart(2,'0')}`;if(wm[k])res.push(wm[k]);}
    return res;
  }
  // 내림차순 구간: 높은 번호 표지판에서 낮은 번호로 (반대편에서 접근할 때)
  function segDown(z,from,to){
    const res=[],zs=String(z).padStart(2,'0');
    for(let i=from;i>=Math.max(to,1);i--){const k=`${zs}-${String(i).padStart(2,'0')}`;if(wm[k])res.push(wm[k]);}
    return res;
  }
  // 해당 존에 존재하는 가장 큰 표지판 번호 (끝 표지판 = 연결 분기점)
  function maxNum(z){
    let mx=0;Object.values(wm).forEach(w=>{if(w.zone===z&&w.num>mx)mx=w.num;});return mx;
  }
  function upto(z,max){return seg(z,1,max);}
  let base='',route=[];
  if(zone===1||zone===4||zone===5){base='소공원탐방지원센터';route=upto(zone,code);}
  else if(zone===2){
    // 02 존은 02-01(소공원 쪽, 동) ~ 02-14(백담 쪽, 서)로 이어짐.
    if(code<=10){base='소공원탐방지원센터';route=[...upto(1,5),...upto(2,code)];} // 소공원에서 오름차순 접근
    else{base='백담탐방지원센터';route=[...upto(10,15),...segDown(2,maxNum(2),code)];} // 백담에서 끝번호(02-14)→내림차순 접근
  }else if(zone===3){
    base='소공원탐방지원센터';
    if(code<=3)route=[...upto(1,5),...upto(2,7),...upto(3,code)];
    else route=[...upto(1,15),...upto(3,code)];
  }else if(zone===6){base='남설악탐방지원센터';route=upto(6,code);}
  else if(zone===7){
    if(code<=10){base='약수터안내소';route=seg(7,1,code);}
    else{base='용소탐방지원센터';route=seg(7,11,code);}
  }else if(zone===8){
    if(code<=6){base='용소탐방지원센터';route=seg(8,1,code);}
    else{base='흘림골탐방지원센터';route=seg(8,7,code);}
  }else if(zone===9){base='한계령탐방지원센터';route=upto(9,code);}
  else if(zone===10){base='백담탐방지원센터';route=upto(10,code);}
  else if(zone===11){
    if(code<=8){base='한계산성분소';route=seg(11,1,code);}
    else{base='남교리탐방지원센터';route=seg(11,9,code);}
  }else if(zone===12){base='소공원탐방지원센터';route=upto(12,code);}
  else if(zone===13){
    if(code<=4){base='소공원탐방지원센터';route=[...upto(1,5),...upto(2,6),...seg(13,1,code)];}
    else{base='백담탐방지원센터';route=[...upto(10,28),...seg(13,5,code)];}
  }else if(zone===14){base='점봉산탐방지원센터';route=upto(14,code);}
  else return[];
  // If target code not in wm, find nearest waypoint in same zone
  const _tzs=String(zone).padStart(2,'0');
  const _tKey=`${_tzs}-${String(code).padStart(2,'0')}`;
  const _hasTargetSign=!!wm[_tKey];
  if(!_hasTargetSign&&base){
    let _nearest=null;
    for(let _d=1;_d<=15&&!_nearest;_d++){
      for(const _s of [1,-1]){const _n=code+_d*_s;if(_n<1)continue;const _k=`${_tzs}-${String(_n).padStart(2,'0')}`;if(wm[_k]){_nearest={...wm[_k],approx:true};break;}}
    }
    if(_nearest&&!route.some(w=>w.code===_nearest.code))route.push(_nearest);
  }
  // 거점 결정: 사고 GPS가 있으면 가장 가까운 도로 거점(대피소 제외)을 출발점으로,
  // 없으면 동선(zone) 기본 거점 사용.
  let _baseObj=Object.values(SEORAK_BASES).find(b=>b.name===base)||null;
  if(r.lat&&r.lng){
    const _nb=_nearestBase(r.lat,r.lng);
    if(_nb){_baseObj=_nb;base=_nb.name;}
  }
  const res=[{code:'',name:base,isBase:true,lat:_baseObj?_baseObj.lat:null,lng:_baseObj?_baseObj.lng:null,status:'active'}];
  route.forEach((w,i)=>res.push({code:w.code,name:w.name,lat:w.lat,lng:w.lng,approx:w.approx||false,isTarget:i===route.length-1,status:'pending'}));
  // 거점 → 첫 도보 지점 거리가 멀면(차로 들머리 접근) 차량 이동 구간으로 표시 (명시 구간 외 폴백)
  if(res.length>1&&_baseObj&&_baseObj.lat){
    const _ff=res[1];
    if(_ff&&_ff.lat&&_ff.lng){
      const _vd=_haversineKm(_baseObj.lat,_baseObj.lng,_ff.lat,_ff.lng);
      if(_vd>0.6){_ff.byVehicle=true;_ff.vehKm=_vd;}
    }
  }
  // 목표 표지판 좌표가 시설 데이터에 없어도 사고 GPS가 있으면 그 좌표로 목표 지점 보정/추가
  if(r.lat&&r.lng){
    const _last=res[res.length-1];
    const _targetHasCoord=_last&&_last.isTarget&&_last.lat&&_last.lng;
    if(!_targetHasCoord){
      // 정확한 목표 표지판이 없었던 경우 → 실제 사고 좌표를 목표 지점으로 추가
      res.forEach(w=>{w.isTarget=false;});
      res.push({code:_tKey,name:r.location||(`${_tKey} 부근`),lat:r.lat,lng:r.lng,approx:!_hasTargetSign,isTarget:true,status:'pending'});
    }
  }
  // ── 차량 이동 가능 구간 ──
  // 소공원 구간: 01-01~01-04(와선대), 백담 구간: 10-01~10-07(백담탐방지원센터)까지 차량 접근 가능.
  // 이 구간을 넘는 사고는 출동→차량으로 종점까지 이동 후 종점(와선대/백담센터)부터 도보.
  const VEH_SEG={1:4,10:7};
  res.forEach(w=>{
    if(!w.code)return;
    const _m=w.code.match(/^(\d+)-(\d+)/);if(!_m)return;
    const _z=+_m[1],_n=+_m[2];
    if(VEH_SEG[_z]!=null&&_n<=VEH_SEG[_z])w.byVehicle=true;
  });
  // 차량 구간의 마지막 지점 = 도보 전환점(와선대/백담센터). 그 지점에 도보 시작 표시.
  for(let i=0;i<res.length;i++){
    if(res[i].byVehicle&&(i+1>=res.length||!res[i+1].byVehicle)){res[i].vehEnd=true;break;}
  }
  return res;
}

// 저장된 경로가 비어 있는(좌표 2개 미만) 팀을 현재 표지판 기준으로 재계산.
// 표지판이 사라졌던 시점에 만든 팀의 경로를 복구하기 위함. 멀쩡한 팀은 그대로 둠.
function _regenTeamWpsIfEmpty(t,r,facs){
  const coordCnt=(t.wps||[]).filter(w=>w.lat&&w.lng).length;
  if(coordCnt>=2)return t; // 정상 경로 → 보존
  let newWps=null;
  if(t.type==='heli'){
    if(r.lat&&r.lng)newWps=[{code:'',name:'헬기 기지',isBase:true,status:'active'},{code:'',name:r.location||'사고지점',lat:r.lat,lng:r.lng,isTarget:true,status:'pending'}];
  }else{
    const route=_buildRoute(r,facs).map(w=>({...w,status:w.isBase?'active':'pending'}));
    if(route.filter(w=>w.lat&&w.lng).length>=2)newWps=route;
  }
  if(!newWps)return t; // 복구 불가(좌표 없음) → 그대로
  return {...t,wps:newWps,wpIdx:0}; // 깨진 경로였으므로 진행도 초기화
}
function _initTlTeams(r){
  if(_tlWpResId===r.id&&(_tlTeams.length||_tlBuilding))return;
  _tlWpResId=r.id;_tlVehicle=false;_tlAnimating=false;_tlBuilding=false;
  _tlBuildType=null;_tlBuildMembers=[];_tlBuildOtherOpen=false;_tlBuildAgencyType='소방';
  // Load persisted teams from rescue record
  if(r.teams&&r.teams.length){
    const facs=DB.g('facilities')||[];
    let _regen=false;
    _tlTeams=r.teams.map(t=>{
      const t2=_regenTeamWpsIfEmpty({...t,collapsed:true},r,facs);
      if(t2.wps!==t.wps&&t2!==t&&JSON.stringify(t2.wps)!==JSON.stringify(t.wps))_regen=true;
      return t2;
    });
    _tlSelTeam=0;_tlWps=_tlTeams[0].wps;_tlWpIdx=_tlTeams[0].wpIdx||0;
    if(_regen)_persistTeams(); // 복구된 경로를 저장 → 상황판 지도·타 기기에도 반영
  }else{
    _tlTeams=[];_tlSelTeam=0;_tlWps=[];_tlWpIdx=0;
  }
}

function _snapshotTeams(){
  return _tlTeams.map(t=>({id:t.id,name:t.name,type:t.type,wpIdx:t.wpIdx,wps:(t.wps||[]).map(w=>({...w})),members:(t.members||[]).slice(),curPos:t.curPos||null,agType:t.agType||null,hwTeam:t.hwTeam||null,memberCount:t.memberCount||0,requestedAt:t.requestedAt||t.createdAt||null,arrivedAt:t.arrivedAt||null,boardedAt:t.boardedAt||null,transportMethod:t.transportMethod||null,transportLog:t.transportLog||null,createdAt:t.createdAt||null}));
}
function _persistTeams(){
  if(!_tlWpResId)return;
  const _res=DB.g('rescues')||[];const _ri=_res.findIndex(x=>x.id===_tlWpResId);
  if(_ri<0)return;
  _res[_ri].teams=_snapshotTeams();
  DB.s('rescues',_res);
}

function _saveTeamState(){
  if(_tlTeams[_tlSelTeam]){_tlTeams[_tlSelTeam].wpIdx=_tlWpIdx;_tlTeams[_tlSelTeam].wps=_tlWps;}
}


function _teamStageIdx(team){
  if(!team.wps.length||team.wpIdx===0)return 0;            // 출발
  const cur=team.wps[team.wpIdx]||{};
  if(cur.descent)return 3;                                  // 하산/이송 중
  const targetIdx=team.wps.findIndex(w=>w.isTarget);
  if(targetIdx>=0&&team.wpIdx>=targetIdx)return 2;          // 환자조우
  if(team.wpIdx>=team.wps.length-1)return 3;                // 경로 끝 (목표 없는 경로)
  return 1;                                                 // 이동중
}
// 팀이 하산/이송을 모두 마쳤는지
function _teamDone(team){
  return team.wps.some(w=>w.descent)&&team.wpIdx>=team.wps.length-1;
}
// 모든 팀 완료 여부 확인 → 최초 감지 시 토스트
function _checkAllTeamsDone(resId){
  if(!resId)return;
  const rescue=(DB.g('rescues')||[]).find(r=>r.id===resId);
  if(!rescue||rescue.status!=='ongoing')return;
  const teams=rescue.teams||[];
  if(!teams.length||!teams.every(t=>_teamDone(t)))return;
  const key='allDoneToast_'+resId;
  if(!sessionStorage.getItem(key)){
    sessionStorage.setItem(key,'1');
    toast('🏁 '+_esc(rescue.title)+' — 전 팀 완료! 상황 종료를 확인하세요');
  }
}
// 환자 조우 후 하산(도보·차량)/병원 이송(헬기) 경로를 뒤에 붙임. true=추가됨
function _appendDescentWps(team){
  const tIdx=team.wps.findIndex(w=>w.isTarget);
  if(tIdx<0||team.wpIdx<tIdx||team.wps.some(w=>w.descent))return false;
  if(team.type==='heli'){
    team.wps.push({code:'',name:'속초의료원 이송',lat:_SOKCHO_HOSP.lat,lng:_SOKCHO_HOSP.lng,descent:true,isHosp:true,status:'pending'});
  }else{
    const back=team.wps.slice(0,tIdx).reverse().map(w=>({code:w.code,name:w.name,lat:w.lat,lng:w.lng,isBase:w.isBase,descent:true,status:'pending'}));
    team.wps.push(...back);
  }
  return true;
}
// 조우 전 팀 복귀: 남은 상행 구간을 버리고 지나온 길을 역순으로 붙임. true=변경됨
function _appendReturnWps(team){
  if(team.wps.some(w=>w.descent)||team.wpIdx<=0)return false;
  const cur=team.wpIdx;
  const back=team.wps.slice(0,cur).reverse().map(w=>({code:w.code,name:w.name,lat:w.lat,lng:w.lng,isBase:w.isBase,descent:true,status:'pending'}));
  team.wps=team.wps.slice(0,cur+1).concat(back);
  return true;
}
// 타임라인: 하산 시작 버튼
// 하산/이송 완료 직후 환자 인계 기록 입력 (선택)
function _promptHandover(resId,team){
  setTimeout(()=>{
    const to=prompt((team&&team.type==='heli'?'🏥 이송':'🔽 하산')+' 완료 — 환자 인계 대상을 입력하세요\n(예: 119구급대, 속초의료원 응급실, 보호자 / 건너뛰려면 취소)');
    if(!to||!to.trim())return;
    const res=DB.g('rescues')||[];const ri=res.findIndex(x=>x.id===resId);
    if(ri<0)return;
    const u=DB.g('currentUser')||{};
    res[ri].handover={to:to.trim(),by:u.name||'',time:now(),team:(team&&team.name)||''};
    DB.s('rescues',res);
    toast('🤝 인계 기록 저장: '+to.trim());
    try{_rerenderTlFull();}catch(e){}
  },350);
}
// 현장도착 시각 기록 (유관기관 공식기록: 출동요청↔현장도착 구분)
function tlMarkArrival(idx){
  const team=_tlTeams[idx];if(!team)return;
  team.arrivedAt=now();
  _persistTeams();_rerenderTlFull();
  toast('🏁 '+team.name+' 현장도착 '+String(team.arrivedAt).slice(11,16));
}
function tlDescentTeam(idx){
  const team=_tlTeams[idx];if(!team)return;
  // 도보·차량팀: 이송 방식 선택 (들것이송 / 자력하산) → 단계 명확화
  if(team.type!=='heli'&&!team.transportMethod){
    const m=prompt('🔽 하산/이송 방식을 입력하세요\n1 = 들것이송, 2 = 자력하산, 3 = 차량이송\n(취소 시 일반 하산)');
    if(m==='1')team.transportMethod='들것이송';
    else if(m==='2')team.transportMethod='자력하산';
    else if(m==='3')team.transportMethod='차량이송';
  }else if(team.type==='heli'){team.transportMethod='헬기이송';}
  if(!_appendDescentWps(team)){toast('⚠️ 환자 조우 후 가능');return;}
  _saveTeamState();_tlSelTeam=idx;_tlWps=team.wps;_tlWpIdx=team.wpIdx;
  _persistTeams();_rerenderTlFull();
  const mm=team.transportMethod?' ('+team.transportMethod+')':'';
  toast(team.type==='heli'?'🏥 '+team.name+': 병원 이송 시작'+mm:'🔽 '+team.name+': 하산 시작'+mm);
}
// ── 헬기 환자 탑승 완료 기록
function tlMarkBoarding(idx){
  const team=_tlTeams[idx];if(!team||team.type!=='heli')return;
  team.boardedAt=now();
  _persistTeams();_rerenderTlFull();
  toast('🚁 '+team.name+' 환자 탑승 완료 '+String(team.boardedAt).slice(11,16));
}

// ── 조우 지점 변경: 요구조자가 내려오거나 합류 지점이 바뀌는 경우
function tlChangeTarget(idx){
  const team=_tlTeams[idx];if(!team)return;
  if(team.wps.some(w=>w.descent)){toast('⚠️ 이미 하산 중 — 변경 불가');return;}
  const curTargetIdx=team.wps.findIndex(w=>w.isTarget);
  if(curTargetIdx<0){toast('⚠️ 목표 지점 없음');return;}
  const curTarget=team.wps[curTargetIdx];
  const newCode=prompt('현재 조우 예정: '+(curTarget.code||curTarget.name)+'\n\n새 조우 지점 코드를 입력하세요\n(예: 01-10) — 요구조자가 내려온 경우 더 가까운 지점으로 변경');
  if(!newCode||!newCode.trim())return;
  const code=newCode.trim().toUpperCase();
  // wm(웨이포인트 맵)에서 해당 코드 검색
  const facs=DB.g('facilities')||[];
  let found=null;
  facs.forEach(f=>{const m=f.name&&f.name.match(/^(\d{2})-(\d{2})/);if(m&&(m[0]===code||f.name.toUpperCase().startsWith(code)))found=f;});
  if(!found){
    // 현재 wps에서도 검색
    found=team.wps.find(w=>w.code&&w.code.toUpperCase()===code);
    if(!found){toast('⚠️ '+code+' 지점을 찾을 수 없습니다');return;}
  }
  // 새 목표가 현재 위치보다 앞(진행방향)에 있어야 함
  const newTargetInRoute=team.wps.findIndex((w,i)=>i>team.wpIdx&&w.code&&w.code.toUpperCase()===code);
  if(newTargetInRoute>=0){
    // 이미 경로에 있는 지점 — 그 지점을 새 목표로
    team.wps.forEach((w,i)=>{w.isTarget=false;if(i===newTargetInRoute)w.isTarget=true;});
    // 새 목표 이후 지점들 제거 (불필요한 상행 구간)
    team.wps=team.wps.slice(0,newTargetInRoute+1);
    team.wps[newTargetInRoute].isTarget=true;
  }else{
    // 경로에 없음 — 현재 목표 지점을 교체
    team.wps[curTargetIdx]={code:found.name&&found.name.match(/^(\d{2}-\d{2})/)?found.name.match(/^(\d{2}-\d{2})/)[1]:code,name:found.name||code,lat:found.lat||null,lng:found.lng||null,isTarget:true,status:'pending',approx:false};
    team.wps=team.wps.slice(0,curTargetIdx+1);
  }
  _saveTeamState();_persistTeams();_rerenderTlFull();
  const nm=found.name||code;
  toast('📍 조우 지점 변경: '+nm);
  // 상황일지에 기록
  if(_tlWpResId){const _res=DB.g('rescues')||[];const _ri=_res.findIndex(x=>x.id===_tlWpResId);if(_ri>=0){if(!_res[_ri].timetable)_res[_ri].timetable=[];_res[_ri].timetable.push({stage:'조우 지점 변경',time:now().slice(11,16),note:team.name+' → '+nm});DB.s('rescues',_res);}}
}

// ── 이송 방법 전환 (도보→차량, 들것→헬기 인계 등)
function tlChangeTransport(idx){
  const team=_tlTeams[idx];if(!team)return;
  const methods=['들것이송','자력하산','차량이송','헬기이송(인계)'];
  const cur=team.transportMethod||'미지정';
  const picked=prompt('현재: '+cur+'\n\n새 이송 방법:\n1=들것이송\n2=자력하산\n3=차량이송\n4=헬기이송(인계)');
  const map={'1':'들것이송','2':'자력하산','3':'차량이송','4':'헬기이송(인계)'};
  const newMethod=map[picked&&picked.trim()];
  if(!newMethod)return;
  const prev=team.transportMethod||'미지정';
  team.transportMethod=newMethod;
  if(!team.transportLog)team.transportLog=[];
  team.transportLog.push({from:prev,to:newMethod,at:now()});
  _persistTeams();_rerenderTlFull();
  toast('🔄 '+team.name+' 이송 방법 변경: '+prev+' → '+newMethod);
  if(_tlWpResId){const _res=DB.g('rescues')||[];const _ri=_res.findIndex(x=>x.id===_tlWpResId);if(_ri>=0){if(!_res[_ri].timetable)_res[_ri].timetable=[];_res[_ri].timetable.push({stage:'이송방법 변경',time:now().slice(11,16),note:team.name+': '+prev+' → '+newMethod,type:'team'});DB.s('rescues',_res);}}
}

// ── 타임라인: 복귀 버튼 (다른 팀 회수)
// ── GPS 자동 통과 감지 (타임라인 화면이 열려 있는 동안) ──
let _gpsAutoOn=false,_gpsWatchId=null,_gpsDeclined={};
function _stopGpsAuto(){
  _gpsAutoOn=false;
  if(_gpsWatchId!=null){try{navigator.geolocation.clearWatch(_gpsWatchId);}catch(e){}_gpsWatchId=null;}
  const b=document.getElementById('gpsAutoBtn');
  if(b){b.textContent='📡 GPS 자동 통과 OFF';b.style.background='transparent';b.style.color='rgba(255,255,255,.4)';b.style.borderColor='rgba(255,255,255,.14)';}
}
function toggleGpsAuto(){
  if(_gpsAutoOn){_stopGpsAuto();toast('📡 GPS 자동 통과 끔');return;}
  if(!navigator.geolocation){toast('⚠️ 이 기기는 GPS를 지원하지 않습니다');return;}
  _gpsAutoOn=true;_gpsDeclined={};
  _gpsWatchId=navigator.geolocation.watchPosition(_onGpsAutoFix,
    ()=>{toast('⚠️ GPS 권한 거부 또는 수신 불가');_stopGpsAuto();},
    {enableHighAccuracy:true,maximumAge:5000,timeout:20000});
  const b=document.getElementById('gpsAutoBtn');
  if(b){b.textContent='📡 GPS 자동 통과 ON';b.style.background='rgba(39,174,96,.15)';b.style.color='#27ae60';b.style.borderColor='rgba(39,174,96,.45)';}
  toast('📡 GPS 자동 통과 켬 — 다음 표지판 60m 접근 시 알림 (화면을 켜둔 동안만 동작)');
}
// 백그라운드(화면 꺼짐·앱 전환) 시 GPS 연속수신 일시정지 → 배터리 절약, 복귀 시 자동 재개
document.addEventListener('visibilitychange',function(){
  if(document.hidden){
    if(_gpsAutoOn&&_gpsWatchId!=null){try{navigator.geolocation.clearWatch(_gpsWatchId);}catch(e){}_gpsWatchId=null;}
  }else{
    if(_gpsAutoOn&&_gpsWatchId==null&&navigator.geolocation){
      _gpsWatchId=navigator.geolocation.watchPosition(_onGpsAutoFix,()=>{},{enableHighAccuracy:true,maximumAge:5000,timeout:20000});
    }
    // 앱 재진입 시 날씨가 끝내 안 떠 있으면(첫 로드 실패) 다시 시도
    var _ws=document.getElementById('weatherStrip');
    if(_ws&&_ws.style.display==='none'){try{fetchWeather();}catch(e){}}
  }
});
// 팀의 실제 현재 위치를 GPS로 받아 미니맵에 표시하고, 가장 가까운 경로 지점으로
// 진행도를 맞춘다. (사고지점/목표는 그대로 유지)
function tlSetCurPos(idx){
  const team=_tlTeams[idx];if(!team)return;
  if(!navigator.geolocation){toast('⚠️ 이 기기는 GPS를 지원하지 않습니다');return;}
  toast('📡 현재 위치 확인 중...');
  navigator.geolocation.getCurrentPosition(function(pos){
    const lat=pos.coords.latitude,lng=pos.coords.longitude;
    team.curPos={lat:lat,lng:lng,at:now()};
    // 좌표가 있는 지점 중 가장 가까운 곳 찾기
    let nearest=-1,nd=Infinity;
    team.wps.forEach(function(w,i){
      if(!(w.lat&&w.lng))return;
      const d=_haversineKm(lat,lng,w.lat,w.lng);
      if(d<nd){nd=d;nearest=i;}
    });
    if(nearest>=0){
      // 진행도 스냅: 이전=통과, 현재=활성, 이후=대기 (스킵은 유지)
      team.wps.forEach(function(w,i){if(w.status!=='skipped')w.status=i<nearest?'passed':i===nearest?'active':'pending';});
      team.wpIdx=nearest;
      if(idx===_tlSelTeam){_tlWps=team.wps;_tlWpIdx=team.wpIdx;}
    }
    _persistTeams();
    _rerenderTlFull();
    if(team.wps.some(w=>w.lat&&w.lng))setTimeout(function(){_initTlMiniMap(team.wps,team.curPos);},120);
    const nm=nearest>=0?(team.wps[nearest].code||team.wps[nearest].name||''):'';
    toast('📍 '+team.name+' 현위치 갱신'+(nearest>=0?' — '+nm+' 부근 (약 '+Math.round(nd*1000)+'m)':''));
  },function(){toast('⚠️ GPS 권한 거부 또는 수신 불가');},{enableHighAccuracy:true,timeout:15000,maximumAge:5000});
}
function _onGpsAutoFix(pos){
  if(!_gpsAutoOn)return;
  // 타임라인 화면을 벗어나면 자동 중지 (배터리 보호)
  const v=document.getElementById('v-report');
  if(!v||!v.classList.contains('on')){_stopGpsAuto();return;}
  const team=_tlTeams[_tlSelTeam];
  if(!team||!team.wps)return;
  const nextIdx=team.wpIdx+1;
  const nw=team.wps[nextIdx];
  if(!nw||!nw.lat||!nw.lng)return;
  const dM=Math.round(_haversineKm(pos.coords.latitude,pos.coords.longitude,nw.lat,nw.lng)*1000);
  if(dM>60)return;
  const key=(team.id||_tlSelTeam)+'_'+nextIdx;
  if(_gpsDeclined[key])return;
  if(navigator.vibrate)try{navigator.vibrate([200,100,200]);}catch(e){}
  if(confirm('📍 '+(nw.code?nw.code+' ':'')+(nw.name||'다음 지점')+' 도착 (약 '+dM+'m)\n통과 처리할까요?')){
    tlPassTeam(_tlSelTeam);
  }else{
    _gpsDeclined[key]=1; // 같은 지점 재질문 방지
  }
}

function _wpItemHtmlTeam(w,i,team,teamIdx){
  const isActive=i===team.wpIdx;
  const isLast=i===team.wps.length-1;
  const isBase=w.isBase||w.isStart;
  let dbg,dbd,dtxt,nc,badge='';
  if(w.status==='passed'){
    dbg='rgba(39,174,96,.22)';dbd='#27ae60';dtxt='✓';nc='rgba(255,255,255,.42)';
    badge='<span style="background:rgba(39,174,96,.12);color:#5dbf8a;border:1px solid rgba(39,174,96,.25);border-radius:5px;font-size:9px;padding:1px 6px;">통과</span>';
  }else if(w.status==='skipped'){
    dbg='rgba(120,120,120,.12)';dbd='rgba(120,120,120,.35)';dtxt='↷';nc='rgba(255,255,255,.28)';
    badge='<span style="background:rgba(120,120,120,.1);color:rgba(180,180,180,.7);border:1px solid rgba(120,120,120,.2);border-radius:5px;font-size:9px;padding:1px 6px;">스킵</span>';
  }else if(isActive){
    dbg='rgba(231,76,60,.25)';dbd='#e74c3c';dtxt=isBase?'🏠':'📍';nc='#e0edf8';
    badge='<span style="background:rgba(231,76,60,.18);color:#e74c3c;border:1px solid rgba(231,76,60,.38);border-radius:5px;font-size:9px;padding:1px 6px;font-weight:700;">현재 위치</span>';
  }else if(w.isTarget){
    dbg='rgba(192,57,43,.12)';dbd='rgba(192,57,43,.45)';dtxt='🚨';nc='rgba(220,80,80,.8)';
    badge=`<span style="background:rgba(192,57,43,.12);color:#e05050;border:1px solid rgba(192,57,43,.28);border-radius:5px;font-size:9px;padding:1px 6px;font-weight:700;">사고지점${w.approx?' (근처)':''}</span>`;
  }else if(isBase){
    dbg='rgba(39,174,96,.15)';dbd='rgba(39,174,96,.4)';dtxt='🏠';nc='rgba(255,255,255,.5)';
  }else{
    dbg='rgba(79,168,208,.08)';dbd='rgba(79,168,208,.25)';dtxt=w.isHosp?'🏥':(w.code||'·');nc='rgba(255,255,255,.35)';
    if(w.descent)badge='<span style="background:rgba(39,174,96,.08);color:rgba(93,191,138,.7);border:1px solid rgba(39,174,96,.18);border-radius:5px;font-size:9px;padding:1px 6px;">🔽 하산</span>';
  }
  // 차량 접근 구간: 🚗 배지 / 차량 종점(와선대·백담센터)은 🥾 도보 시작 배지
  const vehBadge=w.vehEnd
    ?`<span style="background:rgba(241,196,15,.14);color:#f0c040;border:1px solid rgba(241,196,15,.35);border-radius:5px;font-size:9px;padding:1px 6px;font-weight:700;margin-right:4px;">🚗→🥾 도보 시작</span>`
    :(w.byVehicle?`<span style="background:rgba(231,76,60,.14);color:#ff6a4d;border:1px solid rgba(231,76,60,.3);border-radius:5px;font-size:9px;padding:1px 6px;font-weight:700;margin-right:4px;">🚗 차량 이동${w.vehKm?' '+w.vehKm.toFixed(1)+'km':''}</span>`:'');
  const click=(!isBase&&!isActive)?`onclick="event.stopPropagation();tlWarpToTeam(${teamIdx},${i})"`:'' ;
  return `<div id="tlWp_${teamIdx}_${i}" class="tl-wp${isActive?' tl-wp-active':''}${isLast?' last':''}" ${click} style="${!isBase&&!isActive?'cursor:pointer;':''}">
    <div style="position:relative;flex-shrink:0;">
      <div class="tl-wp-dot" style="background:${dbg};border-color:${dbd};">${dtxt}</div>
      ${!isLast?`<div class="tl-wp-conn"${w.byVehicle?' style="background:repeating-linear-gradient(to bottom,#e74c3c 0,#e74c3c 3px,transparent 3px,transparent 6px);"':''}></div>`:''}
    </div>
    <div style="padding-top:2px;flex:1;min-width:0;">
      <div style="font-size:12px;font-weight:${isActive?700:600};color:${nc};line-height:1.35;overflow:hidden;text-overflow:ellipsis;">${w.name}</div>
      <div style="margin-top:3px;">${vehBadge}${badge}${w.passedAt?`<span style="font-size:9px;color:rgba(255,255,255,.28);margin-left:5px;">${w.passedAt}</span>`:''}</div>
    </div>
  </div>`;
}


function _toggleTlFull(idx){
  if(!_tlTeams[idx])return;
  _tlTeams[idx].showFull=!_tlTeams[idx].showFull;
  _rerenderTlFull();
}

function _compactRouteHtml(team,idx){
  const cur=team.wps[team.wpIdx]||team.wps[0];
  const next=team.wps[team.wpIdx+1]||null;
  const atEnd=team.wpIdx>=team.wps.length-1;
  const total=Math.max((team.wps||[]).length-1,1);
  const prog=team.wpIdx;
  const pct=Math.round((prog/total)*100);
  const showFull=!!team.showFull;
  if(!cur)return`<div style="text-align:center;font-size:11px;color:rgba(255,255,255,.42);padding:10px 0;">경로 데이터 없음</div>`;
  // 이름에서 코드 접두어 제거
  const _nm=n=>(n||'').replace(/^\d{2}-\d{2}\s*/,'').trim()||n||'';
  const curLabel=(cur.code?cur.code+' ':'')+_nm(cur.name);
  const nextLabel=next?(next.code?next.code+' ':'')+_nm(next.name):'';
  const _hasDescent=team.wps.some(w=>w.descent);
  // 환자 조우 도달 → 헬기는 4단계, 나머지는 하산 시작
  if(atEnd&&cur.isTarget&&!_hasDescent){
    const joguCard=`
    <div style="background:rgba(39,174,96,.08);border:1px solid rgba(39,174,96,.3);border-radius:12px;padding:12px 14px;margin-bottom:10px;">
      <div style="font-size:10px;color:#5dbf8a;font-weight:700;margin-bottom:4px;">🎯 환자 조우 지점</div>
      <div style="font-size:15px;font-weight:800;color:#eef5fb;">${curLabel}</div>
    </div>`;
    if(team.type==='heli'){
      // 헬기 4단계: 현장도착 → 환자탑승 → 이송시작
      if(!team.arrivedAt){
        return joguCard+`<button onclick="event.stopPropagation();tlMarkArrival(${idx})" style="width:100%;padding:15px;border-radius:12px;border:none;background:linear-gradient(180deg,#e67e22,#c0392b);color:#fff;font-size:14px;font-weight:800;cursor:pointer;margin-bottom:6px;">🏁 헬기 현장도착 기록</button>`;
      }else if(!team.boardedAt){
        return joguCard+`
        <div style="display:flex;gap:6px;padding:7px 9px;background:rgba(39,174,96,.06);border-radius:9px;margin-bottom:10px;font-size:10px;color:#5dbf8a;">
          <span>🏁 도착 ${String(team.arrivedAt).slice(11,16)}</span>
        </div>
        <button onclick="event.stopPropagation();tlMarkBoarding(${idx})" style="width:100%;padding:15px;border-radius:12px;border:none;background:linear-gradient(180deg,#3f9bd1,#2d7db3);color:#fff;font-size:14px;font-weight:800;cursor:pointer;">🚁 환자 탑승 완료</button>`;
      }else{
        return joguCard+`
        <div style="display:flex;gap:10px;padding:7px 9px;background:rgba(39,174,96,.06);border-radius:9px;margin-bottom:10px;font-size:10px;color:#5dbf8a;">
          <span>🏁 도착 ${String(team.arrivedAt).slice(11,16)}</span>
          <span>🚁 탑승 ${String(team.boardedAt).slice(11,16)}</span>
        </div>
        <button onclick="event.stopPropagation();tlDescentTeam(${idx})" style="width:100%;padding:15px;border-radius:12px;border:none;background:linear-gradient(180deg,#2ecc71,#27ae60);color:#fff;font-size:15px;font-weight:800;cursor:pointer;box-shadow:0 3px 10px rgba(39,174,96,.4);">🏥 병원 이송 시작</button>`;
      }
    }
    // 도보·차량팀: 조우 지점 변경 버튼 + 하산 시작
    return joguCard+`
    <button onclick="event.stopPropagation();tlDescentTeam(${idx})" style="width:100%;padding:15px;border-radius:12px;border:none;background:linear-gradient(180deg,#2ecc71,#27ae60);color:#fff;font-size:15px;font-weight:800;cursor:pointer;box-shadow:0 3px 10px rgba(39,174,96,.4);margin-bottom:7px;">🔽 하산 시작</button>
    <button onclick="event.stopPropagation();tlChangeTarget(${idx})" style="width:100%;padding:9px;border-radius:9px;border:1px solid rgba(241,196,15,.3);background:rgba(241,196,15,.06);color:#f0c040;font-size:11px;font-weight:700;cursor:pointer;">📍 조우 지점 변경 (요구조자가 내려온 경우)</button>`;
  }
  // 하산/이송 완료
  if(atEnd&&_hasDescent){
    return`<div style="text-align:center;padding:14px;font-size:13px;color:#2ecc71;font-weight:800;">✅ ${team.type==='heli'?'병원 이송':'하산'} 완료</div>`;
  }
  // 진행 바
  const barHtml=`<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><div style="flex:1;background:rgba(255,255,255,.09);border-radius:5px;height:7px;overflow:hidden;"><div style="height:100%;width:${pct}%;background:linear-gradient(90deg,#2d7db3,#4fa8d0);border-radius:5px;transition:width .3s;"></div></div><span style="font-size:10px;color:#7a9cb8;font-weight:700;font-family:monospace;flex-shrink:0;">${pct}%</span></div>`;
  // 현재 위치 카드 (차량 구간이면 '차량 이동 중' 멘트)
  const _inVeh=!!cur.byVehicle;
  const curCard=`
    <div style="background:${_inVeh?'rgba(231,76,60,.13)':'rgba(231,76,60,.09)'};border:1px solid ${_inVeh?'rgba(231,76,60,.45)':'rgba(231,76,60,.3)'};border-radius:11px;padding:11px 14px;margin-bottom:7px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px;">
        <span style="font-size:10px;color:#ff7060;font-weight:700;">${_inVeh?'🚗 차량 이동 중':'📍 현재 위치'}</span>
        <span style="font-size:10px;color:rgba(255,255,255,.3);font-family:monospace;">${prog} / ${total}</span>
      </div>
      <div style="font-size:15px;font-weight:800;color:#eef5fb;line-height:1.3;word-break:keep-all;">${curLabel}</div>
      ${_inVeh?`<div style="font-size:10px;color:#ff9e80;margin-top:3px;font-weight:600;">${cur.vehEnd?'🥾 여기서부터 도보 이동':'🚗 차량 접근 구간 — 종점까지 차량 이동'}</div>`:''}
      ${cur.passedAt?`<div style="font-size:10px;color:rgba(255,255,255,.3);margin-top:3px;">${String(cur.passedAt).slice(11,16)} 통과</div>`:''}
    </div>`;
  // 다음 위치 (차량 종점이면 '도보 시작점' 멘트)
  const nextCard=next?`
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;padding:0 2px;">
      <span style="font-size:13px;color:rgba(79,168,208,.45);">↓</span>
      <div style="flex:1;min-width:0;">
        <div style="font-size:10px;color:${next.vehEnd?'#ff9e80':'#4a7090'};font-weight:600;margin-bottom:1px;">${next.vehEnd?'다음 · 🥾 도보 시작점':'다음'}${next.byVehicle&&!next.vehEnd?' 🚗':''}${next.descent?' 🔽':''}</div>
        <div style="font-size:13px;font-weight:600;color:rgba(255,255,255,.7);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${nextLabel}</div>
      </div>
    </div>`:
    !atEnd?'':`<div style="text-align:center;font-size:12px;color:#2ecc71;font-weight:700;margin-bottom:8px;">✅ 전 구간 통과</div>`;
  // 통과 버튼 (건너뛰기 제거)
  const passBtn=!atEnd?`
    <button id="tlPassBtn_${idx}" onclick="event.stopPropagation();tlPassTeam(${idx})" style="width:100%;padding:15px;border-radius:12px;border:none;background:linear-gradient(180deg,#3f9bd1,#2a6fa3);color:#fff;font-size:15px;font-weight:800;cursor:pointer;box-shadow:0 3px 10px rgba(45,125,179,.4);margin-bottom:8px;">✓ 통과 → ${next?nextLabel.split(' ')[0]||'다음':''}</button>`:'';
  // GPS + 전체경로 (보조 작은 버튼들)
  const _canChangeTarget=!_hasDescent&&team.wps.some(w=>w.isTarget)&&!atEnd;
  const _canChangeTransport=_hasDescent&&team.transportMethod;
  const secBtns=`
    <div style="display:flex;gap:6px;flex-wrap:wrap;">
      <button onclick="event.stopPropagation();tlSetCurPos(${idx})" style="flex:1;padding:8px;border-radius:9px;border:1px solid rgba(79,168,208,.22);background:rgba(79,168,208,.06);color:#6aa8ff;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;">📡 GPS${team.curPos?` <span style="font-size:9px;opacity:.5;">${String(team.curPos.at).slice(11,16)}</span>`:''}</button>
      ${_canChangeTarget?`<button onclick="event.stopPropagation();tlChangeTarget(${idx})" style="flex:1;padding:8px;border-radius:9px;border:1px solid rgba(241,196,15,.28);background:rgba(241,196,15,.05);color:#e8c84a;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap;">📍 조우 지점</button>`:''}
      ${_canChangeTransport?`<button onclick="event.stopPropagation();tlChangeTransport(${idx})" style="flex:1;padding:8px;border-radius:9px;border:1px solid rgba(230,126,34,.28);background:rgba(230,126,34,.05);color:#e8943a;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap;">🔄 이송 전환</button>`:''}
      <button onclick="event.stopPropagation();_toggleTlFull(${idx})" style="padding:8px 10px;border-radius:9px;border:1px solid rgba(255,255,255,.1);background:transparent;color:rgba(255,255,255,.35);font-size:11px;cursor:pointer;white-space:nowrap;">${showFull?'▲ 접기':'▾ 전체'}</button>
    </div>`;
  const fullList=showFull?`<div id="tlWpList_${idx}" style="max-height:240px;overflow-y:auto;border:1px solid rgba(255,255,255,.07);border-radius:9px;padding:6px 8px;margin-top:8px;">${team.wps.map((w,i)=>_wpItemHtmlTeam(w,i,team,idx)).join('')}</div>`:'';
  return barHtml+curCard+nextCard+passBtn+secBtns+fullList;
}

function _tlTeamFullHtml(team,idx){
  const isSel=idx===_tlSelTeam&&!team.collapsed;
  const si=_teamStageIdx(team);
  const typeIco=_teamIco(team);
  const isCollapsed=!!team.collapsed;
  const STAGE_PILL=['출발','이동 중','환자 조우','하산·이송'];
  const STAGE_COL=['rgba(255,255,255,.38)','#4fa8d0','#e74c3c','#27ae60'];
  const stagePill=`<span style="font-size:10px;font-weight:700;color:${STAGE_COL[si]};background:rgba(${si===2?'231,76,60':si===3?'39,174,96':si===1?'79,168,208':'255,255,255'},.1);border-radius:6px;padding:2px 7px;">${STAGE_PILL[si]||''}</span>`;
  const _mem=team.memberCount?` <span style="font-size:9px;color:rgba(255,255,255,.38);">${team.memberCount}명</span>`:'';
  const _req=team.requestedAt?String(team.requestedAt).slice(11,16):'';
  const _arr=team.arrivedAt?String(team.arrivedAt).slice(11,16):'';
  const _brd=team.boardedAt?String(team.boardedAt).slice(11,16):'';
  const _transport=team.transportMethod?`<span style="font-size:10px;color:#e8943a;background:rgba(230,126,34,.12);border-radius:6px;padding:2px 7px;font-weight:600;">${team.transportMethod}</span>`:'';
  // 유관기관: 출동요청·도착 시각 칩 / 공단팀: 도착 기록 버튼
  const _isAgency=team.agType!=null;
  const _timeChips=`<div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:6px;">
    ${_req?`<span style="font-size:10px;color:#7a96ad;background:rgba(255,255,255,.05);border-radius:6px;padding:2px 7px;">🚨 ${_req}</span>`:''}
    ${_arr?`<span style="font-size:10px;color:#3ad17a;background:rgba(39,174,96,.1);border-radius:6px;padding:2px 7px;">🏁 ${_arr}</span>`:(_isAgency?`<button onclick="event.stopPropagation();tlMarkArrival(${idx})" style="background:rgba(39,174,96,.12);border:1px solid rgba(39,174,96,.35);color:#5dbf8a;border-radius:6px;font-size:10px;font-weight:700;padding:3px 9px;cursor:pointer;">🏁 도착 기록</button>`:'')}
    ${_brd?`<span style="font-size:10px;color:#5fb0d8;background:rgba(79,168,208,.1);border-radius:6px;padding:2px 7px;">🚁 탑승 ${_brd}</span>`:''}
    ${_transport}
  </div>`;
  const routeInner=team.wps.length>1
    ?_compactRouteHtml(team,idx)
    :`<div style="text-align:center;font-size:11px;color:rgba(255,255,255,.42);padding:10px 0;">경로 데이터 없음</div>`;
  return `<div id="tlTeamCard_${idx}" style="background:${isSel?'rgba(79,168,208,.06)':'rgba(255,255,255,.015)'};border:1.5px solid ${isSel?'rgba(79,168,208,.4)':'rgba(255,255,255,.08)'};border-radius:12px;margin-bottom:8px;overflow:hidden;">
    <div onclick="toggleTlTeamRoute(${idx})" style="padding:11px 13px;cursor:pointer;user-select:none;-webkit-user-select:none;">
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:13px;font-weight:700;color:${isSel?'#6bbde0':'#c8dff0'};">${typeIco} ${_esc(team.name)}${_mem}</span>
        <div style="display:flex;align-items:center;gap:7px;">${stagePill}<span style="font-size:12px;color:rgba(255,255,255,.4);">${isCollapsed?'▼':'▲'}</span></div>
      </div>
      ${_timeChips}
    </div>
    <div id="tlTeamRoute_${idx}" style="display:${isCollapsed?'none':'block'};padding:0 13px 13px;border-top:.5px solid rgba(255,255,255,.06);">
      ${routeInner}
    </div>
  </div>`;
}

function toggleTlTeamRoute(idx){
  if(!_tlTeams[idx])return;
  const wasCollapsed=_tlTeams[idx].collapsed;
  _tlTeams[idx].collapsed=!wasCollapsed;
  if(wasCollapsed){_saveTeamState();_tlSelTeam=idx;_tlWps=_tlTeams[idx].wps;_tlWpIdx=_tlTeams[idx].wpIdx;}
  _rerenderTlFull();
}
function tlPassTeam(idx){
  const team=_tlTeams[idx];
  if(!team||_tlAnimating)return;                       // 애니메이션 중 연타 차단
  if(team.wpIdx>=team.wps.length-1)return;             // 이미 끝
  _tlAnimating=true;
  const next=team.wpIdx+1;
  // 즉시 시각 피드백 — 버튼 비활성화 (연타 인지 차단의 핵심)
  [document.getElementById('tlPassBtn_'+idx),document.getElementById('tlPassBtn')].forEach(pb=>{
    if(pb){pb.disabled=true;pb.style.opacity='.5';pb.style.cursor='default';pb.textContent='이동 중…';}
  });
  const nel=document.getElementById('tlWp_'+next);
  if(nel){nel.style.transition='background .2s';nel.style.background='rgba(231,76,60,.07)';}
  const dur=_tlVehicle?240:420;                         // 1400ms → 420ms: 즉각 반응
  setTimeout(()=>{
    // team 객체에 직접 적용 — 전역 변수 재할당과 무관 (교차오염 방지)
    const passedWp=team.wps[team.wpIdx];
    team.wps[team.wpIdx].passedAt=now();
    team.wps[team.wpIdx].status='passed';
    team.wps[next].status='active';
    team.wpIdx=next;
    // 선택팀 전역 동기화
    _tlSelTeam=idx;_tlWps=team.wps;_tlWpIdx=team.wpIdx;
    _tlAnimating=false;
    _saveTeamState();_persistTeams();_rerenderTlFull();
    if(team.wps[next].isTarget)toast('🎯 환자 조우!');
    if(next>=team.wps.length-1&&team.wps[next].descent)_promptHandover(_tlWpResId,team);
    if(_tlWpResId){
      const _res=DB.g('rescues')||[];const _ri=_res.findIndex(x=>x.id===_tlWpResId);
      if(_ri>=0){
        if(!_res[_ri].wpLog)_res[_ri].wpLog=[];
        const _d=new Date();
        _res[_ri].wpLog.push({time:_d.getHours().toString().padStart(2,'0')+':'+_d.getMinutes().toString().padStart(2,'0'),teamName:team.name||'팀',code:passedWp.code||'',wpName:passedWp.name||''});
        DB.s('rescues',_res);
      }
    }
    _checkAllTeamsDone(_tlWpResId);
  },dur);
}
function tlWarpToTeam(teamIdx,wpIdx){_saveTeamState();_tlSelTeam=teamIdx;_tlWps=_tlTeams[teamIdx].wps;_tlWpIdx=_tlTeams[teamIdx].wpIdx;tlWarpTo(wpIdx);}

function _rerenderTlFull(){
  const el=document.getElementById('tlAllTeams');
  if(el)el.innerHTML=_tlTeams.map((t,i)=>_tlTeamFullHtml(t,i)).join('');
  if(!_tlBuilding){const ba=document.getElementById('tlBuildArea');if(ba)ba.innerHTML=_renderCreateBtnsHtml();}
  const allDone=_tlTeams.length>0&&_tlTeams.every(t=>_teamDone(t));
  const bel=document.getElementById('tlAllDoneBanner');
  if(bel)bel.style.display=allDone?'':'none';
}


function tlWarpTo(idx){
  if(_tlAnimating||idx<1||idx>=_tlWps.length)return;
  _tlWps.forEach((w,i)=>{if(w.status!=='skipped')w.status=i<idx?'passed':i===idx?'active':'pending';});
  _tlWpIdx=idx;_saveTeamState();_persistTeams();_rerenderTlFull();
}

function _buildLogHtml(r){
  const baseDate=(r.date||'').slice(0,10);
  const _tKey=t=>{const s=String(t||'').trim();if(/^\d{4}-\d{2}-\d{2}/.test(s))return s;return baseDate+' '+s;};
  const _tShow=t=>{const s=String(t||'').trim();return s.length>5?s.slice(11,16)||s.slice(-5):s;};
  // type: 'victim'=요구조자 관련(빨강) | 'team'=팀 이동(파랑) | 'report'=보고(보라) | 'nps'=공단(초록)
  const logEntries=[];
  if(r.date)logEntries.push({k:_tKey(r.date),t:_tShow(r.date),ico:'🚨',label:'1보 접수',sub:r.reception||'',type:'victim'});
  (r.timetable||[]).forEach(e=>{
    if(!e.time)return;
    const isVictim=e.stage==='요구조자 조우'||e.stage==='심정지'||e.stage==='의식확인';
    const isCpr=e.stage==='심정지'&&(e.cprStart||e.cprEnd);
    let sub=e.note||'';
    if(isCpr){
      const cprDur=e.cprStart&&e.cprEnd?(()=>{try{const s=new Date(e.cprStart.replace(' ','T')),en=new Date(e.cprEnd.replace(' ','T'));const m=Math.round((en-s)/60000);return m>0?' ('+m+'분)':'';}catch(e){return ''}})():'';
      sub=(e.cprStart?'CPR '+String(e.cprStart).slice(11,16):'')+(e.cprEnd?'→'+String(e.cprEnd).slice(11,16)+cprDur:'')+(e.aed?' · AED '+e.aed:'')+(sub?' · '+sub:'');
    }
    logEntries.push({k:_tKey(e.time),t:_tShow(e.time),ico:e.stage==='심정지'?'💔':isVictim?'🎯':'📌',label:e.stage,sub,type:isVictim?'victim':'team'});
  });
  // 위치통과: "01-15 통과" (팀명은 서브)
  (r.wpLog||[]).forEach(l=>{
    logEntries.push({k:_tKey(l.time),t:l.time,ico:'📍',label:(l.code||'?')+' 통과',sub:l.teamName||'',type:'team'});
  });
  (r.teams||[]).forEach(t=>{
    if(t.createdAt){
      const _ico=t.type==='heli'?'🚁':t.type==='vehicle'?'🚗':'🥾';
      const _base=t.wps&&t.wps[0]?t.wps[0].name.replace(/^\d{2}-\d{2}\s*/,''):'';
      const _tgt=t.wps&&t.wps.length>1?t.wps[t.wps.length-1].name.replace(/^\d{2}-\d{2}\s*/,''):'';
      const _mem=t.members&&t.members.length?t.members.join(', '):'';
      logEntries.push({k:_tKey(t.createdAt),t:_tShow(t.createdAt),ico:_ico,label:t.name+' 출동',sub:(_mem?_mem+' · ':'')+(_base&&_tgt?_base+' → '+_tgt:''),type:'team'});
    }
    if(t.arrivedAt)logEntries.push({k:_tKey(t.arrivedAt),t:_tShow(t.arrivedAt),ico:'🏁',label:t.name+' 현장도착',sub:'',type:'team'});
    if(t.boardedAt)logEntries.push({k:_tKey(t.boardedAt),t:_tShow(t.boardedAt),ico:'🚁',label:t.name+' 환자 탑승',sub:'',type:'team'});
    (t.transportLog||[]).forEach(tr=>logEntries.push({k:_tKey(tr.at),t:_tShow(tr.at),ico:'🔄',label:t.name+' 이송전환',sub:tr.from+' → '+tr.to,type:'team'}));
  });
  (r.reports||[]).forEach((p,pi)=>{if(p.repTime)logEntries.push({k:_tKey(p.repTime),t:_tShow(p.repTime),ico:'📋',label:(pi+2)+'보 보고'+(p.author?' · '+p.author:''),sub:p.update||'',type:'report'});});
  (r.npsLog||[]).forEach(nl=>{if(nl.time)logEntries.push({k:_tKey(nl.time),t:_tShow(nl.time),ico:'🏕️',label:'공단 공유'+(nl.author?' · '+nl.author:''),sub:nl.text||'',type:'nps'});});
  if(r.handover&&r.handover.to)logEntries.push({k:_tKey(r.handover.time),t:_tShow(r.handover.time),ico:'🤝',label:'환자 인계 → '+r.handover.to,sub:r.handover.by||'',type:'victim'});
  logEntries.sort((a,b)=>a.k.localeCompare(b.k));
  if(!logEntries.length)return '';
  // 타입별 색상
  const TYPE_COL={victim:'#e74c3c',team:'#4fa8d0',report:'#9b59b6',nps:'#27ae60'};
  const TYPE_BG={victim:'rgba(231,76,60,.1)',team:'rgba(79,168,208,.08)',report:'rgba(155,89,182,.08)',nps:'rgba(39,174,96,.08)'};
  const isWpPass=e=>e.type==='team'&&e.ico==='📍';
  const rows=logEntries.map((e,i)=>{
    const col=TYPE_COL[e.type]||'#7a9cb8';
    const bg=TYPE_BG[e.type]||'transparent';
    const isLast=i===logEntries.length-1;
    return `<div style="display:flex;gap:0;position:relative;">
      <!-- 세로 타임라인 트랙 -->
      <div style="display:flex;flex-direction:column;align-items:center;width:28px;flex-shrink:0;">
        <div style="width:8px;height:8px;border-radius:50%;background:${col};flex-shrink:0;margin-top:4px;box-shadow:0 0 4px ${col}66;"></div>
        ${isLast?'':`<div style="width:1.5px;flex:1;min-height:12px;background:linear-gradient(${col}66,rgba(255,255,255,.06));margin-top:2px;"></div>`}
      </div>
      <!-- 이벤트 내용 -->
      <div style="flex:1;padding:2px 0 ${isLast?'0':'10px'} 4px;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:${e.sub?'2':'0'}px;">
          <span style="font-size:11px;color:#7a9cb8;font-family:monospace;font-weight:600;white-space:nowrap;">${e.t}</span>
          <span style="font-size:${isWpPass(e)?'11':'12'}px;font-weight:${isWpPass(e)?'600':'700'};color:${isWpPass(e)?'rgba(255,255,255,.55)':col};">${e.ico} ${_esc(e.label)}</span>
        </div>
        ${e.sub?`<div style="font-size:10px;color:rgba(255,255,255,.35);padding-left:2px;line-height:1.4;">${_esc(e.sub)}</div>`:''}
      </div>
    </div>`;
  }).join('');
  // 범례
  const legend=`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">
    ${Object.entries({요구조자:'victim',팀이동:'team',보고:'report','공단':'nps'}).map(([lbl,tp])=>`<span style="font-size:9px;color:${TYPE_COL[tp]};background:${TYPE_BG[tp]};border-radius:4px;padding:1px 6px;font-weight:700;">${lbl}</span>`).join('')}
  </div>`;
  return `<div style="background:#060d1a;border-radius:10px;padding:11px 13px;margin-top:8px;border:.5px solid rgba(79,168,208,.15);">
    <div style="font-size:11px;color:#4fa8d0;font-weight:700;margin-bottom:7px;">📜 상황 일지</div>
    ${legend}${rows}
  </div>`;
}
function renderTimeline(r,viewMode,outId){
  const _isBoard=outId&&outId!=='repContent';
  if(!_isBoard){_hideRepFooter();window._reportMode='timeline';clearInterval(_draftAutoTimer);} // 타임라인 보기 — 작성모드 해제

  _curViewResId=r.id;
  const mode=(viewMode==='full'||viewMode==='write')?'write':'advanced';
  _tlMode=mode;_tlViewMode=mode;
  const all=[r,...(r.reports||[])];
  const w=document.getElementById(outId||'repContent');
  if(!w)return;

  function renderComments(resId){
    // 구조 레코드 내장 댓글(동기화됨) + 구버전 로컬 댓글 병합
    const rec=getRes(resId);
    const seen=new Set();
    const cmts=[...(rec.comments||[]),...(DB.g('comments_'+resId)||[])]
      .filter(c=>{if(seen.has(c.id))return false;seen.add(c.id);return true;})
      .sort((a,b)=>(a.id||0)-(b.id||0));
    if(!cmts.length)return '<div style="font-size:11px;color:rgba(255,255,255,.25);padding:4px 0;">댓글 없음</div>';
    return cmts.map(cm=>`<div style="background:#060d1a;border-radius:7px;padding:8px 10px;margin-bottom:5px;">
      <div style="font-size:11px;color:#4fa8d0;font-weight:600;">${_esc(cm.author||'익명')} · ${cm.time}</div>
      <div style="font-size:12px;color:#b8d4e8;margin-top:3px;line-height:1.5;">${_esc(cm.text)}</div>
    </div>`).join('');
  }

  const tabHdr=`<div style="background:#0b1c30;border-radius:10px;padding:11px 12px;border:.5px solid rgba(255,255,255,.07);margin-bottom:10px;">
    <div style="font-size:14px;font-weight:700;color:#e0edf8;">${_esc(r.title)}</div>
    <div style="font-size:11px;color:#3a6a8a;margin-top:3px;">${_esc(r.type)} · ${r.status==='ongoing'?'<span style="color:#c0392b;font-weight:700;">진행중</span>':'<span style="color:#27ae60;font-weight:700;">종료</span>'} · ${r.date}${r.status==='ongoing'&&_elapsedStr(r.date)?` · <span class="js-elapsed" data-d="${_esc(r.date)}" style="color:#f0a500;font-weight:700;">⏱ ${_elapsedStr(r.date)}</span>`:''}</div>
    <div style="display:flex;gap:5px;margin-top:9px;">
      <button onclick="${_isBoard?`_boardOpenDetail(${r.id},'advanced')`:`renderTimeline(getRes(${r.id}),'advanced')`}" style="flex:1;padding:6px;border-radius:7px;border:1px solid;font-size:11px;font-weight:600;cursor:pointer;background:${'advanced'===mode?'rgba(79,168,208,.15)':'transparent'};color:${'advanced'===mode?'#4fa8d0':'rgba(255,255,255,.35)'};border-color:${'advanced'===mode?'rgba(79,168,208,.5)':'rgba(255,255,255,.1)'};">📍 고도화 타임라인</button>
      ${isExternal()?'':`<button onclick="${_isBoard?`_boardOpenDetail(${r.id},'write')`:`renderTimeline(getRes(${r.id}),'write')`}" style="flex:1;padding:6px;border-radius:7px;border:1px solid;font-size:11px;font-weight:600;cursor:pointer;background:${'write'===mode?'rgba(79,168,208,.15)':'transparent'};color:${'write'===mode?'#4fa8d0':'rgba(255,255,255,.35)'};border-color:${'write'===mode?'rgba(79,168,208,.5)':'rgba(255,255,255,.1)'};">📄 보고서</button>`}
    </div>
  </div>`;

  if(mode==='advanced'){
    _initTlTeams(r);
    w.innerHTML=tabHdr+`
      <!-- 다목적위치표지판 미니맵 (팀 생성 후 표시) -->
      <div id="tlMiniMapWrap" style="display:${_tlTeams.some(t=>t.wps.some(w=>w.lat&&w.lng))?'block':'none'};background:#0b1c30;border-radius:10px;border:.5px solid rgba(79,168,208,.15);margin-bottom:10px;overflow:hidden;">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px 5px;">
          <div style="font-size:11px;color:#4fa8d0;font-weight:700;">🗺️ 경로 진행</div>
          <div id="tlMiniMapProg" style="font-size:11px;color:#7a9cb8;"></div>
        </div>
        <div id="tlMiniMap" style="width:100%;height:150px;"></div>
      </div>
      <!-- GPS 자동 통과 (상단 공유 버튼) -->
      <div style="display:flex;gap:6px;margin-bottom:8px;">
        <button id="gpsAutoBtn" onclick="toggleGpsAuto()" style="flex:1;padding:8px 10px;border-radius:9px;border:1px solid ${_gpsAutoOn?'rgba(39,174,96,.45)':'rgba(255,255,255,.12)'};background:${_gpsAutoOn?'rgba(39,174,96,.12)':'transparent'};color:${_gpsAutoOn?'#27ae60':'rgba(255,255,255,.45)'};font-size:12px;font-weight:700;cursor:pointer;">📡 GPS 자동통과 ${_gpsAutoOn?'켜짐 ●':'꺼짐'}</button>
        <button onclick="openTimetable()" style="flex:1;padding:8px 10px;border-radius:9px;border:1px solid rgba(255,255,255,.1);background:transparent;color:rgba(255,255,255,.45);font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;">📌 조우·특이사항 기록</button>
      </div>
      <!-- 팀별 경로 카드 -->
      <div id="tlAllTeams">
        ${_tlTeams.map((t,i)=>_tlTeamFullHtml(t,i)).join('')}
      </div>
      <!-- 전 팀 완료 배너 -->
      <div id="tlAllDoneBanner" style="display:${(_tlTeams.length>0&&_tlTeams.every(t=>_teamDone(t)))?'':'none'};background:rgba(39,174,96,.12);border:1.5px solid rgba(39,174,96,.45);border-radius:12px;padding:14px 16px;margin-bottom:10px;text-align:center;">
        <div style="font-size:13px;font-weight:800;color:#27ae60;margin-bottom:6px;">🏁 전 팀 하산/이송 완료</div>
        <div style="font-size:11px;color:rgba(255,255,255,.45);margin-bottom:10px;">상황을 종료하시겠습니까?</div>
        <button onclick="selResId=${r.id};curResId=${r.id};endSit();" style="background:rgba(39,174,96,.2);border:1px solid rgba(39,174,96,.55);color:#27ae60;border-radius:8px;padding:8px 0;font-size:12px;font-weight:700;cursor:pointer;width:100%;">✅ 상황 종료</button>
      </div>
      <!-- 팀 생성 영역 -->
      <div id="tlBuildArea">
        ${_tlBuilding?_renderBuildPanelHtml():_renderCreateBtnsHtml()}
      </div>
      ${_scenePhotosHtml(r)}
      ${_buildLogHtml(r)}
      <div style="background:#0b1c30;border-radius:10px;padding:11px 12px;border:.5px solid rgba(79,168,208,.12);margin-top:8px;">
        <div style="font-size:11px;color:#4fa8d0;font-weight:700;margin-bottom:8px;">💬 댓글</div>
        <div id="commentList_adv_${r.id}">${renderComments(r.id)}</div>
        <div style="display:flex;gap:6px;margin-top:8px;">
          <input type="text" id="cmtInput_adv_${r.id}" class="fi" placeholder="댓글 입력..." style="flex:1;">
          <button onclick="submitComment(${r.id},'adv')" style="background:#1a4a6e;color:#fff;border:none;padding:0 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;">등록</button>
        </div>
      </div>
      `;
    if(_tlTeams.some(t=>t.wps.some(w=>w.lat&&w.lng)))setTimeout(()=>_initTlMiniMap((_tlTeams.find(t=>t.wps.some(w=>w.lat&&w.lng))||{wps:[]}).wps),150);
  } else {
    // 통합 보고서 mode
    const _ok=v=>{if(!v&&v!==0)return false;const s=String(v).trim();return s&&s!=='-'&&!['미상','없음','모르겠음','알수없음','미정','해당없음','기타'].includes(s);};
    const _okA=v=>(Array.isArray(v)?v:[]).filter(x=>_ok(x));
    const _row=(k,v)=>v?`<div style="display:flex;gap:8px;padding:5px 0;border-bottom:.5px solid rgba(255,255,255,.04);align-items:flex-start;"><span style="font-size:11px;color:#4a7090;font-weight:600;flex-shrink:0;min-width:46px;">${k}</span><span style="font-size:11px;color:#b8d4e8;line-height:1.55;flex:1;">${v}</span></div>`:'';
    const rows=[];
    const dparts=[_ok(r.date)?r.date:'',_ok(r.dispatch)?'신고 '+r.dispatch:'',_ok(r.arrival)?'출동 '+r.arrival:''].filter(Boolean);
    if(dparts.length)rows.push(_row('일시',dparts.join(' · ')));
    if(_ok(r.location))rows.push(_row('위치',_esc(r.location)+(_ok(r.loctype)?' · '+_esc(r.loctype):'')));
    const wx=[_ok(r.weather)?_esc(r.weather):'',_ok(r.weatherAlert)?_esc(r.weatherAlert):''].filter(Boolean).join(' ');
    if(wx)rows.push(_row('기상',wx));
    const vp=[_ok(r.vName)?_esc(r.vName):'',_ok(r.vBirth)?_ageFromBirth(r.vBirth)+'세':(_ok(r.vAge)?_esc(r.vAge)+'세':''),_ok(r.vGender)&&r.vGender!=='알수없음'?_esc(r.vGender):'',_ok(r.vNation)&&r.vNation!=='알수없음'?_esc(r.vNation):''].filter(Boolean);
    if(vp.length)rows.push(_row('사고자',vp.join(' · ')+((r.victims2&&r.victims2.length)?` <span style="color:#e9897e;font-weight:700;">외 ${r.victims2.length}명</span>`:'')));
    if(r.victims2&&r.victims2.length)rows.push(_row('추가자',r.victims2.map(v=>[_esc(v.name||'미상'),v.gender&&v.gender!=='알수없음'?_esc(v.gender):'',v.age?_esc(v.age)+'세':'',_esc(v.severity),_esc(v.note)].filter(Boolean).join(' · ')).join('<br>')));
    if(_ok(r.vTel))rows.push(_row('연락처',_esc(r.vTel)));
    if(_ok(r.severity))rows.push(_row('중증도',_esc(r.severity)));
    if(_ok(r.outcome))rows.push(_row('결과',_esc(r.outcome)+(_ok(r.causeCategory)?' · '+_esc(r.causeCategory):'')));
    // 활력징후 추이: 1보 + 각 보고의 vitals 수집
    {const vseq=[];if(r.vitals&&_vitalsStr(r.vitals))vseq.push(r.vitals);(r.reports||[]).forEach(p=>{if(p.vitals&&_vitalsStr(p.vitals))vseq.push(p.vitals);});
     if(vseq.length){const vhtml=vseq.map(v=>`<div style="font-size:10px;color:#9bbdd4;line-height:1.6;"><span style="color:#4a7090;">${(v.at||'').slice(5,16)||'-'}</span> ${_vitalsStr(v)}</div>`).join('');rows.push(_row('활력',vhtml));}}
    const inj=_okA(r.injuryParts);if(inj.length)rows.push(_row('부상',inj.join(', ')));
    const rm=_okA(r.rescueMethod);if(rm.length)rows.push(_row('구조',rm.join(', ')));
    const mob=_okA(r.mobilize);if(mob.length)rows.push(_row('응소',mob.join(', ')));
    if(_ok(r.cause))rows.push(_row('원인',_esc(r.cause)));
    if(_ok(r.alcohol)&&r.alcohol!=='알수없음')rows.push(_row('음주',_esc(r.alcohol)+(_ok(r.alcAmount)?' · '+_esc(r.alcAmount):'')));
    if(_ok(r.situation))rows.push(_row('경위',_esc(r.situation)));
    if(_ok(r.hospital)&&r.hospital!=='미정')rows.push(_row('이송',_esc(r.hospital)));
    if(r.handover&&r.handover.to)rows.push(_row('인계',_esc(r.handover.to)+(r.handover.time?' · '+r.handover.time.slice(11):'')+(r.handover.by?' ('+_esc(r.handover.by)+')':'')));
    if(_ok(r.extra))rows.push(_row('특이',_esc(r.extra)));
    const updates=(r.reports||[]).map((p,i)=>({p,pn:i+2})).filter(({p})=>p.update||(p.victimChange&&p.victimChange!=='변화없음')||p.addMem||p.extra);
    const updHtml=updates.length?`<div style="margin-top:7px;padding-top:7px;border-top:.5px solid rgba(255,255,255,.08);"><div style="font-size:10px;color:#4a7090;font-weight:700;margin-bottom:3px;">추가 보고</div>${updates.map(({p,pn})=>{const pts=[];if(p.update)pts.push(_esc(p.update));if(p.victimChange&&p.victimChange!=='변화없음')pts.push('부상자 '+_esc(p.victimChange));if(p.addMem)pts.push('추가대원 '+_esc(p.addMem));if(p.extra)pts.push(_esc(p.extra));return `<div style="padding:5px 0;border-bottom:.5px solid rgba(255,255,255,.04);"><span style="font-size:10px;color:#4fa8d0;font-weight:700;">${pn}보</span> <span style="font-size:10px;color:#4a7090;font-weight:600;">${p.repTime||''} · ${_esc(p.author||'')}</span><br><span style="font-size:11px;color:#b8d4e8;line-height:1.5;">${pts.join(' / ')}</span></div>`;}).join('')}</div>`:'';
    const logHtml=_buildLogHtml(r);
    w.innerHTML=tabHdr+logHtml+`
      <div style="display:flex;gap:6px;margin-bottom:8px;">
        <button onclick="copyReportText(${r.id})" style="flex:1;padding:8px;border-radius:8px;border:1px solid rgba(79,168,208,.35);background:rgba(79,168,208,.1);color:#4fa8d0;font-size:11px;font-weight:700;cursor:pointer;">📋 보고서 복사</button>
        <button onclick="shareReportText(${r.id})" style="flex:1;padding:8px;border-radius:8px;border:1px solid rgba(39,174,96,.35);background:rgba(39,174,96,.1);color:#27ae60;font-size:11px;font-weight:700;cursor:pointer;">📤 공유</button>
        <button onclick="printReport(${r.id})" style="flex:1;padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.04);color:#b8d4e8;font-size:11px;font-weight:700;cursor:pointer;">🖨 인쇄/PDF</button>
      </div>
      <div style="background:#0b1c30;border-radius:10px;padding:12px;border:.5px solid rgba(255,255,255,.07);margin-bottom:8px;">
        <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:3px;">1보 · ${r.date||''}</div>
        ${rows.join('')||'<div style="font-size:11px;color:rgba(255,255,255,.25);">입력된 정보 없음</div>'}
        ${updHtml}
      </div>
      ${_scenePhotosHtml(r)}

      <div style="background:#0b1c30;border-radius:10px;padding:12px;border:.5px solid rgba(255,255,255,.07);margin-top:10px;">
        <div style="font-size:11px;color:#4fa8d0;font-weight:700;margin-bottom:8px;">💬 댓글</div>
        <div id="commentList_${r.id}">${renderComments(r.id)}</div>
        <div style="display:flex;gap:6px;margin-top:8px;">
          <input type="text" id="cmtInput_${r.id}" class="fi" placeholder="댓글 입력..." style="flex:1;">
          <button onclick="submitComment(${r.id})" style="background:#1a4a6e;color:#fff;border:none;padding:0 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;">등록</button>
        </div>
      </div>

      <div style="background:#0b1c30;border-radius:10px;padding:11px 12px;border:.5px solid rgba(79,168,208,.12);margin-top:8px;">
        <div style="font-size:11px;color:#4fa8d0;font-weight:700;margin-bottom:7px;">👥 출동 인원</div>
        ${(r.members&&r.members.length)?`<div style="font-size:11px;color:#b8d4e8;margin-bottom:4px;"><span style="color:#4a7090;font-weight:600;">초동팀:</span> ${_esc(r.members.join(', '))}</div>`:''}
        ${(r.teams&&r.teams.length)?r.teams.map(t=>{
          const ico=_teamIco(t);
          const si=_teamStageIdx(t);
          const stLbl=['출발','이동중','환자조우','하산'][si]||'';
          const mem=(t.members&&t.members.length)?': '+_esc(t.members.join(', ')):'';
          return `<div style="font-size:11px;color:#b8d4e8;margin-bottom:3px;"><span style="color:#7ec8a0;font-weight:600;">${ico} ${_esc(t.name)}</span>${mem} <span style="color:#7a9cb8;font-size:10px;">(${stLbl})</span></div>`;
        }).join(''):''}
        ${(!r.members||!r.members.length)&&(!r.teams||!r.teams.length)?'<div style="font-size:11px;color:rgba(255,255,255,.3);">미기재 — 타임라인에서 팀을 생성하면 자동 표시됩니다</div>':''}
        ${(r.extraTeams&&r.extraTeams.length)?r.extraTeams.map(t=>`<div style="font-size:11px;color:#b8d4e8;margin-bottom:3px;"><span style="color:#7ec8a0;font-weight:600;">${_esc(t.teamName)}:</span> ${_esc((t.members||[]).join(', '))}</div>`).join(''):''}
        ${(r.agencies)?(()=>{
          const ag=r.agencies;const parts=[];
          if(ag.hwandongha)parts.push(`🚒 ${(DB.g('extAgencyDisplayName')||'환동해 특수대응단').split(' ')[0]} ${ag.hwTeam||'?'}팀`);
          if(ag.fireAgencies&&ag.fireAgencies.length)ag.fireAgencies.forEach(a=>parts.push(`🚒 ${_esc(a.name)}`));
          if(ag.police)parts.push('🚔 경찰');
          if(ag.forestry)parts.push('🌲 산림청');
          if(ag.other)parts.push(_esc(ag.other));
          if(ag.agenciesNote)parts.push(`(${_esc(ag.agenciesNote)})`);
          return parts.length?`<div style="font-size:11px;color:#b8d4e8;margin-top:2px;"><span style="color:#4a7090;">유관기관:</span> ${parts.join(' · ')}</div>`:'';
        })():''}
      </div>
      ${_mobilizeBlockHtml('rescues',r)}`;
  }
  // sticky footer
  const _ftEl=document.getElementById(_isBoard?'boardDetailFooter':'rep1BoFooter');
  if(_ftEl){
    if(r.status==='ongoing'){
      _ftEl.style.display='block';
      if(mode==='write'&&!isExternal()){
        const _histBtn=all.length>1?`<button onclick="showPrevHistModal(${r.id})" style="display:block;width:100%;padding:6px 10px;border-radius:7px;border:.5px solid rgba(79,168,208,.25);background:rgba(79,168,208,.07);color:#4a8aaa;font-size:11px;font-weight:600;cursor:pointer;margin-bottom:6px;text-align:left;">📋 이전 이력 보기 (${all.length-1}건)</button>`:'';
        _ftEl.innerHTML=_histBtn+`<div style="display:flex;gap:7px;"><button class="btn-submit" style="flex:2;background:#1a4a6e;color:#fff;" onclick="selResId=${r.id};curResId=${r.id};addPhase();">📝 내용 추가</button><button class="btn-submit" style="flex:1;background:#0d5040;color:#fff;" onclick="selResId=${r.id};curResId=${r.id};endSit();">✅ 상황 종료</button></div>`
          +`<button onclick="openNpsResponse(${r.id})" style="margin-top:6px;width:100%;background:rgba(0,120,60,.18);color:#7ec8a0;border:1px solid rgba(0,120,60,.3);border-radius:9px;padding:9px;font-size:12px;font-weight:600;cursor:pointer;">🏕️ 공단 응소 기록</button>`;
      } else if(!isExternal()){
        _ftEl.innerHTML=`<button class="btn-submit" style="width:100%;background:#0d5040;color:#fff;" onclick="selResId=${r.id};curResId=${r.id};endSit();">✅ 상황 종료</button>`
          +`<button onclick="openNpsResponse(${r.id})" style="margin-top:6px;width:100%;background:rgba(0,120,60,.18);color:#7ec8a0;border:1px solid rgba(0,120,60,.3);border-radius:9px;padding:9px;font-size:12px;font-weight:600;cursor:pointer;">🏕️ 공단 응소 기록</button>`;
      }
    } else {
      _ftEl.style.display='block';
      _ftEl.innerHTML='<div style="text-align:center;font-size:12px;color:#27ae60;padding:8px;">✅ 상황 종료됨</div>';
    }
  }
}
function showPrevHistModal(id){
  const res=DB.g('rescues')||[];
  const r=res.find(x=>x.id===id);
  if(!r)return;
  const all=[r,...(r.reports||[])];
  if(all.length<=1){toast('이전 이력 없음');return;}
  let ov=document.getElementById('prevHistOv');
  if(!ov){ov=document.createElement('div');ov.id='prevHistOv';document.body.appendChild(ov);}
  ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;display:flex;align-items:flex-end;';
  const rows=all.slice(0,-1).reverse().map((p,ri)=>{
    const origIdx=all.length-2-ri;
    const label=origIdx===0?`1보 · ${r.date||'-'}`:`${origIdx+1}보 · ${p.repTime||'-'}`;
    const author=origIdx===0?r.author||'-':p.author||'-';
    const body=origIdx===0?[r.location,r.situation,r.extra].filter(Boolean).join(' · '):(p.update||'');
    return `<div style="padding:9px 14px;border-bottom:.5px solid rgba(255,255,255,.06);">
      <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:3px;">${label} · ${_esc(author)}</div>
      ${body?`<div style="font-size:11px;color:#b8d4e8;line-height:1.5;">${_esc(body)}</div>`:''}
    </div>`;
  }).join('');
  ov.innerHTML=`<div style="background:#040a16;border-radius:14px 14px 0 0;width:100%;max-height:70vh;max-height:70dvh;overflow:hidden;display:flex;flex-direction:column;border-top:.5px solid rgba(79,168,208,.25);">
    <div style="padding:14px 16px 10px;display:flex;align-items:center;justify-content:space-between;border-bottom:.5px solid rgba(255,255,255,.07);flex-shrink:0;">
      <span style="font-size:13px;font-weight:700;color:#e0edf8;">📋 이전 이력 (${all.length-1}건)</span>
      <button onclick="document.getElementById('prevHistOv').style.display='none'" style="background:none;border:none;color:rgba(255,255,255,.5);font-size:20px;cursor:pointer;padding:0 4px;line-height:1;">×</button>
    </div>
    <div style="overflow-y:auto;flex:1;">${rows}</div>
  </div>`;
  ov.onclick=e=>{if(e.target===ov)ov.style.display='none';};
}
function getRes(id){return (DB.g('rescues')||[]).find(r=>r.id===id)||{};}

// ── 현장 사진 갤러리: 구조 건에 사진 여러 장 추가/열람 ──
function _scenePhotosHtml(r){
  const pics=[];
  if(r.injuryPhoto)pics.push({url:r.injuryPhoto,label:'부상'});
  if(r.transPhoto)pics.push({url:r.transPhoto,label:'이송'});
  (r.photos||[]).forEach(p=>pics.push({url:p.url,label:(p.time||'').slice(11,16)}));
  return `<div style="background:#0b1c30;border-radius:10px;padding:11px 12px;border:.5px solid rgba(255,255,255,.07);margin-top:8px;">
    <div style="font-size:11px;color:#4fa8d0;font-weight:700;margin-bottom:7px;">📷 현장 사진 <span style="color:rgba(255,255,255,.3);font-weight:400;">${pics.length}장</span></div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;">
      ${pics.map(p=>`<div onclick="openLightbox('${p.url}')" style="aspect-ratio:1;border-radius:8px;overflow:hidden;cursor:pointer;position:relative;background:#060d1a;">
        <img src="${p.url}" style="width:100%;height:100%;object-fit:cover;" loading="lazy">
        ${p.label?`<span style="position:absolute;bottom:2px;left:4px;font-size:8px;color:#fff;text-shadow:0 1px 2px #000;">${p.label}</span>`:''}
      </div>`).join('')}
      <div onclick="addScenePhotos(${r.id})" style="aspect-ratio:1;border-radius:8px;border:1.5px dashed rgba(79,168,208,.35);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;color:#4fa8d0;gap:2px;">
        <span style="font-size:17px;line-height:1;">＋</span><span style="font-size:8px;">사진 추가</span>
      </div>
    </div>
  </div>`;
}
function addScenePhotos(resId){
  const inp=document.createElement('input');
  inp.type='file';inp.accept='image/*';inp.multiple=true;
  inp.onchange=async()=>{
    const files=[...(inp.files||[])];
    if(!files.length)return;
    const u0=DB.g('currentUser')||{};
    if(!navigator.onLine){
      for(const f of files){
        const c=await _compressImage(f);
        const qItem={id:Date.now()+'_sc'+Math.random().toString(36).slice(2,6),file:c,pid:'',dest:{key:'rescues',id:resId,field:'photos',append:true,by:u0.name||''}};
        _offlinePhotoQueue.push(qItem);_photoQPut(qItem);
      }
      toast('📵 오프라인 — 사진 '+files.length+'장 대기, 연결되면 자동 업로드');
      return;
    }
    toast('⬆️ 사진 '+files.length+'장 업로드 중...');
    const u=DB.g('currentUser')||{};
    let ok=0;
    for(const f of files){
      try{
        const c=await _compressImage(f);
        const url=await uploadImageToStorage(c,'photos/scene_'+resId);
        const res=DB.g('rescues')||[];const ri=res.findIndex(x=>x.id===resId);
        if(ri<0)break;
        if(!res[ri].photos)res[ri].photos=[];
        res[ri].photos.push({url,time:now(),by:u.name||''});
        DB.s('rescues',res);ok++;
      }catch(e){}
    }
    toast(ok?('✅ 사진 '+ok+'장 추가'):'⚠️ 업로드 실패');
    try{const r=getRes(resId);if(r&&r.id)renderTimeline(r,_tlViewMode==='write'?'write':'advanced');}catch(e){}
  };
  inp.click();
}
function openLightbox(url){
  let lb=document.getElementById('photoLightbox');
  if(!lb){
    lb=document.createElement('div');lb.id='photoLightbox';
    lb.style.cssText='position:fixed;inset:0;z-index:99;background:rgba(0,0,0,.93);display:flex;align-items:center;justify-content:center;padding:18px;';
    lb.onclick=()=>{lb.style.display='none';};
    lb.innerHTML='<img id="lightboxImg" style="max-width:100%;max-height:100%;border-radius:10px;object-fit:contain;">';
    document.body.appendChild(lb);
  }
  document.getElementById('lightboxImg').src=url;
  lb.style.display='flex';
}
function submitComment(resId,variant){
  const prefix=variant==='adv'?'cmtInput_adv_':'cmtInput_';
  const inp=document.getElementById(prefix+resId);if(!inp)return;
  const text=inp.value.trim();if(!text){toast('⚠️ 댓글을 입력하세요');return;}
  inp.value=''; // 즉시 비워 이중 탭 중복 등록 방지
  const res=DB.g('rescues')||[];const ri=res.findIndex(x=>x.id===resId);
  if(ri<0){toast('⚠️ 구조 정보 없음');return;}
  if(!res[ri].comments)res[ri].comments=[];
  // 구버전(이 기기에만 저장된) 댓글을 레코드로 1회 이관
  (DB.g('comments_'+resId)||[]).forEach(c=>{
    if(!res[ri].comments.some(x=>x.id===c.id))res[ri].comments.push(c);
  });
  try{localStorage.removeItem('v7_comments_'+resId);}catch(e){}
  const u=DB.g('currentUser')||{};
  res[ri].comments.push({id:Date.now()+Math.random(),author:u.name||'익명',time:now(),text});
  res[ri].comments.sort((a,b)=>(a.id||0)-(b.id||0));
  DB.s('rescues',res);
  const cmts=res[ri].comments;
  inp.value='';
  const cmtHtml=cmts.map(cm=>`<div style="background:#060d1a;border-radius:7px;padding:8px 10px;margin-bottom:5px;"><div style="font-size:11px;color:#4fa8d0;font-weight:600;">${_esc(cm.author)} · ${cm.time}</div><div style="font-size:12px;color:#b8d4e8;margin-top:3px;line-height:1.5;">${_esc(cm.text)}</div></div>`).join('');
  // 댓글 목록 갱신 (두 위치 모두)
  const listEl=document.getElementById('commentList_'+resId);if(listEl)listEl.innerHTML=cmtHtml;
  const listElAdv=document.getElementById('commentList_adv_'+resId);if(listElAdv)listElAdv.innerHTML=cmtHtml;
  toast('💬 댓글 등록');
  pushNoti(`💬 댓글: ${text.slice(0,20)}...`,'💬','rescue_update',{app:'rescue',tab:2,id:resId});
}

// ══ AI 출동지령서 스캔 (Gemini) ══
async function aiScanDispatch(input){
  const file=input.files&&input.files[0];
  if(!file)return;
  const apiKey=(DB.g('geminiApiKey')||'').trim();
  const spinner=document.getElementById('aiScanSpinner');
  const statusEl=document.getElementById('aiScanStatus');
  if(!apiKey){
    if(statusEl){statusEl.style.display='block';statusEl.textContent='⚠️ Gemini API 키가 설정되지 않았습니다. 관리자 > 시스템에서 입력하세요.';}
    input.value='';return;
  }
  // base64 변환
  const b64=await new Promise(res=>{
    const r=new FileReader();
    r.onload=e=>res(String(e.target.result||'').split(',')[1]||'');
    r.onerror=()=>res('');
    r.readAsDataURL(file);
  });
  if(!b64){if(statusEl){statusEl.style.display='block';statusEl.textContent='⚠️ 이미지를 읽지 못했습니다. 다른 사진으로 시도하세요.';}input.value='';return;}
  if(spinner)spinner.style.display='block';
  if(statusEl){statusEl.style.display='block';statusEl.textContent='🤖 AI가 출동지령서를 분석중입니다...';}
  const prompt=`이 출동지령서(산악구조 신고/출동 문서) 이미지에서 아래 항목을 추출하여 반드시 JSON 형식으로만 응답하세요. 코드블록 없이 JSON만 출력하세요. 없는 항목은 null로 표시하세요.
{
  "date": "사고 발생 또는 신고 접수 일시 (YYYY-MM-DDTHH:MM 형식, 연도 없으면 올해 기준)",
  "dispatch": "신고 접수 시각 (HH:MM)",
  "arrival": "공단 출동 또는 현장 도착 시각 (HH:MM)",
  "location": "사고 발생 장소 (표지판 번호 포함, 예: 12-03 부근)",
  "loctype": "장소 구분 — 법정탐방로/비법정탐방로/암벽/빙벽 중 하나만",
  "type": "사고 유형 — 실족추락/심장마비/탈진/길잃음/뇌졸중/기타 중 가장 가까운 것",
  "vName": "사고자(피해자) 이름",
  "vBirth": "사고자 생년월일 (YYYY-MM-DD, 나이만 있으면 추정 생년 계산)",
  "vGender": "성별 (남/여/알수없음)",
  "vTel": "사고자 또는 신고자 연락처",
  "severity": "중증도 (경증/중증/중경증/사망/알수없음)",
  "situation": "사고 경위 및 상황 요약 (2-3문장)",
  "reception": "최초 신고 내용 요약",
  "weather": "기상 정보 (있으면)"
}`;
  try{
    const resp=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`,{
      method:'POST',
      headers:{'content-type':'application/json'},
      body:JSON.stringify({
        contents:[{parts:[
          {inline_data:{mime_type:file.type,data:b64}},
          {text:prompt}
        ]}],
        generationConfig:{responseMimeType:'application/json'}
      })
    });
    if(!resp.ok){const err=await resp.json().catch(()=>({}));throw new Error(err.error?.message||resp.status);}
    const data=await resp.json();
    const raw=(data.candidates?.[0]?.content?.parts?.[0]?.text)||'';
    let parsed;
    try{parsed=JSON.parse(raw.replace(/```json|```/g,'').trim());}
    catch(e){throw new Error('JSON 파싱 실패: '+raw.slice(0,80));}
    _applyAiScanResult(parsed);
    const filled=Object.values(parsed).filter(v=>v!==null).length;
    if(statusEl)statusEl.textContent=`✅ ${filled}개 항목 자동 입력 완료 — 확인 후 저장하세요`;
  }catch(e){
    if(statusEl)statusEl.textContent='❌ 오류: '+e.message;
    toast('❌ AI 스캔 실패: '+e.message);
  }finally{
    if(spinner)spinner.style.display='none';
    input.value='';
  }
}
function _applyAiScanResult(d){
  const _set=(id,v)=>{if(v===null||v===undefined)return;const el=document.getElementById(id);if(el){el.value=v;el.dispatchEvent(new Event('input'));}};
  if(d.date)_set('r_date',d.date.slice(0,16));
  if(d.dispatch)_set('r_disp',d.dispatch);
  if(d.arrival)_set('r_arrival',d.arrival);
  if(d.location){_set('r_loc',d.location);}
  if(d.loctype&&['법정탐방로','비법정탐방로','암벽','빙벽'].includes(d.loctype)){
    selLoctype(d.loctype);
    const hi=document.getElementById('r_loctype');if(hi)hi.value=d.loctype;
  }
  if(d.type){
    const tEl=document.getElementById('r_type');if(tEl)tEl.value=d.type;
  }
  if(d.vName)_set('r_vName',d.vName);
  if(d.vBirth)_set('r_vBirth',d.vBirth);
  if(d.vGender&&d.vGender!=='알수없음'){
    document.querySelectorAll('#genderPills .pill').forEach(p=>{if(p.textContent.trim()===d.vGender)p.click();});
  }
  if(d.vTel)_set('r_vTel',d.vTel);
  if(d.severity){
    const sEl=document.getElementById('r_severity');if(sEl)sEl.value=d.severity;
  }
  if(d.situation)_set('r_situation',d.situation);
  if(d.reception)_set('r_reception',d.reception);
  if(d.weather)_set('r_weather',d.weather);
  try{autoGenTitle();}catch(e){}
  toast('📋 출동지령서 자동 입력됨');
}
function openNpsResponse(resId){
  var txt=prompt('공단 응소 내용을 입력하세요:','공단에서 응소를 실시하고 있어요');
  if(txt===null)return;
  txt=(txt||'').trim();
  if(!txt){toast('⚠️ 내용을 입력하세요');return;}
  submitNpsResponse(resId,txt);
}
function submitNpsResponse(resId,text){
  const res=DB.g('rescues')||[];
  const idx=res.findIndex(x=>x.id===resId);
  if(idx===-1){toast('⚠️ 사고 정보 없음');return;}
  if(!res[idx].npsLog)res[idx].npsLog=[];
  const author=getAuthor();
  res[idx].npsLog.push({time:new Date().toISOString(),author,text});
  DB.s('rescues',res);
  toast('🏕️ 공단 응소 기록됨');
  if(document.getElementById('v-report').classList.contains('on')){
    renderTimeline(res[idx],_tlViewMode||'brief');
  }
  if(_boardDetailId===resId){
    const bd=document.getElementById('boardDetail');
    if(bd&&bd.style.display!=='none')renderTimeline(res[idx],_tlViewMode||'advanced','boardDetailContent');
  }
}
// ── 구조 보고서 텍스트/공유/인쇄 ────────────────────
// 활력징후 스테퍼: 빈값이면 예시값으로 시작, 이후 ±step (음수 금지, max 제한)
function _vitStep(id,delta,example,step,max){
  const el=document.getElementById(id);if(!el)return;
  let v=parseFloat(el.value);
  if(isNaN(v))v=example;          // 첫 조작 → 예시값을 첫값으로
  else v=v+delta*step;
  if(v<0)v=0;
  if(max!=null&&v>max)v=max;
  el.value=step<1?(Math.round(v*10)/10).toFixed(1):String(Math.round(v));
}
// 직접 입력 시 음수·초과 방지
function _vitClamp(el,max){
  if(el.value===''||el.value==='-')return;
  let v=parseFloat(el.value);
  if(isNaN(v))return;
  if(v<0)el.value='0';
  else if(max!=null&&v>max)el.value=String(max);
}
// Enter(모바일 '다음') → 다음 활력징후 입력으로 포커스 이동
function _vitNext(e){
  if(e.key!=='Enter')return;
  e.preventDefault();
  const inputs=[...document.querySelectorAll('.vit-input')];
  const i=inputs.indexOf(e.target);
  if(i>=0&&i<inputs.length-1)inputs[i+1].focus();
  else e.target.blur();
}
// 음주 의심·확인됨 → 음주량 입력란 표시
function _toggleAlcAmount(){
  const a=document.getElementById('r_alc')?.value;
  const w=document.getElementById('alcAmountWrap');
  if(w)w.style.display=(a&&a!=='없음')?'block':'none';
}
// 활력징후 수집 — 하나라도 입력됐을 때만 객체 반환(측정시각 포함)
function _collectVitals(){
  const g=id=>{const e=document.getElementById(id);return e?e.value.trim():'';};
  const hr=g('r_hr'),spo2=g('r_spo2'),temp=g('r_temp'),avpu=g('r_avpu'),bp=g('r_bp');
  if(!hr&&!spo2&&!temp&&(!avpu||avpu==='선택')&&!bp)return null;
  return {hr,spo2,temp,avpu:avpu==='선택'?'':avpu,bp,at:now()};
}
function _vitalsStr(v){
  if(!v)return '';
  const p=[];
  if(v.hr)p.push('HR '+v.hr);
  if(v.bp)p.push('BP '+v.bp);
  if(v.spo2)p.push('SpO₂ '+v.spo2+'%');
  if(v.temp)p.push(v.temp+'℃');
  if(v.avpu)p.push(v.avpu);
  return p.join(' · ');
}
function _buildReportText(r){
  if(!r)return '';
  const _ok=v=>{if(!v&&v!==0)return false;const s=String(v).trim();return s&&s!=='-'&&!['미상','없음','모르겠음','알수없음','미정','해당없음'].includes(s);};
  const _okA=v=>(Array.isArray(v)?v:[]).filter(x=>_ok(x));
  const L=[];
  L.push('[ 설악산 구조 보고서 ]');
  L.push('제목: '+(r.title||'-'));
  L.push('유형: '+(r.type||'-')+' / '+(r.status==='ongoing'?'진행중':'종료'));
  if(_ok(r.date))L.push('일시: '+r.date);
  if(_ok(r.location))L.push('위치: '+r.location+(_ok(r.loctype)?' ('+r.loctype+')':''));
  if(_ok(r.lat)&&_ok(r.lng))L.push('좌표: '+(+r.lat).toFixed(5)+', '+(+r.lng).toFixed(5));
  const wx=[_ok(r.weather)?r.weather:'',_ok(r.weatherAlert)?r.weatherAlert:''].filter(Boolean).join(' ');
  if(wx)L.push('기상: '+wx);
  const vp=[_ok(r.vName)?r.vName:'',_ok(r.vBirth)?_ageFromBirth(r.vBirth)+'세':(_ok(r.vAge)?r.vAge+'세':''),_ok(r.vGender)&&r.vGender!=='알수없음'?r.vGender:'',_ok(r.vNation)&&r.vNation!=='알수없음'?r.vNation:''].filter(Boolean);
  if(vp.length)L.push('사고자: '+vp.join(' · ')+((r.victims2&&r.victims2.length)?' 외 '+r.victims2.length+'명':''));
  if(r.victims2&&r.victims2.length){r.victims2.forEach((v,i)=>L.push('  추가자'+(i+1)+': '+[v.name||'미상',v.gender&&v.gender!=='알수없음'?v.gender:'',v.age?v.age+'세':'',v.severity,v.note].filter(Boolean).join(' · ')));}
  if(_ok(r.vTel))L.push('연락처: '+r.vTel);
  if(_ok(r.severity))L.push('중증도: '+r.severity);
  {const vseq=[];if(r.vitals&&_vitalsStr(r.vitals))vseq.push(r.vitals);(r.reports||[]).forEach(p=>{if(p.vitals&&_vitalsStr(p.vitals))vseq.push(p.vitals);});
   if(vseq.length){L.push('활력징후:');vseq.forEach(v=>L.push('  · '+((v.at||'').slice(11)||'-')+' '+_vitalsStr(v)));}}
  const inj=_okA(r.injuryParts);if(inj.length)L.push('부상부위: '+inj.join(', '));
  if(_ok(r.cause))L.push('원인: '+r.cause);
  const rm=_okA(r.rescueMethod);if(rm.length)L.push('구조방법: '+rm.join(', '));
  const mob=_okA(r.mobilize);if(mob.length)L.push('응소: '+mob.join(', '));
  if(_ok(r.alcohol)&&r.alcohol!=='알수없음')L.push('음주: '+r.alcohol+(_ok(r.alcAmount)?' ('+r.alcAmount+')':''));
  if(_ok(r.situation))L.push('사고경위: '+r.situation);
  if(_ok(r.hospital)&&r.hospital!=='미정')L.push('이송: '+r.hospital);
  if(r.handover&&r.handover.to)L.push('인계: '+r.handover.to+(r.handover.time?' ('+r.handover.time+')':''));
  // 출동 인원
  const teamParts=[];
  if(r.members&&r.members.length)teamParts.push('초동팀 '+r.members.join(', '));
  (r.teams||[]).forEach(t=>{
    const _ops=[];
    if(t.transportMethod)_ops.push(t.transportMethod);
    teamParts.push(t.name+(t.members&&t.members.length?' ('+t.members.join(', ')+')':'')+(t.memberCount?' '+t.memberCount+'명':'')+(_ops.length?' ['+_ops.join(', ')+']':''));
  });
  (r.extraTeams||[]).forEach(t=>{teamParts.push(t.teamName+(t.members&&t.members.length?' ('+t.members.join(', ')+')':''));});
  if(teamParts.length)L.push('출동인원: '+teamParts.join(' / '));
  // 통합 타임라인 (타임테이블 + 위치통과 + 팀 출동/도착/탑승/이송전환 + CPR 상세)
  const baseDate=(r.date||'').slice(0,10);
  const _tKey=t=>{const s=String(t||'').trim();if(/^\d{4}-\d{2}-\d{2}/.test(s))return s;return baseDate+' '+s;};
  const _hm=t=>{const s=String(t||'').trim();return s.length>5?s.slice(11,16):s;};
  const tlAll=[];
  (r.timetable||[]).forEach(e=>{
    if(!e.time&&!e.stage)return;
    let extra='';
    if(e.stage==='심정지'){
      if(e.cprStart)extra+=' / CPR '+_hm(e.cprStart);
      if(e.cprEnd)extra+='→'+_hm(e.cprEnd);
      if(e.aed)extra+=' · AED '+e.aed;
    }
    tlAll.push({k:_tKey(e.time),disp:(_hm(e.time)||'시간미상')+' '+(e.stage||'')+(e.note?' — '+e.note:'')+extra});
  });
  (r.wpLog||[]).forEach(l=>tlAll.push({k:_tKey(l.time),disp:(l.time||'')+' '+(l.code||'?')+' 통과'+(l.teamName?' ('+l.teamName+')':'')}));
  (r.teams||[]).forEach(t=>{
    if(t.requestedAt||t.createdAt)tlAll.push({k:_tKey(t.requestedAt||t.createdAt),disp:_hm(t.requestedAt||t.createdAt)+' '+t.name+' 출동'+(t.members&&t.members.length?' ('+t.members.join(', ')+')':'')});
    if(t.arrivedAt)tlAll.push({k:_tKey(t.arrivedAt),disp:_hm(t.arrivedAt)+' '+t.name+' 현장도착'});
    if(t.boardedAt)tlAll.push({k:_tKey(t.boardedAt),disp:_hm(t.boardedAt)+' '+t.name+' 환자 탑승'});
    (t.transportLog||[]).forEach(tr=>tlAll.push({k:_tKey(tr.at),disp:_hm(tr.at)+' '+t.name+' 이송전환 '+tr.from+'→'+tr.to}));
  });
  if(r.handover&&r.handover.to)tlAll.push({k:_tKey(r.handover.time),disp:_hm(r.handover.time)+' 환자 인계 → '+r.handover.to+(r.handover.by?' ('+r.handover.by+')':'')});
  if(tlAll.length){
    L.push('');L.push('[ 타임라인 ]');
    tlAll.sort((a,b)=>String(a.k).localeCompare(String(b.k)));
    tlAll.forEach(e=>L.push('· '+e.disp));
  }
  // 추가 보고
  const ups=(r.reports||[]).filter(p=>p.update||p.extra);
  if(ups.length){
    L.push('');L.push('[ 추가 보고 ]');
    ups.forEach((p,i)=>{L.push('· '+(i+1)+'보 '+(p.repTime||'')+' '+(p.author?'('+p.author+')':'')+': '+(p.update||p.extra||''));});
  }
  if(_ok(r.extra))L.push('특이사항: '+r.extra);
  L.push('');L.push('작성자: '+(r.author||'-'));
  return L.join('\n');
}
function copyReportText(id){
  const r=getRes(id);const txt=_buildReportText(r);
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(txt).then(()=>toast('📋 보고서가 복사되었습니다')).catch(()=>_fallbackCopy(txt));
  }else _fallbackCopy(txt);
}
function _fallbackCopy(txt){
  try{const ta=document.createElement('textarea');ta.value=txt;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);toast('📋 보고서가 복사되었습니다');}
  catch(e){toast('⚠️ 복사 실패 — 길게 눌러 복사하세요');}
}
function shareReportText(id){
  const r=getRes(id);const txt=_buildReportText(r);
  if(navigator.share){
    navigator.share({title:r.title||'구조 보고서',text:txt}).catch(()=>{});
  }else{copyReportText(id);toast('📋 공유 미지원 — 복사로 대체했습니다');}
}
function printReport(id){
  const r=getRes(id);const txt=_buildReportText(r);
  const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const win=window.open('','_blank');
  if(!win){toast('⚠️ 팝업 차단 — 인쇄 창을 열 수 없습니다');return;}
  win.document.write('<html><head><title>'+esc(r.title||'구조 보고서')+'</title>'
    +'<meta name="viewport" content="width=device-width,initial-scale=1">'
    +'<style>body{font-family:-apple-system,"Malgun Gothic",sans-serif;padding:24px;color:#111;line-height:1.7;font-size:13px;}'
    +'h1{font-size:18px;border-bottom:2px solid #333;padding-bottom:8px;}pre{white-space:pre-wrap;word-break:break-word;font-family:inherit;}'
    +'@media print{button{display:none;}}</style></head><body>'
    +'<h1>🏔️ 설악산 구조 보고서</h1><pre>'+esc(txt)+'</pre>'
    +'<button onclick="window.print()" style="margin-top:16px;padding:10px 18px;font-size:14px;cursor:pointer;">🖨 인쇄 / PDF 저장</button>'
    +'</body></html>');
  win.document.close();
  setTimeout(()=>{try{win.focus();}catch(e){}},300);
}
function endSit(){
  const res=DB.g('rescues')||[];const idx=res.findIndex(x=>x.id===selResId);if(idx===-1)return;
  if(!confirm('상황을 종료 처리하겠습니까?'))return;
  res[idx].status='done';DB.s('rescues',res);
  pushNoti(`✅ 종료: ${res[idx].title}`,'✅','rescue_close',{app:'rescue',tab:2,id:res[idx].id});
  try{renderRescueMap();}catch(e){}closeDB();toast('✅ 상황 종료');updateSummary();
  // 타임라인 뷰에 있으면 갱신
  if(document.getElementById('v-report').classList.contains('on')){
    renderTimeline(res[idx],_tlViewMode||'brief');
  }
  // 상황판 상세 패널이 열려 있으면 갱신
  if(_boardDetailId===res[idx].id){
    const bd=document.getElementById('boardDetail');
    if(bd&&bd.style.display!=='none')renderTimeline(res[idx],_tlViewMode||'advanced','boardDetailContent');
  }
}

function submitNBo(){
  const res=DB.g('rescues')||[];const idx=res.findIndex(x=>x.id===curResId);if(idx===-1)return;
  if(!res[idx].reports)res[idx].reports=[];
  res[idx].reports.push({
    repTime:document.getElementById('r_repdt').value.replace('T',' '),
    update:document.getElementById('r_upd').value,
    victimChange:document.getElementById('r_vChg').value,
    addMem:document.getElementById('r_addMem').value,
    author:document.getElementById('r_repAuthor').value,
    extra:document.getElementById('r_repExtra')?.value||'',
  });
  DB.s('rescues',res);
  const phNum=res[idx].reports.length;
  renderPhaseBar(phNum,phNum+1);
  pushNoti(`📋 추가 보고: ${res[idx].title}`,'📋','rescue_update',{app:'rescue',tab:2,id:res[idx].id});
  closeM('modalAddPhase');toast('✅ 추가 보고 저장');
  // 타임라인 갱신
  renderTimeline(res[idx]);
}

// ══════════════════════════════════════════
// 1보 폼
// ══════════════════════════════════════════
// ── 구조 1보 폼: 자동 임시저장 + 작성중 이탈 경고 ──
window._reportMode='';        // 'form'(작성) | 'timeline'(타임라인 보기)
let _formDirty=false,_draftAutoTimer=null,_draftListenerBound=false;
const _DRAFT_KEY='_rescueDraft1bo';
function _snapshotRescueForm(){
  const w=document.getElementById('repContent');if(!w)return null;
  const fields={};
  w.querySelectorAll('input,textarea,select').forEach(el=>{
    if(!el.id||el.type==='file')return;
    if(el.type==='checkbox'||el.type==='radio')fields[el.id]={c:el.checked};
    else if(el.value!=='')fields[el.id]={v:el.value};
  });
  const pills=[];
  w.querySelectorAll('.pills').forEach(pc=>{
    if(!pc.id)return;
    pc.querySelectorAll('.pill.on').forEach(p=>pills.push(pc.id+'::'+p.textContent.trim()));
  });
  return {fields,pills,at:Date.now()};
}
function _restoreRescueForm(snap){
  if(!snap)return;
  const w=document.getElementById('repContent');if(!w)return;
  try{
    Object.entries(snap.fields||{}).forEach(([id,o])=>{
      const el=document.getElementById(id);if(!el)return;
      if(o.c!==undefined)el.checked=o.c;else if(o.v!==undefined){el.value=o.v;try{el.dispatchEvent(new Event('change',{bubbles:true}));}catch(e){}}
    });
    (snap.pills||[]).forEach(key=>{
      const i=key.indexOf('::');if(i<0)return;
      const pid=key.slice(0,i),txt=key.slice(i+2);
      const pc=document.getElementById(pid);if(!pc)return;
      pc.querySelectorAll('.pill').forEach(p=>{if(p.textContent.trim()===txt)p.classList.add('on');});
    });
  }catch(e){}
}
function _saveDraftNow(){
  if(window._reportMode!=='form'||!_formDirty||window._reportIsNbo)return;
  try{const s=_snapshotRescueForm();if(s)localStorage.setItem(_DRAFT_KEY,JSON.stringify(s));}catch(e){}
}
function _clearRescueDraft(){try{localStorage.removeItem(_DRAFT_KEY);}catch(e){}_formDirty=false;}
function _startDraftAutosave(){
  clearInterval(_draftAutoTimer);
  _draftAutoTimer=setInterval(()=>{
    if(window._reportMode!=='form'){clearInterval(_draftAutoTimer);return;}
    _saveDraftNow();
  },30000); // 30초마다 임시저장
}
function _maybeOfferDraftRestore(){
  let snap=null;try{snap=JSON.parse(localStorage.getItem(_DRAFT_KEY)||'null');}catch(e){}
  if(!snap||!snap.at)return;
  if(Date.now()-snap.at>24*3600000){_clearRescueDraft();return;} // 24시간 지난 초안은 폐기
  const mins=Math.max(1,Math.round((Date.now()-snap.at)/60000));
  if(confirm('작성하다 중단한 임시저장 내용이 있습니다 ('+mins+'분 전).\n불러올까요?')){
    _restoreRescueForm(snap);toast('📄 임시저장 내용 불러옴');
  }else{_clearRescueDraft();}
}
function render1BoForm(prefill=null){
  const ms=getTeamMembers();
  const hdTeam=getHwandonghaTeam();
  const isNbo=prefill!==null&&!!prefill._phaseNum;
  const p=prefill||{};
  const w=document.getElementById('repContent');

  const tabs=[
    {id:'repSec1', icon:'📍', label:'위치·기상'},
    {id:'repSec2', icon:'🤕', label:'환자·부상'},
    {id:'repSec3', icon:'🧑', label:'인적사항'},
    {id:'repSec5', icon:'📝', label:'기타'},
  ];

  const _offHrs=_isOffHours();
  const _mobilizeHtml=(!isNbo)?`<div id="mobilizeWrap" style="background:${_offHrs?'rgba(231,76,60,.1)':'rgba(79,168,208,.06)'};border-bottom:1px solid ${_offHrs?'rgba(231,76,60,.3)':'rgba(79,168,208,.18)'};padding:10px 13px;flex-shrink:0;">
      <div style="font-size:11px;color:${_offHrs?'#e74c3c':'#4fa8d0'};font-weight:700;margin-bottom:6px;">${_offHrs?'🌙 야간 출동(18~09시) — 응소 여부 선택 (확인 필요)':'🚨 응소 여부 선택 (해당 시 선택)'}</div>
      <div class="pills" id="mobilizePills">
        ${['특구대','재난과','전직원응소'].map(o=>`<div class="pill${(p.mobilize||[]).includes(o)?' on':''}" onclick="tPill(this)">${o}</div>`).join('')}
      </div>
    </div>`:'';

  w.innerHTML=`
    ${isNbo?`<div id="nboBanner" style="background:rgba(79,168,208,.1);border:1px solid rgba(79,168,208,.25);border-radius:0;padding:9px 13px;font-size:11px;color:#4fa8d0;display:flex;align-items:center;justify-content:space-between;">
      <span>📋 <b>${p._phaseNum||2}보 작성중</b> — 변경사항만 수정</span>
      <button onclick="history.back()" style="background:rgba(255,255,255,.07);color:#c0d8ec;border:none;padding:5px 10px;border-radius:6px;font-size:11px;cursor:pointer;">✕</button>
    </div>`:''}

    ${_mobilizeHtml}

    <!-- AI 출동지령서 스캔 버튼 -->
    <div style="padding:9px 12px;background:#06101e;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;">
      <label style="display:flex;align-items:center;gap:9px;background:rgba(139,92,246,.1);border:1px solid rgba(139,92,246,.3);border-radius:10px;padding:10px 13px;cursor:pointer;touch-action:manipulation;">
        <span style="font-size:18px;">📷</span>
        <div style="flex:1;">
          <div style="font-size:12px;font-weight:700;color:#c4b5fd;">AI 출동지령서 스캔</div>
          <div style="font-size:10px;color:#7a6a9a;margin-top:1px;">사진 촬영 또는 선택 → 자동 입력</div>
        </div>
        <div id="aiScanSpinner" style="display:none;width:18px;height:18px;border:2px solid rgba(139,92,246,.3);border-top-color:#c4b5fd;border-radius:50%;animation:spin .8s linear infinite;flex-shrink:0;"></div>
        <input type="file" accept="image/*" style="display:none;" onchange="aiScanDispatch(this)">
      </label>
      <div id="aiScanStatus" style="display:none;font-size:10px;color:#7a9cb8;margin-top:6px;padding:0 4px;line-height:1.6;"></div>
    </div>

    <div style="display:flex;background:#040a16;border-bottom:1px solid rgba(255,255,255,.06);overflow-x:auto;scrollbar-width:none;flex-shrink:0;">
      ${tabs.map((t,i)=>`<div class="rep-tab${i===0?' rep-tab-on':''}" onclick="switchRepTab('${t.id}',this)"
        style="flex:1;min-width:52px;padding:8px 3px;text-align:center;font-size:10px;cursor:pointer;
        border-bottom:2px solid ${i===0?'#4fa8d0':'transparent'};
        color:${i===0?'#4fa8d0':'rgba(255,255,255,.3)'};white-space:nowrap;">
        ${t.icon}<br>${t.label}</div>`).join('')}
    </div>

    <!-- ══ 섹터0: 고도화 타임라인 ══ -->
    <div id="repSec0" class="rep-sec" style="display:none;padding:12px;overflow-y:auto;">
      <div id="formTlWrap">
        <div style="text-align:center;padding:30px 12px;font-size:12px;color:rgba(255,255,255,.3);line-height:1.8;">위치·기상 탭에서 사고 위치를 입력하면<br>경로 시뮬레이션이 표시됩니다</div>
      </div>
    </div>

    <!-- ══ 섹터1: 위치·기상 ══ -->
    <div id="repSec1" class="rep-sec" style="padding:12px;overflow-y:auto;">
      <div class="rsec"><div class="rsec-t">🚨 사고 유형</div>
        <div class="fg"><span class="fl">사고 유형</span>
          <select id="r_type" class="fsel" onchange="autoGenTitle()">
            ${['안전사고','조난','고립','실종','낙석','위험수목','화재','기타'].map(o=>`<option${p.type===o?' selected':''}>${o}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="rsec"><div class="rsec-t">📍 사고 위치</div>
        <div class="fg">
          <span class="fl">GPS 좌표</span>
          <div style="background:#060d1a;border-radius:9px;border:1px solid rgba(79,168,208,.2);padding:10px 12px;margin-bottom:6px;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
              <div id="r_minimap_coords" style="flex:1;font-family:monospace;font-size:11px;color:#4fa8d0;font-weight:600;">${p.lat&&p.lng?(+p.lat).toFixed(5)+', '+(+p.lng).toFixed(5):'📡 수신 중...'}</div>
              <button id="gpsFormBtn" onclick="gpsToFormMap()" style="background:rgba(79,168,208,.12);border:1px solid rgba(79,168,208,.35);color:#4fa8d0;border-radius:7px;padding:5px 11px;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;flex-shrink:0;">📡 GPS</button>
              <button onclick="openMapPicker()" style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.5);border-radius:7px;padding:5px 11px;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;flex-shrink:0;">🗺 지도</button>
            </div>
            <div id="r_gps_status" style="font-size:10px;color:rgba(255,255,255,.3);line-height:1.4;">${p.lat&&p.lng?'✅ 위치 확인':'GPS 버튼을 눌러 현재 위치를 자동으로 받거나, 🗺 지도에서 직접 선택하세요'}</div>
          </div>
          <!-- 위치 미니맵 -->
          <div id="r_loc_mini_map" style="display:${p.lat&&p.lng?'block':'none'};height:180px;border-radius:10px;overflow:hidden;margin-bottom:8px;border:1px solid rgba(79,168,208,.2);"></div>
          <div class="gps-row">
            <input type="text" id="r_gps" class="fi" placeholder="위도, 경도 직접 입력" value="${p.lat&&p.lng?(+p.lat).toFixed(5)+', '+(+p.lng).toFixed(5):''}" oninput="syncFormMapFromInput()">
          </div>
        </div>
        <div class="fg"><span class="fl">사고 장소</span>
          <input type="text" id="r_loc" class="fi" placeholder="예: 비선대 직상부 암릉 구간" value="${p.location||''}" oninput="autoGenTitle();this.dataset.userEdited='1'">
        </div>
        <div class="fg"><span class="fl">장소구분</span>
          <div style="display:flex;gap:5px;flex-wrap:wrap;" id="loctypeBtns">
            ${['법정탐방로','비법정탐방로','암벽','빙벽'].map(o=>`<button class="tog-btn${(p.loctype||'법정탐방로')===o?' on':''}" data-val="${o}" onclick="selLoctype('${o}')">${o}</button>`).join('')}
          </div>
          <input type="hidden" id="r_loctype" value="${p.loctype||'법정탐방로'}">
        </div>
        <div id="fineWrap" style="display:${p.loctype&&p.loctype.includes('비법정')?'block':'none'};" class="fg">
          <span class="fl" style="color:#e67e22;">⚠️ 과태료 여부</span>
          <select id="r_fine" class="fsel">
            ${['과태료 해당 없음','과태료 부과 예정','확인 필요'].map(o=>`<option${p.fine===o?' selected':''}>${o}</option>`).join('')}
          </select>
        </div>
        <div id="permitWrap" style="display:${p.loctype&&(p.loctype==='암벽'||p.loctype==='빙벽')?'block':'none'};" class="fg">
          <span class="fl">🏔️ 암빙벽 허가</span>
          <select id="r_permit" class="fsel" onchange="chkPermit(this)">${['해당없음','허가자 있음','무허가'].map(o=>`<option${p.permit===o?' selected':''}>${o}</option>`).join('')}</select>
        </div>
        <div id="permitNote" style="display:${p.permit&&p.permit==='허가자 있음'?'block':'none'};" class="fg">
          <input type="text" id="r_permitNote" class="fi" placeholder="허가번호, 소속 등" value="${p.permitNote||''}">
        </div>
        <div id="climbLocWrap" style="display:${(p.loctype==='암벽'||p.loctype==='빙벽')?'block':'none'};" class="fg">
          ${(p.loctype==='암벽'||p.loctype==='빙벽')?`<span class="fl">📍 ${p.loctype} 위치 선택</span><div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:6px;" id="climbLocBtns">${(p.loctype==='암벽'?_ROCK_LOCS:_ICE_LOCS).map(l=>`<button class="tog-btn${(p.location||'')===(l)?' on':''}" onclick="selClimbLoc('${l.replace(/'/g,"\\'")}',this)">${l}</button>`).join('')}</div>`:''}
        </div>
      </div>
      <div class="rsec"><div class="rsec-t">🌤️ 기상 정보</div>
        <div class="fg"><span class="fl">기상 상황</span>
          <div class="pills" id="weatherPills">${['맑음','흐림','비','눈','강풍','안개'].map(o=>`<div class="pill${p.weather===o?' on':''}" onclick="sPill(this,'weatherPills')">${o}</div>`).join('')}</div>
        </div>
        <div class="fg"><span class="fl">기상 특보</span>
          <div style="background:#060d1a;border-radius:8px;border:1px solid rgba(255,255,255,.07);padding:10px;margin-top:4px;">
            <div style="font-size:10px;color:#7a9cb8;font-weight:700;margin-bottom:5px;">종류</div>
            <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px;" id="wAlertTypePills">
              ${['강풍','호우','대설','건조','한파','폭염','황사','태풍'].map(t=>`<div class="pill" onclick="selWAlertType(this,'${t}')" style="font-size:11px;cursor:pointer;">${t}</div>`).join('')}
            </div>
            <div style="font-size:10px;color:#7a9cb8;font-weight:700;margin-bottom:5px;">단계</div>
            <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px;" id="wAlertLevelPills">
              ${['주의보','경보','특보'].map(l=>`<div class="pill" onclick="selWAlertLevel(this,'${l}')" style="font-size:11px;cursor:pointer;">${l}</div>`).join('')}
            </div>
            <button onclick="addWAlert()" style="width:100%;padding:7px;background:rgba(79,168,208,.15);border:1px solid rgba(79,168,208,.3);color:#4fa8d0;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;">＋ 추가</button>
            <div id="wAlertList" style="margin-top:6px;"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- ══ 섹터2: 환자·부상 (순서: 부상현황 → 현장사진 → 원인·경위 → 활력징후) ══ -->
    <div id="repSec2" class="rep-sec" style="display:none;padding:12px;overflow-y:auto;">

      <!-- 1. 부상 현황 -->
      <div class="rsec"><div class="rsec-t">🩺 부상 현황</div>
        <div style="background:#060d1a;border-radius:8px;border:1px solid rgba(255,255,255,.07);padding:10px;margin-bottom:8px;">
          <!-- ① 부상 유형 먼저 -->
          <div style="font-size:10px;color:#7a9cb8;font-weight:700;margin-bottom:5px;">① 부상 유형 <span style="font-weight:400;color:#5a7a92;">※ 전신상태는 부위 불필요</span></div>
          <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px;" id="injTypePills">
            ${['골절','탈구','염좌','열상','타박상','두부손상','심정지','저체온증','탈진/탈수','익수','기타(부위)','기타(전신)'].map(t=>`<div class="pill" onclick="selInjType(this,'${t}')" style="font-size:11px;cursor:pointer;">${t}</div>`).join('')}
          </div>
          <!-- ② 부상 부위 -->
          <div id="injPartWrap" style="margin-bottom:8px;">
            <div style="font-size:10px;color:#7a9cb8;font-weight:700;margin-bottom:5px;">② 부상 부위</div>
            <div style="display:flex;gap:4px;flex-wrap:wrap;" id="injPartPills">
              ${['머리','목','어깨','팔꿈치','손목','손','흉부','복부','허리','골반','무릎','발목','발'].map(t=>`<div class="pill" onclick="selInjPart(this,'${t}')" style="font-size:11px;cursor:pointer;">${t}</div>`).join('')}
            </div>
          </div>
          <!-- 좌/우 — 부위 선택 후 노출 -->
          <div id="injSideWrap" style="display:none;margin-bottom:8px;">
            <div style="font-size:10px;color:#7a9cb8;font-weight:700;margin-bottom:5px;">좌/우</div>
            <div style="display:flex;gap:4px;flex-wrap:wrap;" id="injSidePills">
              ${['좌','우','양쪽'].map(s=>`<div class="pill" onclick="selInjSide(this,'${s}')" style="font-size:11px;cursor:pointer;">${s}</div>`).join('')}
            </div>
          </div>
          <button onclick="addInjury()" style="width:100%;padding:7px;background:rgba(79,168,208,.15);border:1px solid rgba(79,168,208,.3);color:#4fa8d0;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;">＋ 부상 추가</button>
          <div id="injuryList" style="margin-top:6px;"></div>
        </div>
      </div>

      <!-- 2. 현장 사진 (사진은 필요 없다 하셨으나 구조 첨부는 유지 — 사용자 요청으로 삭제 원할 시 별도 요청) -->
      <div class="rsec"><div class="rsec-t">📸 현장 사진</div>
        <div class="frow">
          <div class="fg"><span class="fl">부상 사진</span>
            <div class="photo-slot" onclick="document.getElementById('fileInj').click()"><input type="file" id="fileInj" accept="image/*" capture="environment" style="display:none;" onchange="prevImg(this,'prevInj')"><div id="prevInj">📸</div></div>
          </div>
          <div class="fg"><span class="fl">이송 사진</span>
            <div class="photo-slot" onclick="document.getElementById('fileTrans').click()"><input type="file" id="fileTrans" accept="image/*" capture="environment" style="display:none;" onchange="prevImg(this,'prevTrans')"><div id="prevTrans">📸</div></div>
          </div>
        </div>
      </div>

      <!-- 3. 사고 원인·경위 -->
      <div class="rsec"><div class="rsec-t">⚡ 사고 원인·경위</div>
        <div class="fg"><span class="fl">사고 원인</span>
          <select id="r_cause" class="fsel" onchange="autoGenTitle()">
            ${['본인부주의','실족','추락','낙석 피격','탈진/탈수','저체온','심혈관 이상','동물 피해','익수','기타'].map(o=>`<option${(p.cause||'본인부주의')===o?' selected':''}>${o}</option>`).join('')}
          </select>
        </div>
        <div class="fg"><span class="fl">사고 경위 <span style="font-size:9px;color:#7a9cb8;font-weight:400;">(상세 기술)</span></span>
          <textarea id="r_sit" class="fta" rows="4" placeholder="예) 오전 09:00 비선대 주차장에서 산행 시작, 11:30경 천불동계곡 3km 지점 하산 중 실족하여 우측 발목 부상 발생">${p.situation||''}</textarea>
        </div>
      </div>

      <!-- 4. 활력징후 (음주여부 + 중증도 포함) -->
      <div class="rsec"><div class="rsec-t">💓 활력징후 <span style="font-size:9px;color:#7a9cb8;font-weight:400;">(보고마다 기록 → 추이 확인)</span></div>
        <div style="font-size:9px;color:#5a7e98;margin-bottom:6px;">＋/− 버튼은 예시값에서 시작해 조정 · 안 건드리면 빈값으로 저장</div>
        <div class="frow">
          <div class="fg"><span class="fl">맥박 (회/분)</span>
            <div class="vit-step"><button type="button" onclick="_vitStep('r_hr',-1,80,1)">−</button><input type="number" inputmode="numeric" id="r_hr" class="fi vit-input" min="0" placeholder="예: 80" value="${p.vitals?.hr||''}" enterkeyhint="next" onkeydown="_vitNext(event)" oninput="_vitClamp(this)"><button type="button" onclick="_vitStep('r_hr',1,80,1)">＋</button></div>
          </div>
          <div class="fg"><span class="fl">SpO₂ (%)</span>
            <div class="vit-step"><button type="button" onclick="_vitStep('r_spo2',-1,98,1,100)">−</button><input type="number" inputmode="numeric" id="r_spo2" class="fi vit-input" min="0" max="100" placeholder="예: 98" value="${p.vitals?.spo2||''}" enterkeyhint="next" onkeydown="_vitNext(event)" oninput="_vitClamp(this,100)"><button type="button" onclick="_vitStep('r_spo2',1,98,1,100)">＋</button></div>
          </div>
        </div>
        <div class="frow">
          <div class="fg"><span class="fl">체온 (℃)</span>
            <div class="vit-step"><button type="button" onclick="_vitStep('r_temp',-1,36.5,0.1)">−</button><input type="number" inputmode="decimal" step="0.1" id="r_temp" class="fi vit-input" min="0" placeholder="예: 36.5" value="${p.vitals?.temp||''}" enterkeyhint="next" onkeydown="_vitNext(event)" oninput="_vitClamp(this)"><button type="button" onclick="_vitStep('r_temp',1,36.5,0.1)">＋</button></div>
          </div>
          <div class="fg"><span class="fl">의식 (AVPU)</span>
            <select id="r_avpu" class="fsel">${['','A (명료)','V (음성반응)','P (통증반응)','U (무반응)'].map(o=>`<option${(p.vitals?.avpu||'')===o?' selected':''}>${o||'선택'}</option>`).join('')}</select>
          </div>
        </div>
        <div class="fg"><span class="fl">혈압 (선택)</span><input type="text" id="r_bp" class="fi vit-input" placeholder="예: 120/80" value="${p.vitals?.bp||''}" enterkeyhint="done"></div>
        <!-- 음주 여부 — 버튼식 -->
        <div class="fg"><span class="fl">음주 여부</span>
          <div style="display:flex;gap:6px;" id="alcPills">
            ${['없음','의심','확인됨'].map(o=>`<div class="pill${(p.alcohol||'없음')===o?' on':''}" onclick="sPill(this,'alcPills');_toggleAlcAmount()" style="flex:1;text-align:center;font-size:12px;font-weight:700;padding:8px 0;cursor:pointer;">${o==='없음'?'🚫 없음':o==='의심'?'⚠️ 의심':'🍺 확인됨'}</div>`).join('')}
          </div>
          <input type="hidden" id="r_alc" value="${p.alcohol||'없음'}">
        </div>
        <div class="fg" id="alcAmountWrap" style="display:${(p.alcohol&&p.alcohol!=='없음')?'block':'none'};">
          <span class="fl">음주량 (선택)</span>
          <input type="text" id="r_alcAmount" class="fi" placeholder="예: 소주 1병, 맥주 2캔, 추정 다량" value="${p.alcAmount||''}">
        </div>
        <!-- 중증도 -->
        <div class="fg"><span class="fl">중증도 <button class="info-btn" onclick="openGuide('severity')">ℹ KTAS</button></span>
          <div class="pills" id="sevPills">${['KTAS 1 (소생)','KTAS 2 (긴급)','KTAS 3 (응급)','KTAS 4 (준응급)','KTAS 5 (비응급)'].map(o=>`<div class="pill${p.severity===o?' on':''}" onclick="sPill(this,'sevPills');autoGenTitle()">${o}</div>`).join('')}</div>
        </div>
      </div>
    </div>

    <!-- ══ 섹터3: 인적사항 ══ -->
    <div id="repSec3" class="rep-sec" style="display:none;padding:12px;overflow-y:auto;">
      <div class="rsec"><div class="rsec-t">🧑 사고자 인적사항 <button class="info-btn" onclick="openGuide('victim')">ℹ</button></div>
        <div class="frow">
          <div class="fg"><span class="fl">성명</span><input type="text" id="r_vName" class="fi" value="${p.vName||''}"></div>
          <div class="fg"><span class="fl">연락처</span><input type="tel" id="r_vTel" class="fi" value="${p.vTel||''}"></div>
        </div>
        <div class="frow">
          <div class="fg"><span class="fl">내/외국인</span>
            <select id="r_vNat" class="fsel" onchange="chkNation(this)">${['내국인','외국인','알수없음'].map(o=>`<option${p.vNation===o?' selected':''}>${o}</option>`).join('')}</select>
          </div>
          <div id="r_vNatWrap_extra" style="display:${p.vNation==='외국인'?'block':'none'};" class="fg">
            <span class="fl">국적</span><input type="text" id="r_vNationality" class="fi" placeholder="예: 미국, 중국" value="${p.vNationality||''}">
          </div>
          <div class="fg"><span class="fl">성별</span>
            <select id="r_vGender" class="fsel" onchange="autoGenTitle()">${['알수없음','남','여'].map(o=>`<option${(p.vGender||'알수없음')===o?' selected':''}>${o}</option>`).join('')}</select>
          </div>
        </div>
        <div class="frow">
          <div class="fg"><span class="fl">생년월일</span><input type="text" inputmode="numeric" id="r_vBirth" class="fi" placeholder="19901231" maxlength="10" value="${p.vBirth||''}" oninput="_fmtBirth(this)"></div>
          <div class="fg"><span class="fl">거주지</span><input type="text" id="r_vAddr" class="fi" placeholder="시/도" value="${p.vAddr||''}"></div>
        </div>
        <div class="fg"><span class="fl">기저질환</span><input type="text" id="r_vDis" class="fi" placeholder="없음 또는 해당 질환" value="${p.vDisease||''}"></div>
        <div class="fg"><span class="fl">알레르기</span><input type="text" id="r_vAll" class="fi" placeholder="없음 또는 항목" value="${p.vAllergy||''}"></div>
        <div class="fg"><span class="fl">복용약</span><input type="text" id="r_vMed" class="fi" placeholder="없음 또는 항목" value="${p.vMeds||''}"></div>
      </div>
      <div class="rsec"><div class="rsec-t">👥 추가 사고자 <span style="font-size:9px;color:#7a9cb8;font-weight:400;">(다수 사상자 발생 시)</span></div>
        <div id="victim2List">${(p.victims2||[]).map(v=>`<div class="victim2-item" style="background:#060d1a;border-radius:8px;padding:10px;margin-bottom:6px;border:1px solid rgba(231,76,60,.15);">${_victim2CardHtml(v)}</div>`).join('')}</div>
        <button onclick="addVictim2()" style="width:100%;padding:9px;background:rgba(231,76,60,.08);border:1px dashed rgba(231,76,60,.3);color:#e9897e;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;margin-top:4px;">＋ 사고자 추가</button>
      </div>
      <div class="rsec"><div class="rsec-t">📞 신고자</div>
        <div class="fg">
          <div style="display:flex;gap:6px;" id="hasRepBtns">
            <button class="tog-btn${p.hasRep==='y'?'':' on'}" data-val="n" onclick="selHasRep('n')">없음</button>
            <button class="tog-btn${p.hasRep==='y'?' on':''}" data-val="y" onclick="selHasRep('y')">있음</button>
          </div>
          <input type="hidden" id="r_hasRep" value="${p.hasRep||'n'}">
        </div>
        <div id="reporterWrap" style="display:${p.hasRep==='y'?'block':'none'};">
          <div class="frow">
            <div class="fg"><span class="fl">성명</span><input type="text" id="r_repName" class="fi" value="${p.repName||''}"></div>
            <div class="fg"><span class="fl">연락처</span><input type="tel" id="r_repTel" class="fi" value="${p.repTel||''}"></div>
          </div>
        </div>
      </div>
      <div class="rsec"><div class="rsec-t">👥 동반자</div>
        <div class="fg">
          <div style="display:flex;gap:6px;" id="hasCompBtns">
            <button class="tog-btn${(p.companions&&p.companions.length)?'':' on'}" data-val="n" onclick="selHasComp('n')">없음</button>
            <button class="tog-btn${(p.companions&&p.companions.length)?' on':''}" data-val="y" onclick="selHasComp('y')">있음</button>
          </div>
          <input type="hidden" id="r_hasComp" value="${(p.companions&&p.companions.length)?'y':'n'}">
        </div>
        <div id="companionWrap" style="display:${(p.companions&&p.companions.length)?'block':'none'};">
          <div id="companionList">
            ${(p.companions||[]).map((c,i)=>`<div class="companion-item" data-idx="${i}" style="background:#060d1a;border-radius:8px;padding:10px;margin-bottom:6px;border:1px solid rgba(255,255,255,.07);">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;"><span style="font-size:11px;color:#4fa8d0;font-weight:700;">동반자 ${i+1}</span><button onclick="removeCompanion(${i})" style="background:rgba(192,57,43,.15);color:#c0392b;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;">삭제</button></div>
              <div class="frow"><div class="fg"><span class="fl">성명</span><input type="text" class="fi comp-name" placeholder="이름" value="${c.name||''}"></div><div class="fg"><span class="fl">연락처</span><input type="tel" class="fi comp-tel" placeholder="연락처" value="${c.tel||''}"></div></div>
            </div>`).join('')}
          </div>
          <button onclick="addCompanion()" style="width:100%;padding:9px;background:rgba(79,168,208,.08);border:1px dashed rgba(79,168,208,.3);color:#4fa8d0;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;margin-top:4px;">＋ 동반자 추가</button>
        </div>
      </div>
    </div>

    <!-- ══ 섹터4: 기타 ══ -->
    <div id="repSec5" class="rep-sec" style="display:none;padding:12px;overflow-y:auto;">
      <div class="rsec"><div class="rsec-t">🛠️ 동원 장비</div>
        <div class="fg"><span class="fl">구조 방법 (복수)</span>
          <div class="pills" id="rescMeth">${['들것','부축','헬기','차량','자력하산','로프구조','기타'].map(o=>`<div class="pill${(p.rescueMethod||[]).includes(o)?' on':''}" onclick="tPill(this)">${o}</div>`).join('')}</div>
        </div>
        <div class="fg"><span class="fl">동원 장비</span>
          <textarea id="r_equip" class="fta" rows="2" placeholder="들것, 로프, AED, 헬기 등">${p.equipment||''}</textarea>
        </div>
      </div>
      <div class="rsec" style="margin-top:12px;"><div class="rsec-t">🚑 병원 후송</div>
        <select id="r_hosp" class="fsel">${['미정','후송 없음','후송 완료','후송 중','본인 귀가','기타'].map(o=>`<option${(p.hospital||'미정')===o?' selected':''}>${o}</option>`).join('')}</select>
      </div>
      <div class="rsec" style="margin-top:12px;"><div class="rsec-t">📋 사고 제목 및 작성 정보</div>
        <div class="fg">
          <span class="fl">사고 제목 <span style="font-size:9px;color:#7a9cb8;font-weight:400;">(자동생성 — 수정 가능)</span></span>
          <input type="text" id="r_title" class="fi" placeholder="위치·기상 탭 입력 시 자동생성" value="${p.title||''}">
        </div>
        <div class="fg"><span class="fl">보고 작성자</span>
          <input type="text" id="r_author" class="fi" value="${isExternal()?_extAuthorStr():getAuthor()}" disabled style="opacity:.6;cursor:default;">
        </div>
        <div class="fg"><span class="fl">기타 특이사항</span>
          <textarea id="r_extra" class="fta" rows="3">${p.extra||''}</textarea>
        </div>
      </div>
    </div>
  `;

  const _footer=document.getElementById('rep1BoFooter');
  if(_footer){
    _footer.style.display='block';
    _footer.innerHTML=isNbo
      ?`<button class="btn-submit" style="background:#1a4a6e;color:#fff;" onclick="submitNBoFromForm()">💾 ${p._phaseNum||2}보 저장</button>`
      :`<button class="btn-submit" style="background:#1a4a6e;color:#fff;" onclick="submit1Bo()">💾 1보 등록</button>`;
  }

  _ttInlineEntries=p.timetable||[];   // (수정) 미선언 _ttEntries → strict 모드 ReferenceError로 이후 초기화 전체 중단되던 버그
  initExtraDispatch(p);
  initExtraTeams(p);
  initWAlerts(p);
  initInjuries(p);
  initFireAgencies(p);
  initFormMiniMap(p.lat,p.lng);
  // GPS 자동 실행 (lat/lng 없을 때)
  if(!p.lat&&!p.lng)setTimeout(()=>gpsToFormMap(),800);
  // 작성 모드 진입 — 자동저장·이탈경고 활성화
  window._reportMode='form';
  window._reportIsNbo=isNbo; // N보는 1보 임시저장 키를 공유하지 않음
  _formDirty=false;
  if(!_draftListenerBound){
    const wc=document.getElementById('repContent');
    if(wc){wc.addEventListener('input',()=>{if(window._reportMode==='form')_formDirty=true;});
           wc.addEventListener('change',()=>{if(window._reportMode==='form')_formDirty=true;});
           _draftListenerBound=true;}
  }
  if(!isNbo)_startDraftAutosave(); // 신규 1보만 임시저장
}

function _renderFormTl(){
  // 신규 1보 폼 탭: 팀 카드만 렌더 (고도화 타임라인의 same 컴포넌트 재사용, 구버전 경로뷰 제거)
  const loc=document.getElementById('r_loc')?.value||'';
  const loctype=document.getElementById('r_loctype')?.value||'법정탐방로';
  const curUser=DB.g('currentUser')||{};
  const members=curUser.name?[curUser.name]:[];
  const tempR={id:'_form_tl_',title:'신규 구조',location:loc,loctype:loctype,
    members:members,extraTeams:[],agencies:{},r119:false,
    timetable:[],lat:null,lng:null,status:'ongoing'};
  _initTlTeams(tempR);
  const wrap=document.getElementById('formTlWrap');
  if(!wrap)return;
  wrap.innerHTML=`
    <div id="tlAllTeams">${_tlTeams.map((t,i)=>_tlTeamFullHtml(t,i)).join('')}</div>
    <div id="tlBuildArea">${_tlBuilding?_renderBuildPanelHtml():_renderCreateBtnsHtml()}</div>`;
}
let _1boSubmitting=false;
function switchRepTab(secId,el){
  document.querySelectorAll('.rep-sec').forEach(s=>s.style.display='none');
  const target=document.getElementById(secId);
  if(target) target.style.display='block';
  document.querySelectorAll('.rep-tab').forEach(t=>{
    t.style.color='rgba(255,255,255,.3)';
    t.style.borderBottomColor='transparent';
    t.classList.remove('rep-tab-on');
  });
  if(el){el.style.color='#4fa8d0';el.style.borderBottomColor='#4fa8d0';el.classList.add('rep-tab-on');}
  if(secId==='repSec0') _renderFormTl();
}





function submit1Bo(){
  if(_1boSubmitting)return;
  _1boSubmitting=true;
  const _btn=document.querySelector('#rep1BoFooter .btn-submit');
  if(_btn){_btn.disabled=true;_btn.style.opacity='.5';}
  try{
  autoGenTitle();
  const title=document.getElementById('r_title').value.trim()||autoGenTitle(true);
  const gps=(document.getElementById('r_gps')?.value||'').split(',');
  // 좌표 검증: 범위 밖(위경도 뒤바뀜 포함)·NaN이면 좌표 없이 저장(지도 오표시 방지)
  let lat=parseFloat(gps[0]), lng=parseFloat(gps[1]);
  if(isNaN(lat)||isNaN(lng)||lat<-90||lat>90||lng<-180||lng>180){
    if(gps[0]&&gps[1]&&(isNaN(lat)||isNaN(lng)||Math.abs(lat)>90))toast('⚠️ 좌표 형식 오류 — 위치 없이 저장됩니다');
    lat=null;lng=null;
  }
  const members=[...document.querySelectorAll('#memChkGrid .chk-grid .chk-box.on')].map(b=>{
    const txt=b.closest('.chk-item')?.querySelector('.chk-txt');
    return txt?txt.textContent.trim().split(' ')[0]:'';
  }).filter(Boolean);
  const extraMembers=[..._extraDispatch];
  // 현재 날짜/시간
  const nowStr=now();
  const r={
    id:Date.now(), title,
    type:document.getElementById('r_type')?.value||'안전사고',
    date:nowStr,
    reception:document.getElementById('r_recv')?.value||'',
    weather:getSelPills('weatherPills')[0]||'',
    weatherAlert:getWeatherAlertStr()||'',
    alertOpId:((DB.g('alertOps')||[]).find(o=>!o.closedAt)||{}).id||null,
    lat, lng,
    location:document.getElementById('r_loc')?.value||'',
    loctype:document.getElementById('r_loctype')?.value||'',
    fine:document.getElementById('fineWrap')?.style.display!=='none'?(document.getElementById('r_fine')?.value||''):'',
    vName:document.getElementById('r_vName')?.value||'',
    vTel:document.getElementById('r_vTel')?.value||'',
    vNation:document.getElementById('r_vNat')?.value||'알수없음',
    vNationality:document.getElementById('r_vNationality')?.value||'',
    vGender:document.getElementById('r_vGender')?.value||'알수없음',
    vBirth:document.getElementById('r_vBirth')?.value||'',
    vAddr:document.getElementById('r_vAddr')?.value||'',
    vDisease:document.getElementById('r_vDis')?.value||'',
    vAllergy:document.getElementById('r_vAll')?.value||'',
    vMeds:document.getElementById('r_vMed')?.value||'',
    companions:getCompanions(),
    victims2:getVictims2(),
    cause:document.getElementById('r_cause')?.value||'',
    injuryParts:getSelPills('injParts'),
    injuryTypes:getSelPills('injTypes'),
    severity:getSelPills('sevPills')[0]||'',
    alcohol:document.getElementById('r_alc')?.value||'없음',
    alcAmount:document.getElementById('r_alcAmount')?.value||'',
    injuries:_injuries,
    situation:document.getElementById('r_sit')?.value||'',
    rescueMethod:getSelPills('rescMeth'),
    members, extraMembers,
    extraTeams:getExtraTeams(),
    agencies:getAgencies(),
    r119:document.getElementById('r_119')?.value||'',
    equipment:document.getElementById('r_equip')?.value||'',
    hospital:document.getElementById('r_hosp')?.value||'미정',
    author:document.getElementById('r_author')?.value||(isExternal()?_extAuthorStr():getAuthor()),
    extAgency:isExternal()?(DB.g('currentUser')||{}).name||null:null,
    extra:document.getElementById('r_extra')?.value||'',
    permit:document.getElementById('r_permit')?.value||'해당없음',
    permitNote:document.getElementById('r_permitNote')?.value||'',
    hasRep:document.getElementById('r_hasRep')?.value||'n',
    repName:document.getElementById('r_repName')?.value||'',
    repTel:document.getElementById('r_repTel')?.value||'',
    injuryPhoto:_photoUrl('prevInj'),
    transPhoto:_photoUrl('prevTrans'),
    timetable: sortTTByTime(_ttInlineEntries||[]),
    mobilize:getSelPills('mobilizePills'),
    vitals:_collectVitals(),
    status:'ongoing', reports:[],
  };
  // 등록 폼 타임라인에서 만든 팀이 있으면 새 구조 레코드로 이관
  if(_tlWpResId==='_form_tl_'&&_tlTeams.length){
    r.teams=_snapshotTeams();
    _tlWpResId=r.id;
  }
  // SOS에서 온 1보면: 레코드에 sosId 연결 + 1회용 토큰 종료(중복 핀 방지)
  if(window._pendingSosId){
    r.sosId=window._pendingSosId;
    if(_fdb)_fdb.collection('sos').doc(window._pendingSosId).set({active:false,closedAt:Date.now()},{merge:true}).catch(()=>{});
    _sosPings=(_sosPings||[]).filter(x=>x.id!==window._pendingSosId);
    window._pendingSosId=null;try{_drawSosPins();_updateSosFab();}catch(e){}
  }
  const res=DB.g('rescues')||[];
  res.push(r);
  DB.s('rescues',res);
  // 저장 즉시 지도·목록·요약 갱신 → 등록 직후 지도에 바로 표시
  try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}try{updateSummary();}catch(e){}
  // 오프라인 대기 사진을 이 레코드에 연결 (연결 복구 시 자동 반영)
  _registerPendingPhoto('prevInj',{key:'rescues',id:r.id,field:'injuryPhoto'});
  _registerPendingPhoto('prevTrans',{key:'rescues',id:r.id,field:'transPhoto'});
  pushNoti('🚨 구조 1보: '+title+' ('+r.type+')',RES_TYPES[r.type]?.ico||'🚨',r.type,{app:'rescue',tab:2,id:r.id},'안전사고');
  if(r.mobilize&&r.mobilize.length)pushNoti('🚨 야간 응소 요청: '+r.mobilize.join(', ')+' — '+title,'🚨','rescue_mobilize',{app:'rescue',tab:2,id:r.id});
  syncToSheets('rescue',{id:r.id,title,type:r.type,date:r.date,author:r.author});
  toast('🚨 1보 등록 완료'+(r.mobilize&&r.mobilize.length?' · 응소: '+r.mobilize.join(', '):''));
  _clearRescueDraft(); // 정상 등록됐으므로 임시저장 폐기
  // 저장 즉시 고도화 타임라인으로 이동
  selResId=r.id;curResId=r.id;
  document.getElementById('bnav').style.display='none';
  _hideRepFooter();
  showV('v-report');
  document.getElementById('topTitle').textContent=r.title;
  history.pushState({view:'rescue-timeline',id:r.id},'','');
  renderTimeline(r,'advanced');
  }finally{
    _1boSubmitting=false;
    if(_btn){_btn.disabled=false;_btn.style.opacity='1';}
  }
}

// ══════════════════════════════════════════
// 위험상황 보고
// ══════════════════════════════════════════
let _hazFireTL=[];
function chkHazType(txt){
  const isFire=txt.includes('산불');
  document.getElementById('hazFireTimelineWrap').style.display=isFire?'block':'none';
  document.getElementById('hazFireMobilizeWrap').style.display=isFire?'block':'none';
  document.getElementById('hazFireLeadWrap').style.display=isFire?'block':'none';
  if(isFire){
    const el=document.getElementById('hazFireTLTime');
    if(el)el.value=new Date().toISOString().slice(0,16);
    const stages=['최초 발화 확인','소방 신고','소방 도착','진화 시작','진화 완료','재발화','완전 진화'];
    const qp=document.getElementById('hazFireQuickPills');
    if(qp)qp.innerHTML=stages.map(s=>`<div class="pill" onclick="addHazFireTL('${s}')" style="font-size:10px;">${s}</div>`).join('');
  }
}
function addHazFireTL(stage){
  const timeEl=document.getElementById('hazFireTLTime');
  const noteEl=document.getElementById('hazFireTLNote');
  const time=timeEl?.value?.replace('T',' ')||new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'});
  noteEl.value=stage;
  renderHazFireTL();
}
function confirmHazFireTL(){
  const time=(document.getElementById('hazFireTLTime')?.value||'').replace('T',' ');
  const note=document.getElementById('hazFireTLNote')?.value||'';
  if(!note.trim()){toast('⚠️ 내용 입력');return;}
  _hazFireTL.push({time,note});
  _hazFireTL.sort((a,b)=>a.time.localeCompare(b.time));
  document.getElementById('hazFireTLNote').value='';
  renderHazFireTL();
}
function renderHazFireTL(){
  const el=document.getElementById('hazFireTLList');
  if(!el)return;
  el.innerHTML=_hazFireTL.length?_hazFireTL.map((t,i)=>`<div style="display:flex;align-items:center;gap:7px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05);">
    <span style="font-size:10px;color:#4fa8d0;flex-shrink:0;">${t.time.slice(11)||t.time}</span>
    <span style="font-size:11px;color:#e0edf8;flex:1;">${_esc(t.note)}</span>
    <button onclick="_hazFireTL.splice(${i},1);renderHazFireTL()" style="background:none;border:none;color:#c0392b;font-size:13px;cursor:pointer;">✕</button>
  </div>`).join(''):'<div style="font-size:11px;color:rgba(255,255,255,.25);padding:4px 0;">타임라인 항목 없음</div>';
}
// 등록 후 상세화면에서도 산불 진행 타임라인을 계속 추가/삭제할 수 있도록(N보 대체)
function _hazFireTLHtml(h){
  if(!h.hazType||!h.hazType.includes('산불'))return '';
  const tl=h.fireTL||[];
  const stages=['최초 발화 확인','소방 신고','소방 도착','진화 시작','진화 완료','재발화','완전 진화'];
  return `<div id="fireTLBlk_${h.id}" style="background:#0b1c30;border-radius:10px;padding:11px 12px;border:.5px solid rgba(192,57,43,.25);margin-top:8px;">
    <div style="font-size:11px;color:#c0392b;font-weight:700;margin-bottom:7px;">🔥 산불 진행 타임라인</div>
    <div style="margin-bottom:6px;">
      ${tl.length?tl.map((t,i)=>`<div style="display:flex;align-items:center;gap:7px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <span style="font-size:10px;color:#4fa8d0;flex-shrink:0;">${_esc((t.time||'').slice(11)||t.time||'-')}</span>
        <span style="font-size:11px;color:#e0edf8;flex:1;">${_esc(t.note)}</span>
        <button onclick="delHazFireTL(${h.id},${i})" style="background:none;border:none;color:#c0392b;font-size:13px;cursor:pointer;">✕</button>
      </div>`).join(''):'<div style="font-size:11px;color:rgba(255,255,255,.25);padding:4px 0;">타임라인 항목 없음</div>'}
    </div>
    <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;">
      ${stages.map(s=>`<div class="pill" onclick="document.getElementById('fireTLNote_${h.id}').value='${_escq(s)}'" style="font-size:10px;">${s}</div>`).join('')}
    </div>
    <div style="display:flex;gap:5px;align-items:flex-end;">
      <input type="datetime-local" id="fireTLTime_${h.id}" class="fi" style="flex:1;" value="${new Date().toISOString().slice(0,16)}">
      <input type="text" id="fireTLNote_${h.id}" class="fi" style="flex:2;" placeholder="상황 내용">
      <button onclick="addHazFireTLEntry(${h.id})" style="background:#1a4a6e;color:#fff;border:none;padding:9px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;flex-shrink:0;">추가</button>
    </div>
  </div>`;
}
function addHazFireTLEntry(id){
  const haz=DB.g('hazards')||[];
  const idx=haz.findIndex(x=>x.id===id);if(idx===-1)return;
  const time=(document.getElementById('fireTLTime_'+id)?.value||'').replace('T',' ');
  const note=document.getElementById('fireTLNote_'+id)?.value||'';
  if(!note.trim()){toast('⚠️ 내용 입력');return;}
  const tl=[...(haz[idx].fireTL||[]),{time,note}].sort((a,b)=>(a.time||'').localeCompare(b.time||''));
  haz[idx]={...haz[idx],fireTL:tl};
  DB.s('hazards',haz);
  const blk=document.getElementById('fireTLBlk_'+id);
  if(blk)blk.outerHTML=_hazFireTLHtml(haz[idx]);
  toast('🔥 타임라인 추가');
}
function delHazFireTL(id,i){
  const haz=DB.g('hazards')||[];
  const idx=haz.findIndex(x=>x.id===id);if(idx===-1)return;
  const tl=(haz[idx].fireTL||[]).slice();tl.splice(i,1);
  haz[idx]={...haz[idx],fireTL:tl};
  DB.s('hazards',haz);
  const blk=document.getElementById('fireTLBlk_'+id);
  if(blk)blk.outerHTML=_hazFireTLHtml(haz[idx]);
}
function openNewHazard(){
  _hazFireTL=[];
  document.getElementById('hz_dt').value=nowDT();
  document.getElementById('hz_loc').value='';document.getElementById('hz_gps').value='';
  initHazMiniMap();
  document.getElementById('hz_desc').value='';const _ha=document.getElementById('hz_author');_ha.value=getAuthor();_ha.disabled=true;
  document.getElementById('prevHaz').innerHTML='📸 현장 사진';
  document.getElementById('hazFireTimelineWrap').style.display='none';
  document.getElementById('hazFireMobilizeWrap').style.display='none';
  document.getElementById('hazFireLeadWrap').style.display='none';
  _resetPills('hazTypePills','hazDangerPills','hazStatusPills','hazOnSitePills','hazResponsePills','hazMobilizePills');
  document.querySelector('#hazStatusPills .pill').classList.add('on');
  renderHazFireTL();
  document.getElementById('modalHazard').classList.add('on');
}
let _hazSubmitting=false;
function submitHazard(){
  const type=getSelPills('hazTypePills')[0];
  if(!type){toast('⚠️ 유형 선택');return;}
  if(_hazSubmitting)return; // 이중 탭 중복 등록 방지
  _hazSubmitting=true;
  setTimeout(()=>{_hazSubmitting=false;},1500);
  const gps=document.getElementById('hz_gps').value.split(',');
  const lat=parseFloat(gps[0])||null,lng=parseFloat(gps[1])||null;
  const h={
    id:Date.now(),hazType:type,
    dt:document.getElementById('hz_dt').value.replace('T',' '),
    loc:document.getElementById('hz_loc').value,lat,lng,
    danger:getSelPills('hazDangerPills')[0]||'',
    desc:document.getElementById('hz_desc').value,
    hazStatus:getSelPills('hazStatusPills')[0]||'미조치',
    statusLog:[{status:getSelPills('hazStatusPills')[0]||'미조치',at:now(),by:document.getElementById('hz_author').value||'-'}],
    onSite:getSelPills('hazOnSitePills')[0]||'',response:getSelPills('hazResponsePills')[0]||'',
    author:document.getElementById('hz_author').value,
    photo:_photoUrl('prevHaz'),
    fireTL:type.includes('산불')?[..._hazFireTL]:[],
    mobilize:type.includes('산불')?getSelPills('hazMobilizePills'):[],
    leadAgency:type.includes('산불')?'산림청':'',
  };
  const haz=DB.g('hazards')||[];haz.push(h);DB.s('hazards',haz);
  _registerPendingPhoto('prevHaz',{key:'hazards',id:h.id,field:'photo'});
  pushNoti(`⚠️ 위험상황: ${type} · ${h.loc||'-'}`,'⚠️','낙석',{app:'rescue',tab:2});
  if(h.mobilize&&h.mobilize.length)pushNoti(`🚨 산불 응소 요청: ${h.mobilize.join(', ')} — ${h.loc||'-'}`,'🚨','rescue_mobilize',{app:'rescue',tab:2});
  closeM('modalHazard');try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}toast('⚠️ 위험상황 등록'+(h.mobilize&&h.mobilize.length?' · 응소: '+h.mobilize.join(', '):''));updateSummary();
}

// ══════════════════════════════════════════
// 시설물
// ══════════════════════════════════════════
let selFacId=null;
let facMapStatusF=new Set(),facMapTypeF=new Set(),facMapLocF=new Set();
let facListSort='default'; // 'default' | 'overdue'(점검 오래된순)
function setFacListSort(v){
  facListSort=facListSort===v?'default':v;
  _persistFilters();
  if(facListSort==='overdue')_loadArchive('history').then(()=>{_updateFacListFilterPanel();renderFacList();}); // 1년 이전 점검이력도 반영
  _updateFacListFilterPanel();renderFacList();
}
function renderInspectMap(){
  if(!mapI){return;}
  iOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});iOvs=[];iEls=[];
  _iClusterOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_iClusterOvs=[];
  const _admin=isAdminUser();const _meta=DB.g('catFacMeta')||{};
  const facs=(DB.g('facilities')||[]).filter(f=>_admin||!(_meta[f.type]||{}).adminOnly);
  const sMap={'전체':null,'양호':'ok','요주의':'warn','위험':'bad'};
  const sCol={'전체':'rgba(200,220,240,.6)','양호':'#27ae60','요주의':'#e67e22','위험':'#c0392b'};
  const types=['전체',...new Set(facs.map(f=>f.type.split(' ').slice(1).join(' ')||f.type).filter(Boolean))];
  const _signFacs=(DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판'));
  const locs=['전체',...new Set(_signFacs.map(f=>(f.name.match(/\d+/)||[''])[0]).filter(Boolean)).values()].sort((a,b)=>a==='전체'?-1:a.localeCompare(b,'ko'));
  _updateInspFilterPanel(types,locs);
  const filtered=facs.filter(f=>{
    const sOk=facMapStatusF.size===0||facMapStatusF.has(f.status);
    const tOk=facMapTypeF.size===0||[...facMapTypeF].some(t=>f.type.includes(t));
    const lOk=facMapLocF.size===0||[...facMapLocF].some(v=>_facInZone(f,v));
    return sOk&&tOk&&lOk;
  });
  filtered.forEach(f=>{
    if(!f.lat||!f.lng)return;
    const el=document.createElement('div');el.className=`mpin p-${f.status}${f.status==='bad'?' blink':''}`;el.innerHTML=f.type.split(' ')[0];
    let _ts=null;
    el.addEventListener('touchstart',e=>{_ts={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});
    el.addEventListener('touchend',e=>{
      if(!_ts)return;
      const dx=e.changedTouches[0].clientX-_ts.x,dy=e.changedTouches[0].clientY-_ts.y;
      _ts=null;
      if(Math.abs(dx)<8&&Math.abs(dy)<8){e.stopPropagation();e.preventDefault();openFacFromMap(f.id);}
    });
    el.addEventListener('click',e=>{e.stopPropagation();openFacFromMap(f.id);});
    const ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(f.lat,f.lng),content:el,clickable:true});
    ov._lat=f.lat;ov._lng=f.lng;
    // 지도 부착은 _reclusterInspect가 결정(밀집 핀은 버블로 묶음) — 초기 수백개 일괄 부착/제거 비용 제거
    iOvs.push(ov);iEls.push(el);
  });
  if(mapI)_scaleOvs(iEls,mapI.getLevel(),1);
  // 시설물 클러스터링 (밀집 시 개수 버블로 묶음)
  _iItems=iOvs.map(ov=>({ov,lat:ov._lat,lng:ov._lng}));
  try{_reclusterInspect();}catch(e){}
}
function setMapFacF(t,v){
  const set=t==='s'?facMapStatusF:t==='t'?facMapTypeF:facMapLocF;
  if(set.has(v))set.delete(v);else set.add(v);
  _persistFilters();renderInspectMap();renderFacList();
}
function _smfs(t,v){setMapFacF(t,v);}
// 필터 패널 공용 헬퍼 (시설물지도/시설물목록/구조필터 3곳에서 동일 템플릿 사용)
function _filterChip(label,set,val,onclick,col){
  const on=set.has(val);
  const c=col||(on?'#4fa8d0':'rgba(255,255,255,.5)');
  return `<span onclick="${onclick}" style="display:inline-block;margin:2px 2px;padding:3px 8px;border-radius:20px;font-size:10px;font-weight:600;cursor:pointer;border:1.5px solid ${on?c:'rgba(255,255,255,.12)'};color:${on?c:'rgba(255,255,255,.35)'};background:${on?c+'22':'transparent'};">${label}</span>`;
}
function _filterSec(id,title,html,set,extraCnt){
  const el=document.getElementById(id);if(!el)return;
  const cnt=(set?set.size:0)+(extraCnt||0),open=window._fpSec&&window._fpSec[id];
  el.innerHTML=`
    <div onclick="_toggleFPSec('${id}')"
      style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);cursor:pointer;user-select:none;">
      <span style="font-size:11px;font-weight:700;color:#9bbdd4;">${title}${cnt?` <span style="color:#e05050;font-size:10px;">(${cnt})</span>`:''}</span>
      <b style="font-size:13px;color:#3a6a8a;font-weight:400;">${open?'⌄':'›'}</b>
    </div>
    <div style="display:${open?'block':'none'};padding:4px 0 2px;">${html}</div>`;
}
function _updateInspFilterPanel(types,locs){
  const sChips=[{l:'양호',v:'ok',c:'#27ae60'},{l:'요주의',v:'warn',c:'#e67e22'},{l:'위험',v:'bad',c:'#c0392b'}];
  _filterSec('inspFP_status','상태',
    sChips.map(({l,v,c})=>_filterChip(l,facMapStatusF,v,`_smfs('s','${v}')`,c)).join(''),facMapStatusF);
  _filterSec('inspFP_type','종류',
    types.filter(t=>t!=='전체').map(v=>_filterChip(v,facMapTypeF,v,`_smfs('t','${v.replace(/'/g,"\\'")}')`,'#4fa8d0')).join(''),facMapTypeF);
  _filterSec('inspFP_loc','위치 (구간)',
    locs.filter(v=>v!=='전체').map(v=>_filterChip(_zoneLbl(v),facMapLocF,v,`_smfs('l','${v.replace(/'/g,"\\'")}')`,'#9b59b6')).join(''),facMapLocF);
  // 배지/카운트 업데이트
  const total=facMapStatusF.size+facMapTypeF.size+facMapLocF.size;
  ['inspFilterBadge','facListFilterBadge'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.style.display=total?'inline-flex':'none';if(total)el.textContent=total;});
  ['inspFilterCount','facListFilterCount'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.textContent=total?`(${total})`:'';});
}
function _toggleFPSec(id){
  if(!window._fpSec)window._fpSec={};
  window._fpSec[id]=!window._fpSec[id];
  const el=document.getElementById(id);if(!el)return;
  const body=el.children[1],arrow=el.querySelector('b');
  if(body)body.style.display=window._fpSec[id]?'block':'none';
  if(arrow)arrow.textContent=window._fpSec[id]?'⌄':'›';
}
function _initFPDrag(hId,pId,closeFn){
  const h=document.getElementById(hId),p=document.getElementById(pId);
  if(!h||!p||h._fpBound)return;h._fpBound=true;
  let y0=0;
  const mv=e=>{const y=(e.touches?e.touches[0]:e).clientY;p.style.transform=`translateY(${Math.max(0,y-y0)}px)`;};
  const up=e=>{const y=(e.changedTouches?e.changedTouches[0]:e).clientY;p.style.transition='transform .22s cubic-bezier(.4,0,.2,1)';if(y-y0>60)closeFn();else p.style.transform='translateY(0)';document.removeEventListener('mousemove',mv);document.removeEventListener('mouseup',up);};
  h.addEventListener('touchstart',e=>{y0=e.touches[0].clientY;p.style.transition='none';},{passive:true});
  h.addEventListener('touchmove',mv,{passive:true});
  h.addEventListener('touchend',up);
  h.addEventListener('mousedown',e=>{y0=e.clientY;p.style.transition='none';document.addEventListener('mousemove',mv);document.addEventListener('mouseup',up);e.preventDefault();});
}
function toggleInspFilter(){
  const p=document.getElementById('inspFilterPanel');
  const open=p.style.display==='flex';
  if(open){closeInspFilter();}
  else{p.style.display='flex';p.style.transform='translateY(0)';_initFPDrag('inspFPHandle','inspFilterPanel',closeInspFilter);}
}
function closeInspFilter(){
  const p=document.getElementById('inspFilterPanel');
  p.style.transform='translateY(100%)';
  setTimeout(()=>{p.style.display='none';p.style.transform='translateY(0)';},220);
}
function resetInspFilter(){
  facMapStatusF=new Set();facMapTypeF=new Set();facMapLocF=new Set();
  renderInspectMap();renderFacList();
}
// ─── 시설물 목록 필터 ───
function toggleFacListFilter(){
  const p=document.getElementById('facListFilterPanel');
  const open=p.style.display==='flex';
  if(open){_closeFacListFilter();}
  else{p.style.display='flex';p.style.transform='translateY(0)';_updateFacListFilterPanel();_initFPDrag('facLFPHandle','facListFilterPanel',_closeFacListFilter);}
}
function _closeFacListFilter(){
  const p=document.getElementById('facListFilterPanel');
  p.style.transform='translateY(100%)';
  setTimeout(()=>{p.style.display='none';p.style.transform='translateY(0)';},220);
}
function resetFacListFilter(){
  facMapStatusF=new Set();facMapTypeF=new Set();facMapLocF=new Set();facListSort='default';
  _persistFilters();renderInspectMap();renderFacList();
}
function _updateFacListFilterPanel(types,locs){
  if(!types||!locs){
    const _a=isAdminUser();const _m2=DB.g('catFacMeta')||{};
    const _f=(DB.g('facilities')||[]).filter(f=>_a||!(_m2[f.type]||{}).adminOnly);
    types=types||[...(new Set(_f.map(f=>f.type.split(' ').slice(1).join(' ')||f.type).filter(Boolean)))];
    const _sf2=(DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판'));
    locs=locs||[...new Set(_sf2.map(f=>(f.name.match(/\d+/)||[''])[0]).filter(Boolean))].sort();
  }
  const sChips=[{l:'양호',v:'ok',c:'#27ae60'},{l:'요주의',v:'warn',c:'#e67e22'},{l:'위험',v:'bad',c:'#c0392b'}];
  const sortSet=facListSort==='overdue'?new Set(['overdue']):new Set();
  _filterSec('facLFP_sort','정렬',_filterChip('⏰ 점검 오래된순',sortSet,'overdue',`setFacListSort('overdue')`,'#f0a500'),sortSet);
  _filterSec('facLFP_status','상태',sChips.map(({l,v,c})=>_filterChip(l,facMapStatusF,v,`_smfs('s','${v}');renderFacList();`,c)).join(''),facMapStatusF);
  _filterSec('facLFP_type','종류',(types||[]).map(v=>_filterChip(v,facMapTypeF,v,`_smfs('t','${v.replace(/'/g,"\\'")}');renderFacList();`,'#4fa8d0')).join(''),facMapTypeF);
  _filterSec('facLFP_loc','위치 (구간)',(locs||[]).map(v=>_filterChip(_zoneLbl(v),facMapLocF,v,`_smfs('l','${v.replace(/'/g,"\\'")}');renderFacList();`,'#9b59b6')).join(''),facMapLocF);
  const total=facMapStatusF.size+facMapTypeF.size+facMapLocF.size;
  ['facListFilterBadge'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.style.display=total?'inline-flex':'none';if(total)el.textContent=total;});
  const fc=document.getElementById('facListFilterCount');if(fc)fc.textContent=total?`(${total})`:'';
}
// ─── 재난/구조 필터 ───
function _updateResFilterPanels(){
  const dateActive=(resDateFrom||resDateTo)?1:0;
  const total=resTypeF.size+resStatusF.size+dateActive;
  ['resMapFilterBadge','resListFilterBadge'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.style.display=total?'inline-flex':'none';if(total)el.textContent=total;});
  ['resMapFilterCount','resListFilterCount'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.textContent=total?`(${total})` : '';});
  const inpSt='background:#0a1828;color:#4fa8d0;border:1px solid rgba(79,168,208,.3);border-radius:6px;padding:5px 6px;font-size:11px;width:100%;box-sizing:border-box;';
  const dateHtml=`<div style="display:flex;gap:6px;align-items:center;margin-top:4px;">
    <input type="date" value="${resDateFrom}" style="${inpSt}" onchange="setResDate('from',this.value)">
    <span style="color:rgba(255,255,255,.3);font-size:11px;flex-shrink:0;">~</span>
    <input type="date" value="${resDateTo}" style="${inpSt}" onchange="setResDate('to',this.value)">
  </div>`;
  const typeHtml=[{v:'🚨구조',l:'🚨 구조보고'},{v:'⚠️위험상황',l:'⚠️ 위험상황'}].map(({v,l})=>_filterChip(l,resTypeF,v,`setResTypeF('${v}')`)).join('');
  const stHtml=[{v:'진행중',l:'🔴 진행중/미조치'},{v:'종료',l:'✅ 종료/완료'}].map(({v,l})=>_filterChip(l,resStatusF,v,`setResStatusF('${v}')`)).join('');
  ['resMFP_date','resLFP_date'].forEach(id=>_filterSec(id,'📅 날짜',dateHtml,null,dateActive));
  ['resMFP_type','resLFP_type'].forEach(id=>_filterSec(id,'종류',typeHtml,resTypeF));
  ['resMFP_status','resLFP_status'].forEach(id=>_filterSec(id,'상태',stHtml,resStatusF));
  _syncOngoingBtn();
}
// 지도 '🔴 진행중' 토글 — 현재 사고만 보기 (상태 필터를 진행중 단독으로)
function toggleOngoingOnly(){
  const on=resStatusF.size===1&&resStatusF.has('진행중');
  resStatusF=on?new Set():new Set(['진행중']);
  _persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();
}
function _syncOngoingBtn(){
  const b=document.getElementById('resOngoingBtn');if(!b)return;
  const on=resStatusF.size===1&&resStatusF.has('진행중');
  b.style.background=on?'rgba(231,76,60,.92)':'rgba(11,28,48,.85)';
  b.style.color=on?'#fff':'#ff8a73';
  b.style.borderColor=on?'#ff5a45':'rgba(231,76,60,.5)';
}
function setResDate(which,v){
  if(which==='from')resDateFrom=v;else resDateTo=v;
  _maybeLoadArchiveForDateFilter();
  _updateResFilterPanels();renderRescueMap();renderResList();
}
// 조회 시작일이 보관 기준(1년)보다 앞이면 과거 기록을 1회 불러온 뒤 다시 그린다
function _maybeLoadArchiveForDateFilter(){
  if(!resDateFrom)return;
  const cutoff=new Date(Date.now()-_ARCHIVE_CUTOFF_DAYS*86400000).toISOString().slice(0,10);
  if(resDateFrom>=cutoff)return;
  Promise.all(['rescues','hazards'].map(_loadArchive)).then(()=>{renderRescueMap();renderResList();});
}
function setResTypeF(v){if(resTypeF.has(v))resTypeF.delete(v);else resTypeF.add(v);_persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();}
function setResStatusF(v){if(resStatusF.has(v))resStatusF.delete(v);else resStatusF.add(v);_persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();}
function resetResFilter(){resTypeF=new Set();resStatusF=new Set();const _d=_resDefaultDates();resDateFrom=_d.from;resDateTo=_d.to;_persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();}
// 시설물 카테고리 필터
function _updateResCatFilterPanel(){
  const _rm=DB.g('catFacMeta')||{};
  const rescueCats=(DB.g('catFac')||[]).filter(c=>(_rm[c]||{}).rescue);
  const defSet=new Set(_RES_DEFAULT_CATS);
  const catBadge=resFacCatH.size+resFacCatF.size;
  const el=document.getElementById('resCatFilterBadge');
  if(el){el.style.display=catBadge?'inline-flex':'none';if(catBadge)el.textContent=catBadge;}
  const cntEl=document.getElementById('resCatFilterCount');
  if(cntEl)cntEl.textContent=catBadge?`(${catBadge})`:'';
  const mkRow=(c,isDefault)=>{
    const active=isDefault?!resFacCatH.has(c):resFacCatF.has(c);
    const col=active?'#4fa8d0':'rgba(255,255,255,.25)';
    return `<div onclick="toggleResFacCat('${c.replace(/'/g,"\\'")}',${isDefault})" style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);cursor:pointer;">
      <div style="width:22px;height:22px;border-radius:50%;border:2px solid ${col};display:flex;align-items:center;justify-content:center;font-size:10px;color:${col};flex-shrink:0;">${active?'✓':''}</div>
      <span style="font-size:12px;color:${active?'#e0edf8':'rgba(255,255,255,.35)'};">${c}</span>
      ${isDefault?'<span style="font-size:9px;color:#3a6a8a;margin-left:auto;">기본</span>':''}
    </div>`;
  };
  const defCats=rescueCats.filter(c=>defSet.has(c));
  const otherCats=rescueCats.filter(c=>!defSet.has(c));
  const wrap=document.getElementById('resCFPContent');
  if(!wrap)return;
  wrap.innerHTML=(defCats.length?`<div style="font-size:10px;color:#3a6a8a;padding:6px 0 2px;font-weight:600;">기본 표시</div>${defCats.map(c=>mkRow(c,true)).join('')}`:'')
    +(otherCats.length?`<div style="font-size:10px;color:#3a6a8a;padding:8px 0 2px;font-weight:600;">추가 표시 (기본 OFF)</div>${otherCats.map(c=>mkRow(c,false)).join('')}`:'')
    +(rescueCats.length===0?'<div style="font-size:12px;color:rgba(255,255,255,.2);padding:12px 0;">재난지도 표시 카테고리 없음</div>':'');
}
function toggleResFacCat(type,isDefault){
  if(isDefault){if(resFacCatH.has(type))resFacCatH.delete(type);else resFacCatH.add(type);}
  else{if(resFacCatF.has(type))resFacCatF.delete(type);else resFacCatF.add(type);}
  _updateResCatFilterPanel();_applyRFacFilter();
}
function resetResCatFilter(){resFacCatH=new Set();resFacCatF=new Set();_updateResCatFilterPanel();_applyRFacFilter();}
function toggleResCatFilter(){
  const p=document.getElementById('resCatFilterPanel');
  const open=p.style.display==='flex';
  if(open){_closeResCatFilter();}
  else{p.style.display='flex';p.style.transform='translateY(0)';_updateResCatFilterPanel();_initFPDrag('resCFPHandle','resCatFilterPanel',_closeResCatFilter);}
}
function _closeResCatFilter(){
  const p=document.getElementById('resCatFilterPanel');
  p.style.transform='translateY(100%)';
  setTimeout(()=>{p.style.display='none';p.style.transform='translateY(0)';},220);
}
function toggleResMapFilter(){
  const p=document.getElementById('resMapFilterPanel');
  const open=p.style.display==='flex';
  if(open){_closeResMapFilter();}
  else{p.style.display='flex';p.style.transform='translateY(0)';_updateResFilterPanels();_initFPDrag('resMFPHandle','resMapFilterPanel',_closeResMapFilter);}
}
function _closeResMapFilter(){
  const p=document.getElementById('resMapFilterPanel');
  p.style.transform='translateY(100%)';
  setTimeout(()=>{p.style.display='none';p.style.transform='translateY(0)';},220);
}
function toggleResListFilter(){
  const p=document.getElementById('resListFilterPanel');
  const open=p.style.display==='flex';
  if(open){_closeResListFilter();}
  else{p.style.display='flex';p.style.transform='translateY(0)';_updateResFilterPanels();_initFPDrag('resLFPHandle','resListFilterPanel',_closeResListFilter);}
}
function _closeResListFilter(){
  const p=document.getElementById('resListFilterPanel');
  p.style.transform='translateY(100%)';
  setTimeout(()=>{p.style.display='none';p.style.transform='translateY(0)';},220);
}
function openFacFromMap(id){
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  selFacId=id;
  const hist=(DB.g('history')||[]).filter(h=>h.facId===id);
  const last=hist.length?hist[hist.length-1]:null;
  document.getElementById('facPopTitle').textContent=f.type.split(' ')[0]+' '+f.name;
  document.getElementById('facPopMeta').innerHTML=`<span style="color:${SC(f.status)};font-weight:700;">${SL(f.status)}</span> · ${_esc(f.loc||'-')}<br>최근 점검: ${last?last.date+' ('+SL(last.status)+')':'없음'}`;
  document.getElementById('resPopup').classList.remove('on');
  document.getElementById('facPopup').classList.add('on');
}
let _facListLimit=50,_facListSig='';
function _moreFacList(){_facListLimit+=50;renderFacList();}
function renderFacList(){
  const _admin=isAdminUser();const _meta=DB.g('catFacMeta')||{};
  const facs=(DB.g('facilities')||[]).filter(f=>_admin||!(_meta[f.type]||{}).adminOnly);
  const types=[...new Set(facs.map(f=>f.type.split(' ').slice(1).join(' ')||f.type).filter(Boolean))];
  const _sf=(DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판'));
  const locs=[...new Set(_sf.map(f=>(f.name.match(/\d+/)||[''])[0]).filter(Boolean))].sort();
  _updateFacListFilterPanel(types,locs);
  const filtered=facs.filter(f=>{
    const sOk=facMapStatusF.size===0||facMapStatusF.has(f.status);
    const tOk=facMapTypeF.size===0||[...facMapTypeF].some(t=>f.type.includes(t));
    const lOk=facMapLocF.size===0||[...facMapLocF].some(v=>_facInZone(f,v));
    return sOk&&tOk&&lOk;
  });
  // 시설별 마지막 점검일(가장 최근 history 항목) — 점검 오래된순 정렬·표시에 사용
  const lastInspMap={};
  (DB.g('history')||[]).forEach(h=>{if(!lastInspMap[h.facId]||h.id>lastInspMap[h.facId])lastInspMap[h.facId]=h.id;});
  if(facListSort==='overdue')filtered.sort((a,b)=>(lastInspMap[a.id]||0)-(lastInspMap[b.id]||0));
  // 필터·정렬이 바뀌면 페이지 한도 리셋
  const _sig=[...facMapStatusF].join()+'|'+[...facMapTypeF].join()+'|'+[...facMapLocF].join()+'|'+facListSort;
  if(_sig!==_facListSig){_facListSig=_sig;_facListLimit=50;}
  const _tot=filtered.length;
  let html=filtered.slice(0,_facListLimit).map(f=>{
    const li=lastInspMap[f.id];
    const dDays=li?Math.floor((Date.now()-li)/86400000):null;
    const overdueBadge=facListSort==='overdue'?`<span style="font-size:9px;font-weight:700;color:${dDays===null||dDays>=90?'#e74c3c':dDays>=30?'#f0a500':'#4a7090'};margin-top:2px;display:block;">⏰ ${dDays===null?'미점검':dDays+'일 전 점검'}</span>`:'';
    return `<div class="lcard" style="padding:7px 10px;border-left:3px solid ${SC(f.status)};" onclick="openFacDetail(${f.id})">
      <div class="lico" style="width:30px;height:30px;font-size:14px;border-color:${SC(f.status)};color:${SC(f.status)};">${_esc(f.type.split(' ')[0])}</div>
      <div class="linfo"><div class="lname" style="font-size:12px;">${_esc(f.name)}</div>
        <div class="lmeta">${_esc(f.type.split(' ').slice(1).join(' ')||f.type)} · ${_esc(f.loc||'-')} · ${f.lat?'📍':''}</div>
        ${overdueBadge}
      </div>
      <span class="lbadge" style="background:${SC(f.status)}22;color:${SC(f.status)};">${SL(f.status)}</span>
    </div>`;
  }).join('');
  if(_tot>_facListLimit){
    html+=`<button onclick="_moreFacList()" style="width:100%;margin-top:8px;padding:11px;border-radius:10px;border:1px solid rgba(79,168,208,.3);background:rgba(79,168,208,.08);color:#4fa8d0;font-size:13px;font-weight:700;cursor:pointer;">▾ 더 보기 (${_tot-_facListLimit}건 더)</button>`;
  }
  document.getElementById('facListWrap').innerHTML=html||'<div class="empty"><div class="empty-ico">🛠️</div><div class="empty-txt">해당 조건 없음</div><button onclick="resetFacListFilter()" style="margin-top:10px;padding:7px 16px;background:rgba(79,168,208,.12);border:1px solid rgba(79,168,208,.35);color:#4fa8d0;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">🔄 필터 초기화</button></div>';
}

function renderInspectStats(){
  const facs=DB.g('facilities')||[];const hist=(DB.g('history')||[]).slice().reverse().slice(0,8);
  document.getElementById('fs-tot').textContent=facs.length;
  document.getElementById('fs-bad').textContent=facs.filter(f=>f.status==='bad').length;
  document.getElementById('fs-warn').textContent=facs.filter(f=>f.status==='warn').length;
  document.getElementById('fs-ok').textContent=facs.filter(f=>f.status==='ok').length;
  const tm={};facs.forEach(f=>{tm[f.type]=(tm[f.type]||0)+1;});
  document.getElementById('facTypeStatWrap').innerHTML=Object.entries(tm).map(([k,v])=>
    `<div class="type-row" style="pointer-events:none;"><span class="t-ico">${_esc(k.split(' ')[0])}</span><span class="t-lbl">${_esc(k.split(' ').slice(1).join(' '))}</span><span class="t-cnt">${v}개</span></div>`).join('');
  document.getElementById('facRecentWrap').innerHTML=hist.length?hist.map(h=>
    `<div style="background:#060d1a;border-radius:8px;padding:9px 11px;margin-bottom:5px;"><div style="font-size:10px;color:rgba(255,255,255,.25);">${h.date} · ${_esc(h.author||'-')}</div><div style="font-size:12px;font-weight:600;color:${SC(h.status)};margin-top:2px;">${_esc(h.facName)} — ${SL(h.status)}</div>${h.note?`<div style="font-size:11px;color:rgba(255,255,255,.35);margin-top:3px;">${_esc(h.note)}</div>`:''}</div>`).join(''):'<div class="muted" style="font-size:12px;padding:5px 0;">점검 이력 없음</div>';
}

// 시설물 상세 (목록 탭에서 탭하면 모달로 상세 + 점검/이력 버튼)
function openFacDetail(id){
  const facs=DB.g('facilities')||[];const f=facs.find(x=>x.id===id);if(!f)return;
  selFacId=id;window._selFacDetailId=id;
  const hist=(DB.g('history')||[]).filter(h=>h.facId===id);
  const lastInsp=hist.length?hist[hist.length-1]:null;
  document.getElementById('facDetailTitle').textContent=f.name;
  document.getElementById('facDetailContent').innerHTML=`
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
      <div style="font-size:32px;">${_esc(f.type.split(' ')[0])}</div>
      <div><div style="font-size:14px;font-weight:700;color:#e0edf8;">${_esc(f.name)}</div>
        <div style="font-size:12px;color:${SC(f.status)};font-weight:600;margin-top:2px;">${SL(f.status)}</div>
      </div>
    </div>
    <div style="background:#060d1a;border-radius:9px;padding:11px 12px;font-size:12px;color:#7a9cb8;line-height:2.1;">
      <b style="color:#c0d8ec;">종류:</b> ${_esc(f.type)}<br>
      <b style="color:#c0d8ec;">위치:</b> ${_esc(f.loc||'-')}<br>
      <b style="color:#c0d8ec;">좌표:</b> ${f.lat?f.lat.toFixed(5)+', '+f.lng.toFixed(5):'GPS 미등록'}<br>
      <b style="color:#c0d8ec;">설치일:</b> ${_esc(f.install||'-')}<br>
      <b style="color:#c0d8ec;">등록자:</b> ${_esc(f.author||'-')}<br>
      <b style="color:#c0d8ec;">점검 횟수:</b> ${hist.length}회<br>
      <b style="color:#c0d8ec;">최근 점검:</b> ${lastInsp?lastInsp.date+' ('+SL(lastInsp.status)+')':'없음'}<br>
      ${f.note?`<b style="color:#c0d8ec;">비고:</b> ${_esc(f.note)}`:''}
    </div>`;
  const mapBtn=document.getElementById('facDetailMapBtn');
  if(mapBtn)mapBtn.style.display=(f.lat&&f.lng)?'block':'none';
  const adminBtns=document.getElementById('facDetailAdminBtns');
  if(adminBtns)adminBtns.style.display=isAdminUser()?'flex':'none';
  document.getElementById('modalFacDetail').classList.add('on');
  // 지도 핀에서 왔을 때도 동일하게 작동
  document.getElementById('facPopup').classList.remove('on');
}
function viewOnFacMap(){
  const f=(DB.g('facilities')||[]).find(x=>x.id===selFacId);
  if(!f||!f.lat)return;
  closeM('modalFacDetail');
  if(curApp!=='inspect'){openApp('inspect');}
  else{switchTab(1,document.getElementById('nv1'));}
  setTimeout(function(){
    try{if(mapI){mapI.setCenter(new kakao.maps.LatLng(f.lat,f.lng));mapI.setLevel(4);}renderInspectMap();}catch(e){}
    openFacFromMap(f.id);
  },220);
}

function openInspModalFromDetail(){closeM('modalFacDetail');openInspModal();}
function openHistModalFromDetail(){closeM('modalFacDetail');openHistModal();}

function openInspModal(){
  const f=(DB.g('facilities')||[]).find(x=>x.id===selFacId);if(!f)return;
  document.getElementById('inspTarget').value=f.name;
  document.getElementById('inspDateTime').value=now(); // 자동, 수정불가
  document.getElementById('inspStatus').value=f.status;
  document.getElementById('inspNote').value='';
  document.getElementById('inspAuthor').value=getAuthor();
  document.getElementById('prevInsp').innerHTML='📸 현장 사진';
  document.getElementById('modalInsp').classList.add('on');closeDB();
}
function submitInsp(){
  const facs=DB.g('facilities')||[];const idx=facs.findIndex(x=>x.id===selFacId);if(idx===-1)return;
  const ns=document.getElementById('inspStatus').value;
  const note=document.getElementById('inspNote').value;
  const author=document.getElementById('inspAuthor').value;
  facs[idx].status=ns;
  facs[idx].statusAt=Date.now(); // 동시 점검 충돌 시 "최신 점검 우선" 판정용 타임스탬프
  const hist=DB.g('history')||[];
  const inspDT=document.getElementById('inspDateTime')?.value||now();
  const h={id:Date.now(),facId:selFacId,facName:facs[idx].name,date:inspDT,status:ns,note,author,photo:_photoUrl('prevInsp')};
  hist.push(h);DB.s('facilities',facs);DB.s('history',hist);
  if(ns==='bad')pushNoti(`점검 위험: ${facs[idx].name}`,'🚨','fac_bad',{app:'inspect',tab:2,id:selFacId});
  else if(ns==='warn')pushNoti(`보수필요: ${facs[idx].name}`,'⚠️','fac_warn',{app:'inspect',tab:2,id:selFacId});
  syncToSheets('inspection',h);
  try{renderInspectMap();}catch(e){}closeM('modalInsp');toast('✅ 점검 저장');updateSummary();
}
function openHistModal(){
  const f=(DB.g('facilities')||[]).find(x=>x.id===selFacId);if(!f)return;
  _renderHistModal(f);
  document.getElementById('modalHist').classList.add('on');closeDB();
  // 1년 이전 점검이력은 조회 시에만 1회 불러옴 — 로드되면 다시 그려서 전체 이력 반영
  if(!_archiveLoaded['history'])_loadArchive('history').then(()=>{if(document.getElementById('modalHist').classList.contains('on'))_renderHistModal(f);});
}
function _renderHistModal(f){
  const hist=(DB.g('history')||[]).filter(h=>h.facId===f.id).reverse();
  document.getElementById('histTitleEl').textContent=f.name+' · '+hist.length+'건';
  document.getElementById('histContent').innerHTML=hist.length?hist.map(h=>`
    <div style="background:#060d1a;border-radius:8px;padding:10px 11px;margin-bottom:5px;">
      <div style="font-size:10px;color:rgba(255,255,255,.5);">${h.date} · ${_esc(h.author||'-')}</div>
      <div style="font-size:12px;font-weight:600;color:${SC(h.status)};margin-top:2px;">${SL(h.status)}</div>
      ${h.note?`<div style="font-size:11px;color:rgba(255,255,255,.55);margin-top:3px;line-height:1.5;">${_esc(h.note)}</div>`:''}
    </div>`).join(''):'<div class="empty"><div class="empty-txt">점검 이력 없음</div><button onclick="closeM(&#39;modalHist&#39;);openInspModal();" style="margin-top:10px;padding:7px 16px;background:rgba(79,168,208,.12);border:1px solid rgba(79,168,208,.35);color:#4fa8d0;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">📝 점검 등록</button></div>';
}
var _editFacId=null;
function openAddFac(){
  _editFacId=null;
  document.getElementById('addFacModalTitle').textContent='🆕 시설물 등록';
  const _catMeta=DB.g('catFacMeta')||{};const _cats=(DB.g('catFac')||[]).filter(c=>isAdminUser()||!(_catMeta[c]||{}).adminOnly);
  fillSel('facTypeSel',_cats);
  document.getElementById('facInstall').value=today();
  ['facNameIn','facGpsIn','facNote'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('facInitSt').value='ok';
  const _fa=document.getElementById('facAuthor');_fa.value=getAuthor();_fa.disabled=true;
  document.getElementById('prevFac').innerHTML='📸 촬영 또는 앨범';
  try{gpsFromMap('facGpsIn','inspect');}catch(e){}
  const _ic=window._lastInspectCrosshairCoord;
  const _li=document.getElementById('facLocIn');
  if(_li){const _ls=_ic?_nearestSign(_ic.lat,_ic.lng):null;_li.value=_ls||'';}
  document.getElementById('modalAddFac').classList.add('on');
}
function openEditFac(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 수정 가능');return;}
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  _editFacId=id;
  document.getElementById('addFacModalTitle').textContent='✏️ 시설물 수정';
  fillSel('facTypeSel',DB.g('catFac')||[]);
  document.getElementById('facTypeSel').value=f.type;
  document.getElementById('facNameIn').value=f.name||'';
  document.getElementById('facLocIn').value=f.loc||'';
  document.getElementById('facGpsIn').value=f.lat&&f.lng?f.lat.toFixed(5)+', '+f.lng.toFixed(5):'';
  document.getElementById('facInstall').value=f.install||'';
  document.getElementById('facNote').value=f.note||'';
  document.getElementById('facInitSt').value=f.status||'ok';
  const _fa=document.getElementById('facAuthor');_fa.value=f.author||getAuthor();_fa.disabled=true;
  document.getElementById('prevFac').innerHTML='📸 촬영 또는 앨범';
  closeM('modalFacDetail');
  document.getElementById('modalAddFac').classList.add('on');
}
function deleteFac(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 삭제 가능');return;}
  if(!confirm('이 시설물을 삭제하시겠습니까?'))return;
  DB.s('facilities',(DB.g('facilities')||[]).filter(f=>f.id!==id));
  closeM('modalFacDetail');
  try{renderInspectMap();}catch(e){}renderFacList();toast('🗑️ 삭제');updateSummary();
}
function submitAddFac(){
  const name=document.getElementById('facNameIn').value.trim();if(!name){toast('⚠️ 명칭 입력');return;}
  const gs=document.getElementById('facGpsIn').value;
  let lat=null,lng=null;
  if(gs){const p=gs.split(',');lat=parseFloat(p[0]);lng=parseFloat(p[1]);if(isNaN(lat)||isNaN(lng)){lat=null;lng=null;}}
  const status=document.getElementById('facInitSt').value;
  const facs=DB.g('facilities')||[];
  const data={type:document.getElementById('facTypeSel').value,name,loc:document.getElementById('facLocIn').value,status,lat,lng,install:document.getElementById('facInstall').value,note:document.getElementById('facNote').value,author:document.getElementById('facAuthor').value,photo:_photoUrl('prevFac')};
  if(_editFacId){
    const idx=facs.findIndex(f=>f.id===_editFacId);
    if(idx!==-1)facs[idx]=Object.assign(facs[idx],data);
    _editFacId=null;
    DB.s('facilities',facs);
    try{renderInspectMap();}catch(e){}renderFacList();closeM('modalAddFac');toast('✅ 시설물 수정');updateSummary();
  } else {
    facs.push(Object.assign({id:Date.now()},data));
    DB.s('facilities',facs);
    if(status==='bad')pushNoti(`위험 시설물: ${name}`,'🚨','fac_bad',{app:'inspect',tab:2});
    try{renderInspectMap();}catch(e){}closeM('modalAddFac');toast('✅ 시설물 등록');updateSummary();
  }
}

// ══════════════════════════════════════════
// 특보운영
// ══════════════════════════════════════════
// 단계별 최소 응소 인원 (별표 10 사무소 운영기준)
const ALERT_REQS={
  '예비특보':{사무소:[{role:'당직',min:1}],분소:[]},
  'Ⅰ단계(주의보)':{사무소:[{role:'당직',min:1},{role:'비상근무',min:1}],분소:[{role:'당직',min:1}]},
  'Ⅱ단계(경보)':{사무소:[{role:'당직',min:1},{role:'비상근무',min:1},{role:'과장',min:1}],분소:[{role:'당직',min:1},{role:'비상근무',min:1}]},
  'Ⅲ단계':{사무소:[{role:'당직',min:1},{role:'과장',min:1},{role:'비상근무',min:1}],분소:[{role:'사무소 전직원',min:1}]}
};
const ALERT_LEVEL_COLORS={'예비특보':'#f0d040','Ⅰ단계(주의보)':'#ffa040','Ⅱ단계(경보)':'#ff8a80','Ⅲ단계':'#d7aefb'};
// 응소·관측 단위: 사무소(본소) + 분소. 대청분소는 대피소 단위로 세분화 운영.
const ALERT_GROUPS=[
  {name:'사무소',label:'사무소(본소)',ico:'🏢',reqType:'사무소',stations:[{loc:'사무소',label:'사무소(본소)'}]},
  {name:'대청분소',label:'대청분소 (대피소)',ico:'⛺',reqType:'분소',stations:[
    {loc:'희운각',label:'희운각대피소',shelter:true},{loc:'양폭',label:'양폭대피소',shelter:true},{loc:'수렴동',label:'수렴동대피소',shelter:true},{loc:'소청',label:'소청대피소',shelter:true},{loc:'중청',label:'중청대피소',shelter:true}]},
  {name:'백담분소',label:'백담분소',ico:'🏔️',reqType:'분소',stations:[{loc:'백담분소',label:'백담분소'}]},
  {name:'오색분소',label:'오색분소',ico:'🏔️',reqType:'분소',stations:[{loc:'오색분소',label:'오색분소'}]},
  {name:'한계산성분소',label:'한계산성분소',ico:'🏔️',reqType:'분소',stations:[{loc:'한계산성분소',label:'한계산성분소'}]},
  {name:'점봉산분소',label:'점봉산분소',ico:'🏔️',reqType:'분소',stations:[{loc:'점봉산분소',label:'점봉산분소'}]}
];
// 기상청 자동 우량계 관측 지점 (강수·적설 보고 전용 — 응소인원 없음)
const RAIN_STATIONS=[
  {loc:'미시령',   label:'미시령(기상대)', obs:true},
  {loc:'오색리',   label:'오색(기상대)',   obs:true},
  {loc:'설악댐',   label:'설악댐(관측소)',  obs:true},
  {loc:'마등령',   label:'마등령(기상대)', obs:true},
  {loc:'청봉관측', label:'청봉(관측소)',   obs:true},
  {loc:'백담계곡', label:'백담계곡(관측소)',obs:true},
  {loc:'한계성',   label:'한계산성(관측소)',obs:true},
];
// 전체 관측소(응소·관측 단위) 평탄 목록
const ALERT_STATIONS=[];ALERT_GROUPS.forEach(g=>g.stations.forEach(s=>ALERT_STATIONS.push({loc:s.loc,label:s.label,group:g.name,reqType:g.reqType,shelter:!!s.shelter})));
RAIN_STATIONS.forEach(s=>ALERT_STATIONS.push({loc:s.loc,label:s.label,group:'우량계',reqType:'obs',obs:true}));
const _stationLabel=loc=>{const s=ALERT_STATIONS.find(x=>x.loc===loc);return s?s.label:(loc||'사무소');};
let _alertLevel='',_alertType='',_respLoc='',_respRole='',_reportInterval=60;
let _reportLoc='',_reportOpId=null,_alertReminderTimer=null;
// '2026-06-24 21:30' → ms (관측 보고 알림 주기 계산용)
function _alertTimeMs(s){if(!s)return 0;const m=String(s).match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);if(!m)return 0;return new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5]).getTime();}
// 단계별 필요 인원 (사무소/분소 기준)
function _reqOf(level,reqType){const req=ALERT_REQS[level]||{};return reqType==='사무소'?(req.사무소||[]):(req.분소||[]);}
// 특정 관측소의 최신 관측 보고
function _latestReport(op,loc){const rs=(op.reports||[]).filter(r=>r.loc===loc);if(!rs.length)return null;return rs.reduce((a,b)=>((b.at||0)>(a.at||0)?b:a));}
// ── 평시 상시 당직 인원 (특보 없어도 근무) ──
// 본소 1 · 백담분소 1 · 대피소 각 2 · 그 외 분소 0(특보 시 응소)
const DUTY_BASELINE={'사무소':1,'백담분소':1,'오색분소':0,'한계산성분소':0,'점봉산분소':0,'희운각':2,'양폭':2,'수렴동':2,'소청':2,'중청':2};
const _dutyOf=loc=>DUTY_BASELINE[loc]||0;
const _grpDuty=g=>g.stations.reduce((s,st)=>s+_dutyOf(st.loc),0);
// 평시 당직 현황 카드 (특보 없을 때)
function _renderDutyBaseline(){
  return `<div class="ao-card">
    <div class="ao-sec-hd" style="margin-top:0;"><span class="bar" style="background:#5fcf8f;"></span>🟢 평시 당직 현황</div>
    <div style="font-size:12.5px;color:#cfe2f2;line-height:2;">
      🏢 <b>본소(사무소)</b> — 당직 <b style="color:#7ee0a8;">1명</b> 상시<br>
      🏔️ <b>백담분소</b> — 당직 <b style="color:#7ee0a8;">1명</b> 상시<br>
      ⛺ <b>대피소</b> (희운각·양폭·수렴동·소청·중청) — 각 <b style="color:#7ee0a8;">2명</b> 상시
    </div>
    <div style="font-size:10px;color:#5a7e98;margin-top:8px;line-height:1.6;">※ 오색·한계산성·점봉산 분소는 상시 당직 없음(특보 시 응소).<br>주의보 시 백담은 상시 당직자가 특보 당직 겸직, 경보 시 1명 추가 응소.</div>
  </div>`;
}
// 응소 현황 요약 (일회성) — 상시 당직 + 응소 합산해 충족/부족 한 줄
function _renderRespSummary(active,opLevel){
  const rows=ALERT_GROUPS.map(g=>{
    const reqs=_reqOf(opLevel,g.reqType);
    const required=reqs.reduce((s,r)=>s+r.min,0);
    const base=_grpDuty(g);
    const reg=active.responders.filter(r=>g.stations.some(s=>s.loc===(r.loc||'사무소'))).length;
    const eff=base+reg, shortage=Math.max(0,required-eff), ok=required===0||shortage===0;
    const badge=required===0
      ? `<span style="font-size:10px;color:#6a94b0;">대기</span>`
      : ok? `<span style="font-size:10px;color:#5fcf8f;font-weight:800;">✅ 충족</span>`
          : `<span style="font-size:10px;color:#ff8a73;font-weight:800;">⚠️ ${shortage}명 부족</span>`;
    const det=[];if(base)det.push(`상시 ${base}`);if(reg)det.push(`응소 ${reg}`);
    const sub=det.length?`${det.join(' + ')}${required?` / 필요 ${required}`:''}`:(required?`필요 ${required}`:'평시');
    return `<div style="display:flex;align-items:center;gap:8px;padding:7px 2px;border-bottom:1px solid rgba(255,255,255,.04);">
      <span style="font-size:12.5px;color:#dceaf6;min-width:104px;flex-shrink:0;">${g.ico} ${_esc(g.label)}</span>
      <span style="font-size:11px;flex:1;color:#5a7e98;">${sub}</span>${badge}
    </div>`;
  }).join('');
  return `<div class="ao-card" style="padding:4px 12px 8px;">${rows}<div style="font-size:9px;color:#46708f;margin-top:6px;">상시=평시 당직 자동 반영 · 응소 등록은 🚨 입력 탭</div></div>`;
}
// 관측 현황 요약 (지속) — 거점별 최신값 + 경과시간 + 미보고 강조
function _renderObsSummary(active){
  const itvMin=active.reportInterval||60, itvMs=itvMin*60000;
  const start=active.startedAtMs||_alertTimeMs(active.startedAt)||0;
  const mt=_alertMeasureType(active), NOW=Date.now();
  const targets=[];
  ALERT_STATIONS.filter(s=>!s.obs).forEach(s=>{
    const manned=_dutyOf(s.loc)>0||active.responders.some(r=>(r.loc||'사무소')===s.loc)||(active.reports||[]).some(r=>r.loc===s.loc);
    if(manned)targets.push(s);
  });
  ALERT_STATIONS.filter(s=>s.obs&&(active.reports||[]).some(r=>r.loc===s.loc)).forEach(s=>targets.push(s));
  if(!targets.length)return `<div class="ao-card" style="font-size:11px;color:#456a85;padding:10px 12px;">관측 거점이 아직 없습니다</div>`;
  const valTxt=last=>{
    if(!last)return '<span style="color:#456a85;">보고 없음</span>';
    if(mt==='snow')return `❄️ <b style="color:#9ce0f0;">${_esc(String(last.snow??'-'))}</b>cm`;
    if(mt==='rain')return `🌧️ <b style="color:#a8cdf5;">${_esc(String(last.rain??'-'))}</b>mm`;
    return `❄️ <b style="color:#9ce0f0;">${_esc(String(last.snow??'-'))}</b> · 🌧️ <b style="color:#a8cdf5;">${_esc(String(last.rain??'-'))}</b>`;
  };
  const _ov=s=>{const last=_latestReport(active,s.loc);const at=last?(last.at||_alertTimeMs(last.time)):0;return last?(NOW-at>itvMs):(start>0&&NOW-start>itvMs);};
  const rows=targets.map(s=>{
    const last=_latestReport(active,s.loc), at=last?(last.at||_alertTimeMs(last.time)):0, overdue=_ov(s);
    let ago='-';if(at){const m=Math.floor((NOW-at)/60000);ago=m>=60?Math.floor(m/60)+'시간 '+(m%60)+'분 전':m+'분 전';}
    return `<div style="display:flex;align-items:center;gap:8px;padding:7px 2px;border-bottom:1px solid rgba(255,255,255,.04);${overdue?'background:rgba(231,76,60,.07);border-radius:6px;':''}">
      <span style="font-size:12px;color:${overdue?'#ff9e80':'#cfe2f2'};min-width:92px;flex-shrink:0;">${s.obs?'📡 ':''}${_esc(s.label)}</span>
      <span style="font-size:12px;flex:1;">${valTxt(last)}</span>
      <span style="font-size:10px;color:${overdue?'#ff8a73':'#6a96b4'};font-weight:${overdue?'800':'400'};flex-shrink:0;">${overdue?'⏰ 미보고':_esc(ago)}</span>
    </div>`;
  }).join('');
  const ovCnt=targets.filter(_ov).length;
  const head=`<div style="font-size:10px;color:#6a94b0;margin-bottom:5px;">보고 주기 ${itvMin>=60?(itvMin/60)+'시간':itvMin+'분'} · ${ovCnt?`<span style="color:#ff8a73;font-weight:800;">미보고 ${ovCnt}곳</span>`:'<span style="color:#5fcf8f;font-weight:700;">전 거점 양호</span>'}</div>`;
  return `<div class="ao-card" style="padding:8px 12px;">${head}${rows}</div>`;
}
// 특보 종류에 따른 측정 항목: 대설→snow, 호우·태풍→rain, 혼합→both
function _alertMeasureType(op){const types=(op.alerts||[]).map(a=>a.type||'');const hasRain=types.some(t=>t.includes('호우')||t.includes('태풍'));const hasSnow=types.some(t=>t.includes('대설'));if(hasRain&&hasSnow)return'both';if(hasSnow)return'snow';return'rain';}
// ── 특보 발령 단계 모델 (수동·자동 공통, 발령 목록 op.alerts[]) ──
const ALERT_STAGE_ORDER=['예비특보','Ⅰ단계(주의보)','Ⅱ단계(경보)','Ⅲ단계'];
function _stageRank(s){const i=ALERT_STAGE_ORDER.indexOf(s);return i<0?0:i;}
function _stageShort(s){return s==='Ⅰ단계(주의보)'?'주의보':s==='Ⅱ단계(경보)'?'경보':s;}
// 기상청 특보 등급('경보'/'주의보'/'예비특보') → 내부 운영 단계
function _kmaStage(lvl){return lvl==='경보'?'Ⅱ단계(경보)':((lvl||'').indexOf('예비')>=0?'예비특보':'Ⅰ단계(주의보)');}
// 발령 목록(구버전 op.level/type 자동 보정)
function _opAlerts(op){
  if(op.alerts&&op.alerts.length)return op.alerts;
  if(op.level)return[{type:op.type||'기타',stage:op.level,source:(op.createdBy&&String(op.createdBy).indexOf('자동')>=0)?'auto':'manual'}];
  return[];
}
// 운영 인력 단계 = 발령된 특보 중 최고 단계
function _opLevel(op){const al=_opAlerts(op);if(!al.length)return'예비특보';return al.reduce((hi,a)=>_stageRank(a.stage)>_stageRank(hi)?a.stage:hi,al[0].stage);}
// 기상청 발효 특보(alertMap)를 {type,stage} 목록으로 정규화 (타입별 최고등급)
function _kmaLiveList(alertMap){
  const seen={},out=[];
  Object.keys(alertMap||{}).forEach(k=>{(alertMap[k].reasons||[]).forEach(r=>{
    const lvl=r.indexOf('경보')>=0?'경보':(r.indexOf('주의보')>=0?'주의보':'');
    const type=r.replace('경보','').replace('주의보','');
    if(!type||!lvl)return;
    const stage=_kmaStage(lvl);
    if(!seen[type]){seen[type]={type,stage};out.push(seen[type]);}
    else if(_stageRank(stage)>_stageRank(seen[type].stage))seen[type].stage=stage;
  });});
  return out;
}
// 마지막으로 화면에 표시된 공식 기상청 특보 (추정값 제외)
window._kmaLiveAlerts=window._kmaLiveAlerts||[];

let _alertTab=1; // 1:목록 2:통계 3:입력
function alertTab(n){_alertTab=n;renderAlertView();}
function _updateAlertNav(){
  [1,2,3].forEach(i=>{const el=document.getElementById('anv'+i);if(el)el.classList.toggle('on',_alertTab===i);});
}
function renderAlertView(){
  try{_updateCrisisBanner();}catch(e){}
  const ops=DB.g('alertOps')||[];
  const active=ops.find(o=>!o.closedAt);
  // 관측 리마인더는 탭과 무관하게 운영 중이면 항상 동작
  if(active){active.responders=active.responders||[];active.reports=active.reports||[];active.alerts=active.alerts||_opAlerts(active);_startAlertReminder();}
  else{_stopAlertReminder();}
  _updateAlertNav();
  const _wrapEl=document.getElementById('alertViewWrap');
  if(!_wrapEl)return;
  if(_alertTab===2){_wrapEl.innerHTML=_renderAlertStats(ops);return;}
  if(_alertTab===3){_wrapEl.innerHTML=_renderAlertInput(active);return;}

  // ── 목록 탭 ──
  // 기상청 실시간 발효 특보 (자동 발령 근거)
  const kmaLive=window._kmaLiveAlerts||[];
  let wxHtml='';
  if(kmaLive.length){
    wxHtml=`<div class="ao-wx">
      <div style="font-size:10px;color:#5d92bc;font-weight:800;letter-spacing:.3px;margin-bottom:7px;">📡 기상청 실시간 발효 특보</div>
      ${kmaLive.map(a=>`<div class="ao-wx-chip"><span class="ao-level-badge ao-level-${a.stage.indexOf('Ⅱ')>=0?'Ⅱ단계':'Ⅰ단계'}">${_stageShort(a.stage)}</span> <span style="color:#dceaf6;">${_esc(a.type||'')}</span></div>`).join('')}
    </div>`;
  } else {
    wxHtml=`<div class="ao-wx-empty">☀️ 현재 기상청 발효 특보 없음</div>`;
  }

  // 활성 특보운영 — 분소별 응소 현황 + 시간별 기상관측
  let activeHtml='';
  if(active){
    const opLevel=_opLevel(active);
    const lvColor=ALERT_LEVEL_COLORS[opLevel]||'#4fa8d0';
    const itv=active.reportInterval||60;
    const mt=_alertMeasureType(active);
    // 경과 시간
    let elapsed='';
    if(active.startedAtMs){const ms=Date.now()-active.startedAtMs,h=Math.floor(ms/3600000),m=Math.floor((ms%3600000)/60000);elapsed=(h>0?h+'시간 ':'')+m+'분 경과';}
    const alertChips=active.alerts.map((a,ai)=>`<span class="ao-alert-chip ${a.source==='auto'?'auto':'manual'}">${a.source==='auto'?'📡자동':'✋수동'} <b>${_esc(a.type)}${_stageShort(a.stage)}</b>${isAdminUser()?`<span onclick="removeAlertItem(${active.id},${ai})" style="cursor:pointer;color:#ff6b5b;margin-left:4px;font-weight:800;">×</span>`:''}</span>`).join('');
    // 히어로 배너 + 요약 stat + 상세
    activeHtml=`
      <div class="ao-hero" style="background:linear-gradient(135deg,${lvColor}26,${lvColor}0d);border:1.5px solid ${lvColor}55;">
        <div class="ao-hero-top">
          <div>
            <span class="ao-hero-live" style="color:${lvColor};"><span class="ao-pulse"></span>특보운영 중</span>
            <div class="ao-hero-lv" style="color:${lvColor};">${_esc(opLevel)}</div>
            <div class="ao-hero-meta">🕐 ${_esc(active.startedAt||'')} 시작${elapsed?' · '+elapsed:''}</div>
            <div class="ao-hero-meta">⏱️ 관측 보고 주기: ${itv>=60?(itv/60)+'시간':itv+'분'}마다</div>
          </div>
          ${isAdminUser()?`<button onclick="endAlertOps(${active.id})" class="ao-end-btn">운영 종료</button>`:''}
        </div>
      </div>

      <div class="ao-stats">
        <div class="ao-stat"><div class="ao-stat-num" style="color:${lvColor};">${active.alerts.length}</div><div class="ao-stat-lbl">발효 특보</div></div>
        <div class="ao-stat"><div class="ao-stat-num" style="color:#7ee0a8;">${active.responders.length}</div><div class="ao-stat-lbl">응소 인원</div></div>
        <div class="ao-stat"><div class="ao-stat-num" style="color:#a8cdf5;">${active.reports.length}</div><div class="ao-stat-lbl">관측 보고</div></div>
      </div>

      <div class="ao-card">
        <div class="ao-sec-hd" style="margin-top:0;"><span class="bar" style="background:#ff8a80;"></span>🚨 발령 특보</div>
        <div>${alertChips||'<span style="font-size:11px;color:#456a85;">발령된 특보 없음</span>'} ${isAdminUser()?`<button onclick="openAlertStart()" class="ao-add-alert">+ 특보 발령</button>`:''}</div>
        ${active.note?`<div style="font-size:12px;color:#9fc0da;margin-top:8px;background:rgba(255,255,255,.03);border-radius:8px;padding:7px 10px;">📝 ${_esc(active.note)}</div>`:''}
      </div>

      <div class="ao-sec-hd"><span class="bar"></span>👤 응소 현황 <span style="font-size:9px;color:#46708f;font-weight:600;margin-left:auto;">일회성 · 입력은 🚨 입력 탭</span></div>
      ${_renderRespSummary(active,opLevel)}

      <div class="ao-sec-hd"><span class="bar" style="background:#4fc0a0;"></span>📡 관측 현황 <span style="font-size:9px;color:#46708f;font-weight:600;margin-left:auto;">주기마다 지속 보고</span></div>
      ${_renderObsSummary(active)}

      <div class="ao-sec-hd"><span class="bar" style="background:#4fc0a0;"></span>📊 누적 관측 요약</div>
      ${_renderCumulativeSummary(active)}

      <div class="ao-sec-hd"><span class="bar" style="background:#6e96e6;"></span>🕐 시간대별 관측 기록</div>
      ${_renderReportsTable(active)}`;
  } else {
    activeHtml=`<div class="ao-empty">
      <div class="ao-empty-ico">🌀</div>
      <div class="ao-empty-msg">현재 진행 중인 특보운영이 없습니다</div>
      ${isAdminUser()?`<button onclick="alertTab(3)" class="ao-start-btn">🌀 특보운영 시작</button>`:'<div style="font-size:11px;color:#456a85;">관리자가 특보운영을 시작하면 표시됩니다</div>'}
    </div>
    ${_renderDutyBaseline()}`;
  }

  // 이전 운영 이력 (보관·열람) — 클릭 시 상세 모달
  const closed=ops.filter(o=>o.closedAt).reverse();
  let histHtml='';
  if(closed.length){
    histHtml=`<div style="margin-top:18px;"><div class="ao-sec-hd"><span class="bar" style="background:#5d82a0;"></span>📜 특보운영 기록 보관함 <span style="font-size:10px;color:#46708f;font-weight:600;margin-left:auto;">총 ${closed.length}건</span></div>
    ${closed.map(o=>{
      const incCnt=_incidentsInOp(o).length;
      return `<div class="ao-hist" onclick="openAlertHistory(${o.id})" style="cursor:pointer;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
        <div style="font-size:12px;font-weight:700;color:#bcd2e6;flex:1;min-width:0;">${_esc(_opLevel(o))} · ${_esc(_opAlerts(o).map(a=>a.type+_stageShort(a.stage)).join(', ')||'-')}</div>
        <span style="font-size:14px;color:#46708f;flex-shrink:0;">›</span>
      </div>
      <div style="font-size:10px;color:#46708f;margin-top:3px;">${_esc((o.startedAt||'').slice(5))} → ${_esc((o.closedAt||'').slice(5))} · 응소 ${(o.responders||[]).length}명 · 관측 ${(o.reports||[]).length}건${incCnt?` · <span style="color:#ff8a80;">🚨 안전사고 ${incCnt}건</span>`:''}</div>
    </div>`;}).join('')}
    </div>`;
  }

  const wrap=document.getElementById('alertViewWrap');
  if(wrap) wrap.innerHTML=wxHtml+`<div id="alertActiveWrap">`+activeHtml+`</div>`+histHtml;
}

// ── 특보운영 통계 탭 ──
function _renderAlertStats(ops){
  ops=ops||DB.g('alertOps')||[];
  const active=ops.find(o=>!o.closedAt);
  const closed=ops.filter(o=>o.closedAt);
  if(!ops.length){
    return `<div class="ao-empty"><div class="ao-empty-ico">📊</div><div class="ao-empty-msg">특보운영 기록이 없습니다</div></div>`;
  }
  // 단계별 / 종류별 집계 (발령된 모든 특보 기준)
  const lvlMap={},typeMap={};
  ops.forEach(o=>{const lv=_opLevel(o);lvlMap[lv]=(lvlMap[lv]||0)+1;(_opAlerts(o)||[]).forEach(a=>{const t=a.type||'기타';typeMap[t]=(typeMap[t]||0)+1;});});
  const totResp=ops.reduce((s,o)=>s+(o.responders||[]).length,0);
  const totRep=ops.reduce((s,o)=>s+(o.reports||[]).length,0);
  const closedOps=closed.filter(o=>o.closedAtMs&&o.startedAtMs);
  const avgHrs=closedOps.length?(closedOps.reduce((s,o)=>s+((o.closedAtMs||0)-(o.startedAtMs||0)),0)/closedOps.length/3600000):0;
  const lvlColor={'예비특보':'#27ae60','Ⅰ단계(주의보)':'#e67e22','Ⅱ단계(경보)':'#c0392b','Ⅲ단계':'#7d3c98'};
  const safeMax=o=>Math.max(...Object.values(o),1);
  const barRow=(k,v,max,col)=>`<div style="margin-bottom:5px;"><div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px;"><span style="color:#c0d8ec;">${_esc(k)}</span><span style="color:${col};font-weight:700;">${v}건</span></div><div style="height:4px;background:rgba(255,255,255,.06);border-radius:2px;overflow:hidden;"><div style="height:100%;width:${Math.round(v/max*100)}%;background:${col};border-radius:2px;"></div></div></div>`;
  const mini=(label,val,col)=>`<div style="background:#060d1a;border-radius:9px;padding:11px 6px;text-align:center;"><div style="font-size:20px;font-weight:800;color:${col||'#e0edf8'};line-height:1.1;">${val}</div><div style="font-size:10px;color:#7a9cb8;margin-top:3px;">${label}</div></div>`;
  const ord=['예비특보','Ⅰ단계(주의보)','Ⅱ단계(경보)','Ⅲ단계'];
  const lvlRows=Object.entries(lvlMap).sort((a,b)=>ord.indexOf(a[0])-ord.indexOf(b[0])).map(([k,v])=>barRow(k,v,safeMax(lvlMap),lvlColor[k]||'#4fa8d0')).join('');
  const typeRows=Object.entries(typeMap).sort((a,b)=>b[1]-a[1]).map(([k,v])=>barRow(k,v,safeMax(typeMap),'#4fa8d0')).join('');
  return `<div style="padding:2px 2px 10px;">
    <div class="scard" style="margin-bottom:10px;">
      <div class="stitle">🌀 특보운영 종합</div>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-bottom:6px;">
        ${mini('총 운영',ops.length,'#4fa8d0')}${mini('운영중',active?1:0,active?'#c0392b':'#4fa8d0')}
        ${mini('누적 응소',totResp+'명','#7ee0a8')}${mini('누적 관측',totRep+'건','#a8cdf5')}
      </div>
      ${avgHrs?`<div style="font-size:11px;color:#5a8aaa;text-align:center;margin-top:4px;">평균 운영 시간 ${avgHrs>=1?avgHrs.toFixed(1)+'시간':Math.round(avgHrs*60)+'분'} · 종료 ${closed.length}건</div>`:''}
    </div>
    ${lvlRows?`<div class="scard" style="margin-bottom:10px;"><div class="stitle">📶 단계별</div>${lvlRows}</div>`:''}
    ${typeRows?`<div class="scard"><div class="stitle">🌧️ 특보 종류별</div>${typeRows}</div>`:''}
  </div>`;
}

// ── 특보운영 입력 탭 (발령·응소·관측 진입점) ──
function _renderAlertInput(active){
  const admin=isAdminUser();
  let html='<div style="padding:4px 2px 10px;">';
  if(!active){
    html+=`<div class="ao-card" style="text-align:center;padding:22px 16px;">
      <div style="font-size:34px;margin-bottom:8px;">🌀</div>
      <div style="font-size:13px;color:#9fc0da;margin-bottom:14px;">진행 중인 특보운영이 없습니다</div>
      ${admin?`<button onclick="openAlertStart()" class="ao-start-btn" style="margin:0 auto;">🌀 특보운영 시작</button>`
             :`<div style="font-size:11px;color:#456a85;">관리자가 특보운영을 시작하면<br>여기서 응소·관측을 입력할 수 있습니다</div>`}
    </div>`;
    return html+'</div>';
  }
  // 운영 중 — 발령/종료(관리자) + 분소별 빠른 입력(전원)
  const repBtnLbl=(mt=>mt==='snow'?'❄️ 적설보고':mt==='rain'?'🌧️ 강우보고':'🌧️ 기상보고')(_alertMeasureType(active));
  if(admin){
    html+=`<div class="ao-card" style="margin-bottom:12px;">
      <div class="ao-sec-hd" style="margin-top:0;"><span class="bar" style="background:#ff8a80;"></span>🚨 특보 발령 · 운영</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button onclick="openAlertStart()" class="ao-loc-btn" style="flex:1;min-width:130px;">＋ 특보 추가 발령</button>
        <button onclick="endAlertOps(${active.id})" class="ao-loc-btn" style="flex:1;min-width:130px;background:rgba(192,57,43,.14);border-color:rgba(192,57,43,.4);color:#ff8a80;">■ 운영 종료</button>
      </div>
    </div>`;
  }
  // 위기경보·탐방로 통제 빠른 버튼 (관리자)
  if(admin){
    const cl=DB.g('crisisLevel')||{};const clv=cl.level||'';
    const clColor=clv==='관심'?'#3498db':clv==='주의'?'#e6b800':clv==='경계'?'#e67e22':clv==='심각'?'#c0392b':'rgba(79,168,208,.5)';
    html+=`<div class="ao-card" style="margin-bottom:12px;">
      <div class="ao-sec-hd" style="margin-top:0;"><span class="bar" style="background:${clColor};"></span>🚨 재난위기경보${clv?` <span style="background:${clColor}26;color:${clColor};font-size:10px;font-weight:800;border-radius:6px;padding:1px 7px;margin-left:6px;">${CRISIS_LABEL[clv]||clv}${cl.type?' — '+cl.type:''}</span>`:'<span style="font-size:10px;color:#4a7090;margin-left:6px;">미설정</span>'}</div>
      <button onclick="openCrisisLevelModal()" class="ao-loc-btn" style="width:100%;border-color:${clColor}55;color:${clColor};">🚨 위기경보 단계 설정</button>
    </div>`;
    const ts=DB.g('trailStatus')||{};const ctrlCnt=Object.values(ts).filter(v=>v.status==='통제').length;
    html+=`<div class="ao-card" style="margin-bottom:12px;">
      <div class="ao-sec-hd" style="margin-top:0;"><span class="bar" style="background:#e67e22;"></span>🚧 탐방로 통제 현황${ctrlCnt?` <span style="background:rgba(231,76,60,.2);color:#ff9e80;font-size:10px;font-weight:800;border-radius:6px;padding:1px 7px;margin-left:6px;">통제 ${ctrlCnt}구간</span>`:''}</div>
      <div style="display:flex;gap:6px;">
        <button onclick="openTrailCtrl()" class="ao-loc-btn" style="flex:1;">🚧 통제/개방 관리</button>
        <button onclick="openTrailLog()" class="ao-loc-btn" style="border-color:rgba(255,255,255,.12);color:#8aa6bc;">🕑 이력</button>
      </div>
    </div>`;
  }
  // 정기 기상 브리핑 (관리자 작성 / 전원 열람)
  {
    const wb=DB.g('weatherBrief')||{};
    const fresh=wb.text&&wb.atMs&&(Date.now()-wb.atMs<6*3600*1000);
    html+=`<div class="ao-card" style="margin-bottom:12px;">
      <div class="ao-sec-hd" style="margin-top:0;"><span class="bar" style="background:#4fa8d0;"></span>🌦️ 기상 브리핑${wb.time?` <span style="font-size:10px;color:#6a94b0;font-weight:700;margin-left:6px;">${_esc(wb.time)} 기준</span>`:''}</div>
      ${wb.text?`<div style="font-size:12.5px;line-height:1.6;color:${fresh?'#cfe2f2':'#8aa6bc'};white-space:pre-wrap;padding:2px 0 4px;">${_esc(wb.text)}</div><div style="font-size:10px;color:#5a7a92;margin-bottom:6px;">— ${_esc(wb.by||'')}${fresh?'':' · ⚠️ 6시간 경과(갱신 필요)'}</div>`:`<div style="font-size:11px;color:#5a7a92;padding:2px 0 6px;">등록된 브리핑이 없습니다.</div>`}
      <div style="display:flex;gap:6px;">
        ${admin?`<button onclick="openWeatherBrief()" class="ao-loc-btn" style="flex:1;border-color:#4fa8d055;color:#4fa8d0;">✍️ 작성/갱신</button>`:''}
        <button onclick="openWeatherLog()" class="ao-loc-btn" style="${admin?'':'width:100%;'}border-color:rgba(255,255,255,.12);color:#8aa6bc;">🕑 이력</button>
      </div>
    </div>`;
  }
  html+=`<div class="ao-sec-hd"><span class="bar"></span>📍 분소별 빠른 입력</div>`;
  ALERT_GROUPS.forEach(g=>{
    g.stations.forEach(st=>{
      const isShelter=!!st.shelter;
      const cnt=(active.responders||[]).filter(r=>(r.loc||'사무소')===st.loc).length;
      const occ=isShelter?_latestOccupancy(active,st.loc):null;
      // 대피소: 직원+탐방객 체류인원 표시 / 분소: 당직자(응소인원)만 표시
      const occLine=occ?`<div style="font-size:11px;color:#7ec8a0;margin:2px 0 4px;">⛺ 직원 ${occ.staff??'-'}명 · 탐방객 ${occ.visitors??'-'}명 <span style="color:#4a7090;">${(occ.time||'').slice(11,16)}</span>${occ.note?' · '+_esc(occ.note):''}</div>`:'';
      const base=_dutyOf(st.loc);
      html+=`<div class="ao-loc-card" style="margin-bottom:8px;">
        <div class="ao-loc-hd"><b style="color:#e8f2fb;font-size:13px;">${isShelter?'⛺ ':g.ico+' '}${_esc(st.label)}</b><span class="ao-loc-cnt ${(cnt+base)?'ok':''}">👤 ${base?`상시 ${base}`:''}${base&&cnt?' + ':''}${cnt?`응소 ${cnt}`:(base?'':'응소 0')}명</span></div>
        ${occLine}
        <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap;">
          <button onclick="openAddResponder(${active.id},'${st.loc}')" class="ao-loc-btn">👤 응소 등록</button>
          <button onclick="openAlertReport(${active.id},'${st.loc}')" class="ao-loc-btn rep">${repBtnLbl}</button>
          ${isShelter?`<button onclick="openAlertOcc(${active.id},'${st.loc}')" class="ao-loc-btn" style="background:rgba(46,204,113,.08);border-color:rgba(46,204,113,.3);color:#7ec8a0;">⛺ 체류인원</button>`:''}
        </div>
      </div>`;
    });
  });
  return html+'</div>';
}


function _renderAlertReqTable(level){
  const req=ALERT_REQS[level];
  if(!req)return'';
  return`<div style="margin-top:10px;font-size:10px;color:#3a6a8a;font-weight:700;margin-bottom:4px;">📋 단계별 필요 인원 (별표10)</div>
  <table class="ao-req-table">
    <tr><th>구분</th><th>역할</th><th>최소인원</th></tr>
    ${req.사무소.map(r=>`<tr><td>사무소</td><td>${r.role}</td><td>${r.min}명</td></tr>`).join('')}
    ${req.분소.map(r=>`<tr><td>분소</td><td>${r.role}</td><td>${r.min}명</td></tr>`).join('')}
  </table>`;
}

function openAlertStart(){
  _alertLevel='';_alertType='';
  document.querySelectorAll('#alertLevelPills .pill,#alertTypePills .pill').forEach(p=>p.classList.remove('on'));
  document.getElementById('alertStartNote').value='';
  document.getElementById('alertReqTable').innerHTML='';
  // 이미 운영 중이면 '특보 추가 발령' 모드 — 보고주기 행 숨김(이미 설정됨)
  const active=(DB.g('alertOps')||[]).find(o=>!o.closedAt);
  const itvRow=document.getElementById('alertItvRow');
  const startBtn=document.getElementById('alertStartBtn');
  const title=document.getElementById('alertStartTitle');
  if(active){
    if(itvRow)itvRow.style.display='none';
    if(startBtn)startBtn.textContent='🚨 특보 추가 발령';
    if(title)title.textContent='🚨 특보 추가 발령';
  }else{
    if(itvRow)itvRow.style.display='';
    _reportInterval=60;
    document.querySelectorAll('#alertItvPills .pill').forEach(p=>p.classList.toggle('on',p.textContent==='1시간'));
    if(startBtn)startBtn.textContent='🌀 특보운영 시작';
    if(title)title.textContent='🌀 특보운영 시작';
  }
  document.getElementById('modalAlertStart').classList.add('on');
}
function selAlertLevel(el,v){
  document.querySelectorAll('#alertLevelPills .pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');_alertLevel=v;
  document.getElementById('alertReqTable').innerHTML=_renderAlertReqTable(v);
}
function selAlertType(el,v){
  document.querySelectorAll('#alertTypePills .pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');_alertType=v;
}
function selReportItv(el,v){document.querySelectorAll('#alertItvPills .pill').forEach(p=>p.classList.remove('on'));el.classList.add('on');_reportInterval=v;}
function startAlertOps(){
  if(!_alertLevel){toast('단계를 선택하세요');return;}
  if(!_alertType){toast('특보 종류를 선택하세요');return;}
  const ops=DB.g('alertOps')||[];
  let active=ops.find(o=>!o.closedAt);
  const note=document.getElementById('alertStartNote').value.trim();
  if(active){
    active.alerts=active.alerts||_opAlerts(active);
    // 같은 종류가 이미 발령돼 있으면 → 단계만 변경(경보↔주의보 상향·하향). 같은 단계면 무시.
    const dup=active.alerts.find(a=>a.type===_alertType);
    if(dup){
      if(dup.stage===_alertLevel){toast('⚠️ 이미 같은 단계로 발령됨: '+_alertType+_stageShort(dup.stage));return;}
      const wasUp=_stageRank(_alertLevel)>_stageRank(dup.stage);
      const prevStage=dup.stage;
      dup.stage=_alertLevel;dup.source='manual';dup.issuedAt=now();dup.issuedAtMs=Date.now();dup.by=getAuthor();
      if(note)active.note=note;
      DB.s('alertOps',ops);
      closeM('modalAlertStart');
      pushNoti((wasUp?'🔺 특보 상향: ':'🔻 특보 하향: ')+_alertType+' '+_stageShort(prevStage)+'→'+_stageShort(_alertLevel),'🚨','op_change',{app:'alert'});
      toast((wasUp?'🔺 상향: ':'🔻 하향: ')+_alertType+' '+_stageShort(prevStage)+'→'+_stageShort(_alertLevel));
      renderAlertView();updateSummary();
      return;
    }
    active.alerts.push({type:_alertType,stage:_alertLevel,source:'manual',issuedAt:now(),issuedAtMs:Date.now(),by:getAuthor()});
    if(note)active.note=note;
    DB.s('alertOps',ops);
    closeM('modalAlertStart');
    pushNoti('🚨 특보 추가 발령: '+_alertType+_stageShort(_alertLevel),'🚨','op_change',{app:'alert'});
    toast('🚨 특보 발령: '+_alertType+_stageShort(_alertLevel));
    renderAlertView();updateSummary();
    return;
  }
  // 신규 특보운영 세션 생성
  ops.push({id:Date.now(),alerts:[{type:_alertType,stage:_alertLevel,source:'manual',issuedAt:now(),issuedAtMs:Date.now(),by:getAuthor()}],note,startedAt:now(),startedAtMs:Date.now(),reportInterval:_reportInterval||60,closedAt:null,responders:[],reports:[],createdBy:getAuthor()});
  DB.s('alertOps',ops);
  closeM('modalAlertStart');
  pushNoti('🌀 특보운영 시작: '+_alertType+_stageShort(_alertLevel),'🌀','op_start',{app:'alert'});
  toast('🌀 특보운영 시작');
  _startAlertReminder();
  renderAlertView();updateSummary();
}
// 발령된 개별 특보 해제 (마지막 특보 해제 시에도 세션은 유지 — 종료는 '종료' 버튼)
function removeAlertItem(opId,idx){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const ops=DB.g('alertOps')||[];
  const op=ops.find(o=>o.id===opId);
  if(!op)return;
  op.alerts=op.alerts||_opAlerts(op);
  const rm=op.alerts[idx];
  if(!rm)return;
  if(!confirm((rm.type+_stageShort(rm.stage))+' 특보를 해제하겠습니까?'))return;
  op.alerts.splice(idx,1);
  DB.s('alertOps',ops);
  toast('해제: '+rm.type+_stageShort(rm.stage));
  renderAlertView();updateSummary();
}
// 기상청 발효 특보 자동 동기화 (공식 발효 특보 수신 시에만 호출됨 — 빈 목록=공식 '특보 없음')
//  · 신규 종류 → 자동 발령   · 자동발령분 단계 변경(경보↔주의보 자동 하향·상향)   · 기상청에서 사라진 자동분 → 자동 해제
//  · 수동(✋) 발령분은 절대 건드리지 않음. 전체 운영 종료는 관리자 수동(자동 종료 안 함).
function _syncAutoAlerts(liveList){
  liveList=liveList||[];
  const ops=DB.g('alertOps')||[];
  let active=ops.find(o=>!o.closedAt);
  if(!active&&!liveList.length)return;            // 운영도 없고 특보도 없음 → 무동작
  let created=false;
  if(!active){
    if(!liveList.length)return;
    active={id:Date.now(),alerts:[],note:'',startedAt:now(),startedAtMs:Date.now(),reportInterval:60,closedAt:null,responders:[],reports:[],createdBy:'자동(기상청)'};
    ops.push(active);created=true;
  }
  active.alerts=active.alerts||_opAlerts(active);
  const liveByType={};liveList.forEach(a=>{liveByType[a.type]=a;});
  const added=[],changed=[],removed=[];
  // 1) 추가 + 자동분 단계 동기화
  liveList.forEach(a=>{
    const ex=active.alerts.find(x=>x.type===a.type);
    if(!ex){active.alerts.push({type:a.type,stage:a.stage,source:'auto',issuedAt:now(),issuedAtMs:Date.now()});added.push(a.type+_stageShort(a.stage));}
    else if(ex.source==='auto'&&ex.stage!==a.stage){const prev=ex.stage;ex.stage=a.stage;ex.issuedAt=now();ex.issuedAtMs=Date.now();changed.push(a.type+' '+_stageShort(prev)+'→'+_stageShort(a.stage));}
  });
  // 2) 자동분 중 기상청에서 해제된 종류 → 자동 해제 (수동분 보존)
  active.alerts=active.alerts.filter(x=>{
    if(x.source==='auto'&&!liveByType[x.type]){removed.push(x.type+_stageShort(x.stage));return false;}
    return true;
  });
  if(!created&&!added.length&&!changed.length&&!removed.length)return; // 변경 없음
  DB.s('alertOps',ops);
  if(active.alerts.length)_startAlertReminder();
  // 기기별 1회만 알림 (중복 푸시 방지)
  const sig=active.id+'|'+added.join(',')+'|'+changed.join(',')+'|'+removed.join(',');
  if((added.length||changed.length||removed.length)&&localStorage.getItem('_aoAuto_'+sig)!=='1'){
    localStorage.setItem('_aoAuto_'+sig,'1');
    let msg=[];
    if(added.length)msg.push('🌀 자동발령 '+added.join(', '));
    if(changed.length)msg.push('🔻 단계변경 '+changed.join(', '));
    if(removed.length)msg.push('✅ 자동해제 '+removed.join(', '));
    pushNoti('📡 기상특보 '+msg.join(' / '),'📡','op_kma',{app:'alert'});
  }
  if(window.curApp==='alert')renderAlertView();
  updateSummary();
}
// ── 체류인원 ──
// ── 위기경보 단계 배너 ──
// 국가재난위기경보 4단계: 관심(파랑) → 주의(노랑) → 경계(주황) → 심각(빨강)
const CRISIS_LEVELS=['관심','주의','경계','심각'];
const CRISIS_LABEL={'관심':'🔵 관심','주의':'🟡 주의','경계':'🟠 경계','심각':'🔴 심각'};
const CRISIS_TYPE_OPTS=['호우','강풍','대설','산사태','복합'];
function _updateCrisisBanner(){
  const cl=DB.g('crisisLevel')||{};
  const lvl=cl.level||'';
  const type=cl.type||'';
  const text=lvl?`${CRISIS_LABEL[lvl]||lvl} | 재난위기경보${type?' — '+type:''}  (${(cl.updatedAt||'').slice(5,16)})`:'';
  ['crisisBanner','boardCrisisBanner'].forEach(id=>{
    const el=document.getElementById(id);if(!el)return;
    el.className='crisis-banner'+(lvl?' on crisis-'+lvl:'');
    el.innerHTML=lvl?text+'(클릭: 해제 또는 변경)':'';
    if(lvl&&isAdminUser())el.onclick=()=>openCrisisLevelModal();
    else el.onclick=null;
  });
}
function openCrisisLevelModal(){
  const cl=DB.g('crisisLevel')||{};
  const html=`<div style="padding:6px 0;">
    <div style="font-size:12px;color:#7a9cb8;margin-bottom:14px;">산사태·기상재해 국가위기경보 단계를 설정하세요. 전 기기 즉시 표시됩니다.</div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px;">
      ${CRISIS_LEVELS.map(l=>`<button onclick="setCrisisLevel('${l}')" style="flex:1;min-width:60px;padding:10px 4px;border-radius:10px;border:2px solid ${l==='관심'?'#3498db':l==='주의'?'#f1c40f':l==='경계'?'#e67e22':'#c0392b'};background:${l===(cl.level||'')?'rgba(255,255,255,.1)':'transparent'};color:${l==='주의'?'#f1c40f':l==='관심'?'#3498db':l==='경계'?'#e67e22':'#c0392b'};font-size:14px;font-weight:900;cursor:pointer;">${CRISIS_LABEL[l]||l}</button>`).join('')}
    </div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;">
      ${CRISIS_TYPE_OPTS.map(t=>`<div class="pill${(cl.type||'')===''+t?' on':''}" onclick="this.parentNode.querySelectorAll('.pill').forEach(p=>p.classList.remove('on'));this.classList.add('on');window._crisisTypeTemp='${t}';">${t}</div>`).join('')}
    </div>
    <button onclick="clearCrisisLevel()" style="width:100%;padding:9px;border-radius:9px;border:1px solid rgba(255,255,255,.15);background:transparent;color:rgba(255,255,255,.4);font-size:12px;cursor:pointer;">✕ 위기경보 해제</button>
  </div>`;
  window._crisisTypeTemp=cl.type||'';
  const modal=document.createElement('div');
  modal.id='crisisModal';modal.className='modal on';
  modal.innerHTML=`<div class="mbox"><div class="mhdr"><span class="mtitle">🚨 재난위기경보 설정</span><button class="mclose" onclick="document.getElementById('crisisModal').remove()">×</button></div>${html}</div>`;
  document.body.appendChild(modal);
}
function setCrisisLevel(level){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const type=window._crisisTypeTemp||'';
  DB.s('crisisLevel',{level,type,updatedAt:now(),by:getAuthor()});
  const el=document.getElementById('crisisModal');if(el)el.remove();
  _updateCrisisBanner();
  pushNoti(`🚨 재난위기경보 ${CRISIS_LABEL[level]||level} 발령${type?' — '+type:''}`, '🚨','crisis',{app:'alert'});
  toast(`🚨 위기경보 ${level} 설정`);
  // 심각/경계 단계는 전 탐방로 통제 연동 제안
  if((level==='심각'||level==='경계')){
    const ts=DB.g('trailStatus')||{};
    const openCnt=SEORAK_TRAILS.filter(t=>((ts[t.id]||{}).status||'개방')!=='통제').length;
    if(openCnt>0&&confirm(`🚨 ${level} 단계입니다.\n현재 미통제 ${openCnt}개 구간을 전부 '통제'로 전환하시겠습니까?`)){
      SEORAK_TRAILS.forEach(t=>{ts[t.id]={status:'통제',time:now(),at:Date.now(),by:getAuthor(),note:`위기경보 ${level} 일괄통제`};});
      DB.s('trailStatus',ts);
      pushNoti(`🚧 위기경보 ${level} 연동 — 전 탐방로 통제`,'🚧','trail',{app:'alert'});
      toast('🚧 전 탐방로 통제 완료');
    }
  }
}
function clearCrisisLevel(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  DB.s('crisisLevel',null);
  const el=document.getElementById('crisisModal');if(el)el.remove();
  _updateCrisisBanner();
  toast('✅ 위기경보 해제');
}
// ── 정기 기상 브리핑 ──
function openWeatherBrief(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const wb=DB.g('weatherBrief')||{};
  const tmpl=wb.text||'■ 현재: \n■ 강수: \n■ 풍속: \n■ 전망: \n■ 조치사항: ';
  const modal=document.createElement('div');
  modal.id='wbModal';modal.className='modal on';
  modal.innerHTML=`<div class="mbox"><div class="mhdr"><span class="mtitle">🌦️ 기상 브리핑 작성</span><button class="mclose" onclick="document.getElementById('wbModal').remove()">×</button></div>
    <div style="font-size:11px;color:#6a94b0;margin-bottom:8px;">전 직원·응소자에게 즉시 공유됩니다. 정기(예: 04:30·16:30) 갱신 권장.</div>
    <textarea id="wbText" class="fi" style="min-height:160px;line-height:1.6;font-size:13px;resize:vertical;">${_esc(tmpl)}</textarea>
    <button class="btn btn-primary" style="margin-top:10px;" onclick="saveWeatherBrief()">📢 브리핑 게시</button>
  </div>`;
  document.body.appendChild(modal);
}
function saveWeatherBrief(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const text=(document.getElementById('wbText').value||'').trim();
  if(!text){toast('내용을 입력하세요');return;}
  const entry={text,time:now(),atMs:Date.now(),by:getAuthor()};
  DB.s('weatherBrief',entry);
  // 이력 누적 (사후 보고서·추이 확인용, 최근 60건 유지)
  const log=DB.g('weatherLog')||[];
  log.unshift(entry);
  DB.s('weatherLog',log.slice(0,60));
  const el=document.getElementById('wbModal');if(el)el.remove();
  pushNoti('🌦️ 기상 브리핑 갱신','🌦️','weather',{app:'alert'});
  toast('📢 기상 브리핑 게시');
  renderAlertView();
}
// 기상 브리핑 이력 열람
function openWeatherLog(){
  const log=DB.g('weatherLog')||[];
  const modal=document.createElement('div');
  modal.id='wbLogModal';modal.className='modal on';
  modal.innerHTML=`<div class="mbox"><div class="mhdr"><span class="mtitle">🌦️ 기상 브리핑 이력 <span style="font-size:11px;color:#6a94b0;font-weight:600;">(${log.length}건)</span></span><button class="mclose" onclick="document.getElementById('wbLogModal').remove()">×</button></div>
    <div style="max-height:60vh;overflow-y:auto;">
    ${log.length?log.map(e=>`<div style="background:#060d1a;border-radius:9px;padding:10px 12px;margin-bottom:7px;border:1px solid rgba(79,168,208,.12);">
      <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:5px;">${_esc(e.time||'')}${e.by?` · ${_esc(e.by)}`:''}</div>
      <div style="font-size:12px;color:#cfe2f2;line-height:1.6;white-space:pre-wrap;">${_esc(e.text||'')}</div>
    </div>`).join(''):'<div style="text-align:center;color:#6a94b0;font-size:12px;padding:24px;">기록된 브리핑이 없습니다.</div>'}
    </div>
  </div>`;
  document.body.appendChild(modal);
}
function _latestOccupancy(op,loc){
  const list=(op.occupancy||[]).filter(o=>o.loc===loc);
  if(!list.length)return null;
  return list.reduce((a,b)=>(b.at||0)>(a.at||0)?b:a);
}
let _occOpId=null,_occLoc='';
function openAlertOcc(opId,presetLoc){
  _occOpId=opId;_occLoc=presetLoc||'';
  document.getElementById('occOpId').value=opId;
  document.getElementById('occLoc').value=presetLoc||'';
  document.getElementById('occLocDisplay').textContent=presetLoc?_stationLabel(presetLoc):'관측소 미지정';
  document.getElementById('occStaff').value='';
  document.getElementById('occVisitors').value='';
  document.getElementById('occNote').value='';
  document.getElementById('modalAlertOcc').classList.add('on');
  setTimeout(()=>document.getElementById('occStaff').focus(),200);
}
function addAlertOccupancy(){
  const opId=parseInt(document.getElementById('occOpId').value)||_occOpId;
  const loc=document.getElementById('occLoc').value||_occLoc;
  if(!loc){toast('거점 정보가 없습니다');return;}
  const staff=document.getElementById('occStaff').value.trim();
  const visitors=document.getElementById('occVisitors').value.trim();
  if(staff===''&&visitors===''){toast('직원 또는 탐방객 수를 입력하세요');return;}
  const ops=DB.g('alertOps')||[];
  const idx=ops.findIndex(o=>o.id===opId);
  if(idx===-1){toast('운영 기록을 찾을 수 없습니다');return;}
  if(!ops[idx].occupancy)ops[idx].occupancy=[];
  ops[idx].occupancy.push({
    id:Date.now(),loc,
    staff:staff!==''?parseInt(staff):null,
    visitors:visitors!==''?parseInt(visitors):null,
    note:document.getElementById('occNote').value.trim(),
    time:now(),at:Date.now(),by:getAuthor()
  });
  DB.s('alertOps',ops);
  closeM('modalAlertOcc');
  toast('👥 '+_stationLabel(loc)+' 체류인원 보고 완료');
  renderAlertView();
}

// ── 탐방로 통제 ──
// 설악산 주요 탐방로 구간 목록
const SEORAK_TRAILS=[
  {id:'baekdam-bongjeongam',  name:'백담사 → 봉정암',       zone:'백담'},
  {id:'sogong-biseon',        name:'소공원 → 비선대',       zone:'소공원'},
  {id:'biseon-yangpok',       name:'비선대 → 양폭대피소',   zone:'소공원'},
  {id:'yangpok-bongjeongam',  name:'양폭 → 봉정암',         zone:'소공원'},
  {id:'daecheong-heunun',     name:'대청봉 → 희운각 대피소',zone:'대청'},
  {id:'osaek-daecheong',      name:'오색 → 대청봉',         zone:'오색'},
  {id:'osaek-pokpo',          name:'오색 → 설악폭포',       zone:'오색'},
  {id:'hangyeryeong-daecheong',name:'한계령 → 끝청봉',      zone:'한계령'},
  {id:'jujeongol',            name:'주전골',                zone:'오색'},
  {id:'cable-gwongumseong',   name:'케이블카 → 권금성',     zone:'소공원'},
  {id:'nahan-toyang',         name:'나한봉 → 토왕성폭포전망대',zone:'소공원'},
  {id:'ulsan-bawi',           name:'소공원 → 울산바위',     zone:'소공원'},
  {id:'heullimgol',           name:'흘림골',                zone:'오색'},
  {id:'olsanbawi-biseon',     name:'울산바위 → 비선대',     zone:'소공원'},
];
const TRAIL_STATUS_OPTS=['개방','주의','통제'];
const TRAIL_STATUS_COLORS={'개방':'#27ae60','주의':'#e67e22','통제':'#c0392b'};
function openTrailCtrl(){
  const ts=DB.g('trailStatus')||{};
  const zones=[...new Set(SEORAK_TRAILS.map(t=>t.zone))];
  let html='';
  zones.forEach(z=>{
    html+=`<div style="font-size:10px;color:#5a8aa0;font-weight:800;letter-spacing:.5px;margin:10px 0 4px;">${z.toUpperCase()} 구간</div>`;
    SEORAK_TRAILS.filter(t=>t.zone===z).forEach(t=>{
      const cur=(ts[t.id]||{}).status||'개방';
      html+=`<div style="display:flex;align-items:center;gap:6px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.04);">
        <div style="flex:1;font-size:12px;color:#cfe2f2;">${_esc(t.name)}</div>
        <div style="display:flex;gap:4px;">${TRAIL_STATUS_OPTS.map(s=>`<button onclick="this.closest('.trow')._sel='${s}';this.parentNode.querySelectorAll('button').forEach(b=>b.classList.remove('on'));this.classList.add('on')" class="ao-loc-btn tst${cur===s?' on':''}" data-tid="${t.id}" data-st="${s}" style="font-size:10px;padding:3px 8px;min-width:0;background:${cur===s?TRAIL_STATUS_COLORS[s]+'26':'rgba(255,255,255,.04)'};border-color:${cur===s?TRAIL_STATUS_COLORS[s]:'rgba(255,255,255,.1)'};color:${cur===s?TRAIL_STATUS_COLORS[s]:'rgba(255,255,255,.4)'}">${s}</button>`).join('')}</div>
      </div>`;
    });
  });
  document.getElementById('trailCtrlBody').innerHTML=html;
  document.getElementById('trailCtrlNote').value='';
  document.getElementById('modalTrailCtrl').classList.add('on');
}
// 모달 내 전 구간 상태를 한 번에 선택(저장 전 미리보기, '저장' 눌러야 반영)
function _trailBatch(st){
  document.querySelectorAll('#trailCtrlBody .trow, #trailCtrlBody [data-tid]').forEach(()=>{});
  document.querySelectorAll('#trailCtrlBody > div').forEach(row=>{
    const btns=row.querySelectorAll('button[data-tid]');
    btns.forEach(b=>{
      const on=b.dataset.st===st;
      b.classList.toggle('on',on);
      const c=TRAIL_STATUS_COLORS[b.dataset.st];
      b.style.background=on?c+'26':'rgba(255,255,255,.04)';
      b.style.borderColor=on?c:'rgba(255,255,255,.1)';
      b.style.color=on?c:'rgba(255,255,255,.4)';
    });
  });
  toast(`전 구간 '${st}' 선택 — 저장을 눌러 반영`);
}
function saveTrailCtrl(){
  const ts=DB.g('trailStatus')||{};
  const note=document.getElementById('trailCtrlNote').value.trim();
  const changes=[]; // 변경된 구간만 이력에 기록 (언제·누가·왜)
  document.querySelectorAll('#trailCtrlBody button[data-tid].on').forEach(btn=>{
    const tid=btn.dataset.tid,st=btn.dataset.st;
    const prev=(ts[tid]||{}).status||'개방';
    if(prev!==st){const tn=(SEORAK_TRAILS.find(t=>t.id===tid)||{}).name||tid;changes.push({name:tn,from:prev,to:st});}
    ts[tid]={status:st,time:now(),at:Date.now(),by:getAuthor(),note};
  });
  // 버튼 미클릭 = 기존 상태 유지; 없는 구간은 개방으로
  SEORAK_TRAILS.forEach(t=>{if(!ts[t.id])ts[t.id]={status:'개방',time:now(),at:Date.now(),by:'초기'};});
  DB.s('trailStatus',ts);
  // 변경 이력 누적 (민원·법적 대응용, 최근 100건)
  if(changes.length){
    const log=DB.g('trailLog')||[];
    log.unshift({time:now(),atMs:Date.now(),by:getAuthor(),note,changes});
    DB.s('trailLog',log.slice(0,100));
  }
  closeM('modalTrailCtrl');
  const ctrlCnt=Object.values(ts).filter(v=>v.status==='통제').length;
  const warnCnt=Object.values(ts).filter(v=>v.status==='주의').length;
  toast(`🚧 통제 ${ctrlCnt}구간 · 주의 ${warnCnt}구간 저장`);
  if(ctrlCnt>0)pushNoti(`🚧 탐방로 통제 ${ctrlCnt}구간 설정`,'🚧','trail',{app:'alert'});
  renderAlertView();updateSummary();
}
// 탐방로 통제 변경 이력 열람
function openTrailLog(){
  const log=DB.g('trailLog')||[];
  const SC=TRAIL_STATUS_COLORS;
  const modal=document.createElement('div');
  modal.id='trailLogModal';modal.className='modal on';
  modal.innerHTML=`<div class="mbox"><div class="mhdr"><span class="mtitle">🚧 통제 변경 이력 <span style="font-size:11px;color:#6a94b0;font-weight:600;">(${log.length}건)</span></span><button class="mclose" onclick="document.getElementById('trailLogModal').remove()">×</button></div>
    <div style="max-height:60vh;overflow-y:auto;">
    ${log.length?log.map(e=>`<div style="background:#060d1a;border-radius:9px;padding:10px 12px;margin-bottom:7px;border:1px solid rgba(230,126,34,.15);">
      <div style="font-size:10px;color:#e67e22;font-weight:700;margin-bottom:5px;">${_esc(e.time||'')} · ${_esc(e.by||'')}${e.note?` <span style="color:#8aa6bc;font-weight:400;">— ${_esc(e.note)}</span>`:''}</div>
      ${(e.changes||[]).map(c=>`<div style="font-size:11.5px;color:#cfe2f2;line-height:1.7;">${_esc(c.name)}: <span style="color:${SC[c.from]||'#888'};">${_esc(c.from)}</span> → <span style="color:${SC[c.to]||'#888'};font-weight:700;">${_esc(c.to)}</span></div>`).join('')}
    </div>`).join(''):'<div style="text-align:center;color:#6a94b0;font-size:12px;padding:24px;">변경 이력이 없습니다.</div>'}
    </div>
  </div>`;
  document.body.appendChild(modal);
}
function endAlertOps(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const _op=(DB.g('alertOps')||[]).find(o=>o.id===id);
  const _n=_op?(_op.alerts||_opAlerts(_op)).length:0;
  // 특보가 여러 건이면 전체 종료 대신 개별 해제(×)·단계 하향이 가능함을 안내
  const _msg=_n>1
    ? '⚠️ 현재 '+_n+'건의 특보가 발령 중입니다.\n\n일부만 해제하려면 [취소] 후 각 특보의 ×(해제) 또는 특보 추가 발령으로 단계 하향(경보→주의보)을 하세요.\n\n전체 특보운영을 종료하시겠습니까?'
    : '특보운영을 종료하겠습니까?';
  if(!confirm(_msg))return;
  const ops=DB.g('alertOps')||[];
  const idx=ops.findIndex(o=>o.id===id);
  if(idx===-1)return;
  ops[idx].closedAt=now();
  ops[idx].closedAtMs=Date.now();
  DB.s('alertOps',ops);
  _stopAlertReminder();
  pushNoti('✅ 특보운영 종료','✅','op_end',{app:'alert'});
  toast('✅ 특보운영 종료');
  renderAlertView();
}
// ── 특보운영 기간 중 발생한 안전사고(구조) 기록 찾기 ──
function _incidentsInOp(op){
  if(!op)return[];
  const res=DB.g('rescues')||[];
  const s=op.startedAtMs||(op.startedAt?Date.parse(op.startedAt.replace(' ','T')):0);
  const e=op.closedAtMs||(op.closedAt?Date.parse(op.closedAt.replace(' ','T')):Date.now());
  return res.filter(r=>{
    if(op.id&&r.alertOpId===op.id)return true;          // 명시적 연결 우선
    if(r.alertOpId&&r.alertOpId!==op.id)return false;   // 다른 운영에 연결됨
    if(!r.id)return false;                               // 시간범위 fallback
    return r.id>=s&&r.id<=e;
  }).sort((a,b)=>(b.id||0)-(a.id||0));
}
// ── 보관함: 종료된 특보운영 상세 열람 ──
function openAlertHistory(opId){
  const op=(DB.g('alertOps')||[]).find(o=>o.id===opId);
  if(!op){toast('기록을 찾을 수 없습니다');return;}
  document.getElementById('alertHistBody').innerHTML=_renderAlertOpDetail(op);
  document.getElementById('modalAlertHistory').classList.add('on');
}
function _renderAlertOpDetail(op){
  const opLevel=_opLevel(op);
  const lvColor=ALERT_LEVEL_COLORS[opLevel]||'#4fa8d0';
  const alertChips=(op.alerts||_opAlerts(op)).map(a=>`<span class="ao-alert-chip ${a.source==='auto'?'auto':'manual'}">${a.source==='auto'?'📡자동':'✋수동'} <b>${_esc(a.type)}${_stageShort(a.stage)}</b></span>`).join('')||'<span style="font-size:11px;color:#456a85;">-</span>';
  // 응소자: 관측소별 그룹
  const resps=op.responders||[];
  let respHtml='';
  if(resps.length){
    const byLoc={};
    resps.forEach(r=>{const k=r.loc||'사무소';(byLoc[k]=byLoc[k]||[]).push(r);});
    respHtml=Object.entries(byLoc).map(([loc,arr])=>`<div class="ao-loc-card" style="margin-bottom:6px;">
      <div class="ao-loc-hd"><b style="color:#e8f2fb;font-size:12px;">${_esc(_stationLabel(loc))}</b><span class="ao-loc-cnt ok">👤 ${arr.length}명</span></div>
      <div style="margin-top:5px;">${arr.map(r=>`<span class="ao-resp-chip"><b style="color:#e0edf8;">${_esc(r.name)}</b> ${_esc(r.role||'')}${r.arrivedAt?' <span style="color:#7ec8a0;">'+_esc(r.arrivedAt)+'</span>':''}</span>`).join('')}</div>
    </div>`).join('');
  } else respHtml='<div style="font-size:11px;color:#456a85;padding:8px 0;">응소 기록 없음</div>';
  // 그 기간 발생 안전사고
  const incs=_incidentsInOp(op);
  let incHtml='';
  if(incs.length){
    incHtml=incs.map(r=>`<div class="ao-hist" onclick="closeM('modalAlertHistory');try{openResListDetail(${r.id});}catch(e){}" style="cursor:pointer;border-left:3px solid #c0392b;">
      <div style="font-size:12px;font-weight:700;color:#ffc9c2;">🚨 ${_esc(r.title||r.type||'안전사고')}</div>
      <div style="font-size:10px;color:#46708f;margin-top:3px;">${_esc((r.date||'').slice(5))}${r.weatherAlert?' · 🌀 '+_esc(r.weatherAlert):''}</div>
    </div>`).join('');
  } else incHtml='<div style="font-size:11px;color:#456a85;padding:8px 0;">기간 중 발생한 안전사고 없음</div>';
  return `
    <div class="ao-hero" style="background:linear-gradient(135deg,${lvColor}22,${lvColor}0a);border:1.5px solid ${lvColor}44;margin-bottom:14px;">
      <div class="ao-hero-lv" style="color:${lvColor};margin-top:0;">${_esc(opLevel)}</div>
      <div class="ao-hero-meta">🕐 ${_esc(op.startedAt||'')} → ${_esc(op.closedAt||'운영중')}</div>
      <div class="ao-hero-meta">👤 응소 ${(op.responders||[]).length}명 · 📊 관측 ${(op.reports||[]).length}건 · 🚨 안전사고 ${incs.length}건</div>
    </div>
    <div class="ao-sec-hd" style="margin-top:0;"><span class="bar" style="background:#ff8a80;"></span>🚨 발령 특보</div>
    <div style="margin-bottom:6px;">${alertChips}</div>
    ${op.note?`<div style="font-size:12px;color:#9fc0da;background:rgba(255,255,255,.03);border-radius:8px;padding:7px 10px;margin-bottom:6px;">📝 ${_esc(op.note)}</div>`:''}
    <div class="ao-sec-hd"><span class="bar"></span>📋 응소 현황</div>
    ${respHtml}
    <div class="ao-sec-hd"><span class="bar" style="background:#4fc0a0;"></span>📊 누적 관측 요약</div>
    ${_renderCumulativeSummary(op)}
    <div class="ao-sec-hd"><span class="bar" style="background:#6e96e6;"></span>🕐 시간대별 관측 기록</div>
    ${_renderReportsTable(op)}
    <div class="ao-sec-hd"><span class="bar" style="background:#c0392b;"></span>🚨 기간 중 발생 안전사고</div>
    ${incHtml}`;
}
// 관측소(분소/대피소) 선택 pill을 동적으로 생성
function _renderStationPills(wrapId,sel,fnName){
  const w=document.getElementById(wrapId);if(!w)return;
  // 운영 분소/대피소 먼저, 기상청 우량계 관측소는 구분선 뒤
  const main=ALERT_STATIONS.filter(s=>!s.obs);
  const obs=ALERT_STATIONS.filter(s=>s.obs);
  w.innerHTML=main.map(s=>`<div class="pill${s.loc===sel?' on':''}" onclick="${fnName}(this,'${s.loc}')">${_esc(s.label)}</div>`).join('')+
    (obs.length?`<div style="width:100%;font-size:9px;color:#4a6a84;font-weight:700;margin:5px 0 2px;">📡 기상청 관측소</div>`+obs.map(s=>`<div class="pill${s.loc===sel?' on':''}" onclick="${fnName}(this,'${s.loc}')" style="border-style:dashed;">${_esc(s.label)}</div>`).join(''):'');
}
function openAddResponder(id,presetLoc){
  _respLoc=presetLoc||'';_respRole='';
  document.getElementById('respTargetId').value=id;
  document.getElementById('respNameIn').value='';
  document.getElementById('respArrivedAt').value='';
  // 분소 카드에서 호출 시 소속 고정, 그렇지 않으면 선택 가능
  const locWrap=document.getElementById('respLocPills');
  if(presetLoc){
    locWrap.innerHTML=`<span style="font-size:12px;font-weight:700;color:#e0edf8;background:rgba(79,168,208,.15);border:1px solid rgba(79,168,208,.3);border-radius:20px;padding:4px 12px;">${_esc(_stationLabel(presetLoc))}</span>`;
  }else{
    _renderStationPills('respLocPills',_respLoc,'selRespLoc');
  }
  document.querySelectorAll('#respRolePills .pill').forEach(p=>p.classList.remove('on'));
  // 등록된 직원 빠른선택
  const users=(DB.g('pendingUsers')||[]).filter(u=>u.approvalStatus==='approved');
  document.getElementById('respNameQuickWrap').innerHTML=users.map(u=>`<div onclick="document.getElementById('respNameIn').value='${_escq(u.realName||u.name||'')}'" style="cursor:pointer;background:rgba(79,168,208,.08);border:1px solid rgba(79,168,208,.2);color:#7db8d8;border-radius:20px;padding:3px 9px;font-size:10px;font-weight:600;">${_esc(u.realName||u.name||'')}</div>`).join('');
  document.getElementById('modalAlertResp').classList.add('on');
}
function selRespLoc(el,v){document.querySelectorAll('#respLocPills .pill').forEach(p=>p.classList.remove('on'));el.classList.add('on');_respLoc=v;}
function selRespRole(el,v){document.querySelectorAll('#respRolePills .pill').forEach(p=>p.classList.remove('on'));el.classList.add('on');_respRole=v;}
function addAlertResponder(){
  const id=parseInt(document.getElementById('respTargetId').value,10);
  const name=document.getElementById('respNameIn').value.trim();
  if(!name){toast('이름을 입력하세요');return;}
  if(!_respLoc){toast('소속을 선택하세요');return;}
  if(!_respRole){toast('역할을 선택하세요');return;}
  const arrivedAt=document.getElementById('respArrivedAt').value.trim()||now().slice(11);
  const ops=DB.g('alertOps')||[];
  const idx=ops.findIndex(o=>o.id===id);
  if(idx===-1){toast('운영 기록을 찾을 수 없습니다');return;}
  if(!ops[idx].responders)ops[idx].responders=[];
  // 같은 이름+소속 중복 응소 방지 — 이미 등록된 대원이면 막기
  const dup=ops[idx].responders.some(r=>(r.name||'').trim()===name&&(r.loc||'')===_respLoc);
  if(dup){toast('⚠️ 이미 등록된 응소자입니다: '+name+' ('+_respLoc+')');return;}
  ops[idx].responders.push({name,loc:_respLoc,role:_respRole,arrivedAt});
  DB.s('alertOps',ops);
  closeM('modalAlertResp');
  toast('✅ 응소자 추가: '+name);
  renderAlertView();
}
function removeAlertResponder(id,name,loc){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const ops=DB.g('alertOps')||[];
  const idx=ops.findIndex(o=>o.id===id);
  if(idx===-1)return;
  let removed=false;
  ops[idx].responders=(ops[idx].responders||[]).filter(r=>{
    if(!removed&&r.name===name&&(r.loc||'사무소')===(loc||'사무소')){removed=true;return false;}
    return true;
  });
  DB.s('alertOps',ops);
  renderAlertView();
}

// ── 시간대별 기상관측 기록 (개별 관측값 + 관측소별 시간순 누적) ──
function _renderReportsTable(op){
  const mt=_alertMeasureType(op);
  const allReps=(op.reports||[]).slice();
  if(!allReps.length)return`<div style="font-size:12px;color:#456a85;text-align:center;padding:16px 0;background:#0a1424;border-radius:10px;">관측 보고 없음 — 분소별 기상보고 버튼으로 입력</div>`;
  // 입력값은 '관측 시점까지의 누적값' → 합산하지 않고 그대로 표시. 시간당 증가량(Δ)은 직전 보고 대비로 계산.
  const chrono=allReps.slice().sort((a,b)=>(a.at||0)-(b.at||0));
  const last={};const dlt={};
  chrono.forEach(r=>{
    const loc=r.loc||'사무소';last[loc]=last[loc]||{};dlt[r.id]={};
    if(r.snow!=null&&r.snow!==''){const v=parseFloat(r.snow)||0;dlt[r.id].snow=(last[loc].snow!=null)?+(v-last[loc].snow).toFixed(1):null;last[loc].snow=v;}
    if(r.rain!=null&&r.rain!==''){const v=parseFloat(r.rain)||0;dlt[r.id].rain=(last[loc].rain!=null)?+(v-last[loc].rain).toFixed(1):null;last[loc].rain=v;}
  });
  // 표시는 최신순(과거 기록도 모두 보존)
  const reps=allReps.sort((a,b)=>(b.at||0)-(a.at||0)).slice(0,80);
  const _dStr=d=>d==null?'':(d>0?'<span style="color:#ff9e80;">▲'+d+'</span>':(d<0?'<span style="color:#7ec8a0;">▼'+Math.abs(d)+'</span>':'<span style="color:#5a8aa0;">0</span>'));
  const snowHd=mt!=='rain'?'<th>❄️ 누적<br>(cm)</th><th>Δ</th>':'';
  const rainHd=mt!=='snow'?'<th>🌧️ 누적<br>(mm)</th><th>Δ</th>':'';
  const cols=3+(mt==='both'?4:2)+(isAdminUser()?1:0);
  return`<table class="ao-req-table"><tr><th>시각</th><th>관측소</th><th>관측자</th>${snowHd}${rainHd}${isAdminUser()?'<th></th>':''}</tr>
    ${reps.map(r=>{
      const d=dlt[r.id]||{};
      const snowTd=mt!=='rain'?`<td style="text-align:center;color:#9ce0f0;font-weight:800;background:rgba(120,220,240,.06);">${_esc(String(r.snow??'-'))}</td><td style="text-align:center;font-size:10px;">${_dStr(d.snow)}</td>`:'';
      const rainTd=mt!=='snow'?`<td style="text-align:center;color:#a8cdf5;font-weight:800;background:rgba(110,150,230,.06);">${_esc(String(r.rain??'-'))}</td><td style="text-align:center;font-size:10px;">${_dStr(d.rain)}</td>`:'';
      const delTd=isAdminUser()?`<td style="text-align:center;"><span onclick="removeAlertReport(${op.id},${r.id})" style="cursor:pointer;color:#c0392b;">×</span></td>`:'';
      return`<tr><td>${_esc((r.time||'').slice(5,16))}</td><td>${_esc(_stationLabel(r.loc))}</td><td>${_esc(r.observer||'-')}</td>${snowTd}${rainTd}${delTd}</tr>${r.note?`<tr><td colspan="${cols}" style="color:#5a8aa0;font-size:9px;padding:1px 6px 4px;">↳ ${_esc(r.note)}</td></tr>`:''}`;
    }).join('')}
  </table>
  <div style="font-size:9px;color:#456a85;margin-top:5px;">※ 값은 관측 시점까지의 <b>누적값</b>(입력 그대로). Δ는 직전 보고 대비 증가량(시간당 강우).</div>`;
}
// ── 누적 관측 요약 (관측소별 현재 누적 합계 — 한눈에) ──
function _renderCumulativeSummary(op){
  const reps=op.reports||[];
  if(!reps.length)return`<div style="font-size:12px;color:#456a85;text-align:center;padding:14px 0;background:#0a1424;border-radius:10px;">아직 누적된 관측값이 없습니다</div>`;
  const mt=_alertMeasureType(op);
  // 입력값=누적값 → 합산 금지. 관측소별 '최신 누적값'(현재값) + 시계열(추세 그래프용)
  const byLoc={};
  reps.slice().sort((a,b)=>(a.at||0)-(b.at||0)).forEach(r=>{
    const key=r.loc||'사무소';
    if(!byLoc[key])byLoc[key]={label:_stationLabel(key),snow:null,rain:null,snowSeq:[],rainSeq:[],lastTime:''};
    if(r.snow!=null&&r.snow!==''){const v=parseFloat(r.snow)||0;byLoc[key].snow=v;byLoc[key].snowSeq.push(v);}
    if(r.rain!=null&&r.rain!==''){const v=parseFloat(r.rain)||0;byLoc[key].rain=v;byLoc[key].rainSeq.push(v);}
    if((r.time||'')>(byLoc[key].lastTime))byLoc[key].lastTime=r.time||'';
  });
  const entries=Object.entries(byLoc).filter(([,v])=>v.snowSeq.length||v.rainSeq.length);
  if(!entries.length)return`<div style="font-size:12px;color:#456a85;text-align:center;padding:14px 0;background:#0a1424;border-radius:10px;">아직 누적된 관측값이 없습니다</div>`;
  // 미니 막대 추세(스파크라인): 최근 최대 8개 누적값 → 높이 막대
  const _spark=(seq,col)=>{
    if(!seq||seq.length<2)return'';
    const s=seq.slice(-8);const mx=Math.max.apply(null,s)||1;
    return`<span style="display:inline-flex;align-items:flex-end;gap:1px;height:16px;vertical-align:middle;margin-left:5px;">${s.map(v=>`<span style="display:inline-block;width:3px;height:${Math.max(2,Math.round(v/mx*16))}px;background:${col};border-radius:1px;opacity:.85;"></span>`).join('')}</span>`;
  };
  const snowHd=mt!=='rain'?'<th>❄️ 누적 적설(cm)</th>':'';
  const rainHd=mt!=='snow'?'<th>🌧️ 누적 강우(mm)</th>':'';
  const rows=entries.map(([,v])=>{
    const snowTd=mt!=='rain'?`<td style="text-align:center;color:#9ce0f0;font-weight:800;white-space:nowrap;">${v.snow!=null?v.snow.toFixed(1):'-'}${_spark(v.snowSeq,'#7ec8d8')}</td>`:'';
    const rainTd=mt!=='snow'?`<td style="text-align:center;color:#a8cdf5;font-weight:800;white-space:nowrap;">${v.rain!=null?v.rain.toFixed(1):'-'}${_spark(v.rainSeq,'#7db8f0')}</td>`:'';
    return`<tr><td style="font-weight:600;color:#cfe2f2;">${_esc(v.label)}</td>${snowTd}${rainTd}<td style="font-size:9px;color:#5a8aa0;">${_esc((v.lastTime||'').slice(11,16))}</td></tr>`;
  }).join('');
  return`<table class="ao-req-table"><tr><th>관측소</th>${snowHd}${rainHd}<th>최근</th></tr>${rows}</table>
  <div style="font-size:9px;color:#456a85;margin-top:5px;">※ 현재 누적값(최신 보고 기준). 막대는 누적 강우 추세.</div>`;
}
function openAlertReport(opId,presetLoc){
  _reportOpId=opId;_reportLoc=presetLoc||'';
  // 특정 관측소(대피소·본소·분소)에서 보고하면 그 관측소로 고정 — 다른 관측소 재선택 차단
  const _rlw=document.getElementById('reportLocPills');
  if(presetLoc&&_rlw){
    _rlw.innerHTML=`<span style="font-size:12px;font-weight:700;color:#e0edf8;background:rgba(79,168,208,.15);border:1px solid rgba(79,168,208,.3);border-radius:20px;padding:4px 12px;">📍 ${_esc(_stationLabel(presetLoc))}</span>`;
  }else{
    _renderStationPills('reportLocPills',_reportLoc,'selReportLoc');
  }
  document.getElementById('reportObserver').value=getAuthor()==='미지정'?'':getAuthor();
  document.getElementById('reportSnow').value='';
  document.getElementById('reportRain').value='';
  document.getElementById('reportTime').value=now().slice(11);
  document.getElementById('reportNote').value='';
  // 해당 관측소 응소자 빠른선택
  const op=(DB.g('alertOps')||[]).find(o=>o.id===opId);
  const resps=op?(op.responders||[]).filter(r=>!_reportLoc||(r.loc||'사무소')===_reportLoc):[];
  document.getElementById('reportObsQuick').innerHTML=resps.map(r=>`<div onclick="document.getElementById('reportObserver').value='${_escq(r.name)}'" style="cursor:pointer;background:rgba(79,168,208,.08);border:1px solid rgba(79,168,208,.2);color:#7db8d8;border-radius:20px;padding:3px 9px;font-size:10px;font-weight:600;">${_esc(r.name)}</div>`).join('');
  // 특보 종류에 따라 입력 필드 표시·숨김 및 모달 제목 변경
  const mt=_alertMeasureType(op||{});
  const snowEl=document.getElementById('reportSnow');
  const rainEl=document.getElementById('reportRain');
  if(snowEl)snowEl.parentElement.style.display=mt==='rain'?'none':'';
  if(rainEl)rainEl.parentElement.style.display=mt==='snow'?'none':'';
  const modalTitleEl=document.querySelector('#modalAlertReport .mtitle');
  if(modalTitleEl)modalTitleEl.textContent=mt==='snow'?'❄️ 적설량 보고':mt==='rain'?'🌧️ 강우량 보고':'🌧️ 적설량·강우량 보고';
  document.getElementById('modalAlertReport').classList.add('on');
}
function selReportLoc(el,v){document.querySelectorAll('#reportLocPills .pill').forEach(p=>p.classList.remove('on'));el.classList.add('on');_reportLoc=v;}
function addAlertReport(){
  if(!_reportLoc){toast('관측소를 선택하세요');return;}
  const observer=document.getElementById('reportObserver').value.trim();
  const snowRaw=document.getElementById('reportSnow').value.trim();
  const rainRaw=document.getElementById('reportRain').value.trim();
  const _mt=_alertMeasureType((DB.g('alertOps')||[]).find(o=>o.id===_reportOpId)||{});
  if(snowRaw===''&&rainRaw===''){toast(_mt==='snow'?'적설량을 입력하세요':_mt==='rain'?'강우량을 입력하세요':'적설량 또는 강우량을 입력하세요');return;}
  const snow=snowRaw===''?null:parseFloat(snowRaw);
  const rain=rainRaw===''?null:parseFloat(rainRaw);
  const tIn=document.getElementById('reportTime').value.trim();
  const time=tIn?now().slice(0,11)+tIn:now();
  const note=document.getElementById('reportNote').value.trim();
  const ops=DB.g('alertOps')||[];
  const idx=ops.findIndex(o=>o.id===_reportOpId);
  if(idx===-1){toast('운영 기록을 찾을 수 없습니다');return;}
  if(!ops[idx].reports)ops[idx].reports=[];
  ops[idx].reports.push({id:Date.now(),loc:_reportLoc,observer:observer||'-',snow,rain,time,at:Date.now(),by:getAuthor()});
  DB.s('alertOps',ops);
  closeM('modalAlertReport');
  toast('🌧️ '+_stationLabel(_reportLoc)+' 관측 보고 완료');
  renderAlertView();
}
function removeAlertReport(opId,repId){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const ops=DB.g('alertOps')||[];
  const idx=ops.findIndex(o=>o.id===opId);
  if(idx===-1)return;
  ops[idx].reports=(ops[idx].reports||[]).filter(r=>r.id!==repId);
  DB.s('alertOps',ops);
  renderAlertView();
}

// ── 관측 보고 알림: 운영 중 보고주기마다 적설/강우 보고 리마인드 (기기 로컬, 서버 부담 0) ──
function _startAlertReminder(){
  if(_alertReminderTimer)return;
  _alertReminderTimer=setInterval(_checkAlertReminder,60000);
  _checkAlertReminder();
}
function _stopAlertReminder(){if(_alertReminderTimer){clearInterval(_alertReminderTimer);_alertReminderTimer=null;}}
function _checkAlertReminder(){
  const active=(DB.g('alertOps')||[]).find(o=>!o.closedAt);
  if(!active){_stopAlertReminder();return;}
  try{if(isExternal())return;}catch(e){}
  const itvMs=(active.reportInterval||60)*60000;
  const start=active.startedAtMs||_alertTimeMs(active.startedAt);
  if(!start)return;
  const slot=Math.floor((Date.now()-start)/itvMs);
  if(slot<1)return; // 첫 주기 경과 전
  const key='_aoRemind_'+active.id+'_'+slot;
  if(localStorage.getItem(key))return;
  // 이번 주기에 이미 보고가 있으면 알림 생략
  const slotStart=start+slot*itvMs;
  const reported=(active.reports||[]).some(r=>(r.at||_alertTimeMs(r.time))>=slotStart);
  localStorage.setItem(key,'1');
  if(reported)return;
  const msg='🌧️ 적설량·강우량 관측 보고 시간입니다 ('+_opLevel(active)+')';
  toast(msg);
  _showSystemNoti('적설량·강우량 관측 보고 시간입니다','🌧️');
}

// ══════════════════════════════════════════
// 관리자
// ══════════════════════════════════════════
function admTab(tab,el){
  document.querySelectorAll('.adm-tab').forEach(t=>{t.classList.remove('on');t.style.color='';t.style.borderBottomColor='';});
  el.classList.add('on');if(tab==='ctrl'){el.style.color='#c0392b';el.style.borderBottomColor='#c0392b';}
  document.querySelectorAll('.adm-sec').forEach(s=>s.classList.remove('on'));
  document.getElementById('adm-'+tab).classList.add('on');
  ({ctrl:renderAdmCtrl,members:renderAdmMembers,cat:renderAdmCat,sheets:renderAdmSheets,sys:renderAdmSys,staff:renderAdmMembers})[tab]?.();
}
let _admResLimit=15; // 관리자 구조이력 표시 개수(더보기로 증가)
function renderAdmCtrl(){
  const facs=DB.g('facilities')||[];const res=DB.g('rescues')||[];const haz=DB.g('hazards')||[];
  document.getElementById('admCtrlWrap').innerHTML=`
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">📊 전체 현황</div>
      <div class="stat-grid">
        <div class="stat-box"><div class="stat-num">${facs.length}</div><div class="stat-lbl">시설물</div></div>
        <div class="stat-box"><div class="stat-num bad">${facs.filter(f=>f.status==='bad').length}</div><div class="stat-lbl">위험</div></div>
        <div class="stat-box"><div class="stat-num">${res.length}</div><div class="stat-lbl">구조이력</div></div>
        <div class="stat-box" style="border-color:#c0392b;"><div class="stat-num bad">${res.filter(r=>r.status==='ongoing').length}</div><div class="stat-lbl">진행중</div></div>
      </div>
      <div style="margin-top:8px;font-size:11px;color:#7a9cb8;">위험상황 보고 ${haz.length}건 (완료 ${haz.filter(h=>h.hazStatus&&h.hazStatus!=='미조치'&&h.hazStatus!=='조치중').length}건)</div>
    </div>
    <div class="sec-label">⚠️ 위험·요주의 시설물</div>
    ${facs.filter(f=>f.status!=='ok').map(f=>`<div class="adm-row"><div class="adm-info"><div class="adm-name">${f.type.split(' ')[0]} ${f.name}</div><div class="adm-meta">${f.loc||'-'} · <span style="color:${SC(f.status)};">${SL(f.status)}</span></div></div><div class="adm-btns"><button class="abtn" onclick="admChangeFacSt(${f.id})">변경</button><button class="abtn del" onclick="admDelFac(${f.id})">삭제</button></div></div>`).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">위험/요주의 없음</div>'}
    <div class="sec-label">🚨 진행중 구조</div>
    ${res.filter(r=>r.status==='ongoing').map(r=>{const ti=RES_TYPES[r.type]||RES_TYPES['기타'];return`<div class="adm-row"><div class="adm-info"><div class="adm-name">${ti.ico} ${r.title}</div><div class="adm-meta">${r.type} · ${r.date} · ${r.vName||'미상'}</div></div><div class="adm-btns"><button class="abtn" onclick="admEndRes(${r.id})">상황종료</button><button class="abtn del" onclick="admDelRes(${r.id})">삭제</button></div></div>`;}).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">진행중 없음</div>'}
    <div class="sec-label">📒 구조 이력 (전체 ${res.length}건 · 삭제 가능)</div>
    ${res.slice().sort((a,b)=>(b.id||0)-(a.id||0)).slice(0,_admResLimit).map(r=>{const ti=RES_TYPES[r.type]||RES_TYPES['기타'];const og=r.status==='ongoing';return`<div class="adm-row"><div class="adm-info"><div class="adm-name">${ti.ico} ${r.title} ${og?'<span style="font-size:9px;color:#ff6b5e;font-weight:700;">●진행중</span>':'<span style="font-size:9px;color:#3ad17a;">종료</span>'}</div><div class="adm-meta">${r.type} · ${r.date} · ${r.vName||'미상'}</div></div><button class="abtn del" onclick="admDelRes(${r.id})">삭제</button></div>`;}).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">구조 이력 없음</div>'}
    ${res.length>_admResLimit?`<button class="abtn" style="width:100%;margin-top:6px;" onclick="_admResLimit+=30;renderAdmCtrl();">▾ 더 보기 (${res.length-_admResLimit}건)</button>`:''}
    <div class="sec-label">📋 전체 시설물</div>
    ${facs.map(f=>`<div class="adm-row"><div class="adm-info"><div class="adm-name">${f.type.split(' ')[0]} ${f.name}</div><div class="adm-meta"><span style="color:${SC(f.status)};">${SL(f.status)}</span> · ${f.author||'-'}</div></div><button class="abtn del" onclick="admDelFac(${f.id})">삭제</button></div>`).join('')}`;
}
function admChangeFacSt(id){if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}const facs=DB.g('facilities')||[];const idx=facs.findIndex(x=>x.id===id);if(idx===-1)return;const ns=prompt(`상태 (ok/warn/bad)\n현재: ${facs[idx].status}`);if(!['ok','warn','bad'].includes(ns)){toast('⚠️ ok, warn, bad 중 입력');return;}facs[idx].status=ns;facs[idx].statusAt=Date.now();DB.s('facilities',facs);renderAdmCtrl();try{renderInspectMap();}catch(e){}toast('✅ 변경');updateSummary();}
function admDelFac(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  if(!confirm('삭제?'))return;
  DB.s('facilities',(DB.g('facilities')||[]).filter(f=>f.id!==id));
  // 1년 이전 점검이력도 함께 정리되도록 먼저 로드 후 삭제(미로드 시 최근 구간만 지워져 과거 이력이 고아로 남음)
  _loadArchive('history').then(()=>{DB.s('history',(DB.g('history')||[]).filter(h=>h.facId!==id));});
  renderAdmCtrl();try{renderInspectMap();}catch(e){}toast('🗑️ 삭제');updateSummary();
}
function admEndRes(id){if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}const res=DB.g('rescues')||[];const i=res.findIndex(x=>x.id===id);if(i===-1)return;if(!confirm("'"+(res[i].title||'')+"' 상황을 종료 처리하겠습니까?"))return;res[i].status='done';DB.s('rescues',res);renderAdmCtrl();try{renderRescueMap();}catch(e){}toast('✅ 상황 종료');}
function admDelRes(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===id);if(!r)return;
  if(!confirm("'"+(r.title||'구조 기록')+"' 을(를) 삭제하시겠습니까?\n삭제 후 5초 안에 되돌릴 수 있습니다."))return;
  // 목록에서 즉시 제거(되돌리기 대비 사본 보관). 사진 등 비가역 삭제는 5초 후 확정 시에만.
  const backup=JSON.parse(JSON.stringify(r));
  DB.s('rescues',(DB.g('rescues')||[]).filter(x=>x.id!==id));
  renderAdmCtrl();try{renderRescueMap();}catch(e){}updateSummary();
  _undoToast("🗑️ '"+(r.title||'구조 기록')+"' 삭제됨",
    function(){ // 되돌리기
      const cur=DB.g('rescues')||[];
      if(!cur.some(x=>x.id===backup.id)){cur.push(backup);DB.s('rescues',cur);}
      renderAdmCtrl();try{renderRescueMap();}catch(e){}updateSummary();toast('↩ 삭제 취소됨');
    },
    function(){ // 5초 후 실제 확정: 사진·댓글 영구 삭제
      if(backup&&_fst){
        [backup.injuryPhoto,backup.transPhoto,...((backup.reports||[]).map(p=>p.photo)),...((backup.photos||[]).map(p=>p.url))]
          .filter(u=>u&&String(u).startsWith('http'))
          .forEach(u=>{try{_fst.refFromURL(u).delete().catch(()=>{});}catch(e){}});
      }
      try{localStorage.removeItem('v7_comments_'+id);}catch(e){}
    });
}
function renderAdmMembers(){
  const pending=DB.g('pendingUsers')||[];
  const loginLog=(DB.g('loginLog')||[]).slice().sort((a,b)=>(b.at||0)-(a.at||0));
  const acl=_getAcl();
  const roleOf=id=>{const s=String(id||'');return acl.admins.includes(s)?'admin':(acl.members.includes(s)?'member':'none');};

  // 통합 목록: loginLog 우선, pendingUsers에서 보완
  const seen={};const unified=[];
  loginLog.forEach(e=>{
    const kid=String(e.kakaoId||'');if(!kid||seen[kid])return;seen[kid]=1;
    const pu=pending.find(p=>String(p.kakaoId||p.id)===kid);
    unified.push({kakaoId:kid,name:(pu&&(pu.realName||pu.name))||e.name||'',dept:(pu&&pu.dept)||e.dept||'',rank:(pu&&pu.rank)||e.rank||'',kakaoImg:(pu&&pu.kakaoImg)||'',approvalStatus:(pu&&pu.approvalStatus)||'',puId:(pu&&pu.id)||''});
  });
  pending.forEach(p=>{
    const kid=String(p.kakaoId||p.id);if(seen[kid])return;seen[kid]=1;
    unified.push({kakaoId:kid,name:p.realName||p.name||'',dept:p.dept||'',rank:p.rank||'',kakaoImg:p.kakaoImg||'',approvalStatus:p.approvalStatus||'',puId:p.id});
  });

  const usedDepts=[...new Set(unified.map(u=>u.dept).filter(Boolean))];
  const chips=['전체',...usedDepts];
  const fu=_admMemberFilter==='전체'?unified:unified.filter(u=>u.dept===_admMemberFilter);
  const adminCnt=fu.filter(u=>roleOf(u.kakaoId)==='admin').length;
  const memberCnt=fu.filter(u=>roleOf(u.kakaoId)==='member').length;

  const deptOpts=['행정과','재난안전과','탐방시설과','자원보전과','특수산악구조대','대청분소','백담분소','오색분소','한계산성분소','점봉산분소'];
  const rankOpts=['주임','계장','팀장','과장','분소장','소장'];

  let html=`
  <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;line-height:1.6;">카카오 로그인 이력 + DB 접근 권한을 한 곳에서 관리합니다. 역할을 지정하면 즉시 적용됩니다.</div>
  <div style="font-size:11px;color:#9bbdd4;margin-bottom:8px;">총 <b style="color:#e0edf8;">${fu.length}</b>명 · 관리자 <b style="color:#5dbf8a;">${adminCnt}</b> · 멤버 <b style="color:#4fa8d0;">${memberCnt}</b></div>
  <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:10px;">
    ${chips.map(d=>`<div onclick="setAdmMemberFilter('${d}')" style="padding:4px 10px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;${d===_admMemberFilter?'background:#1a4a6e;color:#4fa8d0;':'background:#0b1c30;color:#4a7090;border:1px solid #1a3a5a;'}">${d}</div>`).join('')}
  </div>`;

  if(!fu.length){
    html+=`<div style="font-size:11px;color:#4a7090;padding:8px 0;">카카오 로그인 이력이 없습니다. 직원들이 카카오 로그인하면 자동으로 표시됩니다.</div>`;
  } else {
    html+=fu.map(u=>{
      const role=roleOf(u.kakaoId);
      const roleBadge=role==='admin'?'<span style="color:#5dbf8a;font-size:10px;font-weight:700;">관리자</span>':role==='member'?'<span style="color:#4fa8d0;font-size:10px;font-weight:700;">멤버</span>':'<span style="color:#7a5040;font-size:10px;">미등록</span>';
      const appBadge=u.approvalStatus==='approved'?'<span style="color:#7ec8a0;font-size:9px;">✅승인</span>':(u.approvalStatus?'<span style="color:#e67e22;font-size:9px;">⏳대기</span>':'');
      const editId='adme_'+u.kakaoId;
      return `<div style="padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <div style="display:flex;align-items:center;gap:8px;">
          ${u.kakaoImg?`<img src="${_esc(u.kakaoImg)}" style="width:32px;height:32px;border-radius:50%;object-fit:cover;flex-shrink:0;" onerror="this.style.display='none'">`:`<div style="width:32px;height:32px;border-radius:50%;background:#1a3a5a;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;">👤</div>`}
          <div style="flex:1;min-width:0;">
            <div style="font-size:12px;font-weight:700;color:#e0edf8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(u.name||'이름없음')} ${roleBadge} ${appBadge}</div>
            <div style="font-size:10px;color:#4a7090;margin-top:1px;">${_esc(u.dept)}${u.rank?' · '+_esc(u.rank):''} <span style="font-family:monospace;color:#2a5060;">ID ${_esc(u.kakaoId)}</span></div>
          </div>
          <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;">
            <select onchange="_aclSetRole('${_escq(u.kakaoId)}',this.value)" style="background:#0a1626;color:#cfe2f2;border:1px solid rgba(79,168,208,.25);border-radius:7px;padding:4px 5px;font-size:10px;cursor:pointer;">
              <option value="none"${role==='none'?' selected':''}>미등록</option>
              <option value="member"${role==='member'?' selected':''}>멤버</option>
              <option value="admin"${role==='admin'?' selected':''}>관리자</option>
            </select>
            <button onclick="_toggleAdmMemberEdit('${_escq(editId)}')" style="background:rgba(79,168,208,.12);color:#4fa8d0;border:1px solid rgba(79,168,208,.25);border-radius:6px;padding:4px 7px;font-size:10px;cursor:pointer;">수정</button>
            ${u.puId&&u.approvalStatus!=='approved'?`<button onclick="approveUser('${_escq(u.puId)}')" style="background:rgba(39,174,96,.15);color:#7ec8a0;border:1px solid rgba(39,174,96,.3);border-radius:6px;padding:4px 7px;font-size:10px;cursor:pointer;">승인</button>`:''}
            ${u.puId?`<button onclick="deleteUser('${_escq(u.puId)}')" style="background:rgba(192,57,43,.15);color:#ff8a80;border:1px solid rgba(192,57,43,.25);border-radius:6px;padding:4px 7px;font-size:10px;cursor:pointer;">삭제</button>`:''}
          </div>
        </div>
        <div id="admMemberEdit_${editId}" style="display:none;margin-top:8px;background:rgba(0,0,0,.25);border-radius:9px;padding:10px;">
          <div style="font-size:10px;color:#4a7090;font-weight:600;margin-bottom:7px;">✏️ 직원 정보 수정</div>
          <input id="admME_name_${editId}" class="fi" value="${_esc(u.name||'')}" placeholder="이름" style="margin-bottom:6px;">
          <select id="admME_dept_${editId}" class="fsel" style="margin-bottom:6px;">
            ${deptOpts.map(d=>`<option value="${d}"${u.dept===d?' selected':''}>${d}</option>`).join('')}
          </select>
          <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;" id="admME_ranks_${editId}">
            ${rankOpts.map(r=>`<div onclick="_toggleAdmRank('${_escq(editId)}','${r}')" id="admMER_${editId}_${r}" style="cursor:pointer;border-radius:20px;font-size:10px;font-weight:700;padding:4px 10px;border:1px solid;${u.rank===r?'background:rgba(79,168,208,.2);color:#4fa8d0;border-color:rgba(79,168,208,.5);':'background:rgba(255,255,255,.04);color:rgba(255,255,255,.4);border-color:rgba(255,255,255,.12);'}">${r}</div>`).join('')}
          </div>
          <div style="display:flex;gap:6px;">
            <button onclick="_saveAdmMemberByKakao('${_escq(u.kakaoId)}','${_escq(editId)}')" style="flex:1;background:#1a4a6e;color:#fff;border:none;padding:7px;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;">저장</button>
            <button onclick="_toggleAdmMemberEdit('${_escq(editId)}')" style="background:none;border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.4);padding:7px 10px;border-radius:7px;font-size:11px;cursor:pointer;">취소</button>
          </div>
        </div>
      </div>`;
    }).join('');

    // 카카오 ID 직접 추가
    html+=`<div style="display:flex;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.06);">
      <input id="aclAddIdInp" class="fi" placeholder="카카오 ID 직접 추가 (숫자)" style="flex:1;font-family:monospace;font-size:12px;">
      <button onclick="_aclAddById()" style="background:#1a4a6e;color:#fff;border:none;padding:8px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;">＋ 멤버</button>
    </div>`;
  }
  document.getElementById('admMembersWrap').innerHTML=html;
}
// 통합 직원 정보 저장 (kakaoId 기반으로 pendingUsers 찾거나 새로 생성)
function _saveAdmMemberByKakao(kakaoId,editId){
  const list=DB.g('pendingUsers')||[];
  const name=(document.getElementById('admME_name_'+editId)||{}).value?.trim();
  const dept=(document.getElementById('admME_dept_'+editId)||{}).value||'';
  const rankEl=document.querySelector('#admME_ranks_'+editId+' [data-sel="1"]');
  const rank=rankEl?rankEl.textContent.trim():'';
  if(!name){toast('⚠️ 이름을 입력하세요');return;}
  const idx=list.findIndex(u=>String(u.kakaoId||u.id)===String(kakaoId));
  if(idx>=0){
    list[idx]={...list[idx],realName:name,name,dept,rank};
  } else {
    list.push({id:Date.now(),kakaoId:String(kakaoId),realName:name,name,dept,rank,approvalStatus:'approved',createdAt:now()});
  }
  DB.s('pendingUsers',list);
  // loginLog도 갱신
  const log=(DB.g('loginLog')||[]).slice();
  const li=log.findIndex(e=>String(e.kakaoId)===String(kakaoId));
  if(li>=0){log[li]={...log[li],name,dept,rank};DB.s('loginLog',log);}
  const me=DB.g('currentUser')||{};
  if(String(me.kakaoId)===String(kakaoId)){DB.s('currentUser',{...me,realName:name,name,dept,rank});updateUserUI();}
  renderAdmMembers();
  toast('✅ 직원 정보 저장됨');
}
var _admMemberFilter='전체';
function setAdmMemberFilter(f){_admMemberFilter=f;renderAdmMembers();}
function _toggleAdmMemberEdit(id){
  const el=document.getElementById('admMemberEdit_'+id);
  if(el)el.style.display=el.style.display==='none'?'block':'none';
}
function _toggleAdmRank(uid,rank){
  const rankOpts=['주임','계장','팀장','과장','분소장','소장'];
  rankOpts.forEach(r=>{
    const el=document.getElementById(`admMER_${uid}_${r}`);
    if(!el)return;
    const on=r===rank;
    el.style.background=on?'rgba(79,168,208,.2)':'rgba(255,255,255,.04)';
    el.style.color=on?'#4fa8d0':'rgba(255,255,255,.4)';
    el.style.borderColor=on?'rgba(79,168,208,.5)':'rgba(255,255,255,.12)';
    el.dataset.sel=on?'1':'';
  });
}
function renderAdmCat(){
  const cats=DB.g('catFac')||[];
  const meta=DB.g('catFacMeta')||{};
  const togHtml=(id,label,checked)=>`<label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#7a9cb8;cursor:pointer;margin-top:5px;"><input type="checkbox" id="${id}"${checked?' checked':''}> ${label}</label>`;
  const rowsHtml=cats.map((c,i)=>{
    const m=meta[c]||{};
    const badges=(m.rescue?'<span style="font-size:9px;background:rgba(79,168,208,.15);color:#4fa8d0;border:1px solid rgba(79,168,208,.3);border-radius:3px;padding:1px 5px;margin-right:3px;">🗺 재난</span>':'')+(m.adminOnly?'<span style="font-size:9px;background:rgba(192,57,43,.12);color:#e05050;border:1px solid rgba(192,57,43,.3);border-radius:3px;padding:1px 5px;">🔒 관리자</span>':'');
    return `<div style="border-bottom:1px solid rgba(255,255,255,.05);padding:6px 0;">
      <div class="adm-row" style="margin-bottom:0;">
        <div class="adm-info" style="flex:1;min-width:0;">
          <div class="adm-name" style="font-size:12px;">${_esc(c)}</div>
          <div style="margin-top:3px;">${badges||'<span style="font-size:9px;color:#3a6a8a;">일반</span>'}</div>
        </div>
        <button class="abtn" style="font-size:10px;" onclick="toggleCatEdit(${i})">수정</button>
        <button class="abtn del" style="font-size:10px;" onclick="delCat(${i})">삭제</button>
      </div>
      <div id="catEdit${i}" style="display:none;padding:8px;background:rgba(0,0,0,.2);border-radius:7px;margin-top:4px;">
        <input type="text" id="catEditName${i}" class="fi" value="" style="margin-bottom:4px;">
        ${togHtml('catER'+i,'🗺 재난관리지도에 표시',m.rescue)}
        ${togHtml('catEA'+i,'🔒 관리자만 볼 수 있음',m.adminOnly)}
        <div style="display:flex;gap:6px;margin-top:8px;">
          <button onclick="submitEditCat(${i})" style="flex:1;background:#1a4a6e;color:#fff;border:none;padding:7px;border-radius:7px;font-size:11px;cursor:pointer;">저장</button>
          <button onclick="toggleCatEdit(${i})" style="background:none;border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.4);padding:7px 10px;border-radius:7px;font-size:11px;cursor:pointer;">취소</button>
        </div>
      </div>
    </div>`;
  }).join('');
  const addHtml=`<div id="catAddForm" style="display:none;padding:10px;background:rgba(0,0,0,.2);border-radius:9px;margin-top:8px;">
    <input type="text" id="newCatName" class="fi" placeholder="이모지 포함 이름 예: 🛖 야영시설" style="margin-bottom:4px;">
    ${togHtml('newCatRescue','🗺 재난관리지도에 표시',false)}
    ${togHtml('newCatAdmin','🔒 관리자만 볼 수 있음',false)}
    <div style="display:flex;gap:6px;margin-top:8px;">
      <button onclick="submitAddCat()" style="flex:1;background:#0c4838;color:#fff;border:none;padding:8px;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;">추가</button>
      <button onclick="document.getElementById('catAddForm').style.display='none';document.getElementById('catAddBtn').style.display='block';" style="background:none;border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.4);padding:8px 10px;border-radius:7px;font-size:11px;cursor:pointer;">취소</button>
    </div>
  </div>
  <button id="catAddBtn" class="btn btn-ghost" style="width:100%;padding:9px;border-radius:8px;margin-top:8px;font-size:12px;" onclick="this.style.display='none';document.getElementById('catAddForm').style.display='block';">＋ 카테고리 추가</button>`;
  document.getElementById('admCatWrap').innerHTML=`<div style="font-size:10px;color:#3a6a8a;margin-bottom:7px;font-weight:600;">시설물 카테고리</div>${rowsHtml}${addHtml}`;
  // 수정 폼 name 값 채우기 (innerHTML escaping 우회)
  cats.forEach((c,i)=>{const el=document.getElementById('catEditName'+i);if(el)el.value=c;});
}
function toggleCatEdit(i){const el=document.getElementById('catEdit'+i);if(el)el.style.display=el.style.display==='none'?'block':'none';}
function submitAddCat(){
  const n=(document.getElementById('newCatName').value||'').trim();
  if(!n){toast('⚠️ 카테고리명 입력');return;}
  const cats=DB.g('catFac')||[];
  if(cats.includes(n)){toast('⚠️ 이미 존재');return;}
  cats.push(n);DB.s('catFac',cats);
  const meta=DB.g('catFacMeta')||{};
  meta[n]={rescue:!!document.getElementById('newCatRescue').checked,adminOnly:!!document.getElementById('newCatAdmin').checked};
  DB.s('catFacMeta',meta);renderAdmCat();toast('✅ 추가');
}
function submitEditCat(i){
  const cats=DB.g('catFac')||[];const oldName=cats[i];
  const newName=(document.getElementById('catEditName'+i).value||'').trim();
  if(!newName){toast('⚠️ 카테고리명 입력');return;}
  cats[i]=newName;DB.s('catFac',cats);
  const meta=DB.g('catFacMeta')||{};
  if(oldName!==newName)delete meta[oldName];
  meta[newName]={rescue:!!document.getElementById('catER'+i).checked,adminOnly:!!document.getElementById('catEA'+i).checked};
  DB.s('catFacMeta',meta);renderAdmCat();toast('✅ 수정');
}
function delCat(i){if(!confirm('삭제?'))return;const cats=DB.g('catFac')||[];const name=cats[i];cats.splice(i,1);DB.s('catFac',cats);const meta=DB.g('catFacMeta')||{};delete meta[name];DB.s('catFacMeta',meta);renderAdmCat();}
function renderAdmSheets(){
  const url=DB.g('sheetsUrl')||'';
  document.getElementById('admSheetsWrap').innerHTML=`
    <div class="scard" style="margin-bottom:8px;"><div class="stitle">🔗 Google Sheets 자동 동기화</div>
      <div style="font-size:12px;color:#7a9cb8;line-height:1.6;margin-bottom:10px;">구조보고·시설점검 저장 시 자동으로 스프레드시트에 기록됩니다.</div>
      <div class="fg"><span class="fl">Apps Script 배포 URL</span><input type="text" id="sheetsUrlIn" class="fi" placeholder="https://script.google.com/macros/s/..." value="${url}"></div>
      <button onclick="saveSheetsUrl()" style="width:100%;background:${url?'#0c4838':'#1a4a6e'};color:#fff;border:none;padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">${url?'✅ 저장됨 (재입력하여 변경)':'저장'}</button>
    </div>
    <div class="scard"><div class="stitle">📌 Google Sheets 설정 방법</div>
      <div style="font-size:11px;color:#7a9cb8;line-height:1.8;">1. Google Sheets 열기<br>2. 확장 프로그램 → Apps Script<br>3. 코드 작성 → 배포 → 웹앱으로 배포<br>4. 생성된 URL을 위에 입력</div>
    </div>`;
}
function saveSheetsUrl(){const url=document.getElementById('sheetsUrlIn')?.value?.trim();if(!url){toast('⚠️ URL 입력');return;}DB.s('sheetsUrl',url);toast('✅ URL 저장');renderAdmSheets();}
// ── 전체 데이터 백업/복원 (JSON) ──
const _BACKUP_KEYS=['rescues','hazards','facilities','history','catFac','catFacMeta','pendingUsers','approvedUsers','deletedKakaoIds'];
// 과거 안전사고 데이터(2020~2026) 머지 핵심 — id 기준 중복 제외. silent=자동(토스트 최소)
async function _doAccidentSeed(silent){
  let seed;
  try{const resp=await fetch('./accidents-seed.json?v='+APP_VER);seed=await resp.json();}
  catch(e){if(!silent)toast('⚠️ 데이터 파일을 불러오지 못했습니다');return 0;}
  if(!Array.isArray(seed)||!seed.length){if(!silent)toast('⚠️ 데이터 없음');return 0;}
  try{await _loadArchive('rescues');}catch(e){} // 아카이브까지 로드해 전체 id 비교(중복 방지)
  const cur=DB.g('rescues')||[];
  const have=new Set(cur.map(r=>String(r.id)));
  const add=seed.filter(r=>!have.has(String(r.id)));
  if(!add.length){if(!silent)toast('✅ 이미 모두 가져왔습니다 (추가 0건)');return 0;}
  DB.s('rescues',cur.concat(add));
  toast('📊 과거 안전사고 '+add.length+'건 자동 반영 — 동기화 진행 중',5000);
  try{renderAdmSys();}catch(e){}try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}try{updateSummary();}catch(e){}
  return add.length;
}
// 수동 가져오기 버튼
async function importAccidentSeed(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  if(!confirm('2020~2026 과거 안전사고 약 1,312건을 가져옵니다.\n이미 가져온 건 건너뜁니다. 동기화는 백그라운드로 진행됩니다.'))return;
  toast('📥 데이터 불러오는 중...');
  await _doAccidentSeed(false);
  try{localStorage.setItem('_accSeeded_v1','1');}catch(e){}
}
// 관리자 진입 시 1회 자동 반영 (버튼 클릭 없이) — 관리자 + 미시드 시에만
let _accSeedRunning=false;
async function _autoSeedAccidents(){
  if(_accSeedRunning)return;
  try{if(localStorage.getItem('_accSeeded_v1'))return;}catch(e){}
  if(!_fdb||!isAdminUser())return; // 대량 쓰기는 관리자만 트리거
  _accSeedRunning=true;
  try{const n=await _doAccidentSeed(true);try{localStorage.setItem('_accSeeded_v1','1');}catch(e){}}
  finally{_accSeedRunning=false;}
}
function toggleSosBlock(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const cur=!!DB.g('sosBlocked');
  if(!confirm(cur?'조난·사고자 접수를 다시 허용할까요?':'조난·사고자 접수를 차단할까요?\n차단 중엔 위치가 들어오지 않습니다(악용 방지).'))return;
  DB.s('sosBlocked',!cur);
  toast(cur?'✅ 조난 접수 허용됨':'⛔ 조난 접수 차단됨');
  try{renderAdmSys();}catch(e){}try{_sosPings=[];_drawSosPins();_updateSosFab();}catch(e){}
}
function removeImportedAccidents(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const cur=DB.g('rescues')||[];
  const imp=cur.filter(r=>r.imported);
  if(!imp.length){toast('가져온 데이터가 없습니다 (통계 화면을 한번 열면 보관분까지 로드됩니다)');return;}
  if(!confirm('가져온 과거 안전사고 '+imp.length+'건을 삭제할까요?'))return;
  DB.s('rescues',cur.filter(r=>!r.imported));
  toast('🗑️ '+imp.length+'건 삭제');
  try{renderAdmSys();}catch(e){}try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}try{updateSummary();}catch(e){}
}
function exportAllData(){
  const data={};
  _BACKUP_KEYS.forEach(k=>{data[k]=DB.g(k);});
  const out={app:'seoraksan',ver:APP_VER,exportedAt:now(),data};
  const blob=new Blob(['\uFEFF'+JSON.stringify(out,null,1)],{type:'application/json'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='설악산백업_'+today()+'.json';
  a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);
  toast('⬇️ 백업 파일 다운로드');
}
function importAllData(inp){
  const f=inp.files&&inp.files[0];inp.value='';
  if(!f)return;
  const rd=new FileReader();
  rd.onload=()=>{
    try{
      const out=JSON.parse(String(rd.result).replace(/^\uFEFF/,''));
      if(!out||out.app!=='seoraksan'||!out.data){toast('⚠️ 올바른 백업 파일이 아닙니다');return;}
      const counts=_BACKUP_KEYS.map(k=>{const v=out.data[k];return v&&v.length?k+' '+v.length+'건':null;}).filter(Boolean).join(', ');
      if(!confirm('백업 시점: '+(out.exportedAt||'?')+'\n'+counts+'\n\n현재 데이터를 이 백업으로 덮어씁니다. 계속할까요?'))return;
      if(!confirm('⚠️ 마지막 확인 — 복원 후 되돌릴 수 없습니다.'))return;
      _BACKUP_KEYS.forEach(k=>{if(out.data[k]!==undefined&&out.data[k]!==null)DB.s(k,out.data[k]);});
      toast('✅ 복원 완료');
      renderAdmCtrl();try{renderRescueMap();}catch(e){}updateSummary();
    }catch(e){toast('⚠️ 파일을 읽을 수 없습니다');}
  };
  rd.readAsText(f);
}

// ── 허용목록(_acl) 관리 ──
function _getAcl(){
  const a=DB.g('_acl')||{};
  const norm=x=>(Array.isArray(x)?x:[]).map(String).filter(Boolean);
  return {members:norm(a.members),admins:norm(a.admins)};
}
function _aclSetRole(kakaoId,role){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  kakaoId=String(kakaoId);
  const acl=_getAcl();
  acl.members=acl.members.filter(id=>id!==kakaoId);
  acl.admins=acl.admins.filter(id=>id!==kakaoId);
  if(role==='member')acl.members.push(kakaoId);
  else if(role==='admin')acl.admins.push(kakaoId);
  DB.s('_acl',acl);
  renderAdmSys();
  toast(role==='none'?'제거됨':role==='admin'?'관리자로 설정':'멤버로 설정');
}
function _aclAddById(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const inp=document.getElementById('aclAddIdInp');
  const id=(inp&&inp.value||'').trim();
  if(!id){toast('⚠️ 카카오 ID를 입력하세요');return;}
  if(!/^\d+$/.test(id)){toast('⚠️ 카카오 ID는 숫자여야 합니다');return;}
  _aclSetRole(id,'member');
}
function renderAdmSys(){
  const unseenCnt=_getUnseenCount();
  document.getElementById('admSysWrap').innerHTML=`

    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">💾 데이터 백업 / 복원</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">전체 데이터를 파일로 내려받아 보관하세요 (사진 원본은 서버에 별도 저장)</div>
      <div style="display:flex;gap:6px;">
        <button onclick="exportAllData()" style="flex:1;background:rgba(39,174,96,.1);color:#27ae60;border:1px solid rgba(39,174,96,.3);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">⬇️ 전체 백업</button>
        <button onclick="document.getElementById('restoreFileInp').click()" style="flex:1;background:rgba(230,126,34,.08);color:#e67e22;border:1px solid rgba(230,126,34,.28);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">⬆️ 복원</button>
        <input type="file" id="restoreFileInp" accept=".json" style="display:none;" onchange="importAllData(this)">
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">📊 과거 안전사고 데이터 (2020~2026)</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">엑셀 통계자료 약 1,312건을 가져옵니다. 통계·사고다발구간 히트맵에 반영됩니다. (이미 가져온 건 건너뜀, 동기화는 백그라운드 진행 — 최근 1년 외는 자동 보관)</div>
      <div style="display:flex;gap:6px;">
        <button onclick="importAccidentSeed()" style="flex:1;background:rgba(79,168,208,.12);color:#4fa8d0;border:1px solid rgba(79,168,208,.35);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">📥 데이터 가져오기</button>
        <button onclick="removeImportedAccidents()" style="flex:none;background:rgba(192,57,43,.08);color:#c0392b;border:1px solid rgba(192,57,43,.28);padding:9px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">가져온 것 삭제</button>
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🔄 앱 업데이트</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">현재 버전 <b style="color:#cfe2f2;">${OTA_VER}</b> · 앱(APK)은 재설치 없이 최신 코드로 자체 업데이트됩니다. (웹은 새로고침 시 자동)</div>
      <button onclick="_otaCheck(true)" style="width:100%;padding:11px;border-radius:8px;border:1px solid rgba(79,168,208,.4);background:rgba(79,168,208,.12);color:#4fa8d0;font-size:13px;font-weight:700;cursor:pointer;">🔄 업데이트 확인 / 적용</button>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🆘 조난·사고자 위치 접수</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">악용·오작동 시 전체 접수를 차단할 수 있습니다. 차단 중엔 1회용 링크도 발급되지 않고 수신 위치가 표시되지 않습니다.</div>
      ${(()=>{const blk=!!DB.g('sosBlocked');return `<button onclick="toggleSosBlock()" style="width:100%;padding:11px;border-radius:8px;border:1px solid ${blk?'rgba(39,174,96,.4)':'rgba(192,57,43,.4)'};background:${blk?'rgba(39,174,96,.12)':'rgba(192,57,43,.12)'};color:${blk?'#27ae60':'#e05050'};font-size:13px;font-weight:700;cursor:pointer;">${blk?'⛔ 현재 차단됨 — 탭하여 접수 허용':'🆗 현재 허용됨 — 탭하여 접수 차단'}</button>`;})()}
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🐞 최근 오류 기록 <button onclick="localStorage.removeItem('_errLog');renderAdmSys();" style="float:right;background:none;border:none;color:rgba(255,255,255,.3);font-size:10px;cursor:pointer;">비우기</button></div>
      ${(()=>{try{const log=JSON.parse(localStorage.getItem('_errLog')||'[]');return log.length?log.slice(0,10).map(e=>`<div style="font-size:10px;color:#b8856a;font-family:monospace;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04);">${e.t} ${_esc(e.m)}</div>`).join(''):'<div style="font-size:11px;color:rgba(255,255,255,.25);">기록된 오류 없음 ✅</div>';}catch(e){return'';}})()}
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🚒 외부기관 관리</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">119·산악구조대·특수대응단 등 기관별로 추가하세요. 각 기관에 코드를 전달하면 해당 기관명으로 접수됩니다 (접수·조회·댓글만 가능).</div>
      <div id="extAgencyListWrap">${_extAgencyRowsHtml()}</div>
      <div style="display:flex;gap:6px;margin-top:8px;">
        <button onclick="addExtAgencyRow()" style="flex:1;background:rgba(255,255,255,.05);color:#9bbdd4;border:1px dashed rgba(255,120,30,.3);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">＋ 기관 추가</button>
        <button onclick="saveExtAgencies()" style="flex:1;background:#7a3010;color:#fff;border:none;padding:9px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">💾 전체 저장</button>
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🤖 AI 출동지령서 스캔 키</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">Google Gemini API 키 (무료) — <a href="https://aistudio.google.com/app/apikey" target="_blank" style="color:#c4b5fd;">aistudio.google.com</a>에서 발급</div>
      <div style="display:flex;gap:6px;">
        <input id="geminiKeyInp" type="password" class="fi" value="${DB.g('geminiApiKey')||''}" placeholder="AIza..." style="flex:1;font-family:monospace;font-size:13px;">
        <button onclick="saveGeminiKey()" style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">저장</button>
      </div>
      <div style="font-size:10px;color:#3a4a6a;margin-top:7px;">무료 티어: 1일 1,500회 · 분당 100만 토큰 · 결제 불필요</div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🌦️ 기상청 프록시 주소</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">실제 기상청 데이터를 안정적으로 받기 위한 본인 소유 프록시(Cloudflare Worker) 주소. 비우면 공개 프록시로 동작. 설정법: 저장소 <b>cloudflare-worker/README.md</b></div>
      <div style="display:flex;gap:6px;">
        <input id="kmaProxyInp" type="text" class="fi" value="${_esc(DB.g('kmaProxyUrl')||'')}" placeholder="https://seoraksan-kma.xxx.workers.dev" style="flex:1;font-family:monospace;font-size:11px;">
        <button onclick="saveKmaProxy()" style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">저장</button>
      </div>
      <div style="font-size:10px;color:#3a4a6a;margin-top:7px;">Cloudflare Workers 무료: 1일 10만 요청 · 설정 후 날씨 상세 출처가 '기상청'으로 표시</div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">📲 푸시 알림 (꺼진 폰까지)</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">구조 1보·위험상황 발생 시 자동 발송됩니다. 아래에서 <b style="color:#5dbf8a;">원하는 내용을 직접 작성해 전 직원에게</b> 푸시할 수도 있습니다.</div>
      <div class="fg"><span class="fl">제목</span>
        <input id="pushTitleInp" class="fi" type="text" value="설악산 현장관리" maxlength="40" style="font-size:13px;">
      </div>
      <div class="fg"><span class="fl">내용</span>
        <textarea id="pushBodyInp" class="fi" rows="2" placeholder="보낼 메시지를 입력하세요" maxlength="200" style="font-size:13px;resize:vertical;"></textarea>
      </div>
      <div style="display:flex;gap:6px;margin-top:4px;">
        <button onclick="sendCustomPush()" style="flex:2;background:#1a4a6e;color:#fff;border:none;padding:10px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">📨 전 직원에게 발송</button>
        <button onclick="renderAdmSys()" style="background:rgba(255,255,255,.05);color:#7a9cb8;border:1px solid rgba(255,255,255,.1);padding:10px 12px;border-radius:8px;font-size:12px;cursor:pointer;">↻ 새로고침</button>
      </div>
      <div id="fcmAdvWrap" style="margin-top:8px;">
        <div onclick="var e=document.getElementById('fcmAdv');e.style.display=e.style.display==='none'?'block':'none';" style="font-size:10px;color:#3a6a8a;cursor:pointer;">⚙️ 고급: 발송기 직접 지정 (선택)</div>
        <div id="fcmAdv" style="display:none;margin-top:6px;">
          <div class="fg"><span class="fl">Apps Script 발송 URL (비우면 내장값 사용)</span>
            <input id="fcmUrlInp" class="fi" type="text" placeholder="내장값 사용 중" value="${DB.g('fcmPushUrl')||''}" style="font-family:monospace;font-size:11px;">
          </div>
          <div class="fg"><span class="fl">공유 비밀번호</span>
            <input id="fcmSecInp" class="fi" type="text" placeholder="내장값 사용 중" value="${DB.g('fcmPushSecret')||''}" style="font-family:monospace;font-size:12px;">
          </div>
          <button onclick="saveFcmCfg()" style="width:100%;background:#1a4a6e;color:#fff;border:none;padding:8px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">💾 저장</button>
        </div>
      </div>
      <div id="fcmStatus" style="font-size:10px;color:#3a6a8a;margin-top:8px;line-height:1.7;">등록된 기기 확인 중…</div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">👥 새 가입자 알림${unseenCnt>0?` <span style="background:#c0392b;color:#fff;font-size:10px;padding:1px 7px;border-radius:20px;margin-left:6px;font-weight:700;">${unseenCnt}</span>`:''}</div>
      ${_renderPendingList()}
    </div>
    <div class="scard" style="margin-bottom:8px;"><div class="stitle">📊 데이터 현황</div>
      <div style="font-size:12px;color:#b8d4e8;line-height:2.1;">시설물 <b>${(DB.g('facilities')||[]).length}개</b> · 점검이력 <b>${(DB.g('history')||[]).length}건</b><br>구조이력 <b>${(DB.g('rescues')||[]).length}건</b> · 위험상황 <b>${(DB.g('hazards')||[]).length}건</b><br>특보운영 <b>${(DB.g('alertOps')||[]).length}건</b> · 대원 <b>${(DB.g('members')||[]).length}명</b></div>
      <div style="margin-top:8px;display:flex;align-items:center;gap:6px;font-size:11px;">
        <span style="width:8px;height:8px;border-radius:50%;background:${_fdb?'#27ae60':'#e05050'};display:inline-block;flex-shrink:0;"></span>
        <span style="color:${_fdb?'#5dbf8a':'#e05050'};font-weight:700;">Firebase ${_fdb?'연결됨':'미연결'}</span>
        ${_fdb?'<span style="color:#4a7090;">· 모든 데이터 실시간 동기화 중</span>':'<span style="color:#7a3020;">· 오프라인 상태입니다</span>'}
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">📁 데이터 백업 / 복원</div>
      <div style="font-size:11px;color:#7a9cb8;margin-bottom:10px;">시설물·구조이력·위키 전체를 JSON 파일로 내보내거나 복원합니다</div>
      <div style="display:flex;flex-direction:column;gap:7px;">
        <button onclick="exportAllData()" style="width:100%;background:rgba(39,174,96,.12);color:#5dbf8a;border:1px solid rgba(39,174,96,.3);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">📤 JSON 내보내기 (백업)</button>
        <label style="width:100%;background:rgba(79,168,208,.1);color:#4fa8d0;border:1px solid rgba(79,168,208,.28);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;text-align:center;display:block;">
          📥 JSON 가져오기 (복원)
          <input type="file" accept=".json" style="display:none;" onchange="importAllData(this)">
        </label>
        <button onclick="forceSyncFirestore()" style="width:100%;background:rgba(255,165,0,.1);color:#f0a020;border:1px solid rgba(255,165,0,.28);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">🔄 Firebase 강제 동기화</button>
        <button onclick="updateSignCoords()" style="width:100%;background:rgba(93,191,138,.12);color:#5dbf8a;border:1px solid rgba(93,191,138,.3);padding:10px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">🪧 표지판 좌표 최신화 (엑셀 기준 일괄 적용)</button>
        <button onclick="fixMisclassifiedTemples()" style="width:100%;background:rgba(79,168,208,.1);color:#4fa8d0;border:1px solid rgba(79,168,208,.28);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">🪧 암지형 오분류 복구 (귀면암 등)</button>
      </div>
    </div>
    <div class="scard"><div class="stitle" style="color:#c0392b;">⚠️ 위험 작업</div>
      <div style="display:flex;flex-direction:column;gap:7px;">
        <button onclick="resetAll()" style="width:100%;background:rgba(192,57,43,.1);color:#c0392b;border:1px solid rgba(192,57,43,.28);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">전체 데이터 초기화</button>
        <button onclick="clearNotisOnly()" style="width:100%;background:rgba(255,255,255,.05);color:#b8d4e8;border:none;padding:10px;border-radius:8px;font-size:12px;cursor:pointer;">알림 이력만 삭제</button>
      </div>
    </div>`;
  setTimeout(_refreshFcmStatus,100);
}
function deleteUser(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const list=DB.g('pendingUsers')||[];
  const u=list.find(function(p){return p.id===id;});
  if(!u)return;
  if(!confirm((u.realName||u.name||'이 사용자')+'을(를) 삭제하시겠습니까?\n(작성한 데이터는 유지됩니다)'))return;
  if(u.kakaoId){
    const deleted=DB.g('deletedKakaoIds')||[];
    if(!deleted.includes(String(u.kakaoId)))deleted.push(String(u.kakaoId));
    DB.s('deletedKakaoIds',deleted);
  }
  DB.s('pendingUsers',list.filter(function(p){return p.id!==id;}));
  renderAdmSys();
  try{renderAdmMembers();}catch(e){}
  toast('🗑️ 삭제 완료');
}
function approveUser(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const list=DB.g('pendingUsers')||[];
  const idx=list.findIndex(function(p){return p.id===id;});
  if(idx===-1)return;
  list[idx].approvalStatus='approved';
  list[idx].seen=true;
  DB.s('pendingUsers',list);
  renderAdmMembers();
  renderAdmSys();
  toast('✅ 승인 완료');
}
function _checkDeletedUser(){
  if(DB.g('authType')!=='kakao')return;
  var u=DB.g('currentUser')||{};
  if(!u.kakaoId)return;
  var deleted=DB.g('deletedKakaoIds')||[];
  if(!deleted.includes(String(u.kakaoId)))return;
  DB.s('authType','');
  DB.s('currentUser',{});
  if(window.showLoginScreen)window.showLoginScreen();
  updateUserUI();
  toast('⚠️ 계정이 관리자에 의해 삭제되었습니다');
}
function resetAll(){if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}if(!confirm('모든 데이터 초기화. 되돌릴 수 없습니다.'))return;['members','catFac','facilities','rescues','hazards','history','alertOps','notis','notiSetting','currentUser','sheetsUrl'].forEach(k=>DB.d(k));initDB();toast('✅ 초기화');renderAdmSys();updateSummary();}
function clearNotisOnly(){DB.s('notis',[]);updateBell();toast('🗑️ 알림 이력 삭제');renderAdmSys();}

// (구버전 exportAllData/importAllData 중복 정의 제거 — 권한 데이터 누락·복원버튼 버그 유발.
//  더 완전한 상단 정의(_BACKUP_KEYS 기반, app 마커·검증·이중확인)로 일원화)

function forceSyncFirestore(){
  if(!_fdb){toast('⚠️ Firebase 미연결 — 인터넷 연결 확인');return;}
  const keys=['facilities','history','catFac','catFacMeta'];
  let cnt=0;
  keys.forEach(k=>{
    const v=_fs[k];
    if(v===undefined||v===null)return;
    if(_SHARED_COLL.includes(k)){
      v.forEach(r=>{if(r&&r.id!=null)_txMergeSet(k,String(r.id),r).catch(()=>{});}); // 건별 콜렉션은 _txMergeDoc(단일문서) 대상이 아님 — per-record 병합으로 분리
    }else{
      _txMergeDoc(k,_fsDocBase[k],v).catch(()=>{});
    }
    cnt++;
  });
  toast('🔄 Firebase에 '+cnt+'개 항목 동기화 중...');
  setTimeout(()=>toast('✅ 동기화 완료'),1500);
}

// 잘못 사찰로 분류된 암지형 다목적표지판 복구
// "암"으로 끝나는 이름이 다목적위치표지판인데 사찰로 잘못 변경된 것을 되돌림
// 다목적위치표지판 권위 좌표 (2024~2025 지형지물 엑셀 기준, 12-08 lat=lng 오류 보정)
const _SIGN_COORD_FIX={"01-01":[38.173718,128.480326],"01-02":[38.173346,128.47574],"01-03":[38.170381,128.473421],"01-04":[38.166325,128.471024],"01-05":[38.162865,128.466413],"01-06":[38.159572,128.469408],"01-07":[38.155681,128.470476],"01-08":[38.152346,128.469876],"01-09":[38.150047,128.472944],"01-10":[38.146238,128.473648],"01-11":[38.143603,128.474455],"01-12":[38.139774,128.47469],"01-13":[38.136418,128.473544],"01-14":[38.13374,128.469714],"01-15":[38.135076,128.46466],"01-16":[38.132853,128.464842],"01-17":[38.13034,128.461456],"01-18":[38.12721,128.458564],"01-19":[38.12373,128.457235],"01-20":[38.120766,128.462003],"02-01":[38.164229,128.463435],"02-02":[38.165649,128.462028],"02-03":[38.16608,128.457469],"02-04":[38.163876,128.452519],"02-05":[38.161342,128.447673],"02-06":[38.161155,128.44155],"02-07":[38.158086,128.437903],"02-08":[38.156006,128.43436],"02-09":[38.153822,128.431494],"02-10":[38.153225,128.430556],"02-11":[38.151083,128.427951],"02-12":[38.152069,128.420109],"02-13":[38.152974,128.416565],"02-14":[38.15252,128.411329],"03-01":[38.154916,128.438841],"03-02":[38.153187,128.441108],"03-03":[38.150306,128.443895],"03-04":[38.14833,128.450044],"03-05":[38.146088,128.453457],"03-06":[38.142938,128.454629],"03-07":[38.140757,128.45799],"03-08":[38.13874,128.461976],"03-09":[38.135323,128.463904],"04-01":[38.177708,128.483462],"04-02":[38.180858,128.479667],"04-03":[38.183441,128.476513],"04-04":[38.187867,128.475315],"04-05":[38.190873,128.473491],"05-01":[38.170065,128.495219],"05-02":[38.168687,128.500664],"05-03":[38.165785,128.501889],"05-04":[38.162964,128.502201],"06-01":[38.087797,128.448537],"06-02":[38.092245,128.450126],"06-03":[38.096467,128.451558],"06-04":[38.098362,128.454893],"06-05":[38.103345,128.456638],"06-06":[38.105879,128.459868],"06-07":[38.108556,128.459998],"06-08":[38.113456,128.460649],"06-09":[38.115969,128.46315],"07-01":[38.077336,128.442598],"07-02":[38.076182,128.439941],"07-03":[38.078343,128.437413],"07-04":[38.080587,128.43512],"07-05":[38.082892,128.432072],"07-06":[38.083242,128.430483],"08-01":[38.081944,128.427122],"08-02":[38.07937,128.42608],"08-03":[38.08044,128.423813],"08-04":[38.080789,128.419306],"08-05":[38.083671,128.417325],"08-06":[38.086039,128.416179],"08-07":[38.087871,128.417377],"08-08":[38.088614,128.421311],"09-01":[38.100203,128.409455],"09-02":[38.10358,128.41206],"09-03":[38.108377,128.410679],"09-04":[38.110374,128.410132],"09-05":[38.112063,128.410236],"09-06":[38.111282,128.416645],"09-07":[38.110274,128.421674],"09-08":[38.109432,128.427041],"09-09":[38.110071,128.43061],"09-10":[38.112214,128.437488],"09-11":[38.115139,128.441708],"09-12":[38.11617,128.448039],"09-13":[38.116624,128.451661],"09-14":[38.119302,128.45463],"10-01":[38.175507,128.372925],"10-02":[38.170978,128.372351],"10-03":[38.168363,128.371283],"10-04":[38.169578,128.375608],"10-05":[38.167891,128.37936],"10-06":[38.164905,128.376207],"10-07":[38.160108,128.374905],"10-08":[38.157452,128.375296],"10-09":[38.15628,128.380897],"10-10":[38.156816,128.386082],"10-11":[38.153276,128.389078],"10-12":[38.152989,128.394159],"10-13":[38.152579,128.399891],"10-14":[38.153527,128.405154],"10-15":[38.150234,128.408359],"10-16":[38.146899,128.411954],"10-17":[38.145418,128.415471],"10-18":[38.143215,128.415628],"10-19":[38.14128,128.415185],"10-20":[38.138748,128.416747],"10-21":[38.136607,128.419145],"10-22":[38.135785,128.423366],"10-23":[38.133644,128.425945],"10-24":[38.132595,128.430374],"10-25":[38.131196,128.433501],"10-26":[38.130203,128.437931],"10-27":[38.128132,128.444052],"10-28":[38.128647,128.44671],"10-29":[38.127557,128.450982],"11-01":[38.121889,128.344708],"11-02":[38.125471,128.343197],"11-03":[38.129012,128.34192],"11-04":[38.131772,128.344916],"11-05":[38.135334,128.346584],"11-06":[38.138627,128.342389],"11-07":[38.139779,128.338168],"11-08":[38.14262,128.338272],"11-09":[38.143772,128.334077],"11-10":[38.147519,128.332045],"11-11":[38.151637,128.332957],"11-12":[38.155404,128.331654],"11-13":[38.157977,128.327798],"11-14":[38.159973,128.323186],"11-15":[38.16166,128.321206],"11-16":[38.164666,128.318731],"11-17":[38.171418,128.314666],"11-18":[38.174361,128.312035],"11-19":[38.17541,128.307736],"11-20":[38.174627,128.305625],"11-21":[38.175862,128.303593],"11-22":[38.179465,128.301717],"12-01":[38.153952,128.375739],"12-02":[38.153951,128.372482],"12-03":[38.15045,128.368105],"12-05":[38.148019,128.359142],"12-06":[38.145115,128.355129],"12-07":[38.142191,128.352446],"12-08":[38.139514,128.349736],"12-09":[38.136837,128.347365],"12-10":[38.135458,128.350726],"12-11":[38.135027,128.356094],"12-12":[38.131322,128.357709],"12-13":[38.128851,128.359585],"12-14":[38.128235,128.364041],"12-15":[38.124532,128.377693],"12-16":[38.123467,128.382941],"12-17":[38.123319,128.387724],"12-18":[38.124021,128.393508],"12-19":[38.122416,128.397052],"12-20":[38.119884,128.398954],"12-21":[38.116487,128.401664],"12-22":[38.114141,128.406223],"13-01":[38.148634,128.43165],"13-02":[38.146721,128.435845],"13-03":[38.145281,128.439232],"13-04":[38.143017,128.444416],"13-05":[38.141041,128.445433],"13-06":[38.137665,128.445745],"13-07":[38.132538,128.446319]};
// 표지판 loc 코드 추출: f.loc 우선, 없으면 이름 앞 'NN-NN' 패턴
function _signLocCode(f){
  if(f.loc&&/^\d{2}-\d{2}$/.test(String(f.loc).trim()))return String(f.loc).trim();
  const m=String(f.name||'').match(/(\d{2}-\d{2})/);
  return m?m[1]:'';
}
// 라이브 시설물 좌표를 권위 좌표로 일괄 덮어쓰기 (지도에 즉시 반영)
function updateSignCoords(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const facs=DB.g('facilities');if(!facs||!facs.length){toast('⚠️ 시설물 데이터 없음');return;}
  const changes=[];
  facs.forEach(f=>{
    if(!f.type||!f.type.includes('다목적위치표지판'))return;
    const code=_signLocCode(f);if(!code||!_SIGN_COORD_FIX[code])return;
    const [lat,lng]=_SIGN_COORD_FIX[code];
    if(Math.abs((+f.lat||0)-lat)>0.00001||Math.abs((+f.lng||0)-lng)>0.00001){
      changes.push({code,from:[+f.lat,+f.lng],to:[lat,lng]});
    }
  });
  if(!changes.length){toast('✅ 이미 모든 좌표가 최신입니다');return;}
  const preview=changes.slice(0,8).map(c=>c.code).join(', ')+(changes.length>8?` 외 ${changes.length-8}개`:'');
  if(!confirm(`표지판 ${changes.length}개의 좌표를 최신 데이터로 덮어씁니다.\n\n변경: ${preview}\n\n진행할까요? (모든 기기에 즉시 반영)`))return;
  const f2=facs.map(f=>{
    if(!f.type||!f.type.includes('다목적위치표지판'))return f;
    const code=_signLocCode(f);if(!code||!_SIGN_COORD_FIX[code])return f;
    const [lat,lng]=_SIGN_COORD_FIX[code];
    return Object.assign({},f,{lat,lng});
  });
  DB.s('facilities',f2);
  try{_invalidateSignCache&&_invalidateSignCache();}catch(e){}
  try{if(typeof renderFacList==='function')renderFacList();}catch(e){}
  toast('✅ '+changes.length+'개 표지판 좌표 최신화 완료');
}
// 부팅 시 1회 자동: 라이브 표지판 좌표를 권위 좌표(엑셀)로 최신화.
// 시설물이 Firestore에서 로드된 뒤 실행. 기기당 1회(버전 플래그), 변경분만 기록.
function _autoApplyCoordFix(){
  if(localStorage.getItem('_coordFixVer')==='2')return;
  let tries=0;
  (function poll(){
    const facs=DB.g('facilities')||[];
    const signs=facs.filter(f=>f.type&&f.type.includes('다목적위치표지판'));
    if(signs.length<10){ if(tries++<20){setTimeout(poll,1500);} return; } // 아직 로드 안 됨
    let changed=0;
    const f2=facs.map(f=>{
      if(!f.type||!f.type.includes('다목적위치표지판'))return f;
      const code=_signLocCode(f);if(!code||!_SIGN_COORD_FIX[code])return f;
      const [lat,lng]=_SIGN_COORD_FIX[code];
      if(Math.abs((+f.lat||0)-lat)>0.00001||Math.abs((+f.lng||0)-lng)>0.00001){changed++;return Object.assign({},f,{lat,lng});}
      return f;
    });
    if(changed>0){
      DB.s('facilities',f2);
      try{_invalidateSignCache&&_invalidateSignCache();}catch(e){}
      setTimeout(function(){try{toast('🪧 표지판 좌표 '+changed+'개 자동 최신화됨');}catch(e){}},900);
    }
    localStorage.setItem('_coordFixVer','2');
  })();
}
function fixMisclassifiedTemples(){
  const facs=DB.g('facilities');if(!facs){toast('⚠️ 시설물 데이터 없음');return;}
  // 실제 사찰/암자 이름 목록 (오색암 등 정확한 사찰만 포함)
  const REAL_TEMPLES=['봉정암','오세암','오색암','백담사','신흥사','계조암','내원암','안양암','극락암'];
  const SIGN_TYPE='🪧 다목적위치표지판';
  const TEMPLE_TYPE='🛕 사찰';
  let fixed=0;
  const f2=facs.map(f=>{
    if(f.type===TEMPLE_TYPE&&f.name){
      const isRealTemple=REAL_TEMPLES.some(t=>f.name.includes(t));
      if(!isRealTemple){
        fixed++;
        return Object.assign({},f,{type:SIGN_TYPE});
      }
    }
    return f;
  });
  if(fixed===0){toast('수정이 필요한 항목 없음');return;}
  DB.s('facilities',f2);
  toast('✅ '+fixed+'개 항목을 다목적위치표지판으로 복구');
}

// ══════════════════════════════════════════
// 내 설정 (일반직원용)
// ══════════════════════════════════════════
var _settingsTab='info';
function settingsTab(tab,el){
  _settingsTab=tab;
  document.querySelectorAll('#v-settings .adm-tab').forEach(t=>t.classList.remove('on'));
  document.querySelectorAll('#v-settings .adm-sec').forEach(s=>s.classList.remove('on'));
  if(el)el.classList.add('on');
  document.getElementById('stab-'+tab+'-sec').classList.add('on');
  renderSettings();
}
function renderSettings(){
  const u=DB.g('currentUser')||{};
  if(_settingsTab==='info'){
    document.getElementById('settingsInfoWrap').innerHTML=`
      <div class="scard" style="margin-bottom:8px;">
        <div class="stitle">👤 내 계정</div>
        <div style="font-size:12px;color:#b8d4e8;line-height:2.0;">이름: <b>${_esc(u.realName||u.name||'미설정')}</b><br>소속: <b>${_esc(u.dept||'미설정')}</b><br>직위: <b>${_esc(u.rank||'미설정')}</b>${u.kakaoId?`<br><span style="color:#4a7090;font-size:10px;">카카오ID: ${_esc(u.kakaoId)}</span>`:''}</div>
        <div style="display:flex;align-items:center;gap:6px;margin-top:6px;margin-bottom:8px;">
          <div style="font-size:11px;color:${u.approvalStatus==='approved'?'#7ec8a0':'#e67e22'};">● ${u.approvalStatus==='approved'?'승인됨':'승인 대기'}</div>
        </div>
        <button onclick="openChangeUser()" style="width:100%;background:#1a4a6e;color:#fff;border:none;padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">✏️ 계정 수정</button>
      </div>
      <div class="scard" style="margin-bottom:8px;">
        <div class="stitle">💬 카카오 로그인</div>
        ${(()=>{if(u.kakaoImg||u.kakaoId){return`<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;"><img src="${_esc(u.kakaoImg||'')}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;background:#1a3a5a;" onerror="this.style.display='none'"><div style="font-size:12px;color:#b8d4e8;"><b style="color:#e0edf8;">${_esc(u.name||'')}</b> 님으로 연결됨</div></div><button onclick="kakaoLogout()" style="width:100%;background:rgba(255,80,80,.12);color:#ff8a80;border:1px solid rgba(255,80,80,.25);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;margin-bottom:6px;">🚪 카카오 로그아웃</button><button onclick="withdrawAccount()" style="width:100%;background:rgba(180,20,20,.12);color:#cc4444;border:1px solid rgba(180,20,20,.25);padding:8px;border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;">🗑️ 회원탈퇴</button>`;}return`<div style="font-size:11px;color:#7a9cb8;margin-bottom:8px;">카카오 계정으로 로그인하면 작성자 정보가 자동 설정됩니다.</div><button onclick="kakaoLogin()" style="width:100%;background:rgba(254,229,0,.18);color:#f0d900;border:1px solid rgba(254,229,0,.3);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">💬 카카오로 로그인</button>`;})()}
      </div>
      <a href="https://github.com/109yoon/seoraksan/releases/latest" target="_blank" style="display:flex;align-items:center;gap:10px;background:#0b1c30;border:1px solid rgba(79,168,208,.18);border-radius:10px;padding:11px 13px;text-decoration:none;flex-shrink:0;">
        <span style="font-size:18px;">📱</span>
        <div style="flex:1;"><div style="font-size:12px;font-weight:700;color:#e0edf8;">안드로이드 APK 다운로드</div><div style="font-size:10px;color:#3a6a8a;margin-top:1px;">최신 빌드 받기 (GitHub Releases)</div></div>
        <span style="font-size:11px;color:#4fa8d0;">↗</span>
      </a>`;
  } else {
    const s=_ensureNotiDefaults();
    const allOn=NOTI_GROUPS.every(g=>g.items.every(it=>s[it.k]!==false));
    document.getElementById('settingsNotiWrap').innerHTML=`
      <div class="scard">
        <div class="stitle" style="display:flex;align-items:center;justify-content:space-between;">🔔 알림 설정
          <button onclick="togNotiAll(${allOn?'false':'true'})" style="font-size:10px;font-weight:700;background:rgba(79,168,208,.12);color:#4fa8d0;border:1px solid rgba(79,168,208,.3);border-radius:7px;padding:4px 9px;cursor:pointer;">${allOn?'전체 끄기':'전체 켜기'}</button>
        </div>
        <div class="tog-sub" style="margin:-4px 0 10px;color:#5a7e98;">📵 끈 항목은 앱 알림·OS 푸시 모두 차단됩니다. '(앱 내만)' 항목은 끄지 않아도 OS 푸시는 가지 않습니다.</div>
        ${NOTI_GROUPS.map(g=>`
          <div style="font-size:11px;font-weight:800;color:#6a94b0;letter-spacing:.4px;margin:14px 0 4px;border-top:1px solid rgba(255,255,255,.05);padding-top:10px;">${g.title}</div>
          ${g.items.map(it=>`<div class="tog-row"><div><div class="tog-lbl">${it.l}${it.push===false?' <span style="font-size:9px;color:#4a7090;font-weight:600;">(앱 내만)</span>':''}</div><div class="tog-sub">${it.sub}</div></div><div class="toggle ${s[it.k]!==false?'on':'off'}" onclick="togNotiSet('${it.k}',this)"></div></div>`).join('')}
        `).join('')}
      </div>`;
  }
}
function togNotiSet(k,el){const s=DB.g('notiSetting')||{};const cur=s[k]!==false;s[k]=!cur;DB.s('notiSetting',s);el.className='toggle '+(!cur?'on':'off');_updateFcmTokenSettings();toast(!cur?'✅ 알림 켜짐':'🔕 꺼짐');}
function togNotiAll(on){const s=DB.g('notiSetting')||{};NOTI_GROUPS.forEach(g=>g.items.forEach(it=>{s[it.k]=on;}));DB.s('notiSetting',s);_updateFcmTokenSettings();renderSettings();toast(on?'✅ 전체 알림 켜짐':'🔕 전체 알림 꺼짐');}

// ══════════════════════════════════════════
// Google Sheets
// ══════════════════════════════════════════
async function syncToSheets(type,data){const url=DB.g('sheetsUrl');if(!url)return;try{await fetch(url,{method:'POST',mode:'no-cors',headers:{'Content-Type':'application/json'},body:JSON.stringify({type,data,ts:new Date().toISOString()})});}catch(e){console.warn('Sheets:',e);}}

// ══════════════════════════════════════════
// 가이드
// ══════════════════════════════════════════
const GUIDES={
  injury:{title:'부상 유형 안내',items:[{t:'골절',d:'뼈 파손. 변형·압통·부종. 부목 고정 후 이송.'},{t:'열상',d:'피부 찢김. 지혈 후 드레싱.'},{t:'뇌진탕',d:'두부 외상. 구토·기억상실 가능. 경과 관찰.'},{t:'저체온증',d:'체온 35°C 이하. 서서히 가온.'},{t:'심정지',d:'즉각 CPR. AED 확보.'}]},
  bodypart:{title:'신체 부위 주의',items:[{t:'두부·경추',d:'이동 금지. 경추 고정 후 이송.'},{t:'흉복부',d:'내출혈 가능. 산소 공급.'},{t:'골반',d:'대출혈. 압박 금지.'},{t:'척추',d:'로그롤. 마비 위험.'}]},
  severity:{title:'KTAS 중증도',items:[{t:'1 소생',d:'심정지·무호흡. 즉각 처치.'},{t:'2 긴급',d:'의식저하·호흡곤란. 15분 내.'},{t:'3 응급',d:'활력징후 안정. 30분 내.'},{t:'4 준응급',d:'경미 외상. 60분 내.'},{t:'5 비응급',d:'자력 이동. 120분 내.'}]},
  victim:{title:'사고자 기록 안내',items:[{t:'기저질환',d:'고혈압·당뇨·심장병. 처치 방향에 영향.'},{t:'복용약',d:'항혈전제는 출혈 위험 증가.'},{t:'알레르기',d:'약물 알레르기 특히 중요.'}]},
};
function openGuide(key){const g=GUIDES[key];if(!g)return;document.getElementById('guideTitle').textContent=g.title;document.getElementById('guideContent').innerHTML=g.items.map(i=>`<div class="guide-item"><div class="guide-t">${i.t}</div><div class="guide-d">${i.d}</div></div>`).join('');document.getElementById('modalGuide').classList.add('on');}

// ══════════════════════════════════════════
// 홈 요약
// ══════════════════════════════════════════
// ── 카카오 access_token → Apps Script 검증 → Firebase 커스텀 토큰 로그인 ──
// 서버(Apps Script)가 카카오 신원을 확인하고 허용목록을 대조한 뒤에만 토큰을 발급한다.
// 성공 시 _authRole(admin/member)이 세팅되고, 이후 Firestore 접근은 그 토큰으로 이뤄진다.
// (규칙이 아직 느슨한 전환기에는 실패해도 익명 인증이 유지되어 앱이 깨지지 않는다.)
async function _signInWithKakaoToken(kakaoAccessToken){
  const url=_FCM_PUSH_URL||(DB.g('fcmPushUrl')||'').trim();
  if(!url||!kakaoAccessToken)return{error:'no_url_or_token'};
  let j;
  // 미승인일 때 서버가 대기명단에 넣을 수 있도록 현재 프로필 동봉(관리자 직원 탭 자동 노출)
  const _cu=DB.g('currentUser')||{};
  const _prof={realName:_cu.realName||'',name:_cu.name||'',dept:_cu.dept||'',rank:_cu.rank||''};
  try{
    const res=await fetch(url,{
      method:'POST',
      headers:{'content-type':'text/plain;charset=utf-8'}, // Apps Script preflight 회피
      body:JSON.stringify({secret:_FCM_PUSH_SECRET||(DB.g('fcmPushSecret')||''),action:'mintToken',kakaoAccessToken:kakaoAccessToken,profile:_prof})
    });
    j=await res.json();
  }catch(e){return{error:'network',detail:String(e)};}
  if(j&&j.token){
    try{
      await firebase.auth().signInWithCustomToken(j.token);
      _authRole=j.role||'member';
      _authKakaoId=j.kakaoId||'';
      _authReady=true;_authErrCode='';
      if(_authRole==='admin')localStorage.setItem('_tokenAdmin','1');
      else localStorage.removeItem('_tokenAdmin');
      _markMemberOk(); // 멤버 확인 → 오프라인 보호 플래그
      try{_enforceAccessGate();}catch(e){} // 멤버 확인 → 혹시 떠있던 게이트 해제
      setTimeout(_flushSyncQueue,300);
    }catch(e){return{error:'signin_failed',detail:String(e)};}
  }
  // 허용목록에서 빠진 사용자 → 멤버 플래그 회수(다음 게이트 평가 때 차단)
  if(j&&j.error==='not_allowed'){try{localStorage.removeItem('_memberOk');}catch(e){}}
  return j||{error:'empty'};
}
// refresh_token으로 카카오 access_token 재발급 (앱 재시작·토큰 만료 후 무중단 복구)
function _refreshKakaoToken(rt){
  return fetch('https://kauth.kakao.com/oauth/token',{
    method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=utf-8'},
    body:'grant_type=refresh_token&client_id='+KAKAO_KEY+'&refresh_token='+encodeURIComponent(rt)
  }).then(function(r){return r.json();}).then(function(t){
    if(t&&t.access_token){
      try{localStorage.setItem('_kkAT',t.access_token);if(t.refresh_token)localStorage.setItem('_kkRT',t.refresh_token);if(window.Kakao&&Kakao.Auth)Kakao.Auth.setAccessToken(t.access_token);}catch(e){}
      return t.access_token;
    }
    return null;
  }).catch(function(){return null;});
}
// 현재 Firebase 세션에 member 클레임이 없으면 카카오 토큰으로 커스텀 토큰 재발급.
// 새 보안규칙(member==true)에서 익명/만료 세션이 쓰기 거부되는 문제를 재로그인 없이 복구.
let _ensuringMember=false;
async function _ensureMemberAuth(){
  if(_ensuringMember)return false;
  try{
    var u=firebase.auth().currentUser;
    if(u&&!u.isAnonymous){
      try{var r=await u.getIdTokenResult();if(r&&r.claims&&r.claims.member){_markMemberOk();return true;}}catch(e){}
    }
    var cu=DB.g('currentUser')||{};
    if(!cu.kakaoId)return false; // 카카오 로그인 이력이 없으면 재발급 불가(게스트)
    _ensuringMember=true;
    // 1) Kakao SDK가 들고 있는 토큰 또는 저장된 access_token으로 시도
    var at='';
    try{at=(window.Kakao&&Kakao.Auth&&Kakao.Auth.getAccessToken())||'';}catch(e){}
    if(!at)at=localStorage.getItem('_kkAT')||'';
    if(at){var mr=await _signInWithKakaoToken(at);if(mr&&mr.token){_ensuringMember=false;return true;}}
    // 2) access_token 만료 → refresh_token으로 새 토큰 발급 후 재시도
    var rt=localStorage.getItem('_kkRT')||'';
    if(rt){
      var nat=await _refreshKakaoToken(rt);
      if(nat){var mr2=await _signInWithKakaoToken(nat);if(mr2&&mr2.token){_ensuringMember=false;return true;}}
    }
    _ensuringMember=false;
    // 멤버 승급 실패 → 미승인/만료. 프로필 완료 상태면 대기 게이트로 차단.
    try{_enforceAccessGate();}catch(e){}
    if(!window._memberAuthWarned){window._memberAuthWarned=true;
      setTimeout(function(){try{toast('⚠️ 저장 권한이 만료되었습니다 — 카카오 재로그인이 필요합니다(데이터는 보존됨)');}catch(e){}},2500);
    }
    return false;
  }catch(e){_ensuringMember=false;return false;}
}
// 로그인 이력 기록 (허용목록 관리 UI에서 직원을 골라 추가할 수 있도록 kakaoId+이름 수집)
function _recordLoginLog(){
  try{
    const u=DB.g('currentUser')||{};
    const kid=u.kakaoId||_authKakaoId;
    if(!kid)return;
    const log=(DB.g('loginLog')||[]).slice();
    const entry={kakaoId:String(kid),name:u.realName||u.name||'',dept:u.dept||'',rank:u.rank||'',at:Date.now()};
    const i=log.findIndex(e=>String(e.kakaoId)===String(kid));
    if(i>=0)log[i]=entry; else log.push(entry);
    log.sort((a,b)=>(b.at||0)-(a.at||0));
    DB.s('loginLog',log.slice(0,300)); // 최근 300명 유지
  }catch(e){}
}
function kakaoLogin(){
  if(!window.Kakao||!Kakao.isInitialized()){toast('⚠️ 카카오 SDK 오류');return;}
  Kakao.Auth.authorize({redirectUri:'https://109yoon.github.io/seoraksan/',throughTalk:false});
}
function _handleKakaoCode(code,redirectUri){
  var _uri=redirectUri||'https://109yoon.github.io/seoraksan/';
  window._needsCode=true; // 동기적으로 먼저 세팅 (checkAuth 타이밍 충돌 방지)
  var _kakaoAccessTok=''; // 서버 검증(커스텀 토큰 발급)에 쓸 카카오 access_token 보관
  fetch('https://kauth.kakao.com/oauth/token',{
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded;charset=utf-8'},
    body:'grant_type=authorization_code&client_id='+KAKAO_KEY+'&redirect_uri='+encodeURIComponent(_uri)+'&code='+encodeURIComponent(code)
  })
  .then(function(r){return r.json();})
  .then(function(tok){
    if(!tok.access_token)throw new Error(tok.error_description||'토큰 오류');
    _kakaoAccessTok=tok.access_token;
    // 토큰 보관: 재방문(앱 재시작) 시 재로그인 없이 member 토큰 자동 재발급에 사용
    try{localStorage.setItem('_kkAT',tok.access_token);if(tok.refresh_token)localStorage.setItem('_kkRT',tok.refresh_token);}catch(e){}
    if(window.Kakao&&Kakao.Auth)Kakao.Auth.setAccessToken(tok.access_token);
    return fetch('https://kapi.kakao.com/v2/user/me',{headers:{Authorization:'Bearer '+tok.access_token}});
  })
  .then(function(r){return r.json();})
  .then(function(res){
    var u=DB.g('currentUser')||{};
    var prof=(res.kakao_account&&res.kakao_account.profile)||{};
    var kakaoId=String(res.id);
    // deletedKakaoIds에서 제거
    var deletedIds=DB.g('deletedKakaoIds')||[];
    if(deletedIds.includes(kakaoId)){
      DB.s('deletedKakaoIds',deletedIds.filter(function(id){return id!==kakaoId;}));
    }
    // 서버에 저장된 내 프로필(이름·부서·계급) 복원 — localStorage가 비어도 재입력 불필요(카카오 재로그인만으로 복구)
    var _roster=[].concat(DB.g('pendingUsers')||[],DB.g('approvedUsers')||[]);
    var _saved=_roster.find(function(x){return x&&String(x.kakaoId||x.id)===kakaoId;})||{};
    var merged=Object.assign({},u,{
      kakaoId:kakaoId,
      kakaoImg:prof.profile_image_url||prof.thumbnail_image_url||'',
      realName:u.realName||_saved.realName||'',
      name:u.name||_saved.name||_saved.realName||prof.nickname||'',
      dept:u.dept||_saved.dept||'',
      rank:u.rank||_saved.rank||''
    });
    DB.s('currentUser',merged);
    DB.s('authType','kakao');
    // 서버 검증 → Firebase 커스텀 토큰 로그인 (허용목록 기반 접근권한 부여)
    _signInWithKakaoToken(_kakaoAccessTok).then(function(mr){
      if(mr&&mr.error==='not_allowed'){
        setTimeout(function(){try{toast('⚠️ 접근 권한이 없습니다. 관리자에게 등록을 요청하세요 (내 ID: '+(mr.kakaoId||'?')+')');}catch(e){}},1200);
      }
      try{_recordLoginLog();}catch(e){}
      try{updateUserUI();}catch(e){}
      // 프로필이 이미 있으면 즉시 게이트 판정(미승인이면 대기 화면). 프로필 미완이면 입력 후 판정.
      try{var cu=DB.g('currentUser')||{};if(cu.dept&&cu.rank&&(cu.realName||cu.name))_enforceAccessGate();}catch(e){}
    });
    if(window._hideLoading)window._hideLoading();
    if(window.hideLoginScreen)window.hideLoginScreen();
    updateUserUI();
    toast('✅ 카카오 로그인 완료');
    // 소속·직위·이름이 이미 저장돼 있으면(재로그인) 다시 입력받지 않음
    if(!merged.dept||!merged.rank||!(merged.realName||merged.name)){
      window._requireProfile=true;
      setTimeout(function(){openChangeUser();},300);
    } else {
      window._needsCode=false;
    }
  })
  .catch(function(e){
    if(window._hideLoading)window._hideLoading();
    toast('⚠️ 카카오 로그인 실패: '+e.message);
  });
}
function kakaoLogout(){
  window._needsCode=false;window._requireProfile=false;
  DB.s('currentUser',{});
  DB.s('authType','');
  // 커스텀 토큰 세션·역할 정리 → 익명 인증으로 복귀
  localStorage.removeItem('_tokenAdmin');_authRole='';_authKakaoId='';
  try{localStorage.removeItem('_kkAT');localStorage.removeItem('_kkRT');localStorage.removeItem('_memberOk');window._memberAuthWarned=false;}catch(e){}
  var _g=document.getElementById('approvalGate');if(_g)_g.style.display='none';
  try{firebase.auth().signOut();}catch(e){}
  if(window.showLoginScreen)window.showLoginScreen();
  updateUserUI();
  try{renderSettings();}catch(e){}
  toast('로그아웃 됐습니다');
}
// ── 외부기관 로그인 (다중 기관 지원) ──
// 저장 구조: extAgencies = [{name, code}] (코드는 평문, 대문자). 구버전(extAgencyCode/
// extAgencyDisplayName)은 최초 1회 자동 마이그레이션.
function _getExtAgencies(){
  var list=DB.g('extAgencies');
  if(Array.isArray(list)&&list.length)return list;
  // 마이그레이션: 단일 기관 설정 → 배열
  var legacyName=DB.g('extAgencyDisplayName')||'환동해 특수대응단';
  var legacyCode=(DB.g('extAgencyCode')||'HWANDONGHA').toUpperCase();
  return [{name:legacyName,code:legacyCode}];
}
function _toggleExtLogin(){
  var f=document.getElementById('extLoginForm');
  if(!f)return;
  var open=f.style.display==='none';
  f.style.display=open?'block':'none';
  if(open){
    // 기관 목록을 드롭다운에 채움
    var sel=document.getElementById('extAgencySel');
    var ags=_getExtAgencies();
    if(sel)sel.innerHTML=ags.map(function(a,i){return '<option value="'+i+'">'+_esc(a.name)+'</option>';}).join('');
    setTimeout(function(){var i=document.getElementById('extPersonInp');if(i)i.focus();},100);
  }
}
// 외부기관 로그인 후 구조 author 문자열: "기관명 · 담당자" (담당자 없으면 기관명만)
function _extAuthorStr(){
  var u=DB.g('currentUser')||{};
  return u.name+(u.person?' · '+u.person:'');
}
async function doExtAgencyLogin(){
  var selEl=document.getElementById('extAgencySel');
  var codeEl=document.getElementById('extCodeInp');
  var personEl=document.getElementById('extPersonInp');
  var person=(personEl?personEl.value:'').trim();
  var code=(codeEl?codeEl.value:'').trim().toUpperCase();
  if(!code){toast('⚠️ 코드를 입력하세요');return;}
  var ags=_getExtAgencies();
  var selIdx=selEl?parseInt(selEl.value||'0',10):0;
  var ag=ags[selIdx]||ags[0];
  if(!ag){toast('⚠️ 등록된 외부기관이 없습니다 (관리자 설정 필요)');return;}
  // 선택한 기관의 코드와 일치해야 함 (해시·평문 모두 허용)
  var storedCode=(ag.code||'').toUpperCase();
  var storedH=await _sha256(storedCode);
  var inputH=await _sha256(code);
  if(inputH!==storedH&&code!==storedCode){toast('❌ '+ag.name+' 코드가 올바르지 않습니다');if(codeEl){codeEl.value='';codeEl.focus();}return;}
  DB.s('currentUser',{name:ag.name,person:person,dept:ag.name,rank:'외부기관',authType:'external'});
  DB.s('authType','external');
  if(window.hideLoginScreen)window.hideLoginScreen();
  updateUserUI();
  goHome();
  toast('✅ '+ag.name+(person?' ('+person+')':'')+'로 로그인');
}
function extAgencyLogout(){
  DB.s('currentUser',{});
  DB.s('authType','');
  if(window.showLoginScreen)window.showLoginScreen();
  updateUserUI();
  toast('로그아웃 됐습니다');
}
function isExternal(){return DB.g('authType')==='external';}
function withdrawAccount(){
  if(!confirm('정말 회원탈퇴 하시겠습니까?\n탈퇴 후 재가입 시 승인코드가 다시 필요합니다.'))return;
  var u=DB.g('currentUser')||{};
  var kakaoId=String(u.kakaoId||'');
  // pendingUsers에서 제거
  if(kakaoId){
    var list=DB.g('pendingUsers')||[];
    DB.s('pendingUsers',list.filter(function(p){return String(p.id)!==kakaoId&&String(p.kakaoId||'')!==kakaoId;}));
    // deletedKakaoIds에 추가해 재로그인 시 코드 재요청
    var deleted=DB.g('deletedKakaoIds')||[];
    if(!deleted.includes(kakaoId)){deleted.push(kakaoId);DB.s('deletedKakaoIds',deleted);}
  }
  DB.s('currentUser',{});
  DB.s('authType','');
  if(window.showLoginScreen)window.showLoginScreen();
  updateUserUI();
  toast('탈퇴 처리되었습니다');
}
// 최상위 authType 키 확인 + 구버전/유실 시 currentUser로부터 추론·복원.
// (예전 버전에서 로그인했거나 어떤 이유로 authType 키만 비어 있어도, currentUser에
//  로그인 흔적이 남아 있으면 로그인 화면을 다시 띄우지 않도록 함)
function _resolveAuthType(){
  var at=DB.g('authType');
  if(at)return at;
  var u=DB.g('currentUser')||{};
  if(u.authType){DB.s('authType',u.authType);return u.authType;}
  if(u.kakaoId){DB.s('authType','kakao');return 'kakao';}
  return '';
}
// 같은 kakaoId의 프로필(이름·소속·직위)을 서버 기록(pendingUsers·loginLog)에서 currentUser로 복원.
// 기기 변경·캐시 초기화로 로컬 currentUser가 비어도 재입력 없이 이어쓰도록 함.
function _restoreProfileFromServer(kakaoId){
  kakaoId=String(kakaoId||'');if(!kakaoId)return false;
  var u=DB.g('currentUser')||{};
  if(u.dept&&u.rank&&(u.realName||u.name))return true; // 이미 완성
  var src=(DB.g('pendingUsers')||[]).find(function(p){return String(p.kakaoId||p.id)===kakaoId&&(p.dept||p.rank);})
        ||(DB.g('loginLog')||[]).find(function(e){return String(e.kakaoId)===kakaoId&&(e.dept||e.rank);});
  if(!src)return false;
  var merged=Object.assign({},u,{
    realName:u.realName||src.realName||src.name||'',
    name:u.name||src.name||src.realName||'',
    dept:u.dept||src.dept||'',
    rank:u.rank||src.rank||''
  });
  DB.s('currentUser',merged);
  return !!(merged.dept&&merged.rank&&(merged.realName||merged.name));
}
function _checkAndRequireProfile(){
  var authType=_resolveAuthType();
  if(!authType)return;
  if(authType==='external')return; // 외부기관: 프로필 입력 불필요
  var u=DB.g('currentUser')||{};
  var isKakao=authType==='kakao';
  if(isKakao){
    if(window._needsCode)return; // _handleKakaoCode가 처리 중 — 간섭 금지
    // 프로필 미완성이면 먼저 서버 기록에서 복원 시도, 그래도 없을 때만 입력 요구
    if(!u.dept||!u.rank||!(u.realName||u.name)){
      if(!(u.kakaoId&&_restoreProfileFromServer(u.kakaoId))){
        window._requireProfile=true;
        setTimeout(function(){openChangeUser();},300);
        return;
      }
      try{updateUserUI();}catch(e){}
    }
    // 프로필 완료 → 멤버 승인 여부 확인(미승인이면 전체 차단)
    try{_enforceAccessGate();}catch(e){}
    return;
  }
  if(!u.dept||!u.rank){
    window._requireProfile=true;setTimeout(function(){openChangeUser();},300);
  }
}

var _weatherFetched=false;
var KMA_KEY='S3Nk1fdqSpqzZNX3anqaWA';
var KMA_BASE='https://apihub.kma.go.kr/api/typ02/openApi/VilageFcstInfoService_2.0';
// 지역별 KMA 격자 좌표
var _WEATHER_REGIONS=[
  {name:'속초',nx:87,ny:141},
  {name:'인제',nx:73,ny:132},
  {name:'양양',nx:79,ny:138},
  {name:'고성',nx:83,ny:146},
  {name:'설악',nx:80,ny:140}
];
function _kmaNCSTTime(){
  var n=new Date(),m=n.getMinutes();
  var d=m<10?new Date(n-3600000):n;
  var h=d.getHours();
  return{date:d.getFullYear()+String(d.getMonth()+1).padStart(2,'0')+String(d.getDate()).padStart(2,'0'),time:String(h).padStart(2,'0')+'00'};
}
function _kmaVsrtTime(){
  // 초단기예보: HH:30 관측 → HH:45 발표. 45분 이후면 당시간:30, 아니면 전시간:30
  var n=new Date(),h=n.getHours(),m=n.getMinutes();
  var bh=m>=45?h:(h===0?23:h-1);
  var bd=m<45&&h===0?new Date(n-86400000):n;
  return{date:bd.getFullYear()+String(bd.getMonth()+1).padStart(2,'0')+String(bd.getDate()).padStart(2,'0'),time:String(bh).padStart(2,'0')+'30'};
}
function _kmaFcstTime(){
  var n=new Date(),h=n.getHours(),m=n.getMinutes();
  var slots=[23,20,17,14,11,8,5,2];
  for(var i=0;i<slots.length;i++){var s=slots[i];if(h>s||(h===s&&m>=10))return{date:n.getFullYear()+String(n.getMonth()+1).padStart(2,'0')+String(n.getDate()).padStart(2,'0'),time:String(s).padStart(2,'0')+'00'};}
  var p=new Date(n-86400000);return{date:p.getFullYear()+String(p.getMonth()+1).padStart(2,'0')+String(p.getDate()).padStart(2,'0'),time:'2300'};
}
function _kmaItems(json){
  if(!json||!json.response)return[];
  var b=json.response.body;if(!b||!b.items)return[];
  var it=b.items.item;return Array.isArray(it)?it:(it?[it]:[]);
}
// 기상청 apihub는 브라우저 CORS 허용 헤더를 주지 않아 GitHub Pages에서 직접 호출이 차단된다.
// ① 직빵(direct) 먼저 시도 — 되면 가장 빠름 ② 막히면 CORS 프록시 경유로 '진짜 기상청' 데이터 확보
// (authKey는 이미 클라이언트에 노출된 공개 키라 프록시 경유로 인한 추가 노출 없음)
var _KMA_PROXIES=[
  function(u){return 'https://api.codetabs.com/v1/proxy/?quest='+encodeURIComponent(u);},
  function(u){return 'https://api.allorigins.win/raw?url='+encodeURIComponent(u);},
  function(u){return 'https://corsproxy.io/?url='+encodeURIComponent(u);}
];
var _KMA_DEFAULT_PROXY='https://seoraksan-kma.yraphael.workers.dev'; // 기본 내장 프록시(Cloudflare Worker) — 관리자 설정 미입력 시 사용
function _fetchKma(url,asText){
  var read=function(r){if(!r||!r.ok)throw new Error('http '+(r&&r.status));return asText?r.text():r.json();};
  var chain=[];
  // ① 관리자가 설정한 본인 소유 프록시(Cloudflare Worker) 우선 — 가장 안정적, 미입력 시 내장 기본값 사용
  var w=(DB.g('kmaProxyUrl')||'').trim()||_KMA_DEFAULT_PROXY;
  if(w)chain.push(w+(w.indexOf('?')>=0?'&':'?')+'url='+encodeURIComponent(url));
  // ② 직빵(direct) — 혹시 되면 최속
  chain.push(url);
  // ③ 공개 CORS 프록시 보조
  _KMA_PROXIES.forEach(function(p){chain.push(p(url));});
  var go=function(i){
    if(i>=chain.length)return Promise.reject(new Error('kma all sources failed'));
    return fetch(chain[i]).then(read).catch(function(){return go(i+1);});
  };
  return go(0);
}
function _parsePCP(v){if(!v||v==='강수없음')return 0;if(v.includes('미만'))return 0.5;var n=parseFloat(v);return isNaN(n)?0:n;}
function _ptyInfo(pty){var p=parseInt(pty||0);return{ico:p===0?'☀️':p===1||p===4?'🌧️':p===2?'🌨️':p===3?'❄️':'🌤️',desc:['맑음','비','비/눈','눈','소나기'][p]||'맑음'};}
function _skyIco(sky,pty){var p=parseInt(pty||0);if(p===1||p===4)return'🌧️';if(p===2)return'🌨️';if(p===3)return'❄️';var s=parseInt(sky||1);return s===1?'☀️':s===3?'⛅':s===4?'☁️':'🌤️';}
// 기상특보 텍스트 파싱 (wrn_now_data_new.php disp=1 응답)
var _kmaWrnCache=null;
var _kmaWrnCacheAt=0; // 기상특보 캐시 시각 — 구조 상황에선 발효/해제가 빨라 오래된 특보를 재사용하면 위험
var _KMA_WRN_TTL=900000; // 15분
function _parseKmaWarnings(txt){
  var alertMap={};
  _kmaWrnCache=txt;
  _kmaWrnCacheAt=Date.now();
  if(!txt||typeof txt!=='string')return alertMap;
  var gangwon=['속초','고성','양양','인제','영동','강원','산지'];
  var wrnTypes=['호우','강풍','대설','태풍','폭풍해일','한파','폭염','풍랑','건조'];
  txt.split('\n').forEach(function(line){
    var l=line.trim();
    if(!l||l.startsWith('#'))return;
    // 헤더 행 건너뜀
    if(/^[A-Z_,\s]+$/.test(l))return;
    var hasWrn=wrnTypes.some(function(t){return l.includes(t);});
    if(!hasWrn)return;
    var hasArea=gangwon.some(function(k){return l.includes(k);});
    if(!hasArea)return;
    var wrnType='';
    wrnTypes.forEach(function(t){if(!wrnType&&l.includes(t))wrnType=t;});
    var level=l.includes('경보')&&!l.includes('주의보경보')?'경보':(l.includes('주의보')?'주의보':'');
    if(!wrnType||!level)return;
    // 지역명 추출
    var rName='강원 영동';
    ['영동북부','영동남부','영동중부','영동','속초','고성','양양','인제','산지'].forEach(function(k){if(l.includes(k))rName=k;});
    if(!alertMap[rName])alertMap[rName]={level:level,reasons:[]};
    if(level==='경보')alertMap[rName].level='경보';
    var reason=wrnType+(level==='경보'?'경보':'주의보');
    if(alertMap[rName].reasons.indexOf(reason)===-1)alertMap[rName].reasons.push(reason);
  });
  return alertMap;
}
function fetchWeather(){
  if(_weatherFetched)return;
  _weatherFetched=true;
  var dt=_kmaNCSTTime(),vt=_kmaVsrtTime();
  // 초단기실황: 기온·풍속·강수형태
  var ncstUrl=KMA_BASE+'/getUltraSrtNcst?authKey='+KMA_KEY+'&dataType=JSON&numOfRows=10&pageNo=1&baseDate='+dt.date+'&baseTime='+dt.time+'&nx=87&ny=141';
  // 초단기예보: SKY(하늘상태)·LGT(낙뢰)
  var vsrtUrl=KMA_BASE+'/getUltraSrtFcst?authKey='+KMA_KEY+'&dataType=JSON&numOfRows=60&pageNo=1&baseDate='+vt.date+'&baseTime='+vt.time+'&nx=87&ny=141';
  // 기상특보현황 (실시간 발효 특보)
  var wrnUrl='https://apihub.kma.go.kr/api/typ01/url/wrn_now_data_new.php?authKey='+KMA_KEY+'&disp=1';
  Promise.all([
    _fetchKma(ncstUrl,false),
    _fetchKma(vsrtUrl,false).catch(function(){return null;}),
    _fetchKma(wrnUrl,true).catch(function(){return '';})
  ]).then(function(results){
    var ncst=results[0],vsrt=results[1],wrnTxt=results[2];
    var ncstOk=ncst&&ncst.response&&ncst.response.header&&ncst.response.header.resultCode==='00';
    if(!ncstOk){_fetchWeatherFallback(wrnTxt);return;}
    // 실황 파싱
    var obs={};
    _kmaItems(ncst).forEach(function(it){obs[it.category]=it.obsrValue;});
    var temp=parseFloat(obs.T1H||0);
    var wspd=parseFloat(obs.WSD||0);
    var pty=parseInt(obs.PTY||0);
    // SKY from 초단기예보
    var sky=1;
    if(vsrt&&vsrt.response&&vsrt.response.header&&vsrt.response.header.resultCode==='00'){
      var skyItem=_kmaItems(vsrt).find(function(it){return it.category==='SKY';});
      if(skyItem)sky=parseInt(skyItem.fcstValue||1);
    }
    // LGT(낙뢰) 확인
    var lgt=false;
    if(vsrt&&vsrt.response&&vsrt.response.header&&vsrt.response.header.resultCode==='00'){
      var lgtItem=_kmaItems(vsrt).find(function(it){return it.category==='LGT'&&it.fcstValue!=='0';});
      if(lgtItem)lgt=true;
    }
    // 아이콘 결정: PTY > LGT > SKY 순
    var ico,desc;
    if(pty===1||pty===4){ico='🌧️';desc=pty===4?'소나기':'비';}
    else if(pty===2){ico='🌨️';desc='비/눈';}
    else if(pty===3){ico='❄️';desc='눈';}
    else if(lgt){ico='⛈️';desc='낙뢰';}
    else{ico=sky===1?'☀️':sky===3?'⛅':sky===4?'☁️':'🌤️';desc=sky===1?'맑음':sky===3?'구름많음':sky===4?'흐림':'맑음';}
    document.getElementById('wIco').textContent=ico;
    document.getElementById('wTmp').textContent=(isNaN(temp)?'--':Math.round(temp))+'°';
    document.getElementById('wDesc').textContent='속초 · '+desc;
    document.getElementById('wWind').textContent='💨 '+Math.round(wspd)+'m/s';
    var ws=document.getElementById('weatherStrip');if(ws)ws.style.display='flex';
    // 실제 기상특보 (기상청 발효 특보)
    var alertMap=_parseKmaWarnings(wrnTxt||'');
    _renderWeatherAlerts(alertMap);
  }).catch(function(e){
    console.warn('KMA 오류, 폴백:',e);
    _weatherFetched=false; // 폴백도 실패할 수 있으니 재시도 가능하도록 해제
    _fetchWeatherFallback();
  });
}
// ── 기상특보 주기적 재조회 (운영 중 실시간 자동 발령) ──
var _kmaWarnPollTimer=null;
function _pollKmaWarnings(){
  if(document.visibilityState&&document.visibilityState!=='visible')return; // 백그라운드면 생략
  var url='https://apihub.kma.go.kr/api/typ01/url/wrn_now_data_new.php?authKey='+KMA_KEY+'&disp=1';
  _fetchKma(url,true).then(function(txt){
    if(typeof txt==='string')_renderWeatherAlerts(_parseKmaWarnings(txt),false); // 공식 특보 → _syncAutoAlerts 자동 발령
  }).catch(function(){});
}
function _startKmaWarnPoll(){
  if(_kmaWarnPollTimer)return;
  _kmaWarnPollTimer=setInterval(_pollKmaWarnings,600000); // 10분마다
  // 앱이 다시 포그라운드로 오면 즉시 1회 재조회 (백그라운드 중 발효된 특보 즉시 반영)
  document.addEventListener('visibilitychange',function(){if(document.visibilityState==='visible')_pollKmaWarnings();});
}
function _fetchWeatherFallback(realWrnTxt){
  // KMA CORS 차단 시 open-meteo로 폴백 (기온만; 특보는 typ01 실데이터가 있으면 그걸 우선)
  var base='https://api.open-meteo.com/v1/forecast';
  var cur=base+'?latitude=38.21&longitude=128.59&current=temperature_2m,wind_speed_10m,weather_code&wind_speed_unit=ms&timezone=Asia%2FSeoul';
  var reg=_WEATHER_REGIONS.map(function(r){
    // latitude/longitude from nx/ny approximation for fallback
    var coords={87:{lat:38.21,lng:128.59},73:{lat:38.06,lng:128.17},79:{lat:38.08,lng:128.62},83:{lat:38.38,lng:128.47},80:{lat:38.13,lng:128.41}};
    var c=coords[r.nx]||{lat:38.13,lng:128.41};
    return base+'?latitude='+c.lat+'&longitude='+c.lng+'&hourly=precipitation,snowfall,windgusts_10m,wind_speed_10m&wind_speed_unit=ms&timezone=Asia%2FSeoul&forecast_hours=24';
  });
  Promise.all([fetch(cur).then(function(r){return r.json();})].concat(reg.map(function(u){return fetch(u).then(function(r){return r.json();});})))
    .then(function(results){
      var cw=(results[0].current||results[0].current_weather||{});
      var code=cw.weather_code!==undefined?cw.weather_code:(cw.weathercode||0);
      var temp=cw.temperature_2m!==undefined?cw.temperature_2m:cw.temperature;
      var wspd=cw.wind_speed_10m!==undefined?cw.wind_speed_10m:cw.windspeed;
      var ico=code===0?'☀️':code<=2?'🌤️':code===3?'☁️':code<=48?'🌫️':code<=55?'🌦️':code<=65?'🌧️':code<=77?'🌨️':code<=82?'🌧️':code<=86?'🌨️':'⛈️';
      var descs=['맑음','대체로맑음','구름조금','흐림','안개','이슬비','비','눈','소나기','뇌우'];
      var desc=descs[code===0?0:code<=1?1:code<=2?2:code<=3?3:code<=48?4:code<=55?5:code<=65?6:code<=77?7:8]||'';
      document.getElementById('wIco').textContent=ico;
      document.getElementById('wTmp').textContent=(isNaN(temp)?'--':Math.round(temp))+'°';
      document.getElementById('wDesc').textContent='속초 · '+desc;
      document.getElementById('wWind').textContent='💨 '+Math.round(wspd)+'m/s';
      var ws=document.getElementById('weatherStrip');if(ws)ws.style.display='flex';
      var rNames=['속초','인제','양양','고성','설악'];
      var alertMap={};
      results.slice(1).forEach(function(d,i){
        var h=d.hourly||{};
        var precip=h.precipitation||[];var snow=h.snowfall||[];var gust=h.windgusts_10m||[];var wind=h.wind_speed_10m||[];
        var s12p=precip.slice(0,12).reduce(function(a,b){return a+b;},0);
        var s12s=snow.slice(0,12).reduce(function(a,b){return a+b;},0);
        var mxG=Math.max.apply(null,gust.slice(0,12).concat([0]));
        var mxW=Math.max.apply(null,wind.slice(0,12).concat([0]));
        var reasons=[],level='';
        if(s12p>=110){level='경보';reasons.push('호우경보');}else if(s12p>=70){level='주의보';reasons.push('호우주의보');}
        if(mxG>=26||mxW>=21){level='경보';reasons.push('강풍경보');}else if((mxG>=20||mxW>=14)&&level!=='경보'){level='주의보';reasons.push('강풍주의보');}
        if(s12s>=20){level='경보';reasons.push('대설경보');}else if(s12s>=5&&level!=='경보'){level='주의보';reasons.push('대설주의보');}
        if(reasons.length)alertMap[rNames[i]]={level:level,reasons:reasons};
      });
      // 기상청 특보(typ01)가 실제로 수신됐으면 추정값 대신 진짜 발효 특보 표시
      if(typeof realWrnTxt==='string'&&realWrnTxt.length){
        _renderWeatherAlerts(_parseKmaWarnings(realWrnTxt),false);
      }else{
        _renderWeatherAlerts(alertMap,true);
      }
    }).catch(function(e){console.warn('날씨 폴백 실패:',e);_weatherFetched=false;});
}
function _renderWeatherAlerts(alertMap,estimated){
  // 특보운영 연동: 공식 발효 특보만 자동 발령 근거로 사용(추정값 제외)
  try{
    window._kmaLiveAlerts=estimated?[]:_kmaLiveList(alertMap);
    if(!estimated){
      _syncAutoAlerts(window._kmaLiveAlerts);
      if(window.curApp==='alert'&&typeof renderAlertView==='function')renderAlertView();
    }
  }catch(e){}
  var wrap=document.getElementById('weatherAlertWrap');if(!wrap)return;
  var entries=Object.entries(alertMap);
  if(!entries.length){wrap.innerHTML='';wrap.style.display='none';return;}
  // 경보 먼저, 주의보 나중
  entries.sort(function(a,b){return a[1].level==='경보'&&b[1].level!=='경보'?-1:1;});
  // 같은 특보를 가진 지역끼리 묶기
  var grouped={};
  entries.forEach(function(e){
    var key=e[1].reasons.join('/');
    if(!grouped[key])grouped[key]={level:e[1].level,regions:[],reasons:e[1].reasons};
    grouped[key].regions.push(e[0]);
  });
  wrap.innerHTML=Object.values(grouped).map(function(g){
    var ico=g.reasons.some(function(r){return r.includes('호우');})?'🌧️':g.reasons.some(function(r){return r.includes('강풍');})?'💨':g.reasons.some(function(r){return r.includes('대설');})?'❄️':'⚠️';
    var regionStr=g.regions.join('·');
    var reasonStr=g.reasons.map(function(r){return r.replace('경보','').replace('주의보','');}).join(', ');
    // estimated=true: 기상청 미연결로 open-meteo 관측값에서 추정한 특보 → 공식 특보와 명확히 구분
    if(estimated){
      return'<div class="w-alert w-alert-추정">'+ico+' <b>추정 '+g.level+'</b> '+regionStr+' — '+reasonStr+' <span style="font-weight:400;opacity:.85;">· 기상청 미연결</span></div>';
    }
    return'<div class="w-alert w-alert-'+g.level+'">'+ico+' <b>'+g.level+'</b> '+regionStr+' — '+reasonStr+'</div>';
  }).join('');
  wrap.style.display='flex';
}
var _wDetailCache=null;
var _wDetailFetching=false;
function openWeatherDetail(){
  document.getElementById('modalWeather').classList.add('on');
  if(_wDetailCache&&(_wDetailCache.regions||Array.isArray(_wDetailCache))){_renderWeatherDetail(_wDetailCache);return;}
  _fetchWeatherDetail();
}
function refreshWeatherDetail(){
  _wDetailCache=null;
  _kmaWrnCache=null;_kmaWrnCacheAt=0; // 수동 새로고침 시 특보도 다시 받아옴
  document.getElementById('weatherDetailBody').innerHTML='<div class="wdetail-loading">날씨 새로고침 중...</div>';
  _fetchWeatherDetail();
}
function _fetchWeatherDetail(){
  if(_wDetailFetching)return;
  _wDetailFetching=true;
  var dt=_kmaNCSTTime(),ft=_kmaFcstTime();
  var ncstCalls=_WEATHER_REGIONS.map(function(r){
    var url=KMA_BASE+'/getUltraSrtNcst?authKey='+KMA_KEY+'&dataType=JSON&numOfRows=10&pageNo=1&baseDate='+dt.date+'&baseTime='+dt.time+'&nx='+r.nx+'&ny='+r.ny;
    return _fetchKma(url,false).catch(function(){return null;}); // 일부 권역 프록시 실패 허용
  });
  var fcst7Url=KMA_BASE+'/getVilageFcst?authKey='+KMA_KEY+'&dataType=JSON&numOfRows=900&pageNo=1&baseDate='+ft.date+'&baseTime='+ft.time+'&nx=80&ny=140';
  // 기상특보: 캐시가 신선(15분 이내)하면 재사용, 아니면 새로 조회
  var wrnFresh=_kmaWrnCache!==null&&(Date.now()-_kmaWrnCacheAt)<_KMA_WRN_TTL;
  var wrnPromise=wrnFresh
    ?Promise.resolve(_kmaWrnCache)
    :_fetchKma('https://apihub.kma.go.kr/api/typ01/url/wrn_now_data_new.php?authKey='+KMA_KEY+'&disp=1',true).catch(function(){return '';});
  Promise.all([
    Promise.all(ncstCalls),
    _fetchKma(fcst7Url,false).catch(function(){return null;}),
    wrnPromise
  ]).then(function(all){
    _wDetailFetching=false;
    // 권역 중 하나라도 성공하면 기상청 데이터로 처리(나머지 권역 프록시 실패는 허용)
    var wrnTxtOk=(typeof all[2]==='string'&&all[2].length>0);
    var wrnMap=_parseKmaWarnings(all[2]||'');
    var anyOk=all[0].some(function(x){return x&&x.response&&x.response.header&&x.response.header.resultCode==='00';});
    // 기온(typ02) 실패해도 특보(typ01)가 살아 있으면 진짜 기상청 특보를 폴백 렌더러로 넘김
    if(!anyOk){_fetchWeatherDetailFallback(wrnTxtOk?wrnMap:null);return;}
    _wDetailCache={regions:_WEATHER_REGIONS.map(function(r,i){return{region:r.name,ncst:all[0][i]};}),fcst7:all[1],wrnMap:wrnMap};
    _renderWeatherDetail(_wDetailCache);
  }).catch(function(){
    _wDetailFetching=false;
    _fetchWeatherDetailFallback();
  });
}
function _fetchWeatherDetailFallback(realWrnMap){
  _wDetailFetching=true;
  var base='https://api.open-meteo.com/v1/forecast';
  var coords={속초:{lat:38.21,lng:128.59},인제:{lat:38.06,lng:128.17},양양:{lat:38.08,lng:128.62},고성:{lat:38.38,lng:128.47},설악:{lat:38.13,lng:128.41}};
  var daily=base+'?latitude=38.13&longitude=128.41&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code,windgusts_10m_max&wind_speed_unit=ms&timezone=Asia%2FSeoul&forecast_days=7';
  Promise.all([
    Promise.all(_WEATHER_REGIONS.map(function(r){
      var c=coords[r.name]||{lat:38.13,lng:128.41};
      return fetch(base+'?latitude='+c.lat+'&longitude='+c.lng+'&current=temperature_2m,wind_speed_10m,weather_code&hourly=precipitation,snowfall,windgusts_10m,wind_speed_10m&wind_speed_unit=ms&timezone=Asia%2FSeoul&forecast_hours=24')
        .then(function(res){return res.json();}).then(function(d){return{region:r.name,data:d};});
    })),
    fetch(daily).then(function(res){return res.json();}).catch(function(){return null;})
  ]).then(function(all){
    _wDetailFetching=false;
    _wDetailCache={omFallback:true,regions:all[0],daily:all[1],realWrnMap:realWrnMap||null};
    _renderWeatherDetail(_wDetailCache);
  }).catch(function(){
    _wDetailFetching=false;
    document.getElementById('weatherDetailBody').innerHTML='<div class="wdetail-loading">날씨 데이터를 불러오지 못했습니다. ↻ 를 눌러 재시도하세요.</div>';
  });
}
function _renderWeatherDetail(cache){
  if(cache.omFallback)return _renderWeatherDetailOM(cache);
  var results=cache.regions||[];
  var fcst7=cache.fcst7||null;
  var wrnMap=cache.wrnMap||{};
  var src=results.some(function(x){return x&&x.ncst&&x.ncst.response;})?'기상청':'Open-Meteo';
  var html='<div style="font-size:10px;color:#3a6a8a;margin-bottom:8px;text-align:right;">'+new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'})+' 기준 ('+src+')</div>';
  // ── 기상특보 (기상청 실제 발효 특보) ──────────────
  var wrnEntries=Object.entries(wrnMap);
  if(wrnEntries.length){
    html+='<div style="margin-bottom:10px;">';
    wrnEntries.forEach(function(e){
      var region=e[0],info=e[1];
      var ico=info.reasons.some(function(r){return r.includes('호우');})?'🌧️':info.reasons.some(function(r){return r.includes('대설');})?'❄️':info.reasons.some(function(r){return r.includes('강풍');})?'💨':info.reasons.some(function(r){return r.includes('태풍');})?'🌀':info.reasons.some(function(r){return r.includes('한파');})?'🥶':info.reasons.some(function(r){return r.includes('폭염');})?'🌡️':'⚠️';
      html+='<div class="wdetail-alert w-alert-'+info.level+'" style="display:flex;align-items:center;gap:5px;padding:7px 10px;border-radius:7px;margin-bottom:4px;">'
        +ico+' <b>기상청 '+info.level+'</b> — '+region+' '+info.reasons.join(', ')+'</div>';
    });
    html+='</div>';
  }else{
    html+='<div style="text-align:center;padding:6px 0 10px;font-size:11px;color:#27ae60;">✅ 현재 발효 중인 특보 없음 (기상청)</div>';
  }
  // ── 권역별 현재 날씨 (초단기실황) ─────────────────
  html+='<div class="wfc-sec"><div class="wfc-title">🌡️ 권역별 현재 날씨</div>';
  html+='<div class="wdetail-now-grid">';
  results.forEach(function(item,idx){
    var r=item.region;
    var obs={};
    _kmaItems(item.ncst).forEach(function(it){obs[it.category]=it.obsrValue;});
    var temp=parseFloat(obs.T1H||0);
    var wspd=parseFloat(obs.WSD||0);
    var rn1=parseFloat(obs.RN1||0);
    var pi=_ptyInfo(obs.PTY||0);
    // 이 지역에 실제 특보 있는지
    var hasWrn=Object.keys(wrnMap).some(function(k){return k.includes(r)||r.includes(k);});
    var wide=(idx===4)?'wdr-wide':'';
    html+='<div class="wdetail-region '+wide+'">'
      +'<div class="wdetail-rname">'+r+(hasWrn?' <span style="color:#ff8a80;">⚠</span>':'')+'</div>'
      +'<div class="wdetail-row">'
        +'<div class="wdetail-ico">'+pi.ico+'</div>'
        +'<div class="wdetail-main">'
          +'<div class="wdetail-tmp">'+(isNaN(temp)?'--':Math.round(temp))+'°</div>'
          +'<div class="wdetail-desc">'+pi.desc+'</div>'
        +'</div>'
      +'</div>'
      +'<div class="wdetail-meta">'
        +'<span>💨'+Math.round(wspd)+'</span>'
        +(rn1>0?'<span>🌧️'+rn1.toFixed(1)+'mm</span>':'')
      +'</div>'
      +'</div>';
  });
  html+='</div></div>';
  // ── 7일 예보 (설악 단기예보) ──────────────────────
  if(fcst7){
    var items=_kmaItems(fcst7);
    var byDate={};
    items.forEach(function(it){
      var dk=it.fcstDate;
      if(!byDate[dk])byDate[dk]={};
      if(it.category==='TMX')byDate[dk].TMX=parseFloat(it.fcstValue);
      else if(it.category==='TMN')byDate[dk].TMN=parseFloat(it.fcstValue);
      else if(it.category==='SKY'&&it.fcstTime==='1200')byDate[dk].SKY=it.fcstValue;
      else if(it.category==='PTY'&&it.fcstTime==='1200')byDate[dk].PTY=it.fcstValue;
      else if(it.category==='PCP'){var p=_parsePCP(it.fcstValue);byDate[dk].PCP=(byDate[dk].PCP||0)+p;}
      else if(it.category==='WSD'){var w=parseFloat(it.fcstValue||0);if(w>(byDate[dk].WSD||0))byDate[dk].WSD=w;}
    });
    var dayNames=['일','월','화','수','목','금','토'];
    var dateKeys=Object.keys(byDate).sort().slice(0,7);
    html+='<div class="wfc-sec"><div class="wfc-title">📅 7일 예보 (설악 기준 · 기상청)</div>';
    dateKeys.forEach(function(dk,i){
      var dd=byDate[dk];
      var d2=new Date(dk.slice(0,4)+'-'+dk.slice(4,6)+'-'+dk.slice(6,8));
      var dayLabel=i===0?'오늘':i===1?'내일':dayNames[d2.getDay()]+'요';
      var ico=_skyIco(dd.SKY||'1',dd.PTY||'0');
      var rain=dd.PCP||0;var gust=dd.WSD||0;
      html+='<div class="wfc-row">'
        +'<div class="wfc-day">'+dayLabel+'</div>'
        +'<div class="wfc-ico">'+ico+'</div>'
        +'<div class="wfc-tmp">'+(dd.TMX!==undefined?Math.round(dd.TMX):'?')+'° <span>/ '+(dd.TMN!==undefined?Math.round(dd.TMN):'?')+'°</span></div>'
        +'<div class="wfc-rain">'+(rain>0?'🌧️'+rain.toFixed(0)+'mm':'')+'</div>'
        +'<div class="wfc-wind">'+(gust>0?'💨'+gust.toFixed(0):'')+'</div>'
        +'</div>';
    });
    html+='</div>';
  }
  document.getElementById('weatherDetailBody').innerHTML=html;
}
function _renderWeatherDetailOM(cache){
  // open-meteo 폴백용 렌더러
  var results=cache.regions||[];
  var daily=cache.daily||null;
  function wico(c){return c===0?'☀️':c<=2?'🌤️':c===3?'☁️':c<=48?'🌫️':c<=55?'🌦️':c<=65?'🌧️':c<=77?'🌨️':c<=82?'🌧️':c<=86?'🌨️':'⛈️';}
  function wdesc(c){return c===0?'맑음':c<=2?'구름조금':c===3?'흐림':c<=48?'안개':c<=55?'이슬비':c<=65?'비':c<=77?'눈':c<=82?'소나기':'뇌우';}
  // 기상특보가 typ01(기상청)에서 실제로 수신된 경우 — 기온만 Open-Meteo, 특보는 진짜 기상청 발효분 사용
  var realWrn=cache.realWrnMap||null;
  var hasRealWrn=(realWrn!==null&&realWrn!==undefined);
  var srcLabel=hasRealWrn?'특보: 기상청 · 기온: Open-Meteo':'Open-Meteo';
  var html='<div style="font-size:10px;color:#3a6a8a;margin-bottom:8px;text-align:right;">'+new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'})+' 기준 ('+srcLabel+')</div>';
  html+='<div class="wfc-sec"><div class="wfc-title">🌡️ 권역별 현재 날씨</div><div class="wdetail-now-grid">';
  var anyAlert=false,alertsAll=[];
  results.forEach(function(item,idx){
    var r=item.region;var d=item.data;
    var cw=d.current||d.current_weather||{};var h=d.hourly||{};
    var code=cw.weather_code!==undefined?cw.weather_code:(cw.weathercode||0);
    var gust=h.windgusts_10m||[];var precip=h.precipitation||[];var snow=h.snowfall||[];
    var mxG=Math.max.apply(null,gust.slice(0,12).concat([0]));
    var s12p=precip.slice(0,12).reduce(function(a,b){return a+b;},0);
    var s12s=snow.slice(0,12).reduce(function(a,b){return a+b;},0);
    var alerts=[];
    if(s12p>=110)alerts.push({lv:'경보',msg:r+' 호우경보'});else if(s12p>=70)alerts.push({lv:'주의보',msg:r+' 호우주의보'});
    if(mxG>=26)alerts.push({lv:'경보',msg:r+' 강풍경보'});else if(mxG>=20)alerts.push({lv:'주의보',msg:r+' 강풍주의보'});
    if(s12s>=20)alerts.push({lv:'경보',msg:r+' 대설경보'});else if(s12s>=5)alerts.push({lv:'주의보',msg:r+' 대설주의보'});
    if(alerts.length){anyAlert=true;alertsAll=alertsAll.concat(alerts);}
    // 실제 기상청 특보가 있으면 권역 ⚠ 표식도 추정값이 아닌 실데이터 기준
    var rWarn=hasRealWrn?Object.keys(realWrn).some(function(k){return k.includes(r)||r.includes(k);}):(alerts.length>0);
    var tmp=cw.temperature_2m!==undefined?Math.round(cw.temperature_2m):cw.temperature!==undefined?Math.round(cw.temperature):'-';
    var wsp=cw.wind_speed_10m!==undefined?Math.round(cw.wind_speed_10m):cw.windspeed!==undefined?Math.round(cw.windspeed):'-';
    var wide=(idx===4)?'wdr-wide':'';
    html+='<div class="wdetail-region '+wide+'">'
      +'<div class="wdetail-rname">'+r+(rWarn?' <span style="color:#ff8a80;">⚠</span>':'')+'</div>'
      +'<div class="wdetail-row"><div class="wdetail-ico">'+wico(code)+'</div>'
      +'<div class="wdetail-main"><div class="wdetail-tmp">'+tmp+'°</div><div class="wdetail-desc">'+wdesc(code)+'</div></div></div>'
      +'<div class="wdetail-meta"><span>💨'+wsp+'</span>'+(mxG>0?'<span>돌풍'+mxG.toFixed(0)+'</span>':'')+(s12p>0?'<span>🌧️'+s12p.toFixed(0)+'mm</span>':'')+(s12s>0?'<span>❄️'+s12s.toFixed(0)+'cm</span>':'')+'</div></div>';
  });
  html+='</div></div>';
  if(hasRealWrn){
    // 진짜 기상청 발효 특보 (typ01) — 추정값 대신 실데이터 표시
    var realEntries=Object.entries(realWrn);
    if(realEntries.length){
      html+='<div style="margin-bottom:10px;">'+realEntries.map(function(e){
        var info=e[1];
        var ic=info.reasons.some(function(x){return x.includes('호우');})?'🌧️':info.reasons.some(function(x){return x.includes('대설');})?'❄️':info.reasons.some(function(x){return x.includes('강풍');})?'💨':info.reasons.some(function(x){return x.includes('태풍');})?'🌀':info.reasons.some(function(x){return x.includes('한파');})?'🥶':info.reasons.some(function(x){return x.includes('폭염');})?'🌡️':'⚠️';
        return'<div class="wdetail-alert w-alert-'+info.level+'" style="display:flex;align-items:center;gap:5px;">'+ic+' <b>기상청 '+info.level+'</b> — '+e[0]+' '+info.reasons.join(', ')+'</div>';
      }).join('')+'</div>';
    }else{
      html+='<div style="text-align:center;padding:6px 0 10px;font-size:11px;color:#27ae60;">✅ 현재 발효 중인 특보 없음 (기상청)</div>';
    }
  }
  else if(anyAlert){html+='<div style="margin-bottom:10px;">'+alertsAll.map(function(a){return'<div class="wdetail-alert w-alert-'+a.lv+'" style="display:flex;align-items:center;gap:5px;">⚠️ <b>'+a.lv+'</b> '+a.msg+'</div>';}).join('')+'</div>';}
  else{html+='<div style="text-align:center;padding:6px 0 10px;font-size:11px;color:#27ae60;">✅ 현재 발효 중인 특보 없음</div>';}
  if(daily&&daily.daily){
    var dd=daily.daily;var days=['일','월','화','수','목','금','토'];
    html+='<div class="wfc-sec"><div class="wfc-title">📅 7일 예보 (설악 기준 · Open-Meteo)</div>';
    (dd.time||[]).forEach(function(t,i){
      var dt2=new Date(t);var dayLabel=i===0?'오늘':i===1?'내일':days[dt2.getDay()]+'요';
      var code=((dd.weather_code||dd.weathercode)||[])[i]||0;
      var tmax=(dd.temperature_2m_max||[])[i];var tmin=(dd.temperature_2m_min||[])[i];
      var rain=(dd.precipitation_sum||[])[i]||0;var gust=(dd.windgusts_10m_max||[])[i]||0;
      html+='<div class="wfc-row"><div class="wfc-day">'+dayLabel+'</div><div class="wfc-ico">'+wico(code)+'</div>'
        +'<div class="wfc-tmp">'+(tmax!==undefined?Math.round(tmax):'?')+'° <span>/ '+(tmin!==undefined?Math.round(tmin):'?')+'°</span></div>'
        +'<div class="wfc-rain">'+(rain>0?'🌧️'+rain.toFixed(0)+'mm':'')+'</div>'
        +'<div class="wfc-wind">'+(gust>0?'💨'+gust.toFixed(0):'')+'</div></div>';
    });
    html+='</div>';
  }
  document.getElementById('weatherDetailBody').innerHTML=html;
}
// ── 날씨 30분마다 자동 갱신 (백그라운드 시 정지) ──
setInterval(function(){
  if(document.hidden)return;
  _weatherFetched=false;_wDetailCache=null;fetchWeather();
},30*60*1000);

// ── 진행중 구조 방치 감시: 마지막 보고 후 일정시간 경과 시 알림 ──────
const _STALE_HOURS=2;            // 경과 임계(시간)
const _STALE_REPEAT_MS=2*3600*1000; // 동일 건 재알림 최소 간격
let _staleAlerted={};            // {id: lastAlertTs}
function _parseDT(s){
  // "YYYY-MM-DD HH:MM" 또는 "YYYY-MM-DDTHH:MM" → ms
  if(!s)return null;
  const m=String(s).match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})/);
  if(!m)return null;
  return new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5]).getTime();
}
function _lastActivityTs(r){
  let t=_parseDT(r.date)||0;
  (r.reports||[]).forEach(p=>{const pt=_parseDT(p.repTime)||_parseDT(p.date);if(pt&&pt>t)t=pt;});
  return t;
}
function _checkStaleRescues(){
  const res=DB.g('rescues')||[];
  const nowMs=Date.now();
  res.filter(r=>r.status==='ongoing').forEach(r=>{
    const last=_lastActivityTs(r);
    if(!last)return;
    const elapsedH=(nowMs-last)/3600000;
    if(elapsedH<_STALE_HOURS)return;
    const lastAlert=_staleAlerted[r.id]||0;
    if(nowMs-lastAlert<_STALE_REPEAT_MS)return;
    _staleAlerted[r.id]=nowMs;
    pushNoti('⏰ 진행중 '+Math.floor(elapsedH)+'시간 경과 — 상태 확인 필요',
      '⏰','progress',{app:'rescue',tab:2,id:r.id});
  });
}
setInterval(_checkStaleRescues,15*60*1000);
setTimeout(_checkStaleRescues,60*1000);
function updateSummary(){
  const res=DB.g('rescues')||[];const facs=DB.g('facilities')||[];
  const og=res.filter(r=>r.status==='ongoing');const bad=facs.filter(f=>f.status==='bad');const warn=facs.filter(f=>f.status==='warn');const ok=facs.filter(f=>f.status==='ok');
  const thisMonth=res.filter(r=>r.date&&r.date.startsWith(today().slice(0,7))).length;
  function se(id,v){const e=document.getElementById(id);if(e)e.textContent=v;}
  se('hs-og',og.length);
  se('hs-tot',thisMonth);
  se('hs-fb',bad.length);
  se('hs-ft',facs.length);
  const ogNumEl=document.getElementById('hs-og');
  if(ogNumEl)ogNumEl.classList.toggle('blink',og.length>0);
  function sd(id,v,col){const e=document.getElementById(id);if(!e)return;e.textContent=v;e.style.color=col||'';}
  sd('hdR',og.length?`⚠️ ${og.length}건 진행중`:'구조보고·위험상황',og.length?'#ffaaaa':'');
  sd('hdI',bad.length?`⚠️ 위험 ${bad.length}개`:'시설 관리·이력',bad.length?'#ffaaaa':'');
  {const _ao=(DB.g('alertOps')||[]).find(o=>!o.closedAt);sd('hdA',_ao?`🌀 ${_opLevel(_ao)} 운영중`:'기상특보 비상근무',_ao?'#ffaaaa':'');}
  updateBell();
  try{_checkNewJoinerAlert();}catch(e){}
  try{renderHomeActive();}catch(e){}
  try{renderMobilizeBanner();}catch(e){}
}
// 홈: 진행중 구조 건을 가로 스크롤 카드로 즉시 노출 (한눈에 현황 파악)
function renderHomeActive(){
  const el=document.getElementById('homeActiveStrip');if(!el)return;
  if(isExternal()){el.style.display='none';el.innerHTML='';return;}
  el.style.display='block';
  const og=(DB.g('rescues')||[]).filter(r=>r.status==='ongoing');
  const haz=(DB.g('hazards')||[]).filter(h=>!h.hazStatus||h.hazStatus==='미조치'||h.hazStatus==='조치중');
  const badFac=(DB.g('facilities')||[]).filter(f=>f.status==='bad');
  const total=og.length+haz.length+badFac.length;
  if(!total){
    el.innerHTML=`<div style="display:flex;align-items:center;gap:12px;background:linear-gradient(135deg,#0e2a20,#0b1c19);border:1px solid rgba(39,174,96,.22);border-radius:16px;padding:15px 16px;">
      <div style="width:40px;height:40px;border-radius:50%;background:rgba(39,174,96,.15);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">✅</div>
      <div style="min-width:0;"><div style="font-size:14px;font-weight:800;color:#eaf2fa;">현재 주의 항목 없음</div>
      <div style="font-size:11.5px;color:#7fb89c;margin-top:2px;">진행 중인 구조·위험 상황이 없습니다</div></div>
    </div>`;
    return;
  }
  // 상단 요약(0건 카테고리는 생략)
  const sum=[];
  if(og.length)sum.push(`<span style="color:#ff7a6e;font-weight:800;">진행중 ${og.length}</span>`);
  if(haz.length)sum.push(`<span style="color:#f0a44a;font-weight:800;">위험상황 ${haz.length}</span>`);
  if(badFac.length)sum.push(`<span style="color:#ffc05a;font-weight:800;">위험시설 ${badFac.length}</span>`);
  // 공통 카드 골격
  const _card=(onclick,accent,borderRGBA,badgeBg,badgeCol,badgeTxt,ico,mobHtml,title,meta,foot)=>
    `<div onclick="${onclick}" style="flex:0 0 auto;width:166px;background:#0f1e30;border:1px solid ${borderRGBA};border-left:3px solid ${accent};border-radius:13px;padding:10px 12px;cursor:pointer;box-shadow:0 2px 9px rgba(0,0,0,.3);">
      <div style="display:flex;align-items:center;gap:5px;margin-bottom:6px;">
        <span style="font-size:14px;">${ico}</span>
        <span style="font-size:8.5px;font-weight:800;color:${badgeCol};background:${badgeBg};border-radius:6px;padding:2px 6px;letter-spacing:.2px;">${badgeTxt}</span>
        ${mobHtml||''}
      </div>
      <div style="font-size:11.5px;font-weight:700;color:#eaf2fa;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${title}</div>
      <div style="font-size:9.5px;color:#8ab4cc;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${meta}</div>
      ${foot||''}
    </div>`;
  const cards=[];
  og.slice().reverse().forEach(r=>{
    const ti=RES_TYPES[r.type]||RES_TYPES['기타'];
    const elp=_elapsedStr(r.date);
    const mob=(r.mobilize&&r.mobilize.length)?`<span style="font-size:8px;background:rgba(231,76,60,.2);color:#ff6b5e;border-radius:7px;padding:1px 5px;font-weight:700;">🚨</span>`:'';
    cards.push(_card(`openRescueFromHome(${r.id})`,'#e74c3c','rgba(231,76,60,.3)','rgba(231,76,60,.18)','#ff7a6e','진행중',ti.ico,mob,
      _esc(r.title||r.type),
      _esc(r.vName||'미상')+(r.location?' · '+_esc(r.location):''),
      elp?`<div class="js-elapsed" data-d="${_esc(r.date)}" style="font-size:10px;font-weight:700;color:#f0a500;margin-top:4px;">⏱ ${elp}</div>`:''));
  });
  haz.slice().reverse().forEach(h=>{
    const hico=(h.hazType||'').split(' ')[0]||'⚠️';
    cards.push(_card(`openHazFromHome(${h.id})`,'#e67e22','rgba(230,126,34,.32)','rgba(230,126,34,.18)','#f0a44a',_esc(h.hazStatus||'미조치'),hico,'',
      _esc((h.hazType||'위험상황').replace(/^\S+\s/,'')||'위험상황'),
      _esc(h.loc||'위치 미상')+(h.danger?' · '+_esc(h.danger):'')));
  });
  badFac.forEach(f=>{
    const fico=(f.type||'').split(' ')[0]||'🛠️';
    cards.push(_card(`openFacFromHome(${f.id})`,'#e0a030','rgba(224,160,48,.32)','rgba(224,160,48,.18)','#ffc05a','위험',fico,'',
      _esc(f.name||'시설물'),
      _esc(f.type.split(' ').slice(1).join(' ')||'시설')+(f.loc?' · '+_esc(f.loc):'')));
  });
  el.innerHTML=`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
      <span style="font-size:12.5px;font-weight:800;color:#eaf2fa;">⚡ 주의 현황</span>
      <span style="font-size:10.5px;color:#9bb8cc;">${sum.join(' <span style=\"color:#3a5a74;\">·</span> ')}</span>
    </div>
    <div style="display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding-bottom:2px;">${cards.join('')}</div>`;
}
function openRescueFromHome(id){
  openApp('rescue');
  setTimeout(()=>{try{openResListDetail(id);}catch(e){}},90);
}
function openHazFromHome(id){
  openApp('rescue');
  setTimeout(()=>{try{openHazDetail(id);}catch(e){}},90);
}
function openFacFromHome(id){
  openApp('inspect');
  setTimeout(()=>{try{openFacDetail(id);}catch(e){}},120);
}
// ══════════════════════════════════════════
// 전체 통계 (일반직원도 열람 가능)
// ══════════════════════════════════════════
function renderFullStats(){
  // 전년대비·전체 통계는 1년 이전 기록도 필요 → 최초 1회만 로드 후 재호출(이후엔 이미 로드됨)
  if(_ARCHIVE_COLLS.some(k=>!_archiveLoaded[k])){
    Promise.all(_ARCHIVE_COLLS.map(_loadArchive)).then(()=>{if(window.curApp==='stats')renderFullStats();});
  }
  const res=DB.g('rescues')||[];const facs=DB.g('facilities')||[];
  const haz=DB.g('hazards')||[];const hist=DB.g('history')||[];
  const alertOps=DB.g('alertOps')||[];
  const now_=new Date();const todayStr=today();
  const fy=s=>s&&s.startsWith(now_.getFullYear()+'-');
  const fy_prev=s=>s&&s.startsWith((now_.getFullYear()-1)+'-');
  const fm=s=>s&&s.startsWith(now_.getFullYear()+'-'+(''+(now_.getMonth()+1)).padStart(2,'0'));
  const fw=s=>{if(!s)return false;const ds=String(s).split(' ')[0].split('T')[0];const day=now_.getDay()||7;const m=new Date(now_);m.setDate(now_.getDate()-(day-1));const e=new Date(m);e.setDate(m.getDate()+6);const _f=dt=>dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0')+'-'+String(dt.getDate()).padStart(2,'0');return ds>=_f(m)&&ds<=_f(e);}; // UTC파싱 제거 — 로컬 날짜 문자열 비교(주 경계 정확)
  const fd=s=>s&&s.startsWith(todayStr);
  const period=window._statPeriod||'이번달';
  const pf={'오늘':fd,'이번주':fw,'이번달':fm,'올해':fy,'전체':()=>true}[period]||fm;
  const getDate=r=>r.date||r.dt||'';
  const pRes=res.filter(r=>pf(getDate(r)));
  const pHaz=haz.filter(h=>pf(getDate(h)));
  const pHist=hist.filter(h=>pf(h.date||''));
  const pAlertOps=alertOps.filter(o=>pf((o.startedAt||'').split('T')[0]||o.startedAt||''));
  const activeAlertOps=alertOps.filter(o=>!o.closedAt);
  // 전년대비
  const thisY=res.filter(r=>fy(getDate(r))).length;
  const prevY=res.filter(r=>fy_prev(getDate(r))).length;
  const diff=thisY-prevY;
  const diffStr=diff>0?`▲${diff}`:diff<0?`▼${Math.abs(diff)}`:'±0';
  const diffCol=diff>0?'#c0392b':diff<0?'#27ae60':'#4a7090';
  // 유형별
  const typeMap={};pRes.forEach(r=>{typeMap[r.type]=(typeMap[r.type]||0)+1;});
  // 안전사고 세부
  const accRes=pRes.filter(r=>r.type==='안전사고');
  const injMap={},sevMap={},cauMap={},locMap={},methodMap={};
  accRes.forEach(r=>{
    (r.injuryParts||[]).forEach(p=>{injMap[p]=(injMap[p]||0)+1;});
    if(r.severity)sevMap[r.severity]=(sevMap[r.severity]||0)+1;
    if(r.cause)cauMap[r.cause]=(cauMap[r.cause]||0)+1;
    if(r.loctype)locMap[r.loctype]=(locMap[r.loctype]||0)+1;
    (r.rescueMethod||[]).forEach(m=>{methodMap[m]=(methodMap[m]||0)+1;});
  });
  const topN=(obj,n=5)=>Object.entries(obj).sort((a,b)=>b[1]-a[1]).slice(0,n);
  const safe_max=obj=>Math.max(...Object.values(obj),1);
  const barRow=(k,v,max,col)=>`<div style="margin-bottom:4px;"><div style="display:flex;justify-content:space-between;font-size:10px;margin-bottom:1px;"><span style="color:#c0d8ec;">${_esc(k)}</span><span style="color:${col};font-weight:700;">${v}</span></div><div style="height:3px;background:rgba(255,255,255,.06);border-radius:2px;overflow:hidden;"><div style="height:100%;width:${Math.round(v/max*100)}%;background:${col};border-radius:2px;"></div></div></div>`;
  const mini=(label,val,col='#e0edf8')=>`<div style="background:#060d1a;border-radius:7px;padding:5px 4px;text-align:center;"><div style="font-size:14px;font-weight:800;color:${col};line-height:1.2;">${val}</div><div style="font-size:8px;color:#7a9cb8;margin-top:1px;">${label}</div></div>`;
  const pill_tab=p=>`<div onclick="window._statPeriod='${p}';renderFullStats();" style="flex:1;padding:5px 2px;text-align:center;font-size:11px;font-weight:600;border-radius:7px;cursor:pointer;${p===period?'background:#1a4a6e;color:#e0edf8;':'color:rgba(255,255,255,.6);'}">${p}</div>`;
  const row2=(a,b)=>`<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;">${a}${b}</div>`;
  const w=document.getElementById('statsWrap');
  w.innerHTML=`
    <div style="display:flex;background:#0b1c30;border-radius:9px;padding:3px;gap:2px;margin-bottom:2px;">
      ${['오늘','이번주','이번달','올해','전체'].map(pill_tab).join('')}
    </div>
    ${row2(
      `<div class="scard">
        <div class="stitle">🚨 구조 · ${period} ${pRes.length}건</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:3px;margin-bottom:${Object.keys(typeMap).length?'6':'0'}px;">
          ${mini(period,pRes.length,'#4fa8d0')}${mini('진행중',res.filter(r=>r.status==='ongoing').length,'#c0392b')}
          ${mini('전년대비',diffStr,diffCol)}${mini('누적',res.length)}
        </div>
        ${Object.keys(typeMap).length?topN(typeMap,3).map(([k,v])=>barRow(k,v,safe_max(typeMap),'#4fa8d0')).join(''):''}
      </div>`,
      `<div class="scard">
        <div class="stitle">⚠️ 위험상황 · ${pHaz.length}건</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:3px;margin-bottom:4px;">
          ${mini('낙석',pHaz.filter(h=>h.hazType?.includes('낙석')).length,'#7d3c98')}
          ${mini('위험수목',pHaz.filter(h=>h.hazType?.includes('위험수목')).length,'#ca6f1e')}
          ${mini('산불',pHaz.filter(h=>h.hazType?.includes('산불')).length,'#a93226')}
        </div>
        <div style="font-size:9px;color:#5a8aaa;">미조치 ${pHaz.filter(h=>h.hazStatus==='미조치').length} · 완료 ${pHaz.filter(h=>h.hazStatus&&h.hazStatus!=='미조치'&&h.hazStatus!=='조치중').length}</div>
      </div>`
    )}
    <div class="scard">
      <div class="stitle">🛠️ 시설물 · 점검 ${pHist.length}건</div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:3px;">
        ${mini('전체',facs.length)}${mini('위험',facs.filter(f=>f.status==='bad').length,'#c0392b')}
        ${mini('요주의',facs.filter(f=>f.status==='warn').length,'#e67e22')}${mini('기간점검',pHist.length,'#27ae60')}
      </div>
    </div>
    ${(()=>{
      const lvlMap={};
      pAlertOps.forEach(op=>{const lv=typeof _opLevel==='function'?_opLevel(op):(((op.alerts||[]).length?(op.alerts[op.alerts.length-1].stage||'예비특보'):(op.level||'예비특보')));lvlMap[lv]=(lvlMap[lv]||0)+1;});
      const typeAlertMap={};
      pAlertOps.forEach(op=>{(op.alerts||[]).forEach(a=>{const t=a.type||'기타';typeAlertMap[t]=(typeAlertMap[t]||0)+1;});});
      const totResponders=pAlertOps.reduce((s,op)=>s+(op.responders||[]).length,0);
      const totReports=pAlertOps.reduce((s,op)=>s+(op.reports||[]).length,0);
      const closedOps=pAlertOps.filter(o=>o.closedAtMs&&o.startedAtMs);
      const avgHrs=closedOps.length?Math.round(closedOps.reduce((s,o)=>s+((o.closedAtMs||0)-(o.startedAtMs||0)),0)/closedOps.length/3600000):0;
      const lvlColor={'예비특보':'#27ae60','Ⅰ단계(주의보)':'#e67e22','Ⅱ단계(경보)':'#c0392b','Ⅲ단계':'#7d3c98'};
      const lvlRows=Object.entries(lvlMap).sort((a,b)=>(['예비특보','Ⅰ단계(주의보)','Ⅱ단계(경보)','Ⅲ단계'].indexOf(b[0])||0)-(['예비특보','Ⅰ단계(주의보)','Ⅱ단계(경보)','Ⅲ단계'].indexOf(a[0])||0)).map(([k,v])=>barRow(k,v,Math.max(...Object.values(lvlMap),1),lvlColor[k]||'#4fa8d0')).join('');
      const typeRows=Object.entries(typeAlertMap).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([k,v])=>barRow(k,v,Math.max(...Object.values(typeAlertMap),1),'#4fa8d0')).join('');
      if(!pAlertOps.length&&!activeAlertOps.length)return '';
      return `<div class="scard">
        <div class="stitle">🌀 특보운영 · ${period} ${pAlertOps.length}건</div>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:3px;margin-bottom:6px;">
          ${mini(period,pAlertOps.length,'#4fa8d0')}${mini('운영중',activeAlertOps.length,activeAlertOps.length?'#c0392b':'#4fa8d0')}
          ${mini('응소인원',totResponders,'#e67e22')}${mini('관측보고',totReports,'#27ae60')}
        </div>
        ${pAlertOps.length?`<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
          <div>${lvlRows?`<div style="font-size:9px;color:#7a9cb8;margin-bottom:3px;">단계별</div>${lvlRows}`:''}</div>
          <div>${typeRows?`<div style="font-size:9px;color:#7a9cb8;margin-bottom:3px;">특보 종류</div>${typeRows}`:''}</div>
        </div>${avgHrs?`<div style="font-size:9px;color:#5a8aaa;margin-top:4px;">평균 운영 ${avgHrs}시간</div>`:''}`:
        `<div style="font-size:10px;color:#5a8aaa;">현재 운영중 ${activeAlertOps.length}건</div>`}
      </div>`;
    })()}
    ${accRes.length?`
    <div class="scard">
      <div class="stitle">🤕 안전사고 세부 · ${accRes.length}건</div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:3px;margin-bottom:6px;">
        ${mini('내국인',accRes.filter(r=>r.vNation==='내국인').length)}
        ${mini('외국인',accRes.filter(r=>r.vNation==='외국인').length)}
        ${mini('음주',accRes.filter(r=>r.alcohol==='확인됨'||r.alcohol==='의심').length,'#e67e22')}
        ${mini('후송',accRes.filter(r=>r.hospital&&r.hospital.includes('후송')).length,'#c0392b')}
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
        <div>${Object.keys(cauMap).length?`<div class="stitle">⚡원인</div>${topN(cauMap,3).map(([k,v])=>barRow(k,v,safe_max(cauMap),'#e67e22')).join('')}`:''}</div>
        <div>${Object.keys(injMap).length?`<div class="stitle">🦵부위</div>${topN(injMap,3).map(([k,v])=>barRow(k,v,safe_max(injMap),'#c0392b')).join('')}`:''}</div>
        <div>${Object.keys(methodMap).length?`<div class="stitle">🚑방법</div>${topN(methodMap,3).map(([k,v])=>barRow(k,v,safe_max(methodMap),'#27ae60')).join('')}`:''}</div>
        <div>${Object.keys(sevMap).length?`<div class="stitle">🩺중증도</div>${topN(sevMap,3).map(([k,v])=>barRow(k,v,safe_max(sevMap),'#7d3c98')).join('')}`:''}</div>
      </div>
    </div>`:''}
  `;
}

function openResListDetail(id){
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===id);if(!r)return;
  selResId=id;curResId=id;
  const all=[r,...(r.reports||[])];
  document.getElementById('phaseSelectTitle').textContent=r.title;
  document.getElementById('phaseSelectList').innerHTML=all.map((p,i)=>{
    const isFirst=i===0;
    const timeStr=isFirst?r.date:p.repTime||'-';
    const authorStr=isFirst?r.author||'-':p.author||'-';
    const summary=isFirst
      ?`${r.type} · ${r.vName||'미상'} · ${r.severity||'-'}`
      :`${(p.update||'').slice(0,40)}${(p.update||'').length>40?'...':''}`;
    return `<div class="lcard" onclick="viewSinglePhase(${id},${i});closeM('modalPhaseSelect')">
      <div style="width:32px;height:32px;border-radius:50%;background:${i===all.length-1?'#1a4a6e':'#0b1c30'};border:2px solid ${i===all.length-1?'#4fa8d0':'rgba(79,168,208,.3)'};display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#4fa8d0;flex-shrink:0;">${i+1}보</div>
      <div class="linfo">
        <div class="lname">${i+1}보 — ${isFirst?'초기 접수':'업데이트'}</div>
        <div class="lmeta">${timeStr} · ${authorStr}</div>
        <div class="lmeta">${summary}</div>
      </div>
    </div>`;
  }).join('');
  document.getElementById('modalPhaseSelect').classList.add('on');
}
function viewSinglePhase(resId,phaseIdx){
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===resId);if(!r)return;
  selResId=resId;curResId=resId;
  document.getElementById('topTitle').textContent=r.title+' · '+(phaseIdx+1)+'보';
  document.getElementById('bnav').style.display='none';
  _hideRepFooter();showV('v-report');
  const all=[r,...(r.reports||[])];
  renderPhaseBar(phaseIdx,all.length);
  // 단일 보 내용만 표시
  const p=all[phaseIdx];const isFirst=phaseIdx===0;
  const w=document.getElementById('repContent');
  const content=isFirst?`
    <div class="rsec"><div class="rsec-t">📋 1보 — 초기 접수</div>
      <div style="font-size:12px;color:#7a9cb8;line-height:2.0;">
        <b>유형:</b> ${r.type}<br><b>발생:</b> ${r.date}<br><b>위치:</b> ${r.location||'-'} (${r.loctype||'-'})<br>
        <b>사고자:</b> ${r.vName||'미상'} / ${(r.vGender&&r.vGender!=='알수없음')?r.vGender:'성별미상'} / ${(r.vNation&&r.vNation!=='알수없음')?r.vNation:'국적미상'}<br>
        <b>연락처:</b> ${r.vTel||'-'}<br><b>중증도:</b> ${r.severity||'-'}<br>
        <b>사고 원인:</b> ${r.cause||'-'}<br><b>부상 부위:</b> ${(r.injuryParts||[]).join(', ')||'-'}<br>
        <b>구조 방법:</b> ${(r.rescueMethod||[]).join(', ')||'-'}<br>
        <b>출동 대원:</b> ${(r.members||[]).join(', ')||'-'}<br>
        <b>병원 후송:</b> ${(r.hospital&&r.hospital!=='미정')?r.hospital:'미정'}<br><b>작성자:</b> ${r.author||'-'}
      </div>
    </div>`:
    `<div class="rsec"><div class="rsec-t">📋 ${phaseIdx+1}보 — 상황 업데이트</div>
      <div style="font-size:12px;color:#7a9cb8;line-height:2.0;">
        <b>보고 시간:</b> ${p.repTime||'-'}<br>
        <b>상황 내용:</b> ${p.update||'-'}<br>
        <b>부상자 상태:</b> ${p.victimChange||'-'}<br>
        ${p.addMem?`<b>추가 대원:</b> ${p.addMem}<br>`:''}
        <b>작성자:</b> ${p.author||'-'}
      </div>
    </div>`;
  w.innerHTML=content+`
    <div style="display:flex;gap:6px;margin-top:6px;">
      <button class="btn btn-ghost" style="flex:1;" onclick="openResListDetail(${resId})">← 보 목록</button>
      <button class="btn btn-blue" style="flex:1;" onclick="renderTimeline(getRes(${resId}))">📊 전체 타임라인</button>
    </div>`;
}
function openFullTimeline(){
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===selResId);if(!r)return;
  closeM('modalPhaseSelect');
  document.getElementById('topTitle').textContent=r.title+' 타임라인';
  document.getElementById('bnav').style.display='none';
  _hideRepFooter();showV('v-report');
  renderPhaseBar((r.reports||[]).length,(r.reports||[]).length+1);
  renderTimeline(r,'brief');
}

// 직원 정렬: 직위 → 과순서 → 이름순
const RANKS=['소장','과장','분소장','대장','팀장','계장','주임'];
const DEPTS=['행정과','재난안전과','탐방시설과','자원보전과','특수산악구조대','대청분소','백담분소','오색분소','한계산성분소','점봉산분소'];
const DEPT_SHORT={'특수산악구조대':'특구대','대청분소':'대청','백담분소':'백담'};
function sortStaff(arr){
  return [...arr].sort((a,b)=>{
    const ri=RANKS.indexOf(a.rank)-RANKS.indexOf(b.rank);
    if(ri!==0)return ri;
    const di=DEPTS.indexOf(a.dept)-DEPTS.indexOf(b.dept);
    if(di!==0)return di;
    return (a.name||'').localeCompare(b.name||'','ko');
  });
}
function getTeamMembers(){
  // 앱에 실제 가입한 사용자만 팀원 풀로 사용
  const users=DB.g('pendingUsers')||[];
  return sortStaff(users.filter(u=>u.name||u.realName).map(u=>({
    name:u.realName||u.name,dept:u.dept||'',rank:u.rank||''
  })));
}

// ══════════════════════════════════════════
// 응소 응답(예상 도착시간 / 응소불가 / 미응답)
// ══════════════════════════════════════════
const MOBILIZE_DEPT_MAP={'특구대':'특수산악구조대','재난과':'재난안전과'}; // 전직원응소는 전체 대상
// 목록 카드에서 한눈에 보이는 응소 응답 요약 배지 — 상세를 열지 않아도 진행 상황 파악 가능
function _mobilizeCompactBadge(r){
  if(!r.mobilize||!r.mobilize.length)return '';
  const roster=_mobilizeRoster(r.mobilize);if(!roster.length)return '';
  const respMap={};(r.mobilizeResp||[]).forEach(x=>{respMap[x.name]=x;});
  const okCnt=roster.filter(s=>(respMap[s.name]||{}).status==='eta').length;
  const noCnt=roster.filter(s=>(respMap[s.name]||{}).status==='unable').length;
  return ` <span style="font-size:9px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);border-radius:9px;padding:1px 6px;font-weight:700;vertical-align:middle;color:#9bbdd4;">🟢${okCnt} 🔴${noCnt} ⚪${roster.length-okCnt-noCnt}</span>`;
}
function _mobilizeRoster(mobilize){
  if(!mobilize||!mobilize.length)return [];
  const all=getTeamMembers();
  if(mobilize.includes('전직원응소'))return all;
  const depts=mobilize.map(m=>MOBILIZE_DEPT_MAP[m]).filter(Boolean);
  if(!depts.length)return [];
  return all.filter(s=>depts.includes(s.dept));
}
function _mobilizeBlockHtml(coll,r){
  if(!r.mobilize||!r.mobilize.length)return '';
  const roster=_mobilizeRoster(r.mobilize);
  const respMap={};(r.mobilizeResp||[]).forEach(x=>{respMap[x.name]=x;});
  const me=DB.g('currentUser')||{};
  const myName=me.realName||me.name||'';
  const iAmTarget=!!myName&&roster.some(s=>s.name===myName);
  const myResp=myName?respMap[myName]:null;
  const okCnt=roster.filter(s=>(respMap[s.name]||{}).status==='eta').length;
  const noCnt=roster.filter(s=>(respMap[s.name]||{}).status==='unable').length;
  const pendCnt=roster.length-okCnt-noCnt;
  // 과/분소별로 묶어서 표시 — 부서가 둘 이상 섞여 있을 때만 그룹 헤더 노출
  const deptGroups={};roster.forEach(s=>{const k=s.dept||'기타';if(!deptGroups[k])deptGroups[k]=[];deptGroups[k].push(s);});
  const deptKeys=Object.keys(deptGroups).sort((a,b)=>DEPTS.indexOf(a)-DEPTS.indexOf(b));
  const multiDept=deptKeys.length>1;
  const personRow=s=>{
    const rr=respMap[s.name];
    let stat;
    if(rr&&rr.status==='eta')stat=`<span style="color:#3ad17a;">🟢 도착예정 ${_esc(rr.eta)}</span>`;
    else if(rr&&rr.status==='unable')stat=`<span style="color:#e74c3c;">🔴 응소불가</span>`;
    else stat=`<span style="color:rgba(255,255,255,.35);">⚪ 미응답</span>`;
    return `<div style="display:flex;justify-content:space-between;align-items:center;padding:3px 0;font-size:11px;">
      <span style="color:#b8d4e8;">${_esc(s.name)}${s.rank?` <span style="color:#4a7090;font-size:9px;">${_esc(s.rank)}</span>`:''}</span>${stat}
    </div>`;
  };
  const rows=deptKeys.map(dk=>{
    const members=deptGroups[dk];
    const dOk=members.filter(s=>(respMap[s.name]||{}).status==='eta').length;
    const dNo=members.filter(s=>(respMap[s.name]||{}).status==='unable').length;
    return (multiDept?`<div style="font-size:10px;font-weight:700;color:#7ec8a0;margin:6px 0 2px;padding-top:6px;border-top:.5px solid rgba(255,255,255,.05);display:flex;justify-content:space-between;"><span>${_esc(dk)}</span><span style="color:#4a7090;">🟢${dOk} 🔴${dNo} / ${members.length}명</span></div>`:'')
      +members.map(personRow).join('');
  }).join('');
  return `<div id="mobBlk_${coll}_${r.id}" style="background:#0b1c30;border-radius:10px;padding:11px 12px;border:.5px solid rgba(231,76,60,.25);margin-top:8px;">
    <div style="font-size:11px;color:#e74c3c;font-weight:700;margin-bottom:7px;">🚨 응소 현황 (${_esc(r.mobilize.join('·'))})</div>
    ${roster.length>1?`<div style="display:flex;gap:10px;font-size:10.5px;font-weight:700;margin-bottom:7px;padding-bottom:7px;border-bottom:.5px solid rgba(255,255,255,.07);">
      <span style="color:#3ad17a;">🟢 ${okCnt}명</span><span style="color:#e74c3c;">🔴 ${noCnt}명</span><span style="color:rgba(255,255,255,.4);">⚪ ${pendCnt}명</span><span style="color:#4a7090;margin-left:auto;">총 ${roster.length}명</span>
    </div>`:''}
    ${rows||'<div style="font-size:11px;color:rgba(255,255,255,.3);">대상 인원 없음</div>'}
    ${iAmTarget?`<div>
      <div id="mobBtnRow_${coll}_${r.id}" style="display:flex;gap:6px;margin-top:8px;">
        <button onclick="_toggleMobEtaInput('${coll}',${r.id})" style="flex:1;background:rgba(39,174,96,.15);color:#3ad17a;border:1px solid rgba(39,174,96,.35);border-radius:8px;padding:7px;font-size:11px;font-weight:700;cursor:pointer;">🟢 ${myResp&&myResp.status==='eta'?'도착시간 수정':'응소 가능·도착시간 입력'}</button>
        <button onclick="submitMobilizeResp('${coll}',${r.id},'unable')" style="flex:1;background:rgba(231,76,60,.12);color:#e74c3c;border:1px solid rgba(231,76,60,.3);border-radius:8px;padding:7px;font-size:11px;font-weight:700;cursor:pointer;">🔴 응소 불가</button>
      </div>
      <div id="mobEtaInputRow_${coll}_${r.id}" style="display:none;margin-top:8px;">
        <div style="display:flex;gap:5px;margin-bottom:6px;">
          ${[10,20,30,60].map(m=>`<button onclick="submitMobilizeResp('${coll}',${r.id},'eta',_etaFromMinutes(${m}))" style="flex:1;background:rgba(39,174,96,.18);color:#3ad17a;border:1px solid rgba(39,174,96,.4);border-radius:8px;padding:6px 2px;font-size:10.5px;font-weight:700;cursor:pointer;">+${m}분</button>`).join('')}
        </div>
        <div style="display:flex;gap:6px;">
          <input type="text" id="mobEtaInp_${coll}_${r.id}" class="fi" placeholder="직접 입력 (예: 14:30)" value="${_esc((myResp&&myResp.eta)||'')}" onkeydown="if(event.key==='Enter')_confirmMobEta('${coll}',${r.id})" style="flex:1;">
          <button onclick="_confirmMobEta('${coll}',${r.id})" style="background:rgba(39,174,96,.18);color:#3ad17a;border:1px solid rgba(39,174,96,.4);border-radius:8px;padding:0 12px;font-size:11px;font-weight:700;cursor:pointer;">확인</button>
          <button onclick="_cancelMobEtaInput('${coll}',${r.id})" style="background:rgba(255,255,255,.06);color:#b8d4e8;border:1px solid rgba(255,255,255,.14);border-radius:8px;padding:0 12px;font-size:11px;font-weight:700;cursor:pointer;">취소</button>
        </div>
      </div>
    </div>`:''}
    ${(pendCnt>0&&isAdminUser())?`<button onclick="_remindMobilizeNonResponders('${coll}',${r.id})" style="width:100%;margin-top:7px;background:rgba(240,165,0,.12);color:#f0a500;border:1px solid rgba(240,165,0,.35);border-radius:8px;padding:6px;font-size:10.5px;font-weight:700;cursor:pointer;">🔔 미응답자 ${pendCnt}명 재알림</button>`:''}
  </div>`;
}
async function _remindMobilizeNonResponders(coll,id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const arr=DB.g(coll)||[];
  const r=arr.find(x=>x.id===id);
  if(!r)return;
  const roster=_mobilizeRoster(r.mobilize);
  const respMap={};(r.mobilizeResp||[]).forEach(x=>{respMap[x.name]=x;});
  const pendNames=roster.filter(s=>!respMap[s.name]).map(s=>s.name);
  if(!pendNames.length){toast('✅ 전원 응답 완료');return;}
  const title=r.title||r.hazType||'위험상황';
  const body=`🔔 [재알림] ${title} — 응소 여부를 회신해 주세요`;
  toast('🔔 미응답자 재알림 발송 중…');
  try{
    if(!_fdb)throw new Error('no-db');
    const url=_FCM_PUSH_URL||(DB.g('fcmPushUrl')||'').trim();
    const snap=await _fdb.collection('fcmTokens').get();
    const tokens=[];snap.forEach(d=>{const v=d.data()||{};if(v.token&&pendNames.includes(v.name))tokens.push(v.token);});
    if(tokens.length&&url){
      const res=await fetch(url,{method:'POST',headers:{'content-type':'text/plain;charset=utf-8'},
        body:JSON.stringify({secret:_FCM_PUSH_SECRET||(DB.g('fcmPushSecret')||''),title:'설악산 현장관리',body,
          data:{app:'rescue',tab:'2',id:String(id)},tokens:tokens})});
      const out=await res.json().catch(()=>({}));
      toast(`🔔 ${out.sent||tokens.length}명에게 재알림 발송됨`);
    }else{
      pushNoti(`🔔 [재알림] ${pendNames.join(', ')} — ${title} 응소 여부 회신 요청`,'🔔','rescue_mobilize',{app:'rescue',tab:2,id});
      toast('🔔 미응답자에게 전체 알림으로 발송됨');
    }
  }catch(e){
    pushNoti(`🔔 [재알림] ${pendNames.join(', ')} — ${title} 응소 여부 회신 요청`,'🔔',r.type||'화재',{app:'rescue',tab:2,id},'안전사고');
    toast('🔔 미응답자에게 전체 알림으로 발송됨');
  }
}
function _etaFromMinutes(min){
  const d=new Date(Date.now()+min*60000);
  return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
}
function _toggleMobEtaInput(coll,id){
  const btnRow=document.getElementById('mobBtnRow_'+coll+'_'+id);
  const inpRow=document.getElementById('mobEtaInputRow_'+coll+'_'+id);
  if(!btnRow||!inpRow)return;
  btnRow.style.display='none';
  inpRow.style.display='block';
  const inp=document.getElementById('mobEtaInp_'+coll+'_'+id);
  if(inp){inp.focus();inp.select();}
}
function _cancelMobEtaInput(coll,id){
  const btnRow=document.getElementById('mobBtnRow_'+coll+'_'+id);
  const inpRow=document.getElementById('mobEtaInputRow_'+coll+'_'+id);
  if(btnRow)btnRow.style.display='flex';
  if(inpRow)inpRow.style.display='none';
}
function _confirmMobEta(coll,id){
  const inp=document.getElementById('mobEtaInp_'+coll+'_'+id);
  const eta=inp?inp.value.trim():'';
  if(!eta){toast('⚠️ 시간 입력 필요');if(inp)inp.focus();return;}
  submitMobilizeResp(coll,id,'eta',eta);
}
function submitMobilizeResp(coll,id,status,eta=''){
  const arr=DB.g(coll)||[];
  const idx=arr.findIndex(x=>x.id===id);
  if(idx===-1)return;
  const me=DB.g('currentUser')||{};
  const myName=me.realName||me.name||'';
  if(!myName){toast('⚠️ 설정에서 이름을 먼저 입력하세요');return;}
  if(status==='eta'&&!String(eta).trim()){toast('⚠️ 시간 입력 필요');return;}
  const resp=(arr[idx].mobilizeResp||[]).filter(x=>x.name!==myName);
  resp.push({name:myName,dept:me.dept||'',rank:me.rank||'',status,eta:String(eta).trim(),time:now()});
  arr[idx]={...arr[idx],mobilizeResp:resp};
  DB.s(coll,arr);
  toast(status==='eta'?'🟢 응소 가능 등록됨':'🔴 응소 불가 등록됨');
  const blk=document.getElementById('mobBlk_'+coll+'_'+id);
  if(blk)blk.outerHTML=_mobilizeBlockHtml(coll,arr[idx]);
  try{renderMobilizeBanner();}catch(e){}
}
// 내가 응답해야 하는(아직 미응답인) 응소 요청 목록 — 홈 화면 배너용
function _myPendingMobilizations(){
  const me=DB.g('currentUser')||{};
  const myName=me.realName||me.name||'';
  if(!myName)return [];
  const collect=(coll,activeFilter)=>(DB.g(coll)||[]).filter(activeFilter).filter(r=>r.mobilize&&r.mobilize.length).filter(r=>{
    if(!_mobilizeRoster(r.mobilize).some(s=>s.name===myName))return false;
    return !(r.mobilizeResp||[]).some(x=>x.name===myName);
  }).map(r=>({coll,id:r.id,title:r.title||r.hazType||'위험상황',mobilize:r.mobilize}));
  return [
    ...collect('rescues',r=>r.status==='ongoing'),
    ...collect('hazards',h=>!h.hazStatus||h.hazStatus==='미조치'||h.hazStatus==='조치중'),
  ];
}
function renderMobilizeBanner(){
  const el=document.getElementById('mobilizeBanner');if(!el)return;
  if(isExternal()){el.innerHTML='';return;}
  const pend=_myPendingMobilizations();
  if(!pend.length){el.innerHTML='';return;}
  const first=pend[0];
  const onclick=first.coll==='rescues'?`openRescueFromHome(${first.id})`:`openHazFromHome(${first.id})`;
  const qBtn=(label,min)=>`<button onclick="event.stopPropagation();submitMobilizeResp('${first.coll}',${first.id},'eta',_etaFromMinutes(${min}))" style="flex:1;background:rgba(39,174,96,.18);color:#3ad17a;border:1px solid rgba(39,174,96,.4);border-radius:8px;padding:6px 2px;font-size:10.5px;font-weight:700;cursor:pointer;">${label}</button>`;
  el.innerHTML=`<div style="background:linear-gradient(135deg,#3a1410,#240a08);border:1px solid rgba(231,76,60,.5);border-radius:16px;padding:14px 16px;margin-bottom:20px;">
    <div onclick="${onclick}" style="display:flex;align-items:center;gap:12px;cursor:pointer;">
      <div style="width:40px;height:40px;border-radius:50%;background:rgba(231,76,60,.22);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;"><span class="blink">🚨</span></div>
      <div style="min-width:0;flex:1;">
        <div style="font-size:14px;font-weight:800;color:#ffdcd6;">응소 요청 — 응답이 필요합니다</div>
        <div style="font-size:11.5px;color:#f0a89e;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(first.title)} · ${_esc(first.mobilize.join('·'))}${pend.length>1?` 외 ${pend.length-1}건`:''}</div>
      </div>
      <div style="font-size:11px;font-weight:700;color:#ff6b5e;flex-shrink:0;">상세 ›</div>
    </div>
    <div style="display:flex;gap:5px;margin-top:10px;">
      ${qBtn('🟢 +10분',10)}${qBtn('🟢 +30분',30)}${qBtn('🟢 +1시간',60)}
      <button onclick="event.stopPropagation();submitMobilizeResp('${first.coll}',${first.id},'unable')" style="flex:1;background:rgba(231,76,60,.15);color:#e74c3c;border:1px solid rgba(231,76,60,.35);border-radius:8px;padding:6px 2px;font-size:10.5px;font-weight:700;cursor:pointer;">🔴 불가</button>
    </div>
  </div>`;
}

function chkHazOnSite(el){
  const val=el.textContent;
  const detail=document.getElementById('hazOnSiteDetail');
  if(detail) detail.style.display=val.includes('있음')?'block':'none';
}

// ── 2보 분기 ──
let _phaseChoice='yes';
let _timetableEntries=[];
// 자주 발생하는 단계만 버튼화 — 나머지는 '✏️ 직접입력'으로 수동 기재
const TT_STAGES_INIT=['지점통과','요구조자 조우','헬기 요청','기상 악화','작전 중단'];
const TT_STAGES_AFTER=['응급처치','심정지','하산 시작','헬기 도착','헬기 회항(기상)','대피소 숙박','작전 재개','휴식'];
let _ttFoundVictim=false;

function selectPhaseChoice(choice,el){
  _phaseChoice=choice;
  document.querySelectorAll('#phaseChoiceWrap button').forEach(b=>{b.style.background='transparent';b.style.color='#c0d8ec';b.style.borderColor='rgba(255,255,255,.1)';});
  el.style.background='rgba(79,168,208,.12)';el.style.color='#4fa8d0';el.style.borderColor='rgba(79,168,208,.5)';
  document.getElementById('phaseChoiceWrap').style.display='none';
  document.getElementById('phaseFormWrap').style.display='block';
  const _ra=document.getElementById('r_repAuthor');if(_ra){_ra.value=getAuthor();_ra.disabled=true;}
  const prevWrap=document.getElementById('prevReadonlyWrap');
  // 전보 내용 표시
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===curResId);
  if(!r){return;}
  const phaseIdx=(r.reports||[]).length; // 현재 작성할 보 번호
  const prev=phaseIdx>0?r.reports[phaseIdx-1]:null;
  if(choice==='yes'){
    // 예: 전보 내용 먼저 보여주고, 변경사항 입력
    if(prev){
      prevWrap.style.display='block';
      prevWrap.innerHTML=`<div style="background:#060d1a;border-radius:9px;padding:10px 12px;margin-bottom:8px;border:1px solid rgba(79,168,208,.15);">
        <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:6px;">📋 전보 (${phaseIdx}보) 내용</div>
        <div style="font-size:11px;color:#7a9cb8;line-height:1.8;">
          <b>시간:</b> ${prev.repTime||'-'}<br>
          <b>상황:</b> ${prev.update||'-'}<br>
          <b>부상자:</b> ${prev.victimChange||'-'}
        </div>
      </div>`;
    }
  } else {
    // 아니오: 1보에서 작성 안 한 항목만 보여줌 + 기존 작성내용은 readonly
    prevWrap.style.display='block';
    prevWrap.innerHTML=`<div style="background:#060d1a;border-radius:9px;padding:10px 12px;margin-bottom:8px;border:1px solid rgba(39,174,96,.15);">
      <div style="font-size:10px;color:#27ae60;font-weight:700;margin-bottom:4px;">✅ 기존 작성 내용 (수정불가)</div>
      <div style="font-size:11px;color:#5a8070;line-height:1.8;">
        유형: ${r.type} · 사고자: ${r.vName||'미상'}<br>
        중증도: ${r.severity||'-'} · 구조방법: ${(r.rescueMethod||[]).join(', ')||'-'}
      </div>
    </div>
    <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:6px;">📝 미작성 항목 추가입력</div>`;
  }
}

function openTimetable(){
  closeM('modalAddPhase');
  _timetableEntries=[];_ttFoundVictim=false;
  renderTimetableList();
  document.getElementById('modalTimetable').classList.add('on');
}
function renderTimetableList(){
  const stages=_ttFoundVictim?TT_STAGES_AFTER:TT_STAGES_INIT;
  const listEl=document.getElementById('timetableList');
  listEl.innerHTML=`
    <div style="margin-bottom:8px;">
      ${_timetableEntries.map((e,i)=>`
        <div style="background:#060d1a;border-radius:8px;padding:10px 12px;margin-bottom:5px;border:1px solid rgba(79,168,208,.12);">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="width:8px;height:8px;border-radius:50%;background:${e.stage==='요구조자 조우'?'#c0392b':'#4fa8d0'};flex-shrink:0;"></div>
            <div style="flex:1;">
              <div style="font-size:12px;font-weight:700;color:#e0edf8;">${e.stage}</div>
              <div style="font-size:10px;color:#4a7090;">${e.time||'-'}</div>
              ${e.note?`<div style="font-size:11px;color:#7a9cb8;margin-top:2px;">${e.note}</div>`:''}
            </div>
            <button onclick="removeTTEntry(${i})" style="background:rgba(192,57,43,.12);border:1px solid rgba(192,57,43,.3);border-radius:8px;color:#e05050;font-size:13px;font-weight:700;cursor:pointer;width:38px;height:38px;flex-shrink:0;display:flex;align-items:center;justify-content:center;">✕</button>
          </div>
        </div>`).join('')}
    </div>
    <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin-bottom:6px;">단계 선택 <span style="color:rgba(255,255,255,.3);font-weight:400;">· 없으면 직접입력</span></div>
    <div style="display:flex;flex-wrap:wrap;gap:5px;">
      ${stages.filter(s=>!_timetableEntries.find(e=>e.stage===s&&s!=='지점통과'&&s!=='휴식')).map(s=>{
        const isVic=s==='요구조자 조우'||s==='심정지';
        return `<div onclick="selectTTStage('${s}')" style="padding:6px 12px;border-radius:20px;border:1.5px solid ${isVic?'rgba(231,76,60,.4)':'rgba(79,168,208,.3)'};color:${isVic?'#e74c3c':'#4fa8d0'};font-size:11px;font-weight:600;cursor:pointer;background:${isVic?'rgba(231,76,60,.07)':'rgba(79,168,208,.06)'};">${s}</div>`;}).join('')}
      <div onclick="selectTTStageCustom()" style="padding:6px 12px;border-radius:20px;border:1.5px dashed rgba(255,255,255,.3);color:rgba(255,255,255,.55);font-size:11px;font-weight:600;cursor:pointer;background:transparent;">✏️ 직접입력</div>
    </div>
    <div id="ttInputWrap" style="display:none;margin-top:10px;">
      <div style="font-size:11px;color:#4fa8d0;font-weight:700;margin-bottom:6px;" id="ttStageLabel"></div>
      <div class="frow">
        <div class="fg"><span class="fl">시간</span><input type="datetime-local" id="ttTime" class="fi" value="NOWDT"></div>
      </div>
      <div class="fg"><span class="fl">메모 (선택)</span><input type="text" id="ttNote" class="fi" placeholder="지점명, 특이사항 등"></div>
      <!-- CPR 추가 필드 (심정지 선택 시만 표시) -->
      <div id="ttCprWrap" style="display:none;background:rgba(231,76,60,.07);border:1px solid rgba(231,76,60,.25);border-radius:9px;padding:10px 12px;margin-top:6px;">
        <div style="font-size:10px;color:#e74c3c;font-weight:700;margin-bottom:7px;">🫀 CPR 기록</div>
        <div class="frow">
          <div class="fg"><span class="fl">CPR 시작</span><input type="datetime-local" id="ttCprStart" class="fi" value="NOWDT"></div>
          <div class="fg"><span class="fl">CPR 종료</span><input type="datetime-local" id="ttCprEnd" class="fi"></div>
        </div>
        <div class="frow">
          <div class="fg"><span class="fl">AED 사용</span>
            <div style="display:flex;gap:6px;margin-top:4px;">
              <button id="ttAedY" onclick="this.style.background='rgba(231,76,60,.25)';this.style.color='#e74c3c';document.getElementById('ttAedN').style.background='transparent';document.getElementById('ttAedN').style.color='rgba(255,255,255,.4)';this._v=1;" style="flex:1;padding:6px;border-radius:7px;border:1px solid rgba(231,76,60,.3);background:transparent;color:rgba(255,255,255,.4);font-size:11px;font-weight:700;cursor:pointer;">사용함</button>
              <button id="ttAedN" onclick="this.style.background='rgba(79,168,208,.15)';this.style.color='#4fa8d0';document.getElementById('ttAedY').style.background='transparent';document.getElementById('ttAedY').style.color='rgba(255,255,255,.4)';" style="flex:1;padding:6px;border-radius:7px;border:1px solid rgba(79,168,208,.25);background:rgba(79,168,208,.1);color:#4fa8d0;font-size:11px;font-weight:700;cursor:pointer;">미사용</button>
            </div>
          </div>
        </div>
      </div>
      <button onclick="confirmTTEntry()" style="width:100%;padding:9px;background:#1a4a6e;color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;margin-top:8px;">추가</button>
    </div>`.replace(/NOWDT/g, new Date().toISOString().slice(0,16));
}
let _selectedTTStage='';
function selectTTStageCustom(){
  const s=prompt('기록할 단계·상황을 직접 입력하세요\n(예: 헬기 이륙 대기, 대피소 직원 합류, 장비 보급, 요구조자 자력보행 등)');
  if(!s||!s.trim())return;
  selectTTStage(s.trim());
}
function selectTTStage(stage){
  _selectedTTStage=stage;
  const wrap=document.getElementById('ttInputWrap');
  const label=document.getElementById('ttStageLabel');
  const cprWrap=document.getElementById('ttCprWrap');
  if(wrap){wrap.style.display='block';}
  if(label){label.textContent=(stage==='심정지'?'💔':'📍')+' '+stage+' 시간 입력';}
  if(cprWrap){cprWrap.style.display=stage==='심정지'?'block':'none';}
}
function confirmTTEntry(){
  const time=document.getElementById('ttTime')?.value||'';
  const note=document.getElementById('ttNote')?.value||'';
  const entry={stage:_selectedTTStage,time:time.replace('T',' '),note};
  // 심정지 → CPR 데이터 수집
  if(_selectedTTStage==='심정지'){
    const cs=document.getElementById('ttCprStart')?.value||'';
    const ce=document.getElementById('ttCprEnd')?.value||'';
    const aedY=document.getElementById('ttAedY');
    if(cs)entry.cprStart=cs.replace('T',' ');
    if(ce)entry.cprEnd=ce.replace('T',' ');
    entry.aed=aedY&&aedY._v?'사용':'미사용';
  }
  _timetableEntries.push(entry);
  if(_selectedTTStage==='요구조자 조우') _ttFoundVictim=true;
  renderTimetableList();
}
function removeTTEntry(i){
  const e=_timetableEntries[i];
  if(e&&!confirm('"'+(e.stage||'기록')+'" 기록을 삭제할까요?'))return;
  _timetableEntries.splice(i,1);if(!_timetableEntries.find(e=>e.stage==='요구조자 조우'))_ttFoundVictim=false;renderTimetableList();
}
function addTimetableEntry(){selectTTStage('지점통과');}
function saveTimetable(){
  const res=DB.g('rescues')||[];const idx=res.findIndex(x=>x.id===curResId);if(idx===-1)return;
  if(!res[idx].timetable)res[idx].timetable=[];
  res[idx].timetable=[...(res[idx].timetable||[]),..._timetableEntries];
  if(!res[idx].reports)res[idx].reports=[];
  res[idx].reports.push({
    repTime:new Date().toISOString().slice(0,16).replace('T',' '),
    update:'타임테이블 업데이트: '+_timetableEntries.map(e=>e.stage+'('+e.time+')').join(' → '),
    victimChange:'변화없음',author:getAuthor(),isTimetable:true,
  });
  DB.s('rescues',res);
  closeM('modalTimetable');
  renderTimeline(res[idx],_tlViewMode||'brief');
  toast('✅ 타임테이블 저장');
}



// ══════════════════════════════════════════
// 추가 출동 인원 관리
// ══════════════════════════════════════════
let _extraDispatch = []; // [{name, type, note}]

function initExtraDispatch(prefill){
  _extraDispatch = (prefill&&prefill.extraMembers) ? [...prefill.extraMembers] : [];
  renderExtraDispatch();
}

function renderExtraDispatch(){
  const el = document.getElementById('extraDispatchList');
  if(!el) return;
  if(!_extraDispatch.length){
    el.innerHTML = '';
    return;
  }
  el.innerHTML = `
    <div style="font-size:10px;color:#4fa8d0;font-weight:700;margin:8px 0 5px;">추가 출동 인원</div>
    ${_extraDispatch.map((d,i)=>`
      <div style="display:flex;align-items:center;gap:8px;background:#060d1a;border-radius:7px;padding:7px 10px;margin-bottom:4px;border:1px solid rgba(79,168,208,.12);">
        <div style="flex:1;">
          <div style="font-size:12px;color:#e0edf8;font-weight:600;">${d.name}</div>
          <div style="font-size:10px;color:#4a7090;">${d.type}${d.note?' · '+d.note:''}</div>
        </div>
        <button onclick="removeExtraDispatch(${i})" style="background:none;border:none;color:#c0392b;font-size:14px;cursor:pointer;padding:2px 5px;">×</button>
      </div>`).join('')}`;
}


function confirmAddDispatch(){
  const name = document.getElementById('dispNameIn').value.trim();
  if(!name){ toast('⚠️ 이름/소속 입력'); return; }
  const type = getSelPills('dispTypePills')[0] || '기타';
  const note = document.getElementById('dispNoteIn').value.trim();
  _extraDispatch.push({name, type, note});
  renderExtraDispatch();
  closeM('modalAddDispatch');
  toast('✅ '+name+' 추가');
}

function removeExtraDispatch(i){
  _extraDispatch.splice(i,1);
  renderExtraDispatch();
}

// ══════════════════════════════════════════
// 타임라인 시간순 정렬 + 편집
// ══════════════════════════════════════════
let _ttInlineEntries = [];
let _ttInlineSelectedStage = '';
let _ttInlineFoundVictim = false;
// _ttInlineEntries 시간순 정렬
function sortTTByTime(entries){
  return [...entries].sort((a,b)=>{
    if(!a.time) return 1;
    if(!b.time) return -1;
    return a.time.localeCompare(b.time);
  });
}

// renderTTInline 교체: 편집 버튼 추가 + 시간순 정렬
function renderTTInline(){
  const listEl = document.getElementById('ttEntryList');
    if(!listEl) return;

  // 시간순 정렬 (원본 배열도 갱신)
  _ttInlineEntries = sortTTByTime(_ttInlineEntries);

  listEl.innerHTML = _ttInlineEntries.length
    ? _ttInlineEntries.map((e,i)=>`
      <div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:#060d1a;border-radius:8px;margin-bottom:5px;border:1px solid rgba(79,168,208,.12);">
        <div style="width:8px;height:8px;border-radius:50%;background:${
          e.stage==='요구조자 조우'?'#c0392b':
          e.stage==='처치완료'?'#27ae60':
          e.stage==='하산시작'?'#4fa8d0':'#4a7090'
        };flex-shrink:0;margin-top:2px;"></div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:700;color:#e0edf8;">${e.actor?`<span style="font-size:10px;color:#7ec8e3;font-weight:600;margin-right:5px;">[${e.actor}]</span>`:''}${e.stage}</div>
          <div style="font-size:10px;color:#4a7090;">${e.time||'시간미기재'}${e.note?' · '+e.note:''}</div>
        </div>
        <div style="display:flex;gap:4px;flex-shrink:0;">
          <button onclick="editTTInline(${i})" style="background:rgba(79,168,208,.08);border:1px solid rgba(79,168,208,.2);color:#4fa8d0;font-size:10px;padding:3px 8px;border-radius:5px;cursor:pointer;">✏️</button>
          <button onclick="removeTTInline(${i})" style="background:rgba(192,57,43,.12);border:1px solid rgba(192,57,43,.3);color:#e05050;font-size:13px;font-weight:700;width:36px;height:36px;flex-shrink:0;border-radius:8px;cursor:pointer;display:flex;align-items:center;justify-content:center;">✕</button>
        </div>
      </div>`).join('')
    : '<div style="font-size:11px;color:rgba(255,255,255,.25);padding:6px 0 10px;">아직 기록 없음 — 아래에서 단계 선택</div>';

}

// 편집: 해당 항목 데이터를 입력 영역에 채우고 인덱스 기억
let _editTTIdx = -1;
function editTTInline(i){
  _editTTIdx = i;
  _ttInlineSelectedStage = _ttInlineEntries[i].stage;
  const area  = document.getElementById('ttInputArea');
  const label = document.getElementById('ttInputLabel');
  const timeIn= document.getElementById('ttTimeIn');
  const noteIn= document.getElementById('ttNoteIn');
  if(area)  area.style.display='block';
  if(label) label.textContent='✏️ '+_ttInlineSelectedStage+' 수정';
  if(timeIn)timeIn.value = _ttInlineEntries[i].time
    ? _ttInlineEntries[i].time.replace(' ','T') : '';
  if(noteIn)noteIn.value = _ttInlineEntries[i].note||'';
  document.querySelectorAll('#ttActorPills .pill').forEach(p=>{
    p.classList.toggle('on', p.textContent===(_ttInlineEntries[i].actor||''));
  });
}

// confirmTTInline 재정의: 수정 or 신규 추가
function confirmTTInline(){
  const time = (document.getElementById('ttTimeIn')?.value||'').replace('T',' ')||now();
  const note = document.getElementById('ttNoteIn')?.value||'';
  // 직접입력이면 메모를 단계명으로
  let finalStage = _ttInlineSelectedStage==='직접입력' ? (note||'기타') : _ttInlineSelectedStage;
  let finalNote  = _ttInlineSelectedStage==='직접입력' ? '' : note;
  // 상황전파: 접수경로를 메모에 자동 포함
  if(_ttInlineSelectedStage==='상황전파'){
    const recv=document.getElementById('r_recv')?.value||'';
    if(recv) finalNote=(recv+(note?' · '+note:''));
  }
  let actor='';
  if(_ttInlineSelectedStage==='상황전파'){
    actor=(DB.g('currentUser')||{}).name||getAuthor()||'';
  } else {
    actor=[...document.querySelectorAll('#ttActorPills .pill.on')].map(p=>p.textContent).join(', ')||'';
  }
  if(_editTTIdx >= 0){
    _ttInlineEntries[_editTTIdx] = {stage: finalStage, time, note: finalNote, actor};
    _editTTIdx = -1;
    toast('✅ 수정 완료');
  } else {
    _ttInlineEntries.push({stage: finalStage, time, note: finalNote, actor});
    if(finalStage==='요구조자 조우') _ttInlineFoundVictim=true;
    toast('✅ '+finalStage+' 기록');
  }
  document.getElementById('ttInputArea').style.display='none';
  renderTTInline();
}

// selectTTInline: 신규 선택 시 editIdx 초기화
function selectTTInline(stage, pillEl){
  _editTTIdx = -1;
  _ttInlineSelectedStage = stage;
  // 선택된 stage pill 시각 표시
  document.querySelectorAll('.tt-stage-pill').forEach(p=>p.classList.remove('on'));
  if(pillEl) pillEl.classList.add('on');
  const area=document.getElementById('ttInputArea');
  const label=document.getElementById('ttInputLabel');
  const timeIn=document.getElementById('ttTimeIn');
  const noteIn=document.getElementById('ttNoteIn');
  const rw=document.getElementById('ttRecvWrap');
  const actorWrap=document.getElementById('ttActorWrap');
  if(!area) return;
  area.style.display='block';
  if(timeIn) timeIn.value=new Date().toISOString().slice(0,16);
  if(rw) rw.style.display=stage==='상황전파'?'block':'none';
  if(actorWrap) actorWrap.style.display=stage==='상황전파'?'none':'';
  if(stage==='직접입력'){
    if(label) label.innerHTML='✏️ 내용 직접 입력 <span style="font-size:10px;color:#7a9cb8;">(메모란에 입력)</span>';
    if(noteIn){noteIn.placeholder='예: 헬기구조완료, 주민신고접수 등';noteIn.focus();}
  } else {
    if(label) label.textContent='📍 '+stage+' 시간 입력';
    if(noteIn){noteIn.placeholder='지점명, 특이사항 등';noteIn.value='';}
  }
  // 누가 pills: 실제 선택된 대원 이름 기반으로 구성
  const actorPillsEl=document.getElementById('ttActorPills');
  if(actorPillsEl && stage!=='상황전파'){
    const staffList=typeof staff!=='undefined'?staff:[];
    const deptMap={};staffList.forEach(s=>{deptMap[s.name]=s.dept;});
    const mainNames=[...document.querySelectorAll('#memChkGrid .chk-item.on')].map(el=>{
      const t=el.querySelector('.chk-txt');return t?(t.childNodes[0]?.textContent||'').trim():'';
    }).filter(Boolean);
    const mainDepts=[...new Set(mainNames.map(n=>DEPT_SHORT[deptMap[n]]||deptMap[n]||'공단'))];
    const extraTeamNames=(_extraTeams||[]).filter(t=>t.members&&t.members.length>0).map(t=>t.teamName||'추가팀');
    const hwChecked=document.getElementById('agHwChk')?.classList.contains('on');
    const hwName=DB.g('extAgencyDisplayName')||'환동해 특수대응단';
    const agencyNames=(_fireAgencies||[]).filter(a=>a.name).map(a=>a.name);
    const allActors=['요구조자',...mainDepts,...extraTeamNames,...(hwChecked?[hwName]:[]),...agencyNames,'기타'];
    actorPillsEl.innerHTML=allActors.map(a=>`<div class="pill tt-actor-pill" onclick="selTTActor(this,'${a.replace(/'/g,"\\'")}') " style="cursor:pointer;font-size:11px;">${a}</div>`).join('');
    const autoActor=stage==='요구조자 조우'||stage==='처치중'||stage==='처치완료'?'요구조자':
      stage==='헬기이륙/출발'||stage==='헬기구조완료'?hwName:null;
    if(autoActor){
      document.querySelectorAll('#ttActorPills .pill').forEach(p=>{if(p.textContent===autoActor)p.classList.add('on');});
    }
  }
}

function removeTTInline(i){
  const e=_ttInlineEntries[i];
  if(e&&!confirm('"'+(e.stage||'기록')+'" 기록을 삭제할까요?'))return;
  _ttInlineEntries.splice(i,1);
  _ttInlineFoundVictim = _ttInlineEntries.some(e=>e.stage==='요구조자 조우');
  renderTTInline();
}

// ══════════════════════════════════════════
// 지도에서 위치 선택
// ══════════════════════════════════════════
let mapPicker=null;

function openMapPicker(){
  document.getElementById('modalMapPicker').classList.add('on');
  // 현재 GPS 입력값으로 초기 위치 결정
  const gpsVal=(document.getElementById('r_gps')?.value||'').split(',');
  const initLat=gpsVal.length===2&&!isNaN(parseFloat(gpsVal[0]))?parseFloat(gpsVal[0]):(window._lastCrosshairCoord?.lat??DC.lat);
  const initLng=gpsVal.length===2&&!isNaN(parseFloat(gpsVal[1]))?parseFloat(gpsVal[1]):(window._lastCrosshairCoord?.lng??DC.lng);
  setTimeout(()=>{
    if(!mapPicker){
      if(!window._KR){ toast('⚠️ 지도 로딩 중... 잠시 후 다시 시도'); return; }
      mapPicker=new kakao.maps.Map(document.getElementById('mapPicker'),{
        center:new kakao.maps.LatLng(initLat,initLng), level:5
      });
      mapPicker.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
      _addPickerSigns();
      var _pickerTimer=null;
      kakao.maps.event.addListener(mapPicker,'center_changed',function(){
        const c=mapPicker.getCenter();
        const coordEl=document.getElementById('pickerCoords');
        if(coordEl) coordEl.textContent=c.getLat().toFixed(5)+', '+c.getLng().toFixed(5);
        clearTimeout(_pickerTimer);
        _pickerTimer=setTimeout(function(){_updateZoneBadge(c.getLat(),c.getLng(),'pickerZoneBadge');},300);
      });
    } else {
      mapPicker.relayout();
      mapPicker.setCenter(new kakao.maps.LatLng(initLat,initLng));
      _addPickerSigns(); // 처음 열 때 시설물이 아직 로딩 전이었을 수 있음
    }
    // 초기 좌표·Zone 뱃지 표시
    const coordEl=document.getElementById('pickerCoords');
    if(coordEl) coordEl.textContent=initLat.toFixed(5)+', '+initLng.toFixed(5);
    _updateZoneBadge(initLat,initLng,'pickerZoneBadge');
  },200);
}

// 위치 선택 지도에 다목적위치표지판 번호 라벨 추가 (1회)
let _pickerSignsAdded=false;
function _addPickerSigns(){
  if(_pickerSignsAdded||!mapPicker)return;
  const signs=(DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판')&&f.lat&&f.lng);
  if(!signs.length)return;
  signs.forEach(f=>{
    const m=(f.name||'').match(/^\d{1,2}-\d{1,3}/);
    const code=m?m[0]:(f.name||'').slice(0,5);
    const el=document.createElement('div');
    el.style.cssText='background:rgba(8,18,36,.82);border:1px solid rgba(125,211,250,.4);border-radius:5px;padding:1px 4px;font-size:9px;font-weight:700;color:#7dd3fa;font-family:monospace;pointer-events:none;white-space:nowrap;';
    el.textContent=code;
    new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(f.lat,f.lng),content:el,zIndex:2}).setMap(mapPicker);
  });
  _pickerSignsAdded=true;
}

function confirmMapPicker(){
  if(!mapPicker){ toast('⚠️ 지도 로딩 필요'); return; }
  const center=mapPicker.getCenter();
  const lat=center.getLat(),lng=center.getLng();
  const coords=lat.toFixed(5)+', '+lng.toFixed(5);
  const gpsEl=document.getElementById('r_gps');
  if(gpsEl) gpsEl.value=coords;
  syncFormMapFromInput();
  _updateFormMiniMap(lat,lng);
  // 사고 장소: 가장 가까운 표지판 번호를 최우선 자동입력
  const locEl=document.getElementById('r_loc');
  if(locEl&&!locEl.value.trim()&&!locEl.dataset.userEdited){
    const s=_nearestSignFull(lat,lng);
    if(s){
      const base=getBaseForSign(s.code);
      const bName=base?((SEORAK_BASES[base.primary]||{}).name||'').replace('탐방지원센터','센터'):'';
      locEl.value=s.code+(s.zoneName?' ('+s.zoneName+')':'')+(bName?' → '+bName:'');
      autoGenTitle();
    }
  }
  closeM('modalMapPicker');
  toast('📍 위치 선택 완료');
}

// ══════════════════════════════════════════
// 사고 제목 자동생성
// ══════════════════════════════════════════
function autoGenTitle(returnOnly=false){
  const loc   = (document.getElementById('r_loc')?.value||'').trim();
  const sev   = getSelPills('sevPills')[0]||'';
  const cause = document.getElementById('r_cause')?.value||'';
  const type  = document.getElementById('r_type')?.value||'안전사고';
  const nation= document.getElementById('r_vNat')?.value||'알수없음';
  const gender= document.getElementById('r_vGender')?.value||'';
  // 부상 내역 요약: 부상현황 목록 → 부상부위/유형 필 순으로 탐색
  let injStr='';
  if(typeof _injuries!=='undefined'&&_injuries.length){
    const i0=_injuries[0];
    injStr=((i0.side&&i0.side!=='해당없음'?i0.side+' ':'')+(i0.part||'')+' '+(i0.type||'')).trim();
    if(_injuries.length>1)injStr+=' 외 '+(_injuries.length-1);
  }
  if(!injStr){
    const ip=getSelPills('injParts')[0]||'',it=getSelPills('injTypes')[0]||'';
    injStr=(ip+' '+it).trim();
  }
  const parts=[];
  if(loc)     parts.push(loc.slice(0,12)+(loc.length>12?'...':''));
  if(type!=='안전사고') parts.push(type);
  if(injStr)  parts.push(injStr);
  else if(cause&&cause!=='실족') parts.push(cause);
  if(sev)     parts.push('KTAS'+sev.replace('KTAS ','').split('(')[0].trim());
  if(nation==='외국인'){
    const gLabel=(gender&&gender!=='알수없음')?'('+gender+')':'';
    parts.push('외국인'+gLabel);
  }
  const title=parts.join(' · ')||today()+' '+type;
  if(returnOnly) return title;
  const el=document.getElementById('r_title');
  if(el&&(!el.dataset.userEdited)){
    el.value=title;
  }
  return title;
}
// 사용자가 직접 수정 시 자동생성 중단
document.addEventListener('input',e=>{
  if(e.target.id==='r_title') e.target.dataset.userEdited='1';
});


// ══════════════════════════════════════════
// 🆘 조난자 위치 전송 (로그인 불필요 · 공개 URL ?sos=1)
// ══════════════════════════════════════════
let _sosDb=null,_sosId=null,_sosWatch=null,_sosLast=null,_sosCount=0;
// 다국어(10): 한국어·영어·중국어·일본어·베트남어·태국어·러시아어·스페인어·프랑스어·독일어
const _SOS_LANGS=[['ko','한국어'],['en','English'],['zh','中文'],['ja','日本語'],['vi','Tiếng Việt'],['th','ไทย'],['ru','Русский'],['es','Español'],['fr','Français'],['de','Deutsch']];
const _SOS_LABEL={ko:'한국어',en:'영어',zh:'중국어',ja:'일본어',vi:'베트남어',th:'태국어',ru:'러시아어',es:'스페인어',fr:'프랑스어',de:'독일어'};
const _SOS_T={
  ko:{org:'설악산 국립공원 구조대',sub:'이 화면을 켠 채로 두면<br>구조대가 당신의 위치를 실시간으로 받습니다',perm:'위치 권한을 허용해 주세요',locating:'위치 확인 중…',recv:'구조대가 위치를 받고 있습니다',block:'전송이 막혔습니다 — 신호 잡히면 자동 재시도',start:'📍 내 위치 전송 시작',retry:'📍 다시 시도',info:'구조대에 전할 정보 (선택)',name:'이름',msg:'상태·부상·주변 지형 등',country:'국적 (예: 대한민국)',tip:'화면을 켜 두고 안전한 곳에서 기다리세요.<br>구조대가 출동합니다.',fail:'전송 실패 — 아래 좌표를 복사해, 링크를 보낸 번호로 문자 회신해 주세요',copy:'📋 좌표 복사'},
  en:{org:'Seoraksan Nat’l Park Rescue',sub:'Keep this screen on.<br>The rescue team receives your location in real time.',perm:'Please allow location access',locating:'Getting your location…',recv:'The rescue team is receiving your location',block:'Sending blocked — will retry when signal returns',start:'📍 Send my location',retry:'📍 Try again',info:'Info for the rescue team (optional)',name:'Name',msg:'Condition, injury, surroundings…',country:'Country',tip:'Keep the screen on and wait in a safe place.<br>The rescue team is coming.',fail:'Send failed — copy the coordinates below and text them to the number that sent you this link',copy:'📋 Copy coordinates'},
  zh:{org:'雪岳山国立公园救援队',sub:'请保持此屏幕开启，<br>救援队正在实时接收您的位置。',perm:'请允许获取位置权限',locating:'正在获取位置…',recv:'救援队正在接收您的位置',block:'发送受阻 — 有信号时将自动重试',start:'📍 发送我的位置',retry:'📍 重试',info:'提供给救援队的信息（可选）',name:'姓名',msg:'状态、受伤、周围地形等',country:'国家',tip:'请保持屏幕开启并在安全处等待。<br>救援队正在赶来。',fail:'发送失败 — 请复制下方坐标，并短信发送给给您链接的号码',copy:'📋 复制坐标'},
  ja:{org:'雪岳山国立公園 救助隊',sub:'この画面をつけたままにしてください。<br>救助隊が位置をリアルタイムで受信します。',perm:'位置情報の許可をお願いします',locating:'位置を確認中…',recv:'救助隊が位置を受信しています',block:'送信がブロックされました — 電波が入ると自動で再試行',start:'📍 自分の位置を送信',retry:'📍 再試行',info:'救助隊への情報（任意）',name:'名前',msg:'状態・けが・周囲の地形など',country:'国籍',tip:'画面をつけたまま安全な場所でお待ちください。<br>救助隊が向かっています。',fail:'送信失敗 — 下の座標をコピーし、リンクを送った番号にSMSで返信してください',copy:'📋 座標をコピー'},
  vi:{org:'Cứu hộ Vườn QG Seoraksan',sub:'Giữ màn hình này bật.<br>Đội cứu hộ đang nhận vị trí của bạn theo thời gian thực.',perm:'Vui lòng cho phép truy cập vị trí',locating:'Đang xác định vị trí…',recv:'Đội cứu hộ đang nhận vị trí của bạn',block:'Bị chặn gửi — sẽ thử lại khi có sóng',start:'📍 Gửi vị trí của tôi',retry:'📍 Thử lại',info:'Thông tin cho đội cứu hộ (tùy chọn)',name:'Tên',msg:'Tình trạng, chấn thương, địa hình…',country:'Quốc gia',tip:'Giữ màn hình bật và chờ ở nơi an toàn.<br>Đội cứu hộ đang đến.',fail:'Gửi thất bại — sao chép tọa độ bên dưới và nhắn tin tới số đã gửi liên kết',copy:'📋 Sao chép tọa độ'},
  th:{org:'หน่วยกู้ภัยอุทยานซอรัคซาน',sub:'เปิดหน้าจอนี้ไว้<br>ทีมกู้ภัยกำลังรับตำแหน่งของคุณแบบเรียลไทม์',perm:'โปรดอนุญาตการเข้าถึงตำแหน่ง',locating:'กำลังหาตำแหน่ง…',recv:'ทีมกู้ภัยกำลังรับตำแหน่งของคุณ',block:'การส่งถูกบล็อก — จะลองใหม่เมื่อมีสัญญาณ',start:'📍 ส่งตำแหน่งของฉัน',retry:'📍 ลองอีกครั้ง',info:'ข้อมูลสำหรับทีมกู้ภัย (ไม่บังคับ)',name:'ชื่อ',msg:'อาการ บาดเจ็บ ภูมิประเทศ',country:'ประเทศ',tip:'เปิดหน้าจอไว้และรอในที่ปลอดภัย<br>ทีมกู้ภัยกำลังไป',fail:'ส่งไม่สำเร็จ — คัดลอกพิกัดด้านล่างแล้วส่ง SMS ไปยังเบอร์ที่ส่งลิงก์ให้คุณ',copy:'📋 คัดลอกพิกัด'},
  ru:{org:'Спасатели нацпарка Сораксан',sub:'Не выключайте экран.<br>Спасатели получают вашу геолокацию в реальном времени.',perm:'Разрешите доступ к геолокации',locating:'Определение местоположения…',recv:'Спасатели получают ваше местоположение',block:'Отправка заблокирована — повтор при сигнале',start:'📍 Отправить геолокацию',retry:'📍 Повторить',info:'Информация для спасателей (необязательно)',name:'Имя',msg:'Состояние, травмы, местность…',country:'Страна',tip:'Не выключайте экран и ждите в безопасном месте.<br>Спасатели уже в пути.',fail:'Сбой отправки — скопируйте координаты ниже и отправьте SMS на номер, приславший ссылку',copy:'📋 Копировать координаты'},
  es:{org:'Rescate Parque Nac. Seoraksan',sub:'Mantén esta pantalla encendida.<br>El equipo de rescate recibe tu ubicación en tiempo real.',perm:'Permite el acceso a la ubicación',locating:'Obteniendo tu ubicación…',recv:'El equipo de rescate recibe tu ubicación',block:'Envío bloqueado: reintento al haber señal',start:'📍 Enviar mi ubicación',retry:'📍 Reintentar',info:'Información para el rescate (opcional)',name:'Nombre',msg:'Estado, lesión, entorno…',country:'País',tip:'Mantén la pantalla encendida y espera en lugar seguro.<br>El rescate va en camino.',fail:'Error de envío — copia las coordenadas y envíalas por SMS al número que te dio el enlace',copy:'📋 Copiar coordenadas'},
  fr:{org:'Secours Parc Nat. Seoraksan',sub:'Gardez cet écran allumé.<br>L’équipe de secours reçoit votre position en temps réel.',perm:'Autorisez l’accès à la localisation',locating:'Localisation en cours…',recv:'L’équipe de secours reçoit votre position',block:'Envoi bloqué — nouvelle tentative au signal',start:'📍 Envoyer ma position',retry:'📍 Réessayer',info:'Infos pour les secours (facultatif)',name:'Nom',msg:'État, blessure, environnement…',country:'Pays',tip:'Gardez l’écran allumé et attendez en lieu sûr.<br>Les secours arrivent.',fail:'Échec d’envoi — copiez les coordonnées et envoyez-les par SMS au numéro qui vous a envoyé le lien',copy:'📋 Copier les coordonnées'},
  de:{org:'Bergrettung NP Seoraksan',sub:'Lassen Sie diesen Bildschirm an.<br>Das Rettungsteam empfängt Ihren Standort in Echtzeit.',perm:'Bitte Standortzugriff erlauben',locating:'Standort wird ermittelt…',recv:'Das Rettungsteam empfängt Ihren Standort',block:'Senden blockiert — erneuter Versuch bei Signal',start:'📍 Meinen Standort senden',retry:'📍 Erneut versuchen',info:'Infos für die Rettung (optional)',name:'Name',msg:'Zustand, Verletzung, Umgebung…',country:'Land',tip:'Bildschirm anlassen und an sicherem Ort warten.<br>Die Rettung kommt.',fail:'Senden fehlgeschlagen — Koordinaten kopieren und per SMS an die Nummer senden, die den Link geschickt hat',copy:'📋 Koordinaten kopieren'}
};
let _sosLang='ko';
function _st(k){return (_SOS_T[_sosLang]||_SOS_T.en)[k]||_SOS_T.en[k]||k;}
function _sosBuildUI(){
  const wrap=document.getElementById('sosVictim');if(!wrap)return;
  const _nm=(document.getElementById('sosName')||{}).value||'';
  const _mg=(document.getElementById('sosMsg')||{}).value||'';
  const _ct=(document.getElementById('sosCountry')||{}).value||'';
  const langBtns=_SOS_LANGS.map(([c,n])=>`<button onclick="_sosSetLang('${c}')" style="flex:0 0 auto;background:${_sosLang===c?'#c0392b':'rgba(255,255,255,.08)'};color:#fff;border:1px solid ${_sosLang===c?'#ffe14d':'rgba(255,255,255,.15)'};border-radius:14px;padding:5px 11px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap;">${n}</button>`).join('');
  wrap.innerHTML=`
    <div style="display:flex;gap:6px;overflow-x:auto;width:100%;max-width:440px;padding-bottom:5px;margin-bottom:2px;-webkit-overflow-scrolling:touch;">${langBtns}</div>
    <div style="font-size:34px;margin-top:2px;">🆘</div>
    <div style="font-size:19px;font-weight:800;margin-top:6px;text-align:center;">${_st('org')}</div>
    <div style="font-size:13px;color:#8ab4cc;margin-top:3px;text-align:center;line-height:1.6;">${_st('sub')}</div>
    <div id="sosStatus" style="margin-top:16px;width:100%;max-width:420px;background:#11233a;border:1.5px solid rgba(231,76,60,.5);border-radius:14px;padding:16px;text-align:center;">
      <div id="sosStatusIco" style="font-size:30px;">📡</div>
      <div id="sosStatusTxt" style="font-size:15px;font-weight:700;margin-top:6px;color:#ffd9d0;">${_st('perm')}</div>
      <div id="sosCoords" style="font-size:12px;color:#9bbdd4;margin-top:8px;font-family:monospace;line-height:1.7;"></div>
    </div>
    <button id="sosStartBtn" onclick="_sosRequest()" style="margin-top:14px;width:100%;max-width:420px;padding:18px;border:none;border-radius:14px;background:linear-gradient(180deg,#e74c3c,#c0392b);color:#fff;font-size:18px;font-weight:800;cursor:pointer;box-shadow:0 4px 14px rgba(192,57,43,.5);">${_st('start')}</button>
    <div style="margin-top:16px;width:100%;max-width:420px;">
      <div style="font-size:12px;color:#8ab4cc;font-weight:700;margin-bottom:6px;">${_st('info')}</div>
      <input id="sosName" placeholder="${_st('name')}" value="${_esc(_nm)}" oninput="_sosPushInfo()" style="width:100%;box-sizing:border-box;background:#0b1c30;border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:9px;padding:12px;font-size:15px;margin-bottom:7px;">
      ${_sosLang!=='ko'?`<input id="sosCountry" placeholder="${_st('country')}" value="${_esc(_ct)}" oninput="_sosPushInfo()" style="width:100%;box-sizing:border-box;background:#0b1c30;border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:9px;padding:12px;font-size:15px;margin-bottom:7px;">`:''}
      <textarea id="sosMsg" placeholder="${_st('msg')}" oninput="_sosPushInfo()" rows="3" style="width:100%;box-sizing:border-box;background:#0b1c30;border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:9px;padding:12px;font-size:15px;resize:vertical;">${_esc(_mg)}</textarea>
    </div>
    <div id="sosTip" style="margin-top:16px;font-size:12px;color:#5a7e98;text-align:center;line-height:1.6;max-width:420px;">${_st('tip')}</div>`;
  _sosRefreshStatus();
}
function _sosRefreshStatus(){
  const btn=document.getElementById('sosStartBtn');
  if(_sosLast){ // 이미 위치 수신 중 → 좌표 유지, 시작버튼 숨김 (언어 바꿔도 끊김 없음)
    _sosSet('✅',_st('recv'),'#7ee0a0');
    if(btn)btn.style.display='none';
    const c=document.getElementById('sosCoords');
    if(c)c.innerHTML=_sosLast.lat.toFixed(6)+', '+_sosLast.lng.toFixed(6)+'<br>±'+_sosLast.acc+'m';
  }else if(_sosWatch!=null){_sosSet('📡',_st('locating'),'#ffd9d0');if(btn)btn.style.display='none';}
  else{_sosSet('📡',_st('perm'),'#ffd9d0');if(btn)btn.style.display='block';}
}
function _sosSetLang(l){_sosLang=l;try{localStorage.setItem('_sosLang',l);}catch(e){}_sosBuildUI();if(_sosLast)_sosWrite(true);} // 언어 즉시 반영 + 팀에 lang 전달
function _bootSos(){
  ['loadingScreen','loginScreen','approvalGate'].forEach(id=>{const e=document.getElementById(id);if(e)e.remove();});
  try{if(window._safeLoadingTimer)clearTimeout(window._safeLoadingTimer);clearInterval(window._loadTipTimer);clearInterval(window._loadBarTimer);}catch(e){}
  // 링크 토큰(?sos=<token>)을 문서 ID로 — 팀 발급(active:true) 링크만 표시됨
  var _tok=((new URLSearchParams(location.search).get('sos'))||'').trim();
  if(/^[a-z0-9]{4,12}$/i.test(_tok))_sosId=_tok;
  else _sosId='x'+Math.random().toString(36).slice(2,8);
  // 언어 자동 감지(저장값 우선)
  try{var sv=localStorage.getItem('_sosLang');if(sv&&_SOS_T[sv])_sosLang=sv;else{var nl=(navigator.language||'ko').slice(0,2).toLowerCase();if(_SOS_T[nl])_sosLang=nl;}}catch(e){}
  const wrap=document.createElement('div');
  wrap.id='sosVictim';
  wrap.style.cssText='position:fixed;inset:0;z-index:99999;background:#0a1320;color:#e0edf8;display:flex;flex-direction:column;align-items:center;padding:18px;overflow-y:auto;font-family:inherit;-webkit-text-size-adjust:100%;';
  document.body.innerHTML='';document.body.appendChild(wrap);
  _sosBuildUI();
  document.title='🆘 SOS — 설악산 구조대';
  try{ if(!firebase.apps.length) firebase.initializeApp(_FB_CFG); }catch(e){}
  try{
    _sosDb=firebase.firestore();
    firebase.auth().signInAnonymously().catch(()=>{});
    firebase.auth().onAuthStateChanged(function(u){ if(u){ _sosAuthed=true; _sosRequest(); if(_sosLast)_sosWrite(); } });
  }catch(e){}
  setTimeout(_sosRequest,400);
}
let _sosAuthed=false;
function _sosSet(ico,txt,col){
  const i=document.getElementById('sosStatusIco'),t=document.getElementById('sosStatusTxt'),b=document.getElementById('sosStatus');
  if(i)i.textContent=ico;if(t){t.textContent=txt;if(col)t.style.color=col;}
  if(b&&col==='#7ee0a0')b.style.borderColor='rgba(46,204,113,.6)';
}
let _sosHeartbeat=null;
function _sosRequest(){
  if(!navigator.geolocation){_sosSet('⚠️',_st('block'),'#ffd9d0');return;}
  // 하트비트: 가만히 있어 watchPosition이 안 울려도 20초마다 강제 재전송(연결 유지)
  if(!_sosHeartbeat)_sosHeartbeat=setInterval(function(){if(_sosLast)_sosWrite(true);},20000);
  if(_sosWatch!=null)return; // 이미 추적 중
  _sosSet('📡',_st('locating'),'#ffd9d0');
  _sosWatch=navigator.geolocation.watchPosition(_sosOnPos,_sosOnErr,{enableHighAccuracy:true,timeout:20000,maximumAge:2000});
}
function _sosOnPos(pos){
  const lat=pos.coords.latitude,lng=pos.coords.longitude,acc=Math.round(pos.coords.accuracy||0);
  _sosLast={lat,lng,acc};
  const btn=document.getElementById('sosStartBtn');if(btn)btn.style.display='none';
  _sosSet('✅',_st('recv'),'#7ee0a0');
  const c=document.getElementById('sosCoords');
  if(c)c.innerHTML=`${lat.toFixed(6)}, ${lng.toFixed(6)}<br>±${acc}m`;
  _sosWrite();
}
function _sosOnErr(e){
  _sosWatch=null;
  _sosSet('⚠️',_st('block'),'#ffd9d0');
  const btn=document.getElementById('sosStartBtn');if(btn){btn.style.display='block';btn.textContent=_st('retry');}
}
let _sosLastWriteTs=0,_sosLastWritePos=null;
function _sosWrite(force){
  if(!_sosDb||!_sosLast)return; // 인증 여부와 무관하게 전송 시도(규칙이 sos 공개 허용)
  // 데이터 절약: 최소 15초 간격 또는 25m 이상 이동 시에만 전송 (force=이름/메모 입력 즉시 반영)
  const nowMs=Date.now();
  if(!force&&_sosLastWriteTs){
    const dt=nowMs-_sosLastWriteTs;
    let moved=999;try{if(_sosLastWritePos)moved=_haversineKm(_sosLastWritePos.lat,_sosLastWritePos.lng,_sosLast.lat,_sosLast.lng)*1000;}catch(e){}
    if(dt<15000&&moved<25)return;
  }
  // 데이터 최소화: 좌표 소수 5자리(약 1m), ua·at 제거(at는 ts로 대체), 빈 값·한국어 lang 생략
  const name=String((document.getElementById('sosName')||{}).value||'').slice(0,40);
  const msg=String((document.getElementById('sosMsg')||{}).value||'').slice(0,250);
  const country=String((document.getElementById('sosCountry')||{}).value||'').slice(0,30);
  const rec={id:_sosId,lat:+_sosLast.lat.toFixed(5),lng:+_sosLast.lng.toFixed(5),acc:Math.round(_sosLast.acc),ts:nowMs};
  if(name)rec.name=name;
  if(msg)rec.msg=msg;
  if(_sosLang!=='ko'){rec.lang=_sosLang;if(country)rec.country=country;} // 외국어 → 언어 계열 전달
  _sosLastWriteTs=nowMs;_sosLastWritePos={lat:_sosLast.lat,lng:_sosLast.lng};
  _sosDb.collection('sos').doc(_sosId).set(rec,{merge:true}).then(function(){
    _sosCount++;
    _sosSet('✅',_st('recv'),'#7ee0a0');
    const c=document.getElementById('sosCoords');
    if(c)c.innerHTML=_sosLast.lat.toFixed(6)+', '+_sosLast.lng.toFixed(6)+'<br>±'+Math.round(_sosLast.acc)+'m · ✓'+_sosCount;
  }).catch(function(e){
    // 전송 실패 → 좌표 복사 후 회신 안내 (데이터 안 터질 때 최후 수단)
    _sosSet('⚠️',_st('block'),'#ffd9d0');
    const c=document.getElementById('sosCoords');
    const co=_sosLast.lat.toFixed(5)+', '+_sosLast.lng.toFixed(5);
    if(c)c.innerHTML='<div style="color:#ffd24d;font-weight:700;margin-bottom:6px;line-height:1.5;">'+_st('fail')+'</div>'
      +'<div style="font-size:16px;color:#fff;font-weight:800;letter-spacing:.5px;">'+co+'</div>'
      +'<button onclick="_sosCopyCoords(\''+co+'\')" style="margin-top:8px;background:#1a4a6e;color:#fff;border:none;border-radius:8px;padding:10px 16px;font-size:14px;font-weight:700;cursor:pointer;">'+_st('copy')+'</button>';
    _sosLastWriteTs=0; // 다음 기회에 즉시 재시도
  });
}
function _sosCopyCoords(co){
  if(navigator.clipboard)navigator.clipboard.writeText(co).then(function(){toast('📋 '+co);}).catch(function(){_sosSmsFallback(co);});
  else _sosSmsFallback(co);
}
function _sosSmsFallback(co){try{location.href='sms:?body='+encodeURIComponent('SOS '+co);}catch(e){}}
let _sosInfoTimer=null;
function _sosPushInfo(){clearTimeout(_sosInfoTimer);_sosInfoTimer=setTimeout(()=>_sosWrite(true),600);}

// ── 구조대 측: 조난·사고자 위치 실시간 구독 (1회용 토큰: 팀이 발급한 active 링크만 표시) ──
let _sosPings=[];                              // 활성(active) 발급 토큰 전체(위치 있든 없든)
function _sosLocated(){return (_sosPings||[]).filter(p=>p.lat&&p.lng);} // 실제 위치 수신된 건
function _initSosWatch(){
  if(!_fdb||window._sosWatchBound)return;
  window._sosWatchBound=true;
  try{
    _fdb.collection('sos').onSnapshot(function(snap){
      // 팀이 발급(active:true)했고 48시간 이내인 것만 — 밤샘·다일 구조 커버, 옛 링크 자동 무효
      _sosPings=DB.g('sosBlocked')?[]:snap.docs.map(d=>d.data()).filter(p=>p&&p.active===true&&Date.now()-(p.issuedAt||p.ts||0)<48*3600000);
      // 위치가 새로 수신된 조난자 알림(최초 스냅샷·미수신 토큰은 제외)
      const seen=window._sosSeen||(window._sosSeen={});
      _sosPings.forEach(p=>{
        if(p.lat&&p.lng&&!seen[p.id]){seen[p.id]=1;
          if(window._sosInited){try{toast('🆘 조난·사고자 위치 수신: '+(p.name||'익명')+(p.acc?' (±'+p.acc+'m)':''),6000);}catch(e){}try{pushNoti('🆘 조난·사고자 위치 수신'+(p.name?': '+p.name:''),'🆘','sos',{app:'rescue',tab:1});}catch(e){}}
        }
      });
      window._sosInited=true;
      try{_drawSosPins();}catch(e){}
      try{_updateSosFab();}catch(e){}
      try{const bv=document.getElementById('v-board');if(bv&&bv.classList.contains('on')&&_boardMap)_renderBoardPins(false);}catch(e){}
      const ids=_sosLocated().map(p=>p.id).sort().join(',');
      if(ids!==window._sosIdSig){
        window._sosIdSig=ids;
        clearTimeout(window._sosRefreshT);
        window._sosRefreshT=setTimeout(function(){
          try{
            if(window.curApp==='rescue'){
              const mv=document.getElementById('v-rescue-map');
              if(mv&&mv.classList.contains('on')){try{renderRescueMap();}catch(e){}}
              try{renderResList();}catch(e){}
            }
            const bv=document.getElementById('v-board');
            if(bv&&bv.classList.contains('on')&&_boardMap){try{_renderBoardPins(false);}catch(e){}}
          }catch(e){}
        },350);
      }
    },function(err){try{_logErr&&_logErr('sos listen: '+(err&&err.message||err));}catch(e){}});
  }catch(e){}
}
function _sosBadgeCount(){return _sosLocated().length;}
function _updateSosFab(){
  const b=document.getElementById('sosReqBtn');if(!b)return;
  const n=_sosBadgeCount();
  b.innerHTML='🆘 조난·사고자'+(n?' <span style="background:#fff;color:#c0392b;border-radius:50%;padding:0 5px;font-weight:800;">'+n+'</span>':' 위치요청');
  b.style.background=n?'rgba(192,57,43,.95)':'rgba(192,57,43,.6)';
}
function _sosVictimUrl(tok){return location.origin+location.pathname+'?sos='+tok;}
// 새 1회용 링크 발급 (토큰 생성 → active:true 문서 생성)
function _sosNewLink(){
  if(!_fdb){toast('연결 준비 중 — 잠시 후 다시');return;}
  if(DB.g('sosBlocked')){toast('⚠️ 조난 접수가 차단되어 있습니다 (관리자 → 시스템에서 해제)');return;}
  const tok=Math.random().toString(36).slice(2,7); // 5자리 토큰
  const by=(typeof getAuthor==='function')?getAuthor():'구조대';
  _fdb.collection('sos').doc(tok).set({id:tok,active:true,issuedAt:Date.now(),by:by},{merge:true})
    .then(function(){toast('🔗 1회용 링크 생성됨 — 조난자에게 보내세요',5000);openSosRequest();if(navigator.share)_sosShareUrl(tok);})
    .catch(function(e){toast('생성 실패: '+(e&&(e.code||e.message)||''));});
}
// 접수 종료 (active:false → 그 링크로는 더 이상 수신 안 됨, 기록은 남음)
function _sosCloseToken(id){
  if(!confirm('이 1회용 링크를 종료할까요?\n종료하면 해당 링크로는 더 이상 위치가 들어오지 않습니다.'))return;
  if(_fdb)_fdb.collection('sos').doc(id).set({active:false,closedAt:Date.now()},{merge:true}).catch(()=>{});
  _sosPings=(_sosPings||[]).filter(p=>p.id!==id);
  try{_drawSosPins();_updateSosFab();}catch(e){}
  if(document.getElementById('sosModal'))openSosRequest();
  toast('✅ 접수 종료 — 링크 비활성화됨');
}
function openSosRequest(){
  const toks=(_sosPings||[]).slice().sort((a,b)=>(b.issuedAt||0)-(a.issuedAt||0));
  const cards=toks.map(p=>{
    const url=_sosVictimUrl(p.id);
    const has=p.lat&&p.lng;
    const mm=p.ts?Math.round((Date.now()-(p.ts||0))/60000):null;
    const status=has
      ? `<span style="color:#3ad17a;font-weight:800;">🟢 위치 수신 ±${p.acc||'?'}m</span> <span style="color:#8ab4cc;font-size:10px;">${mm}분 전</span>`
      : `<span style="color:#ffd24d;font-weight:700;">⚪ 전송 대기 중</span>`;
    return `<div style="background:#0b1c30;border:1px solid ${has?'rgba(231,76,60,.4)':'rgba(255,255,255,.12)'};border-radius:11px;padding:11px 12px;margin-bottom:8px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <span style="font-size:12px;">${status}</span>
        <span style="font-size:9px;color:#5a7e98;font-family:monospace;">🔗 1회용 · ${p.id}</span>
      </div>
      ${has?`<div onclick="_sosFocus('${p.id}')" style="cursor:pointer;margin-bottom:7px;">
        <div style="font-size:13px;font-weight:800;color:#ff8a73;">🆘 ${_esc(p.name||'익명')}</div>
        ${_sosForeignBadge(p)?`<div style="margin-top:3px;">${_sosForeignBadge(p)}</div>`:''}
        ${p.msg?`<div style="font-size:12px;color:#cfe2f2;margin-top:2px;">${_esc(p.msg)}</div>`:''}
        <div style="font-size:10px;color:#5a7e98;font-family:monospace;margin-top:2px;">${(+p.lat).toFixed(5)}, ${(+p.lng).toFixed(5)} · 탭하면 지도 이동</div>
      </div>`:''}
      <div style="display:flex;gap:5px;margin-bottom:6px;">
        <input readonly value="${url}" onclick="this.select()" style="flex:1;min-width:0;background:#060d1a;border:1px solid rgba(79,168,208,.3);color:#7dd3fa;border-radius:7px;padding:8px;font-size:11px;font-family:monospace;">
        <button onclick="_sosCopyUrl('${p.id}')" style="flex-shrink:0;background:#1a4a6e;color:#fff;border:none;border-radius:7px;padding:0 11px;font-size:12px;font-weight:700;cursor:pointer;">복사</button>
      </div>
      <div style="display:flex;gap:5px;">
        ${navigator.share?`<button onclick="_sosShareUrl('${p.id}')" style="flex:1;background:rgba(39,174,96,.12);color:#27ae60;border:1px solid rgba(39,174,96,.35);border-radius:7px;padding:8px;font-size:12px;font-weight:700;cursor:pointer;">📤 보내기</button>`:`<button onclick="_sosSms('${p.id}')" style="flex:1;background:rgba(79,168,208,.1);color:#4fa8d0;border:1px solid rgba(79,168,208,.3);border-radius:7px;padding:8px;font-size:12px;font-weight:700;cursor:pointer;">✉️ 문자</button>`}
        ${has?`<button onclick="sosToRescue('${p.id}')" style="flex:1;background:rgba(231,76,60,.15);color:#ff6b5e;border:1px solid rgba(231,76,60,.4);border-radius:7px;padding:8px;font-size:12px;font-weight:700;cursor:pointer;">🚨 구조등록</button>`:''}
        <button onclick="_sosCloseToken('${p.id}')" style="flex-shrink:0;background:rgba(192,57,43,.1);color:#c0392b;border:1px solid rgba(192,57,43,.3);border-radius:7px;padding:8px 11px;font-size:12px;font-weight:700;cursor:pointer;">종료</button>
      </div>
    </div>`;
  }).join('');
  const html=`
    <div style="background:rgba(241,196,15,.08);border:1px solid rgba(241,196,15,.25);border-radius:9px;padding:9px 11px;margin-bottom:10px;font-size:12px;color:#e8c84a;line-height:1.5;">
      🔗 <b>1회용 링크</b>입니다. 조난·사고자마다 새로 발급해 보내세요.<br>
      <span style="color:#9bbdd4;">구조가 끝나면 <b style="color:#ff8a73;">접수 종료</b>를 누르면 그 링크는 비활성화됩니다. (보내지 않아도 48시간 후 자동 만료)</span>
    </div>
    <button onclick="_sosNewLink()" style="width:100%;padding:14px;border-radius:11px;border:none;background:linear-gradient(180deg,#e74c3c,#c0392b);color:#fff;font-size:15px;font-weight:800;cursor:pointer;box-shadow:0 3px 10px rgba(192,57,43,.4);margin-bottom:12px;">➕ 새 1회용 링크 만들기</button>
    ${toks.length?cards:'<div style="font-size:12px;color:rgba(255,255,255,.35);padding:6px 0;text-align:center;">발급된 링크가 없습니다. 위 버튼으로 새 링크를 만드세요.</div>'}`;
  _sosModal('🆘 조난·사고자 위치요청 (1회용 링크)',html);
}
function _sosModal(title,html){
  let m=document.getElementById('sosModal');
  if(!m){m=document.createElement('div');m.id='sosModal';document.body.appendChild(m);}
  m.style.cssText='position:fixed;inset:0;z-index:9000;background:rgba(0,0,0,.6);display:flex;align-items:flex-end;justify-content:center;';
  m.innerHTML=`<div style="background:#0a1828;width:100%;max-width:480px;max-height:85vh;overflow-y:auto;border-radius:14px 14px 0 0;padding:16px 16px 28px;box-shadow:0 -4px 20px rgba(0,0,0,.7);">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;"><span style="font-size:15px;font-weight:800;color:#e0edf8;">${title}</span><button onclick="_sosCloseModal()" style="background:none;border:none;color:rgba(255,255,255,.5);font-size:24px;cursor:pointer;line-height:1;">×</button></div>
    ${html}</div>`;
  m.onclick=function(e){if(e.target===m)_sosCloseModal();};
}
function _sosCloseModal(){const m=document.getElementById('sosModal');if(m)m.remove();}
// 조난자 위치 삭제 (테스트·종료된 항목 정리)
// 외국인/언어/국적 배지 (팀 화면용)
function _sosForeignBadge(p){
  if(!p||!p.lang||p.lang==='ko')return '';
  const lbl=(typeof _SOS_LABEL!=='undefined'&&_SOS_LABEL[p.lang])||p.lang;
  return '<span style="font-size:10px;background:rgba(241,196,15,.15);color:#f0c040;border:1px solid rgba(241,196,15,.35);border-radius:6px;padding:1px 7px;font-weight:700;">🌐 외국인 · '+lbl+(p.country?' · '+_esc(p.country):'')+'</span>';
}
function _sosAtStr(p){if(!p)return '';if(p.at)return p.at.slice(11);try{return new Date(p.ts).toTimeString().slice(0,8);}catch(e){return '';}}
function deleteSosPing(id,silent){
  if(!_fdb)return;
  if(!silent&&!confirm('이 조난자 위치를 삭제할까요?'))return;
  _fdb.collection('sos').doc(id).delete().catch(()=>{});
  _sosPings=(_sosPings||[]).filter(p=>p.id!==id);
  try{if(window._sosSeen)delete window._sosSeen[id];}catch(e){}
  try{_drawSosPins();}catch(e){}try{_updateSosFab();}catch(e){}
  if(!silent){toast('🗑️ 위치 삭제됨');if(document.getElementById('sosModal'))openSosRequest();}
}
function clearAllSos(){
  const all=(_sosPings||[]).slice();
  if(!all.length){toast('삭제할 위치 없음');return;}
  if(!confirm('수신된 조난자 위치 '+all.length+'건을 모두 삭제할까요?\n(테스트 정리용 — 실제 조난자가 있으면 주의)'))return;
  all.forEach(p=>deleteSosPing(p.id,true));
  toast('🗑️ '+all.length+'건 삭제됨');
  _sosCloseModal();
}
let _sosOvs=[];
function _drawSosPins(){
  _sosOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_sosOvs=[];
  if(!mapR)return;
  _sosLocated().forEach(p=>{
    const pos=new kakao.maps.LatLng(p.lat,p.lng);
    // 정확도 원(±오차반경) — 위치가 '이 범위 안'임을 시각화
    const acc=Math.max(parseInt(p.acc)||0,15);
    try{
      const circ=new kakao.maps.Circle({center:pos,radius:acc,strokeWeight:1.5,strokeColor:'#ff3b30',strokeOpacity:.85,strokeStyle:'shortdash',fillColor:'#ff3b30',fillOpacity:.13});
      circ.setMap(mapR);_sosOvs.push(circ);
    }catch(e){}
    // 작은 도트 + 이름(정확도 표기)
    const el=document.createElement('div');
    el.className='sos-pin';
    el.innerHTML=`<span class="sos-dot">🆘</span><span class="sos-lbl">${_esc((p.name||'조난자').slice(0,8))} ±${acc}m</span>`;
    el.addEventListener('click',e=>{e.stopPropagation();_sosPinPopup(p.id);});
    const ov=new kakao.maps.CustomOverlay({position:pos,content:el,clickable:true,yAnchor:1.15,zIndex:10});
    ov.setMap(mapR);_sosOvs.push(ov);
  });
}
function _sosPinPopup(id){
  const p=(_sosPings||[]).find(x=>x.id===id);if(!p)return;
  const mm=Math.round((Date.now()-(p.ts||0))/60000);
  const html=`
    <div style="background:#0b1c30;border:1px solid rgba(231,76,60,.4);border-radius:11px;padding:13px 15px;margin-bottom:10px;">
      <div style="font-size:16px;font-weight:800;color:#ff8a73;">🆘 ${_esc(p.name||'익명 조난자')}</div>
      ${_sosForeignBadge(p)?`<div style="margin-top:5px;">${_sosForeignBadge(p)}</div>`:''}
      ${p.msg?`<div style="font-size:13px;color:#e0edf8;margin-top:6px;line-height:1.5;">${_esc(p.msg)}</div>`:''}
      <div style="font-size:11px;color:#8ab4cc;margin-top:8px;font-family:monospace;">📍 ${(+p.lat).toFixed(6)}, ${(+p.lng).toFixed(6)}<br>정확도 ±${p.acc||'?'}m · ${mm}분 전 수신 · ${_sosAtStr(p)}</div>
    </div>
    <div style="display:flex;gap:6px;">
      <button onclick="_sosFocus('${p.id}')" style="flex:1;background:rgba(79,168,208,.12);color:#4fa8d0;border:1px solid rgba(79,168,208,.35);border-radius:8px;padding:11px;font-size:13px;font-weight:700;cursor:pointer;">🗺️ 위치로 이동</button>
      <button onclick="sosToRescue('${p.id}')" style="flex:1;background:linear-gradient(180deg,#e74c3c,#c0392b);color:#fff;border:none;border-radius:8px;padding:11px;font-size:13px;font-weight:800;cursor:pointer;">🚨 구조 사고로 등록</button>
    </div>
    <button onclick="_sosCloseModal();_sosCloseToken('${p.id}')" style="width:100%;margin-top:7px;background:rgba(192,57,43,.1);color:#c0392b;border:1px solid rgba(192,57,43,.3);border-radius:8px;padding:10px;font-size:12px;font-weight:700;cursor:pointer;">🔚 접수 종료 (링크 비활성화)</button>`;
  _sosModal('🆘 조난자 위치',html);
}
function _sosCopyUrl(tok){const u=_sosVictimUrl(tok);if(navigator.clipboard)navigator.clipboard.writeText(u).then(()=>toast('📋 1회용 링크 복사됨')).catch(()=>_fallbackCopy(u));else _fallbackCopy(u);}
function _sosShareUrl(tok){const u=_sosVictimUrl(tok);if(navigator.share)navigator.share({title:'설악산 구조대 위치전송',text:'[설악산 구조대] 아래 1회용 링크를 열면 위치가 구조대에 전송됩니다(로그인 불필요).\n'+u}).catch(()=>{});}
function _sosSms(tok){const u=_sosVictimUrl(tok);location.href='sms:?body='+encodeURIComponent('[설악산 구조대] 아래 1회용 링크를 열어 위치를 보내주세요(로그인 불필요): '+u);}
function _sosFocus(id){
  const p=(_sosPings||[]).find(x=>x.id===id);if(!p)return;
  _sosCloseModal();
  if(mapR&&p.lat&&p.lng){try{mapR.setCenter(new kakao.maps.LatLng(p.lat,p.lng));mapR.setLevel(4);}catch(e){}}
}
// 조난·사고자 위치 → 1보 작성 폼으로 바로 이동 (코드기반 제목 '09-11 조난', 이름은 사고자란)
function sosToRescue(id){
  const p=(_sosPings||[]).find(x=>x.id===id);if(!p||!p.lat||!p.lng){toast('위치 수신 후 등록 가능');return;}
  window._pendingSosId=id; // 1보 '제출' 시점에 토큰 종료(작성 취소 시 위치 유지)
  _sosCloseModal();
  // 가까운 표지판 코드 → 제목 'NN-NN 조난'
  let sign=null;try{sign=_nearestSignFull(p.lat,p.lng);}catch(e){}
  const code=sign?sign.code:'';
  // 외국인이면 국적/언어를 인적사항·경위에 반영
  const isForeign=p.lang&&p.lang!=='ko';
  const langLbl=isForeign?((typeof _SOS_LABEL!=='undefined'&&_SOS_LABEL[p.lang])||p.lang):'';
  const foreignNote=isForeign?('[외국인'+(p.country?' · '+p.country:'')+' · '+langLbl+'] '):'';
  const prefill={
    type:'조난', lat:p.lat, lng:p.lng, loctype:'법정탐방로',
    vName:(p.name||''),                       // 이름은 사고자 인적사항(세부)에
    vNation:(isForeign?'외국인':'알수없음'), vNationality:(isForeign?(p.country||langLbl):''),
    situation:(foreignNote+(p.msg||'')).trim(),// 외국인 표기 + 조난자 메모 → 사고경위
    title:(code?code+' 조난':'조난'), sosId:id
  };
  // 1보 작성 폼 열기 (openNewRescue와 동일 경로)
  curResId=null;
  document.getElementById('topTitle').textContent='신규 구조 접수 (1보)';
  document.getElementById('bnav').style.display='none';
  showV('v-report');renderPhaseBar(0,1);render1BoForm(prefill);
  try{_autoFillLoc(p.lat,p.lng);}catch(e){}     // 사고 장소 자동(가까운 표지판)
  setTimeout(function(){
    const t=document.getElementById('r_title');if(!t)return;
    t.value=prefill.title;t.dataset.userEdited='1';
    if(!code){ // 표지판 코드 없음 → 역지오코딩 지명으로 'OO 조난'
      try{
        const gc=new kakao.maps.services.Geocoder();
        gc.coord2Address(p.lng,p.lat,function(res,st){
          if(st===kakao.maps.services.Status.OK&&res&&res[0]){
            const a=res[0].address||res[0].road_address;
            const nm=a?(a.region_3depth_name||a.region_2depth_name||''):'';
            if(nm&&t)t.value=nm+' 조난';
          }
        });
      }catch(e){}
    }
  },220);
  toast('🚨 조난 접수 — 1보 작성 화면');
}

// ══════════════════════════════════════════
// 앱 자체 업데이트 (OTA · Capgo 자체호스팅) — APK 전용. 웹/PWA는 서비스워커가 자동 갱신.
// 번들(www)의 새 버전을 ota.json으로 알리면, 설치된 앱이 받아서 그 자리에서 교체(재빌드 불필요).
// ══════════════════════════════════════════
const OTA_VER='2026.06.28.1';                         // ← 현재 번들 버전 (릴리스마다 올림 · build-ota.sh가 ota.json에 반영)
const OTA_MANIFEST='https://109yoon.github.io/seoraksan/ota.json';
let _otaInfo=null;
function _otaPlugin(){try{return (window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.CapacitorUpdater)||null;}catch(e){return null;}}
function _isNativeApp(){try{return !!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform());}catch(e){return false;}}
async function _otaCheck(manual){
  const plug=_otaPlugin();
  if(!_isNativeApp()||!plug){ if(manual)toast('웹은 새로고침으로 자동 갱신됩니다(앱 전용 기능)'); return; }
  let m;
  try{ const r=await fetch(OTA_MANIFEST+'?t='+Date.now(),{cache:'no-store'}); m=await r.json(); }
  catch(e){ if(manual)toast('⚠️ 업데이트 확인 실패 (네트워크)'); return; }
  if(!m||!m.version||!m.url){ if(manual)toast('업데이트 정보 없음'); return; }
  if(String(m.version)===String(OTA_VER)){ _otaInfo=null;_otaBanner(); if(manual)toast('✅ 최신 버전입니다 ('+OTA_VER+')'); return; }
  _otaInfo=m; _otaBanner();
  if(manual)_otaApply();
}
async function _otaApply(){
  const plug=_otaPlugin(); if(!plug||!_otaInfo)return;
  try{
    toast('⬇️ 업데이트 받는 중… 잠시만요 (완료되면 자동 재시작)',8000);
    const b=await plug.download({url:_otaInfo.url,version:String(_otaInfo.version)});
    await plug.set(b); // 적용 + 자동 재시작 (새 번들이 notifyAppReady 못하면 다음 실행 시 자동 롤백)
  }catch(e){ toast('⚠️ 업데이트 실패: '+(e&&(e.message||e.code)||e)); }
}
function _otaBanner(){
  let el=document.getElementById('otaBanner');
  if(!_otaInfo){ if(el)el.remove(); return; }
  if(!el){ el=document.createElement('div'); el.id='otaBanner'; document.body.appendChild(el); }
  el.style.cssText='position:fixed;top:0;left:0;right:0;z-index:99998;background:linear-gradient(180deg,#e74c3c,#c0392b);color:#fff;padding:11px 14px;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:space-between;gap:10px;box-shadow:0 2px 10px rgba(0,0,0,.5);cursor:pointer;padding-top:calc(11px + env(safe-area-inset-top));';
  el.innerHTML='<span>🔄 새 버전이 있습니다'+(_otaInfo.notes?' — '+_esc(_otaInfo.notes):'')+'</span><button style="background:#fff;color:#c0392b;border:none;border-radius:7px;padding:6px 12px;font-size:12px;font-weight:800;cursor:pointer;flex-shrink:0;">지금 업데이트</button>';
  el.onclick=_otaApply;
}
function _otaInit(){
  if(!_isNativeApp())return;
  const plug=_otaPlugin();
  if(plug&&plug.notifyAppReady){try{plug.notifyAppReady();}catch(e){}} // 현재 번들 정상 표시(미호출 시 다음 실행 롤백)
  setTimeout(function(){_otaCheck(false);},4000); // 시작 후 조용히 확인 → 있으면 상단 배너
}

window.onload=function(){
  // 🆘 조난자 위치전송 모드(?sos): 로그인·앱 로딩 전부 건너뛰고 위치만 전송
  if(/[?&]sos(=|&|$)/.test(location.search)){ try{_bootSos();}catch(e){document.body.innerHTML='<div style="color:#fff;padding:30px;font-size:16px;">위치 전송 초기화 오류: '+(e&&e.message||e)+'<br>새로고침 해주세요.</div>';} return; }
  try{_restoreFilters();}catch(e){} // 마지막 사용 필터 복원
  // ── 로딩 화면 ── (애니메이션은 loadingScreen 직후 인라인 스크립트에서 이미 시작됨)
  (function(){
    window._hideLoading=function(){
      if(window._hideLoadingDone) return;
      window._hideLoadingDone=true;
      if(window._safeLoadingTimer)clearTimeout(window._safeLoadingTimer);
      clearInterval(window._loadTipTimer);clearInterval(window._loadBarTimer);
      var barEl=document.getElementById('loadBar');
      if(barEl)barEl.style.width='100%';
      var _hlTimer=null;
      window.showLoginScreen=function showLoginScreen(){
        if(_hlTimer){clearTimeout(_hlTimer);_hlTimer=null;}
        var ls=document.getElementById('loginScreen');
        if(!ls)return;
        window._loginVisible=true; // 뒤로가기 판정용 (style.display 의존 제거)
        ls.style.opacity='0';
        ls.style.display='flex';
        ls.style.pointerEvents='none';
        requestAnimationFrame(function(){requestAnimationFrame(function(){
          ls.style.transition='opacity .3s';ls.style.opacity='1';ls.style.pointerEvents='auto';
        });});
      }
      window.hideLoginScreen=function hideLoginScreen(){
        var ls=document.getElementById('loginScreen');
        window._loginVisible=false; // 로그인 완료 → 즉시 미표시로 간주 (페이드아웃 중 오판 방지)
        if(!ls||ls.style.display==='none')return;
        ls.style.pointerEvents='none';
        ls.style.transition='opacity .3s';ls.style.opacity='0';
        if(_hlTimer)clearTimeout(_hlTimer);
        _hlTimer=setTimeout(function(){_hlTimer=null;ls.style.display='none';ls.style.transition='';},350);
      }
      function checkAuth(){
        updateUserUI();
        var authType=(typeof DB!=='undefined'&&typeof _resolveAuthType==='function')?_resolveAuthType():'';
        if(!authType){showLoginScreen();}
        else{_checkAndRequireProfile();}
      }
      setTimeout(function(){
        var ls=document.getElementById('loadingScreen');
        if(ls){
          ls.style.pointerEvents='none';
          ls.style.transition='opacity .35s';ls.style.opacity='0';
          setTimeout(function(){
            if(ls.parentNode)ls.parentNode.removeChild(ls);
            checkAuth();
          },350);
        } else {
          checkAuth();
        }
      },120);
    };
    // 최종 폴백은 위쪽 스크립트의 6초 절대 타임아웃(_safeLoadingTimer)에 위임.
    // 여기서 별도로 더 일찍 강제 전환하지 않아야 Firestore 데이터가
    // 도착하기 전에 빈 화면이 먼저 보이는 문제(로딩 중 데이터 미리 받기)를 막을 수 있다.
  })();

  // 안드로이드 하드웨어 뒤로가기: Capacitor App 플러그인 콜백 → history.back() 위임.
  // (이 리스너를 등록하면 Capacitor 기본 동작인 "즉시 앱 종료"가 꺼지고, 아래
  //  popstate 핸들러가 모달 닫기·서브뷰 복귀·홈에서 2회 눌러야 종료를 그대로 처리한다)
  (function(){
    var App=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.App;
    if(!App)return;
    App.addListener('backButton', function(){ window.history.back(); });
  })();
  // 웹/PWA 뒤로가기 처리
  var _backExitReady=false,_backExitTimer=null;
  function _exitApp(){
    var isNative=window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform();
    if(isNative&&window.Capacitor.Plugins&&window.Capacitor.Plugins.App){Capacitor.Plugins.App.exitApp();return true;}
    var isPWA=window.matchMedia('(display-mode: standalone)').matches||!!window.navigator.standalone;
    if(isPWA){window.close();return true;}
    toast('브라우저 탭을 닫아 종료하세요');return false;
  }
  window.addEventListener('popstate', function(e){
    // 로그인 화면(미로그인 상태)에서 뒤로가기: 돌아갈 곳이 없으므로 바로 종료
    if(window._loginVisible){
      history.pushState({view:'home'},'','');
      _exitApp();return;
    }
    // 관리자 로그인 오버레이가 떠 있으면 그것부터 닫기 (전체 화면을 덮고 있어 안 닫으면 먹통처럼 보임)
    var adminOv=document.getElementById('adminLoginOverlay');
    if(adminOv&&adminOv.style.display==='flex'){adminOv.style.display='none';history.pushState({view:'home'},'','');return;}
    // 사진 전체보기 닫기
    var lb=document.getElementById('photoLightbox');
    if(lb&&lb.style.display==='flex'){lb.style.display='none';history.pushState({view:'home'},'','');return;}
    // 변경사항(체인지로그) 모달 닫기
    var clog=document.getElementById('changelogModal');
    if(clog&&clog.style.display!=='none'&&clog.style.display!==''){closeChangelog();history.pushState({view:'home'},'','');return;}
    // 알림(벨) 패널 닫기
    var nPanel=document.getElementById('notiPanel');
    if(nPanel&&nPanel.classList.contains('on')){closeNoti();history.pushState({view:'home'},'','');return;}
    // 열린 모달이 있으면 닫기
    var openModal=document.querySelector('.modal.on,.modal-bottom.on');
    if(openModal){openModal.classList.remove('on');history.pushState({view:'home'},'','');return;}
    // 서브뷰: 유형 세부통계
    if(document.getElementById('v-type-detail').classList.contains('on')){
      showV('v-rescue-stats');renderRescueStats();history.pushState({view:'rescue-stats'},'','');return;
    }
    // v-report(구조 타임라인) → 목록으로 복귀
    if(document.getElementById('v-report').classList.contains('on')){
      // 작성 중(미저장 입력 있음)이면 이탈 경고 — 취소 시 폼에 머무름
      if(window._reportMode==='form'&&_formDirty){
        if(!confirm('작성 중인 내용이 저장되지 않았습니다.\n나가시겠습니까? (임시저장본은 보관됩니다)')){
          history.pushState({view:'rescue-report'},'','');return; // 머무르기
        }
        try{_saveDraftNow();}catch(e){}
      }
      window._reportMode='';clearInterval(_draftAutoTimer);
      _hideRepFooter();
      showV('v-rescue-list');renderResList();
      document.getElementById('appHdr').style.display='block';
      document.getElementById('topTitle').textContent='재난/구조 관리';
      var _bn=document.getElementById('bnav');_bn.style.display='flex';
      [1,2,3].forEach(function(i){document.getElementById('nv'+i).classList.remove('on');});
      document.getElementById('nv2').classList.add('on');
      history.pushState({view:'rescue'},'','');
      return;
    }
    var homeActive=document.getElementById('v-home').classList.contains('on');
    if(!homeActive){
      // 다른 화면 → 홈으로
      showV('v-home');
      document.getElementById('appHdr').style.display='none';
      document.getElementById('bnav').style.display='none';
      closeDB();updateSummary();
      history.pushState({view:'home'},'','');
    } else {
      // 홈 화면: 항상 home 상태를 다시 push해서 앱 밖으로 절대 못 나가게
      history.pushState({view:'home'},'','');
      var isNative=window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform();
      var isPWA=window.matchMedia('(display-mode: standalone)').matches||!!window.navigator.standalone;
      if(_backExitReady){
        clearTimeout(_backExitTimer);_backExitReady=false;
        _exitApp();
      } else {
        _backExitReady=true;
        toast((isNative||isPWA)?'한 번 더 누르면 종료됩니다':'종료하려면 탭을 닫으세요');
        _backExitTimer=setTimeout(function(){_backExitReady=false;},2000);
      }
    }
  });
  // 앱 시작: guard + home 두 개 push → 뒤로가기가 앱 밖으로 절대 이탈 안 함
  history.pushState({view:'_guard_'},'','');
  history.pushState({view:'home'},'','');

  // ── 권한 배너 ──────────────────────────────────
  function _permBanner(type,state){
    var wrap=document.getElementById('permBanners');if(!wrap)return;
    var id='pb-'+type;var old=document.getElementById(id);if(old)old.remove();
    if(state==='granted'){localStorage.setItem('_permOk_'+type,'1');return;}
    if(localStorage.getItem('_permOk_'+type)==='1')return;
    if(state==='denied')localStorage.removeItem('_permOk_'+type);
    var cfg=type==='loc'
      ?{ico:'📍',title:'위치 권한',desc:state==='denied'?'설정에서 위치 권한을 허용해 주세요':'지도 GPS 기능을 위해 위치 접근 허용'}
      :{ico:'🔔',title:'알림 권한',desc:state==='denied'?'설정에서 알림 권한을 허용해 주세요':'구조 발생 시 알림 수신 허용'};
    var div=document.createElement('div');
    div.id=id;
    div.style.cssText='display:flex;align-items:center;gap:8px;background:rgba(79,168,208,.08);border:1px solid rgba(79,168,208,.18);border-radius:9px;padding:8px 10px;flex-shrink:0;';
    div.innerHTML='<span style="font-size:15px;">'+cfg.ico+'</span>'
      +'<div style="flex:1;min-width:0;">'
        +'<div style="font-size:11px;font-weight:700;color:#4fa8d0;">'+cfg.title+'</div>'
        +'<div style="font-size:10px;color:#3a6a8a;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+cfg.desc+'</div>'
      +'</div>'
      +(state!=='denied'?'<button onclick="_reqPerm(\''+type+'\')" style="flex-shrink:0;background:#1a3d5c;color:#4fa8d0;border:1px solid rgba(79,168,208,.3);border-radius:6px;padding:5px 11px;font-size:10px;font-weight:700;cursor:pointer;">허용</button>':'')
      +'<button onclick="document.getElementById(\'pb-'+type+'\').remove()" style="flex-shrink:0;background:none;border:none;color:rgba(255,255,255,.2);font-size:16px;line-height:1;cursor:pointer;padding:0 2px;">×</button>';
    wrap.appendChild(div);
  }
  function _initPermBanners(){
    // 위치 권한
    if(navigator.permissions){
      navigator.permissions.query({name:'geolocation'}).then(function(r){
        _permBanner('loc',r.state);
        r.onchange=function(){_permBanner('loc',r.state);};
      }).catch(function(){_permBanner('loc','prompt');});
    } else if(navigator.geolocation){
      _permBanner('loc','prompt');
    }
    // 알림 권한 (지원하는 경우만)
    if('Notification' in window){
      _permBanner('noti',Notification.permission);
    }
  }
  window._reqPerm=function(type){
    if(type==='loc'){
      navigator.geolocation.getCurrentPosition(
        function(){toast('📍 위치 권한 허용됨');_permBanner('loc','granted');},
        function(){toast('⚠️ 위치 권한이 거부되었습니다');},
        {enableHighAccuracy:true,timeout:15000}
      );
    } else if(type==='noti'){
      if(typeof Notification==='undefined'){toast('이 브라우저는 알림을 지원하지 않습니다');return;}
      Notification.requestPermission().then(function(r){
        _permBanner('noti',r);
        toast(r==='granted'?'🔔 알림 권한 허용됨':'⚠️ 알림 권한이 거부되었습니다');
        if(r==='granted') _initFCM();
      });
    }
  };
  setTimeout(_initPermBanners, 800); // 앱 로딩 후 표시

  // 야외 고대비 모드 복원
  if(localStorage.getItem('_hiContrast')){document.body.classList.add('hi-contrast');var _hb=document.getElementById('hiContrastBtn');if(_hb)_hb.style.opacity='1';}

  // ── Service Worker 등록 (PWA 오프라인 + FCM 백그라운드 알림) ──
  if('serviceWorker' in navigator){
    var _hadController=!!navigator.serviceWorker.controller; // 첫 설치(claim)와 '업데이트'를 구분
    navigator.serviceWorker.register('sw.js').then(function(reg){
      _swReg=reg;
      if('Notification' in window&&Notification.permission==='granted') _initFCM();
      try{reg.update();}catch(e){} // 새 버전 즉시 확인
    }).catch(function(){});
    // 새 서비스워커가 활성화(업데이트)되면 자동 새로고침 → '며칠 전 버전에 멈춤' 방지(자가치유)
    navigator.serviceWorker.addEventListener('controllerchange',function(){
      if(!_hadController||window._swReloaded)return; // 첫 설치는 새로고침 안 함(루프 방지)
      window._swReloaded=true;location.reload();
    });
  }
  try{_otaInit();}catch(e){} // APK 자체 업데이트(OTA) 확인
  // 네이티브(APK): 알림 권한 먼저 요청 → 끝난 뒤 위치 권한 요청 (시스템 다이얼로그가 겹치지 않도록 순차 실행)
  Promise.resolve(_initNativePush()).catch(function(){}).then(function(){return _initNativeLocationPerm();}).catch(function(){});

  initFirebase(function(){
    initDB();
    if(window._KR){ initMaps(); } else { window._KCB=function(){initMaps();}; }
    updateSummary();updateUserUI();fetchWeather();
    try{setTimeout(_autoApplyCoordFix,3500);}catch(e){} // 표지판 좌표 자동 최신화(1회)
    try{if((DB.g('alertOps')||[]).some(o=>!o.closedAt))_startAlertReminder();}catch(e){}
    try{_startKmaWarnPoll();}catch(e){}
    const d=new Date();const days=['일','월','화','수','목','금','토'];
    document.getElementById('homeDate').textContent=d.getFullYear()+'년 '+(d.getMonth()+1)+'월 '+d.getDate()+'일 ('+days[d.getDay()]+')';
    try{_initSosWatch();}catch(e){} // 🆘 조난·사고자 위치 실시간 구독 (early return 전에 보장)
    if(window._kakaoAuthCode){var _kc=window._kakaoAuthCode;window._kakaoAuthCode=null;_handleKakaoCode(_kc);return;}
    // Firebase 준비 후 FCM 토큰 갱신 (권한·SW·VAPID 모두 준비된 경우만)
    if('Notification' in window&&Notification.permission==='granted') _initFCM();
    _flushFcmToken(); // 네이티브 토큰이 Firebase 준비 전 등록됐으면 지금 저장
    // 모니터 거치용: 주소에 ?board=1 붙이면 켜자마자 상황판
    if(/[?&]board=1/.test(location.search))setTimeout(openBoard,300);
    if(window._hideLoading) window._hideLoading();
    // 이미 관리자 세션이면 과거 안전사고 데이터 1회 자동 반영 (아카이브 로드 후)
    try{setTimeout(_autoSeedAccidents,6000);}catch(e){}
  });
};

