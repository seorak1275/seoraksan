'use strict';
// ══════════════════════════════════════════
// 위험상황 보고
// ══════════════════════════════════════════
let _hazFireTL=[];
function chkHazType(txt){
  const isFire=txt.includes('산불');
  document.getElementById('hazFireTimelineWrap').style.display=isFire?'block':'none';
  document.getElementById('hazFireMobilizeWrap').style.display=isFire?'block':'none';
  document.getElementById('hazFireLeadWrap').style.display=isFire?'block':'none';
  if(isFire){
    const el=document.getElementById('hazFireTLTime');
    if(el)el.value=new Date().toISOString().slice(0,16);
    const stages=['최초 발화 확인','소방 신고','소방 도착','진화 시작','진화 완료','재발화','완전 진화'];
    const qp=document.getElementById('hazFireQuickPills');
    if(qp)qp.innerHTML=stages.map(s=>`<div class="pill" onclick="addHazFireTL('${s}')" style="font-size:10px;">${s}</div>`).join('');
  }
}
function addHazFireTL(stage){
  const timeEl=document.getElementById('hazFireTLTime');
  const noteEl=document.getElementById('hazFireTLNote');
  const time=timeEl?.value?.replace('T',' ')||new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'});
  noteEl.value=stage;
  renderHazFireTL();
}
function confirmHazFireTL(){
  const time=(document.getElementById('hazFireTLTime')?.value||'').replace('T',' ');
  const note=document.getElementById('hazFireTLNote')?.value||'';
  if(!note.trim()){toast('⚠️ 내용 입력');return;}
  _hazFireTL.push({time,note});
  _hazFireTL.sort((a,b)=>a.time.localeCompare(b.time));
  document.getElementById('hazFireTLNote').value='';
  renderHazFireTL();
}
function renderHazFireTL(){
  const el=document.getElementById('hazFireTLList');
  if(!el)return;
  el.innerHTML=_hazFireTL.length?_hazFireTL.map((t,i)=>`<div style="display:flex;align-items:center;gap:7px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05);">
    <span style="font-size:10px;color:#3182f6;flex-shrink:0;">${t.time.slice(11)||t.time}</span>
    <span style="font-size:11px;color:#eaecef;flex:1;">${_esc(t.note)}</span>
    <button onclick="_hazFireTL.splice(${i},1);renderHazFireTL()" style="background:none;border:none;color:#c0392b;font-size:13px;cursor:pointer;">✕</button>
  </div>`).join(''):'<div style="font-size:11px;color:rgba(255,255,255,.25);padding:4px 0;">타임라인 항목 없음</div>';
}
// 등록 후 상세화면에서도 산불 진행 타임라인을 계속 추가/삭제할 수 있도록(N보 대체)
function _hazFireTLHtml(h){
  if(!h.hazType||!h.hazType.includes('산불'))return '';
  const tl=h.fireTL||[];
  const stages=['최초 발화 확인','소방 신고','소방 도착','진화 시작','진화 완료','재발화','완전 진화'];
  return `<div id="fireTLBlk_${h.id}" style="background:#1c1c1e;border-radius:10px;padding:11px 12px;border:.5px solid rgba(192,57,43,.25);margin-top:8px;">
    <div style="font-size:11px;color:#c0392b;font-weight:700;margin-bottom:7px;">🔥 산불 진행 타임라인</div>
    <div style="margin-bottom:6px;">
      ${tl.length?tl.map((t,i)=>`<div style="display:flex;align-items:center;gap:7px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <span style="font-size:10px;color:#3182f6;flex-shrink:0;">${_esc((t.time||'').slice(11)||t.time||'-')}</span>
        <span style="font-size:11px;color:#eaecef;flex:1;">${_esc(t.note)}</span>
        <button onclick="delHazFireTL(${h.id},${i})" style="background:none;border:none;color:#c0392b;font-size:13px;cursor:pointer;">✕</button>
      </div>`).join(''):'<div style="font-size:11px;color:rgba(255,255,255,.25);padding:4px 0;">타임라인 항목 없음</div>'}
    </div>
    <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;">
      ${stages.map(s=>`<div class="pill" onclick="document.getElementById('fireTLNote_${h.id}').value='${_escq(s)}'" style="font-size:10px;">${s}</div>`).join('')}
    </div>
    <div style="display:flex;gap:5px;align-items:flex-end;">
      <input type="datetime-local" id="fireTLTime_${h.id}" class="fi" style="flex:1;" value="${new Date().toISOString().slice(0,16)}">
      <input type="text" id="fireTLNote_${h.id}" class="fi" style="flex:2;" placeholder="상황 내용">
      <button onclick="addHazFireTLEntry(${h.id})" style="background:#1a4a6e;color:#fff;border:none;padding:9px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;flex-shrink:0;">추가</button>
    </div>
  </div>`;
}
function addHazFireTLEntry(id){
  const haz=DB.g('hazards')||[];
  const idx=haz.findIndex(x=>x.id===id);if(idx===-1)return;
  const time=(document.getElementById('fireTLTime_'+id)?.value||'').replace('T',' ');
  const note=document.getElementById('fireTLNote_'+id)?.value||'';
  if(!note.trim()){toast('⚠️ 내용 입력');return;}
  const tl=[...(haz[idx].fireTL||[]),{time,note}].sort((a,b)=>(a.time||'').localeCompare(b.time||''));
  haz[idx]={...haz[idx],fireTL:tl};
  DB.s('hazards',haz);
  const blk=document.getElementById('fireTLBlk_'+id);
  if(blk)blk.outerHTML=_hazFireTLHtml(haz[idx]);
  toast('🔥 타임라인 추가');
}
function delHazFireTL(id,i){
  const haz=DB.g('hazards')||[];
  const idx=haz.findIndex(x=>x.id===id);if(idx===-1)return;
  const tl=(haz[idx].fireTL||[]).slice();tl.splice(i,1);
  haz[idx]={...haz[idx],fireTL:tl};
  DB.s('hazards',haz);
  const blk=document.getElementById('fireTLBlk_'+id);
  if(blk)blk.outerHTML=_hazFireTLHtml(haz[idx]);
}
function openNewHazard(){
  if(typeof _HAZ_OFF!=='undefined'&&_HAZ_OFF){toast('⚠️ 위험상황 기능은 현재 비활성화되어 있습니다');return;}
  _hazFireTL=[];
  document.getElementById('hz_dt').value=nowDT();
  document.getElementById('hz_loc').value='';document.getElementById('hz_gps').value='';
  initHazMiniMap();
  document.getElementById('hz_desc').value='';const _ha=document.getElementById('hz_author');_ha.value=getAuthor();_ha.disabled=true;
  {const pv=document.getElementById('prevHaz');pv.dataset.url='';pv.innerHTML='📸 현장 사진';} // 직전 첨부 잔재가 새 등록에 딸려가지 않게
  document.getElementById('hazFireTimelineWrap').style.display='none';
  document.getElementById('hazFireMobilizeWrap').style.display='none';
  document.getElementById('hazFireLeadWrap').style.display='none';
  _resetPills('hazTypePills','hazDangerPills','hazStatusPills','hazOnSitePills','hazResponsePills','hazMobilizePills');
  document.querySelector('#hazStatusPills .pill').classList.add('on');
  renderHazFireTL();
  document.getElementById('modalHazard').classList.add('on');
}
let _hazSubmitting=false;
function submitHazard(){
  const type=getSelPills('hazTypePills')[0];
  if(!type){toast('⚠️ 유형 선택');return;}
  if(_hazSubmitting)return; // 이중 탭 중복 등록 방지
  _hazSubmitting=true;
  setTimeout(()=>{_hazSubmitting=false;},1500);
  const gps=document.getElementById('hz_gps').value.split(',');
  const lat=parseFloat(gps[0])||null,lng=parseFloat(gps[1])||null;
  const h={
    id:Date.now(),hazType:type,
    dt:document.getElementById('hz_dt').value.replace('T',' '),
    loc:document.getElementById('hz_loc').value,lat,lng,
    danger:getSelPills('hazDangerPills')[0]||'',
    desc:document.getElementById('hz_desc').value,
    hazStatus:getSelPills('hazStatusPills')[0]||'미조치',
    statusLog:[{status:getSelPills('hazStatusPills')[0]||'미조치',at:now(),by:document.getElementById('hz_author').value||'-'}],
    onSite:getSelPills('hazOnSitePills')[0]||'',response:getSelPills('hazResponsePills')[0]||'',
    author:document.getElementById('hz_author').value,
    photo:_photoUrl('prevHaz'),
    fireTL:type.includes('산불')?[..._hazFireTL]:[],
    mobilize:type.includes('산불')?getSelPills('hazMobilizePills'):[],
    leadAgency:type.includes('산불')?'산림청':'',
  };
  const haz=DB.g('hazards')||[];haz.push(h);DB.s('hazards',haz);
  _registerPendingPhoto('prevHaz',{key:'hazards',id:h.id,field:'photo'});
  pushNoti(`⚠️ 위험상황: ${type} · ${h.loc||'-'}`,'⚠️','낙석',{app:'rescue',tab:2});
  if(h.mobilize&&h.mobilize.length)pushNoti(`🚨 산불 응소 요청: ${h.mobilize.join(', ')} — ${h.loc||'-'}`,'🚨','rescue_mobilize',{app:'rescue',tab:2});
  closeM('modalHazard');try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}toast('⚠️ 위험상황 등록'+(h.mobilize&&h.mobilize.length?' · 응소: '+h.mobilize.join(', '):''));updateSummary();
}

// ══════════════════════════════════════════
// 시설물
// ══════════════════════════════════════════
let selFacId=null;
let facMapStatusF=new Set(),facMapTypeF=new Set(),facMapLocF=new Set(),facMapGradeF=new Set();
let facListSort='default'; // 'default' | 'overdue'(점검 오래된순)
function setFacListSort(v){
  facListSort=facListSort===v?'default':v;
  _persistFilters();
  if(facListSort==='overdue')_loadArchive('history').then(()=>{_updateFacListFilterPanel();renderFacList();}); // 1년 이전 점검이력도 반영
  _updateFacListFilterPanel();renderFacList();
}
// 점검이력·상태(주의/심각) 제거 마이그레이션 (1회) — 시설은 경고표시 체계로 전환
function _facMigrateV2(){
  try{
    if(localStorage.getItem('_facV2')==='1')return;
    var f=DB.g('facilities')||[],ch=false;
    f.forEach(function(x){if('status' in x){delete x.status;ch=true;}if('statusAt' in x){delete x.statusAt;ch=true;}});
    if(ch)DB.s('facilities',f);
    if((DB.g('history')||[]).length)DB.s('history',[]);
    localStorage.setItem('_facV2','1');
  }catch(e){}
}
function renderInspectMap(){
  if(!mapI){return;}
  _facMigrateV2();
  const _admin=isAdminUser();const _meta=DB.g('catFacMeta')||{};
  // Firestore 수신 전엔 경량 부트 캐시로 핀 먼저 표시(즉시 표시) — 수신되면 자동 재렌더로 교체
  const _facsAll=DB.g('facilities')||(typeof _facBootCache==='function'&&_facBootCache())||[];
  const facs=_facsAll.filter(f=>_admin||!(_meta[f.type]||{}).adminOnly);
  const types=['전체',...new Set(facs.map(f=>{const t=String(f.type||'');return t.split(' ').slice(1).join(' ')||t;}).filter(Boolean))];
  const _signFacs=_facsAll.filter(f=>f.type&&f.type.includes('다목적위치표지판'));
  const locs=['전체',...new Set(_signFacs.map(f=>(String(f.name||'').match(/\d+/)||[''])[0]).filter(Boolean)).values()].sort((a,b)=>a==='전체'?-1:a.localeCompare(b,'ko'));
  _updateInspFilterPanel(types,locs);
  const filtered=facs.filter(f=>{
    if(!_facVisibleTo(f))return false; // 숨김 시설은 일반 사용자에게 미표시
    const wOk=facMapStatusF.size===0||(facMapStatusF.has('warn')&&!!_facWarn(f));
    const tOk=facMapTypeF.size===0||[...facMapTypeF].some(t=>f.type.includes(t));
    const lOk=facMapLocF.size===0||[...facMapLocF].some(v=>_facInZone(f,v));
    const _cg=facMapGradeF.size?_facCurGrade(f):null;
    const gOk=facMapGradeF.size===0||(_cg&&facMapGradeF.has(_cg.g));
    return wOk&&tOk&&lOk&&gOk;
  });
  // 변경 서명 — 원격 갱신마다 수백 오버레이(각 div+리스너3)를 전부 재생성하던 비용 제거:
  // 표시 시설·필터·권한이 그대로면 재구성 건너뜀(다른 컬렉션만 바뀐 원격 갱신 시 지도 잔틱·배터리 소모 방지).
  // 줌 시 스케일·클러스터는 _reclusterInspect가 별도(idle) 처리하므로 여기서 건너뛰어도 안전.
  const _sig=[facMapStatusF,facMapTypeF,facMapLocF,facMapGradeF].map(s=>[...s].sort().join('.')).join('|')+'#'+(_admin?'a':'')
    +'#'+filtered.map(f=>f.id+':'+f.lat+','+f.lng+':'+(_facWarn(f)?'w':'')+(f.hidden?'h':'')+':'+f.type).join('|');
  if(iOvs.length&&_sig===window._inspMapSig)return;
  window._inspMapSig=_sig;
  try{_closeFacOverlapSheet();}catch(e){} // 열린 겹침 목록 시트가 있으면 닫기(재구성 시)
  iOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});iOvs=[];iEls=[];
  _iClusterOvs.forEach(o=>{try{o.setMap(null);}catch(e){}});_iClusterOvs=[];
  filtered.forEach(f=>{
    if(!f.lat||!f.lng)return;
    const el=document.createElement('div');el.className='mpin '+(_facWarn(f)?'p-bad blink':'p-fac');el.innerHTML=f.type.split(' ')[0];
    el._facId=f.id;
    // 종류별 색 — 테두리+바탕 틴트로 한눈에 구분 (경고표시는 빨간 깜빡임 유지)
    if(!_facWarn(f)){const _tc=_facTypeColor(f.type);el.style.borderColor=_tc;el.style.background=`linear-gradient(0deg,${_tc}44,${_tc}44),#1c1c1e`;}
    if(f.hidden)el.style.opacity='.4'; // 권한자에게만 보이는 숨김 시설 — 흐리게
    let _ts=null;
    el.addEventListener('touchstart',e=>{_ts={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});
    el.addEventListener('touchend',e=>{
      if(!_ts)return;
      const dx=e.changedTouches[0].clientX-_ts.x,dy=e.changedTouches[0].clientY-_ts.y;
      _ts=null;
      if(Math.abs(dx)<8&&Math.abs(dy)<8){e.stopPropagation();e.preventDefault();_facPinTap(f.id);}
    });
    el.addEventListener('click',e=>{e.stopPropagation();_facPinTap(f.id);});
    const ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(f.lat,f.lng),content:el,clickable:true});
    ov._lat=f.lat;ov._lng=f.lng;ov._facId=f.id; // 부채꼴 펼침이 겹친 핀을 찾을 때 사용
    ov._sign=!!(f.type&&f.type.includes('다목적위치표지판')); // 줌아웃 시 표지판 숨김용 플래그
    ov._warn=!!_facWarn(f); // 경고 표시 시설은 축소 상태에서도 항상 표시
    // 지도 부착은 _reclusterInspect가 결정(밀집 핀은 버블로 묶음) — 초기 수백개 일괄 부착/제거 비용 제거
    iOvs.push(ov);iEls.push(el);
  });
  if(mapI)_scaleOvs(iEls,mapI.getLevel(),1);
  // 시설물 클러스터링 (밀집 시 개수 버블로 묶음)
  _iItems=iOvs.map(ov=>({ov,lat:ov._lat,lng:ov._lng}));
  try{_reclusterInspect();}catch(e){}
  // 지도 팝업 이전/다음 순서: 대상 좌표만 가볍게 보관하고, O(n²) 체인 계산은 팝업 열 때로 미룸(_facMapOrderCompute).
  // (예전엔 매 렌더마다 전체 시설 대상으로 최근접 체인을 계산 → 필터·줌·핀수정 때마다 재실행되며 지도가 느려짐)
  try{window._facMapPts=filtered.filter(f=>f.lat&&f.lng).map(f=>({id:String(f.id),lat:f.lat,lng:f.lng}));window._facMapOrder=null;}
  catch(e){window._facMapPts=[];window._facMapOrder=[];}
}
// 탐방로 연속 체인(서쪽 끝→가까운 시설 순) — 팝업 이전/다음용. 렌더마다가 아니라 팝업 열 때 1회 계산 후 캐시(다음 렌더에서 무효화).
function _facMapOrderCompute(){
  if(window._facMapOrder)return window._facMapOrder;
  const pts=window._facMapPts||[];
  if(pts.length<=1){window._facMapOrder=pts.map(p=>p.id);return window._facMapOrder;}
  try{
    let cur=pts.reduce((m,f)=>f.lng<m.lng?f:m,pts[0]);
    const left=new Set(pts.map(f=>f.id)),chain=[];
    while(cur){
      chain.push(cur.id);left.delete(cur.id);
      let best=null,bd=Infinity;
      pts.forEach(f=>{if(!left.has(f.id))return;const d=(f.lat-cur.lat)*(f.lat-cur.lat)+(f.lng-cur.lng)*(f.lng-cur.lng);if(d<bd){bd=d;best=f;}});
      cur=best;
    }
    window._facMapOrder=chain;
  }catch(e){window._facMapOrder=pts.map(p=>p.id);}
  return window._facMapOrder;
}
// ── 내 주변 시설물: GPS 기준 가까운 순 목록 + 바로 점검 (점검 나갈 때 한 번에) ──
function openNearFacs(){
  const old=document.getElementById('nearFacOv');if(old){old.remove();return;} // 토글
  toast('📍 내 위치 확인 중...');
  if(!navigator.geolocation){toast('⚠️ 이 기기는 위치를 지원하지 않습니다');return;}
  navigator.geolocation.getCurrentPosition(
    p=>_showNearFacs(p.coords.latitude,p.coords.longitude),
    ()=>toast('⚠️ 위치를 가져올 수 없습니다 — GPS 확인'),
    {enableHighAccuracy:true,timeout:10000,maximumAge:30000});
}
function _showNearFacs(la,ln){
  const _meta=DB.g('catFacMeta')||{};const admin=isAdminUser();
  const facs=(DB.g('facilities')||[]).filter(f=>f.lat&&f.lng&&_facVisibleTo(f)&&(admin||!(_meta[f.type]||{}).adminOnly));
  // 최근 점검일 표시용(참고 정보) — '분기 미점검' 판정·정렬은 제거(점검 주기 논란 소지)
  const _lastChk={};(DB.g('facIssues')||[]).forEach(i=>{if(i.facId&&(i.id||0)>(_lastChk[i.facId]||0))_lastChk[i.facId]=i.id||0;});
  let near=facs.map(f=>({f,d:_haversine(la,ln,f.lat,f.lng),chk:_lastChk[f.id]||0})).filter(n=>n.d<=1000); // 반경 1km 이내만
  near.sort((a,b)=>a.d-b.d); // 가까운 순
  near=near.slice(0,15);
  if(!near.length){toast('1km 이내에 등록된 시설물이 없습니다');return;}
  const old=document.getElementById('nearFacOv');if(old)old.remove();
  const ov=document.createElement('div');ov.id='nearFacOv';
  // 하단바(z20) 위로 — facPopup과 동일하게 화면 맨 아래까지 사용
  ov.style.cssText='position:absolute;bottom:0;left:0;right:0;z-index:30;background:#1c1c1e;border:1px solid rgba(255,255,255,.2);border-radius:16px 16px 0 0;box-shadow:0 -4px 20px rgba(0,0,0,.7);max-height:56vh;display:flex;flex-direction:column;padding-bottom:calc(8px + env(safe-area-inset-bottom));';
  const rows=near.map(n=>{
    const col=_facTypeColor(n.f.type);
    const cg=_facCurGrade(n.f);
    const dist=n.d<1000?Math.round(n.d)+'m':(n.d/1000).toFixed(1)+'km';
    return `<div style="display:flex;align-items:center;gap:8px;padding:7px 4px;border-bottom:1px solid rgba(255,255,255,.04);">
      <span onclick="_nearFacGo(${n.f.id})" style="width:26px;height:26px;border-radius:50%;background:${col}30;border:1.5px solid ${col};display:inline-flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;cursor:pointer;">${_esc(n.f.type.split(' ')[0])}</span>
      <span onclick="_nearFacGo(${n.f.id})" style="flex:1;min-width:0;cursor:pointer;">
        <span style="display:block;font-size:12px;font-weight:700;color:#dceaf6;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${_esc(n.f.name)} ${cg?`<span style="color:${_gColor(cg.g)};font-size:10.5px;font-weight:900;">${_esc(cg.g)}</span>`:''}</span>
        <span style="display:block;font-size:9.5px;color:#5d86a3;">${_esc(n.f.type.split(' ').slice(1).join(' ')||'')} · <b style="color:#a5abb3;">${dist}</b>${n.chk?` · <span style="color:#5fcf8f;">✓ ${new Date(n.chk).toLocaleDateString('ko-KR',{month:'2-digit',day:'2-digit'})} 점검</span>`:''}</span>
      </span>
      <button onclick="document.getElementById('nearFacOv').remove();openFacIssueReport(${n.f.id})" style="flex-shrink:0;padding:6px 11px;border-radius:8px;border:1px solid rgba(255,255,255,.35);background:rgba(255,255,255,.12);color:#3182f6;font-size:11px;font-weight:800;cursor:pointer;-webkit-appearance:none;appearance:none;">🔧 점검</button>
    </div>`;
  }).join('');
  ov.innerHTML=`
    <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 13px 7px;flex-shrink:0;">
      <span style="font-size:12px;font-weight:800;color:#a5abb3;">📍 내 주변 시설물 <span style="font-size:9px;color:#565f6b;font-weight:600;">1km 이내 ${near.length}개 · 가까운 순</span></span>
      <button onclick="document.getElementById('nearFacOv').remove()" style="background:none;border:none;color:rgba(255,255,255,.45);font-size:18px;cursor:pointer;padding:0 2px;line-height:1;">×</button>
    </div>
    <div style="overflow-y:auto;padding:0 13px 10px;">${rows}</div>`;
  const host=document.querySelector('#v-inspect-map .mapwrap')||document.getElementById('v-inspect-map');
  (host||document.body).appendChild(ov);
}
function _nearFacGo(id){
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  const nv=document.getElementById('nearFacOv');if(nv)nv.remove();
  try{if(mapI&&f.lat){mapI.setLevel(Math.min(mapI.getLevel(),4));mapI.panTo(new kakao.maps.LatLng(f.lat,f.lng));}}catch(e){}
  openFacFromMap(id);
}
// ── 개별 시설 숨김 토글 (권한자만) — 일반 사용자에게 이 시설만 안 보이게 ──
function toggleFacHide(id){
  if(!_canManageFac()){toast('⚠️ 탐방시설과·개발자만 가능');return;}
  const facs=DB.g('facilities')||[];const idx=facs.findIndex(x=>x.id===id);if(idx<0)return;
  facs[idx].hidden=!facs[idx].hidden;
  DB.s('facilities',facs);
  try{renderInspectMap();}catch(e){}try{renderFacList();}catch(e){}
  try{if(typeof _syncRFacPool==='function')_syncRFacPool();}catch(e){}
  try{_refreshFacSurface(id);}catch(e){}
  toast(facs[idx].hidden?'🙈 일반 사용자에게 숨김':'👁️ 다시 표시');
}
// 열려 있는 화면(지도 팝업 또는 상세 모달)만 새로고침 — 지도에서 눌렀는데 모달이 뜨는 것 방지
function _refreshFacSurface(id){
  const fp=document.getElementById('facPopup');
  if(fp&&fp.classList.contains('on')){openFacFromMap(id);return;}
  const md=document.getElementById('modalFacDetail');
  if(md&&md.classList.contains('on'))openFacDetail(id);
}
function setMapFacF(t,v){
  const set=t==='s'?facMapStatusF:t==='t'?facMapTypeF:t==='g'?facMapGradeF:facMapLocF;
  if(set.has(v))set.delete(v);else set.add(v);
  _persistFilters();renderInspectMap();renderFacList();
}
function _smfs(t,v){setMapFacF(t,v);}
// 섹션별 '전체' 칩 — 아무것도 선택 안 됐을 때 켜져 보이고, 누르면 그 섹션 선택 해제(=전체 표시)
function _smfsAll(t){
  const set=t==='s'?facMapStatusF:t==='t'?facMapTypeF:t==='g'?facMapGradeF:facMapLocF;
  set.clear();_persistFilters();renderInspectMap();renderFacList();
}
function _srfAll(k){
  if(k==='t')resTypeF=new Set();else resStatusF=new Set();
  _persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();
}
function _filterAllChip(set,onclick){
  const on=set.size===0;
  const c=on?'#7ec8a0':'rgba(255,255,255,.5)';
  return `<span onclick="${onclick}" style="display:inline-block;margin:2px 2px;padding:3px 8px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;border:1.5px solid ${on?c:'rgba(255,255,255,.12)'};color:${on?c:'rgba(255,255,255,.35)'};background:${on?c+'22':'transparent'};">${on?'✓ ':''}전체</span>`;
}
// 필터 패널 공용 헬퍼 (시설물지도/시설물목록/구조필터 3곳에서 동일 템플릿 사용)
function _filterChip(label,set,val,onclick,col){
  const on=set.has(val);
  const c=col||(on?'#3182f6':'rgba(255,255,255,.5)');
  return `<span onclick="${onclick}" style="display:inline-block;margin:2px 2px;padding:3px 8px;border-radius:20px;font-size:10px;font-weight:600;cursor:pointer;border:1.5px solid ${on?c:'rgba(255,255,255,.12)'};color:${on?c:'rgba(255,255,255,.35)'};background:${on?c+'22':'transparent'};">${label}</span>`;
}
function _filterSec(id,title,html,set,extraCnt){
  const el=document.getElementById(id);if(!el)return;
  const cnt=(set?set.size:0)+(extraCnt||0),open=window._fpSec&&window._fpSec[id];
  el.innerHTML=`
    <div onclick="_toggleFPSec('${id}')"
      style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);cursor:pointer;user-select:none;">
      <span style="font-size:11px;font-weight:700;color:#a5abb3;">${title}${cnt?` <span style="color:#e05050;font-size:10px;">(${cnt})</span>`:''}</span>
      <b style="font-size:13px;color:#454e5a;font-weight:400;">${open?'⌄':'›'}</b>
    </div>
    <div style="display:${open?'block':'none'};padding:4px 0 2px;">${html}</div>`;
}
function _updateInspFilterPanel(types,locs){
  _filterSec('inspFP_status','경고표시',
    _filterChip('⚠️ 경고표시만',facMapStatusF,'warn',`_smfs('s','warn')`,'#e05050'),facMapStatusF);
  _filterSec('inspFP_grade','안전등급',
    _filterAllChip(facMapGradeF,`_smfsAll('g')`)+['A','B','C','D','E'].map(g=>_filterChip(g+' '+_gLabel(g),facMapGradeF,g,`_smfs('g','${g}')`,_gColor(g))).join(''),facMapGradeF);
  _filterSec('inspFP_type','종류',
    _filterAllChip(facMapTypeF,`_smfsAll('t')`)+types.filter(t=>t!=='전체').map(v=>_filterChip(v,facMapTypeF,v,`_smfs('t','${v.replace(/'/g,"\\'")}')`,'#3182f6')).join(''),facMapTypeF);
  _filterSec('inspFP_loc','위치 (구간)',
    _filterAllChip(facMapLocF,`_smfsAll('l')`)+locs.filter(v=>v!=='전체').map(v=>_filterChip(_zoneLbl(v),facMapLocF,v,`_smfs('l','${v.replace(/'/g,"\\'")}')`,'#9b59b6')).join(''),facMapLocF);
  // 배지/카운트 업데이트
  const total=facMapStatusF.size+facMapTypeF.size+facMapLocF.size+facMapGradeF.size;
  ['inspFilterBadge','facListFilterBadge'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.style.display=total?'inline-flex':'none';if(total)el.textContent=total;});
  ['inspFilterCount','facListFilterCount'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.textContent=total?`(${total})`:'';});
}
function _toggleFPSec(id){
  if(!window._fpSec)window._fpSec={};
  window._fpSec[id]=!window._fpSec[id];
  const el=document.getElementById(id);if(!el)return;
  const body=el.children[1],arrow=el.querySelector('b');
  if(body)body.style.display=window._fpSec[id]?'block':'none';
  if(arrow)arrow.textContent=window._fpSec[id]?'⌄':'›';
}
// 바텀시트 드래그 닫기(팀 시트 등 아래에서 뜨는 시트용 — 필터 패널은 드롭다운으로 전환되어 미사용)
function _initFPDrag(hId,pId,closeFn){
  const h=document.getElementById(hId),p=document.getElementById(pId);
  if(!h||!p||h._fpBound)return;h._fpBound=true;
  let y0=0,t0=0;
  const mv=e=>{const y=(e.touches?e.touches[0]:e).clientY;p.style.transform=`translateY(${Math.max(0,y-y0)}px)`;};
  const up=e=>{
    const y=(e.changedTouches?e.changedTouches[0]:e).clientY;
    const dist=y-y0,dt=Date.now()-t0,vel=dt>0?dist/dt:0;
    p.style.transition='transform .22s cubic-bezier(.4,0,.2,1)';
    if(dist>40||(dist>12&&vel>0.4))closeFn();else p.style.transform='translateY(0)';
    document.removeEventListener('mousemove',mv);document.removeEventListener('mouseup',up);
  };
  h.addEventListener('touchstart',e=>{y0=e.touches[0].clientY;t0=Date.now();p.style.transition='none';},{passive:true});
  h.addEventListener('touchmove',mv,{passive:true});
  h.addEventListener('touchend',up);
  h.addEventListener('mousedown',e=>{y0=e.clientY;t0=Date.now();p.style.transition='none';document.addEventListener('mousemove',mv);document.addEventListener('mouseup',up);e.preventDefault();});
}
// 필터 패널 = 버튼 '바로 아래' 드롭다운 — 버튼은 위에 있는데 패널이 아래에서 떠서 안 보이던 문제 해결
function _fpOpen(pId,updateFn){
  const p=document.getElementById(pId);if(!p)return;
  p.style.display='flex';
  p.style.transition='none';p.style.transform='translateY(-10px)';p.style.opacity='0';
  if(updateFn)try{updateFn();}catch(e){}
  requestAnimationFrame(()=>{p.style.transition='transform .2s ease,opacity .2s ease';p.style.transform='translateY(0)';p.style.opacity='1';});
}
function _fpClose(pId){
  const p=document.getElementById(pId);if(!p)return;
  p.style.transition='transform .18s ease,opacity .18s ease';
  p.style.transform='translateY(-10px)';p.style.opacity='0';
  setTimeout(()=>{p.style.display='none';p.style.transform='translateY(0)';p.style.opacity='1';},180);
}
function toggleInspFilter(){
  const p=document.getElementById('inspFilterPanel');
  if(p.style.display==='flex')closeInspFilter();else _fpOpen('inspFilterPanel');
}
function closeInspFilter(){_fpClose('inspFilterPanel');}
function resetInspFilter(){
  facMapStatusF=new Set();facMapTypeF=new Set();facMapLocF=new Set();facMapGradeF=new Set();
  renderInspectMap();renderFacList();
}
// ─── 시설물 목록 필터 ───
function toggleFacListFilter(){
  const p=document.getElementById('facListFilterPanel');
  if(p.style.display==='flex')_closeFacListFilter();else _fpOpen('facListFilterPanel',_updateFacListFilterPanel);
}
function _closeFacListFilter(){_fpClose('facListFilterPanel');}
function resetFacListFilter(){
  facMapStatusF=new Set();facMapTypeF=new Set();facMapLocF=new Set();facMapGradeF=new Set();facListSort='default';
  _persistFilters();renderInspectMap();renderFacList();
}
function _updateFacListFilterPanel(types,locs){
  if(!types||!locs){
    const _a=isAdminUser();const _m2=DB.g('catFacMeta')||{};
    const _f=(DB.g('facilities')||[]).filter(f=>_a||!(_m2[f.type]||{}).adminOnly);
    types=types||[...(new Set(_f.map(f=>f.type.split(' ').slice(1).join(' ')||f.type).filter(Boolean)))];
    const _sf2=(DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판'));
    locs=locs||[...new Set(_sf2.map(f=>(f.name.match(/\d+/)||[''])[0]).filter(Boolean))].sort();
  }
  {const _se=document.getElementById('facLFP_sort');if(_se)_se.innerHTML='';} // 점검 정렬 제거
  _filterSec('facLFP_status','경고표시',_filterChip('⚠️ 경고표시만',facMapStatusF,'warn',`_smfs('s','warn');renderFacList();`,'#e05050'),facMapStatusF);
  _filterSec('facLFP_grade','안전등급',_filterAllChip(facMapGradeF,`_smfsAll('g')`)+['A','B','C','D','E'].map(g=>_filterChip(g+' '+_gLabel(g),facMapGradeF,g,`_smfs('g','${g}');renderFacList();`,_gColor(g))).join(''),facMapGradeF);
  _filterSec('facLFP_type','종류',_filterAllChip(facMapTypeF,`_smfsAll('t')`)+(types||[]).map(v=>_filterChip(v,facMapTypeF,v,`_smfs('t','${v.replace(/'/g,"\\'")}');renderFacList();`,'#3182f6')).join(''),facMapTypeF);
  _filterSec('facLFP_loc','위치 (구간)',_filterAllChip(facMapLocF,`_smfsAll('l')`)+(locs||[]).map(v=>_filterChip(_zoneLbl(v),facMapLocF,v,`_smfs('l','${v.replace(/'/g,"\\'")}');renderFacList();`,'#9b59b6')).join(''),facMapLocF);
  const total=facMapStatusF.size+facMapTypeF.size+facMapLocF.size+facMapGradeF.size;
  ['facListFilterBadge'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.style.display=total?'inline-flex':'none';if(total)el.textContent=total;});
  const fc=document.getElementById('facListFilterCount');if(fc)fc.textContent=total?`(${total})`:'';
}
// ─── 재난/구조 필터 ───
function _updateResFilterPanels(){
  const dateActive=(resDateFrom||resDateTo)?1:0;
  // 지도 배지=전체 필터 수 / 목록 배지=날짜만 (목록은 상태·종류 필터를 적용하지 않음 — 항상 진행중+종료 표시)
  const totalMap=resTypeF.size+resStatusF.size+dateActive;
  {const el=document.getElementById('resMapFilterBadge');if(el){el.style.display=totalMap?'inline-flex':'none';if(totalMap)el.textContent=totalMap;}}
  {const el=document.getElementById('resMapFilterCount');if(el)el.textContent=totalMap?`(${totalMap})`:'';}
  {const el=document.getElementById('resListFilterBadge');if(el){el.style.display=dateActive?'inline-flex':'none';if(dateActive)el.textContent=dateActive;}}
  {const el=document.getElementById('resListFilterCount');if(el)el.textContent=dateActive?`(${dateActive})`:'';}
  const inpSt='background:#16161a;color:#3182f6;border:1px solid rgba(255,255,255,.3);border-radius:6px;padding:5px 6px;font-size:11px;width:100%;box-sizing:border-box;';
  const dateHtml=`<div style="display:flex;gap:6px;align-items:center;margin-top:4px;">
    <input type="date" value="${resDateFrom}" style="${inpSt}" onchange="setResDate('from',this.value)">
    <span style="color:rgba(255,255,255,.3);font-size:11px;flex-shrink:0;">~</span>
    <input type="date" value="${resDateTo}" style="${inpSt}" onchange="setResDate('to',this.value)">
  </div>`;
  const typeHtml=_filterAllChip(resTypeF,`_srfAll('t')`)+[{v:'🚨구조',l:'🚨 구조보고'}].concat((typeof _HAZ_OFF!=='undefined'&&_HAZ_OFF)?[]:[{v:'⚠️위험상황',l:'⚠️ 위험상황'}]).map(({v,l})=>_filterChip(l,resTypeF,v,`setResTypeF('${v}')`)).join('');
  const stHtml=_filterAllChip(resStatusF,`_srfAll('s')`)+[{v:'진행중',l:'🔴 진행중/미조치'},{v:'종료',l:'✅ 종료/완료'}].map(({v,l})=>_filterChip(l,resStatusF,v,`setResStatusF('${v}')`)).join('');
  ['resMFP_date','resLFP_date'].forEach(id=>_filterSec(id,'📅 날짜',dateHtml,null,dateActive));
  _filterSec('resMFP_type','종류',typeHtml,resTypeF);
  _filterSec('resMFP_status','상태',stHtml,resStatusF);
  // 목록 패널에서는 종류·상태 섹션 제거 — 목록은 항상 진행중+종료 전부 표시(지도만 필터)
  ['resLFP_type','resLFP_status'].forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML='';});
  _syncOngoingBtn();
}
// 지도 '🔴 진행중' 토글 — 현재 사고만 보기 (상태 필터를 진행중 단독으로)
function toggleOngoingOnly(){
  const on=resStatusF.size===1&&resStatusF.has('진행중');
  resStatusF=on?new Set():new Set(['진행중']);
  _persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();
}
function _syncOngoingBtn(){
  const b=document.getElementById('resOngoingBtn');if(!b)return;
  const on=resStatusF.size===1&&resStatusF.has('진행중');
  b.style.background=on?'rgba(231,76,60,.92)':'rgba(11,28,48,.85)';
  b.style.color=on?'#fff':'#ff8a73';
  b.style.borderColor=on?'#ff5a45':'rgba(231,76,60,.5)';
}
function setResDate(which,v){
  if(which==='from')resDateFrom=v;else resDateTo=v;
  _maybeLoadArchiveForDateFilter();
  _updateResFilterPanels();renderRescueMap();renderResList();
}
// 조회 시작일이 보관 기준(1년)보다 앞이면 과거 기록을 1회 불러온 뒤 다시 그린다
function _maybeLoadArchiveForDateFilter(){
  if(!resDateFrom)return;
  const cutoff=new Date(Date.now()-_ARCHIVE_CUTOFF_DAYS*86400000).toISOString().slice(0,10);
  if(resDateFrom>=cutoff)return;
  Promise.all(['rescues','hazards'].map(_loadArchive)).then(()=>{renderRescueMap();renderResList();});
}
function setResTypeF(v){if(resTypeF.has(v))resTypeF.delete(v);else resTypeF.add(v);_persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();}
function setResStatusF(v){if(resStatusF.has(v))resStatusF.delete(v);else resStatusF.add(v);_persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();}
function resetResFilter(){resTypeF=new Set();resStatusF=new Set();const _d=_resDefaultDates();resDateFrom=_d.from;resDateTo=_d.to;_persistFilters();_updateResFilterPanels();renderRescueMap();renderResList();}
// 시설물 카테고리 필터
function _updateResCatFilterPanel(){
  const _rm=DB.g('catFacMeta')||{};
  const rescueCats=(DB.g('catFac')||[]).filter(c=>(_rm[c]||{}).rescue);
  const defSet=new Set(_RES_DEFAULT_CATS);
  const catBadge=resFacCatH.size+resFacCatF.size;
  const el=document.getElementById('resCatFilterBadge');
  if(el){el.style.display=catBadge?'inline-flex':'none';if(catBadge)el.textContent=catBadge;}
  const cntEl=document.getElementById('resCatFilterCount');
  if(cntEl)cntEl.textContent=catBadge?`(${catBadge})`:'';
  const mkRow=(c,isDefault)=>{
    const active=isDefault?!resFacCatH.has(c):resFacCatF.has(c);
    const col=active?'#3182f6':'rgba(255,255,255,.25)';
    return `<div onclick="toggleResFacCat('${c.replace(/'/g,"\\'")}',${isDefault})" style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);cursor:pointer;">
      <div style="width:22px;height:22px;border-radius:50%;border:2px solid ${col};display:flex;align-items:center;justify-content:center;font-size:10px;color:${col};flex-shrink:0;">${active?'✓':''}</div>
      <span style="font-size:12px;color:${active?'#eaecef':'rgba(255,255,255,.35)'};">${c}</span>
      ${isDefault?'<span style="font-size:9px;color:#454e5a;margin-left:auto;">기본</span>':''}
    </div>`;
  };
  const defCats=rescueCats.filter(c=>defSet.has(c));
  const otherCats=rescueCats.filter(c=>!defSet.has(c));
  const wrap=document.getElementById('resCFPContent');
  if(!wrap)return;
  wrap.innerHTML=(defCats.length?`<div style="font-size:10px;color:#454e5a;padding:6px 0 2px;font-weight:600;">기본 표시</div>${defCats.map(c=>mkRow(c,true)).join('')}`:'')
    +(otherCats.length?`<div style="font-size:10px;color:#454e5a;padding:8px 0 2px;font-weight:600;">추가 표시 (기본 OFF)</div>${otherCats.map(c=>mkRow(c,false)).join('')}`:'')
    +(rescueCats.length===0?'<div style="font-size:12px;color:rgba(255,255,255,.2);padding:12px 0;">재난지도 표시 카테고리 없음</div>':'');
}
function toggleResFacCat(type,isDefault){
  if(isDefault){if(resFacCatH.has(type))resFacCatH.delete(type);else resFacCatH.add(type);}
  else{if(resFacCatF.has(type))resFacCatF.delete(type);else resFacCatF.add(type);}
  _updateResCatFilterPanel();_applyRFacFilter();
}
function resetResCatFilter(){resFacCatH=new Set();resFacCatF=new Set();_updateResCatFilterPanel();_applyRFacFilter();}
function toggleResCatFilter(){
  const p=document.getElementById('resCatFilterPanel');
  if(p.style.display==='flex')_closeResCatFilter();else{_fpOpen('resCatFilterPanel',_updateResCatFilterPanel);_closeResMapFilter();}
}
function _closeResCatFilter(){_fpClose('resCatFilterPanel');}
function toggleResMapFilter(){
  const p=document.getElementById('resMapFilterPanel');
  if(p.style.display==='flex')_closeResMapFilter();else{_fpOpen('resMapFilterPanel',_updateResFilterPanels);_closeResCatFilter();}
}
function _closeResMapFilter(){_fpClose('resMapFilterPanel');}
function toggleResListFilter(){
  const p=document.getElementById('resListFilterPanel');
  if(p.style.display==='flex')_closeResListFilter();else _fpOpen('resListFilterPanel',_updateResFilterPanels);
}
function _closeResListFilter(){_fpClose('resListFilterPanel');}

// ═══════════════════════════════════════════════════════════════════
// 🧭 시설물 내비게이션 — GPS로 진행방향 앞쪽 시설물을 "200m 앞 다목적위치표지판 3-5" 음성+화면 안내
//   · 트레일: 앱 내부 직선거리 GPS 안내(등산로 적합, 오프라인 가능)
//   · 도로: 각 시설의 🚗 버튼 → 카카오맵 앱으로 차량 길안내 핸드오프(REST키 불필요)
// ═══════════════════════════════════════════════════════════════════
var _facNav={on:false,watch:null,voice:true,signOnly:false,announced:{},heading:null,lastLa:null,lastLn:null,wake:null,list:[],map:null,meMk:null,meEl:null,line:null,facMks:[],follow:true,sim:null,simIv:null,spdIdx:0,dest:null,trails:null,trailLines:[],audioCtx:null,audioSrc:null,walkRoute:null,walkLoading:false,origin:null,oriMk:null,annOff:{},destPt:null,lineCase:null,lineDone:null,lineCar:null,thMk:null,armPick:false};
// 목적지: _facNav.dest(시설 id) 또는 _facNav.destPt({lat,lng,name}) — 지도 길게눌러 임의 지점
function _fnDestKey(){if(_facNav.dest)return 'f:'+_facNav.dest;if(_facNav.destPt)return 'p:'+(+_facNav.destPt.lat).toFixed(5)+','+(+_facNav.destPt.lng).toFixed(5);return '';}
function _fnDestF(){if(_facNav.dest){var f=(DB.g('facilities')||[]).find(function(x){return String(x.id)===String(_facNav.dest)&&x.lat;});if(f)return f;}if(_facNav.destPt)return{id:null,lat:_facNav.destPt.lat,lng:_facNav.destPt.lng,name:_facNav.destPt.name||'선택 지점',type:'📍 지도 지점'};return null;}
// 출발지: null=내 위치(GPS), 아니면 {id,lat,lng,name} 지정
// ── 카카오 도보(등산로) 실경로 — 프록시(워커) 통해 조회 ──
function _facNavWalkProxy(){return (DB.g('walkProxyUrl')||'').trim().replace(/\/+$/,'');}
// 경로가 지나는(근처 55m) 시설물을 경로 순서대로 — "어디어디 통과" 목록
function _fnRouteWaypoints(path,destId,origin){
  var facs=(DB.g('facilities')||[]).filter(function(f){return f.lat&&f.lng&&String(f.id)!==String(destId)&&(!origin||String(f.id)!==String(origin.id))&&(typeof _facVisibleTo!=='function'||_facVisibleTo(f));});
  var res=[];
  facs.forEach(function(f){var bi=-1,bd=Infinity;for(var i=0;i<path.length;i++){var d=_haversine(f.lat,f.lng,path[i][0],path[i][1]);if(d<bd){bd=d;bi=i;}}if(bd<=55)res.push({id:String(f.id),name:_fnDisp(f).main,type:f.type,idx:bi});});
  res.sort(function(a,b){return a.idx-b.idx;});
  return res.slice(0,50);
}
function _fnRemainWalk(la,ln,path){ // path=[[lat,lng]…] → 현재위치에서 목적지까지 경로상 남은 거리(m)
  var m=_fnMyPathIdx(la,ln,path);
  var c=_fnRemainWalk._c;
  if(!c||c.path!==path){ // 경로별 누적거리 1회 계산 캐시(틱마다 전체 합산 방지)
    var cum=[0];for(var i=1;i<path.length;i++)cum[i]=cum[i-1]+_haversine(path[i-1][0],path[i-1][1],path[i][0],path[i][1]);
    c=_fnRemainWalk._c={path:path,cum:cum};
  }
  return m.md+(c.cum[path.length-1]-c.cum[m.mi]);
}
// 경로 조회 — mode: 'walk' | 'car'  (좌표 la=위도, ln=경도)
async function _facNavFetchRoute(mode,sLa,sLn,eLa,eLn){
  var base=_facNavWalkProxy();if(!base)return null;
  var url=base+'/?mode='+mode+'&start_x='+sLn+'&start_y='+sLa+'&end_x='+eLn+'&end_y='+eLa+(mode==='car'?'':'&route_mode=SHORTEST');
  try{
    var r=await fetch(url);var j=await r.json();
    if(mode==='car'){
      var rt=j&&j.routes&&j.routes[0];
      if(!rt||rt.result_code!==0)return {error:(rt&&rt.result_msg)||(j&&j.status)||'CAR_ERR'};
      var cp=[],cs=[];
      (rt.sections||[]).forEach(function(sec){
        (sec.roads||[]).forEach(function(rd){var v=rd.vertexes||[];for(var i=0;i+1<v.length;i+=2)cp.push([v[i+1],v[i]]);}); // vertexes flat [lng,lat,…]
        (sec.guides||[]).forEach(function(gd){if(gd.guidance&&gd.y!=null)cs.push({g:gd.guidance,lat:gd.y,lng:gd.x,dist:gd.distance||0});});
      });
      return {path:cp,steps:cs,dist:(rt.summary&&rt.summary.distance)||0,time:(rt.summary&&rt.summary.duration)||0};
    }
    if(!j||j.status!=='OK'||!j.route)return {error:(j&&j.status)||'ERR'};
    var pts=[],steps=[];
    (j.route.legs||[]).forEach(function(lg){(lg.steps||[]).forEach(function(st){
      var sp=st.properties||{};
      if(sp.guidance&&sp.y!=null)steps.push({g:sp.guidance,lat:sp.y,lng:sp.x,dist:sp.distance||0});
      ((st.path&&st.path.points)||[]).forEach(function(pt){pts.push([pt[1],pt[0]]);});
    });});
    var pr=j.route.properties||{};
    return {path:pts,steps:steps,dist:pr.totalDistance||0,time:pr.totalTime||0};
  }catch(e){return {error:'NET'};}
}
var _FN_CAR_MIN=300; // 차/도보 각 구간 최소(m)
// 목적지에 가장 가까운 차량 진입점(비선대·백담센터 등)
function _fnTrailhead(target){
  if(!target)return null;
  var cars=(DB.g('facilities')||[]).filter(function(f){return f.lat&&f.lng&&(typeof _fnCarOk==='function'&&_fnCarOk(f));});
  var best=null,bd=Infinity;cars.forEach(function(f){var d=_haversine(target.lat,target.lng,f.lat,f.lng);if(d<bd){bd=d;best=f;}});
  return best?{f:best,lat:best.lat,lng:best.lng,name:_fnDisp(best).main,distToDest:bd}:null;
}
// walkRoute 객체 구성(회전지점 인덱스·경유목록 포함)
function _fnBuildWR(dkey,okey,st,la,ln,path,steps,dist,time,extra){
  var wr={destId:dkey,okey:okey,fixed:st.fixed,fromLa:la,fromLn:ln,path:path,steps:steps,dist:dist,time:time};
  if(extra)for(var k in extra)wr[k]=extra[k];
  steps.forEach(function(sp){var bi=0,bd=Infinity;for(var i=0;i<path.length;i++){var d=_haversine(sp.lat,sp.lng,path[i][0],path[i][1]);if(d<bd){bd=d;bi=i;}}sp.pi=bi;});
  wr.waypoints=_fnRouteWaypoints(path,_facNav.dest,_facNav.origin);
  return wr;
}
function _fnSetWR(res,dkey,okey,st,la,ln){
  if(res&&res.path&&res.path.length)_facNav.walkRoute=_fnBuildWR(dkey,okey,st,la,ln,res.path,res.steps||[],res.dist,res.time,null);
  else _facNav.walkRoute={destId:dkey,okey:okey,fromLa:la,fromLn:ln,path:null,error:(res&&res.error)||'ERR',errAt:Date.now()};
}
// 출발 좌표(지정출발이면 그 좌표, 아니면 내 GPS)
function _facNavStartLL(){var o=_facNav.origin;if(o&&o.lat!=null)return{la:o.lat,ln:o.lng,fixed:true};if(_facNav.lastLa!=null)return{la:_facNav.lastLa,ln:_facNav.lastLn,fixed:false};return null;}
// 목적지 설정/이동 시 도보경로 요청 (지정출발이면 1회, 내 위치면 120m 넘게 이동 시 재요청)
function _facNavRequestWalk(){
  var target=_fnDestF();
  if(!target||!_facNavWalkProxy()){return;}
  var st=_facNavStartLL();if(!st)return;
  var dkey=_fnDestKey();
  var okey=_facNav.origin?('o:'+_facNav.origin.id):'me';
  var wr=_facNav.walkRoute;
  if(wr&&String(wr.destId)===dkey&&wr.okey===okey&&wr.path){
    if(st.fixed)return; // 지정출발은 고정 → 재요청 불필요
    if(_haversine(wr.fromLa,wr.fromLn,st.la,st.ln)<120)return; // 내 위치는 120m 이내면 유지
  }
  if(wr&&String(wr.destId)===dkey&&wr.okey===okey&&!wr.path&&wr.errAt&&(Date.now()-wr.errAt)<15000)return; // 실패 직후엔 15초 쉬고 재시도(틱마다 재요청 폭주 방지)
  if(_facNav.walkLoading)return;
  _facNav.walkLoading=true;var la=st.la,ln=st.ln;
  var finish=function(){_facNav.walkLoading=false;if(_facNav.on&&_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);};
  var walkOnly=function(){_facNavFetchRoute('walk',la,ln,target.lat,target.lng).then(function(w){_fnSetWR(w,dkey,okey,st,la,ln);finish();});};
  // 목적지 자체가 차량 진입 가능(비선대·백담센터 등) → 전 구간 차량
  var destCar=(_facNav.dest&&target.id&&typeof _fnCarOk==='function'&&_fnCarOk(target));
  // 차→도보 멀티모달 판단: 진입점까지 300m↑ 차량, 거기서 목적지까지 300m↑ 도보, 진입점이 목적지에 더 가까움
  var th=(!destCar&&typeof _fnTrailhead==='function')?_fnTrailhead(target):null;
  var meToDest=_haversine(la,ln,target.lat,target.lng);
  var carLeg=th?_haversine(la,ln,th.lat,th.lng):0;
  var multimodal=!!(th&&carLeg>_FN_CAR_MIN&&th.distToDest>_FN_CAR_MIN&&th.distToDest<meToDest-_FN_CAR_MIN);
  if(destCar){
    _facNavFetchRoute('car',la,ln,target.lat,target.lng).then(function(res){
      if(res&&res.path&&res.path.length)_facNav.walkRoute=_fnBuildWR(dkey,okey,st,la,ln,res.path,res.steps||[],res.dist,res.time,{carOnly:true,carEnd:res.path.length});
      else _fnSetWR(res,dkey,okey,st,la,ln); // 차량 실패 → 도보 폴백 없이 그대로(차량전용 목적지)
      finish();
    });
  }else if(multimodal){
    Promise.all([_facNavFetchRoute('car',la,ln,th.lat,th.lng),_facNavFetchRoute('walk',th.lat,th.lng,target.lat,target.lng)]).then(function(rr){
      var car=rr[0],walk=rr[1];
      if(car&&car.path&&car.path.length&&walk&&walk.path&&walk.path.length){
        var path=car.path.concat(walk.path),carEnd=car.path.length;
        var steps=(car.steps||[]).slice();
        steps.push({g:'여기서부터 도보로 이동합니다',lat:th.lat,lng:th.lng,dist:0,walk:true});
        (walk.steps||[]).forEach(function(s){steps.push(s);});
        _facNav.walkRoute=_fnBuildWR(dkey,okey,st,la,ln,path,steps,(car.dist||0)+(walk.dist||0),(car.time||0)+(walk.time||0),{multi:true,carEnd:carEnd,thName:th.name,thLat:th.lat,thLng:th.lng,carDist:car.dist||0,carTime:car.time||0,walkDist:walk.dist||0,walkTime:walk.time||0});
        finish();
      }else walkOnly(); // 차 또는 도보 실패 → 도보 단독 폴백
    });
  }else walkOnly();
}
function _fnCleanGuide(g){return String(g||'').replace(/^.*?까지\s*/,'').trim();} // "…대피소까지 오른쪽으로 972m 이동"→"오른쪽으로 972m 이동"
function _fnTimeStr(sec){sec=+sec||0;var h=Math.floor(sec/3600),m=Math.round((sec%3600)/60);return h?(h+'시간 '+m+'분'):(m+'분');}
function _fnWalkActive(){var wr=_facNav.walkRoute,dk=_fnDestKey();return !!(dk&&wr&&wr.path&&wr.path.length&&String(wr.destId)===dk);}
// 카카오 도보 턴바이턴: 회전지점 접근 시 안내문 음성(지점당 1회)
function _facNavWalkGuide(la,ln){
  var wr=_facNav.walkRoute;if(!wr||!wr.steps||!_facNav.voice)return;
  for(var i=0;i<wr.steps.length;i++){var s=wr.steps[i];if(s.lat==null)continue;
    var key='step:'+wr.destId+':'+i;if(_facNav.announced[key])continue;
    if(_haversine(la,ln,s.lat,s.lng)<35){_facNav.announced[key]=1;var g=_fnCleanGuide(s.g);if(g)_facNavSpeak(g);}
  }
}
// 화면 꺼짐/백그라운드에서 더 오래 유지 — 무음 오디오 루프(안드로이드 WebView가 '재생 중'으로 보고 프로세스 유지)
function _facNavKeepAlive(on){
  try{
    if(on){
      if(!_facNav.audioCtx){var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;_facNav.audioCtx=new AC();var buf=_facNav.audioCtx.createBuffer(1,_facNav.audioCtx.sampleRate,_facNav.audioCtx.sampleRate);var src=_facNav.audioCtx.createBufferSource();src.buffer=buf;src.loop=true;src.connect(_facNav.audioCtx.destination);src.start();_facNav.audioSrc=src;}
      if(_facNav.audioCtx.resume)_facNav.audioCtx.resume();
    }else{
      try{_facNav.audioSrc&&_facNav.audioSrc.stop();}catch(e){}
      try{_facNav.audioCtx&&_facNav.audioCtx.close();}catch(e){}
      _facNav.audioCtx=null;_facNav.audioSrc=null;
    }
  }catch(e){}
}
var _FN_TH=[1000,500,300,150,80,30]; // 안내 거리 임계(내림차순)
var _FN_SPD=[{k:'🚶 느림',v:1.4},{k:'🏃 보통',v:5},{k:'🚗 빠름',v:13}]; // 시뮬 속도(m/s)
var _FN_SIM_MS=450; // 시뮬 틱(ms)
function _fnBearing(la1,ln1,la2,ln2){var r=Math.PI/180;var y=Math.sin((ln2-ln1)*r)*Math.cos(la2*r);var x=Math.cos(la1*r)*Math.sin(la2*r)-Math.sin(la1*r)*Math.cos(la2*r)*Math.cos((ln2-ln1)*r);return (Math.atan2(y,x)/r+360)%360;}
function _fnRel(b,h){if(h==null||isNaN(h))return null;return ((b-h+540)%360)-180;} // +우측 / -좌측
function _fnIsSign(f){return !!(f.type&&f.type.indexOf('다목적위치표지판')>=0);}
function _fnCode(f){var m=String(f.name||'').match(/\d{2}-\d{1,3}/);return m?m[0]:'';}
function _fnDisp(f){ // 화면 표시용
  if(_fnIsSign(f)){var c=_fnCode(f);return{main:'다목적위치표지판 '+(c||String(f.name||'').trim()),sub:_facZoneLbl?(_facZoneLbl(f)||''):''};}
  return{main:String(f.name||f.type||'시설').trim(),sub:(String(f.type||'').split(' ').slice(1).join(' ')||f.type||'')};
}
var _FN_DIGIT={'0':'공','1':'일','2':'이','3':'삼','4':'사','5':'오','6':'육','7':'칠','8':'팔','9':'구'};
function _fnNumK(n){if(n===0)return '공';var d=['','일','이','삼','사','오','육','칠','팔','구'],s='',h=Math.floor(n/100),t=Math.floor((n%100)/10),o=n%10;if(h)s+=(h>1?d[h]:'')+'백';if(t)s+=(t>1?d[t]:'')+'십';if(o)s+=d[o];return s;}
// 0으로 시작하면 자리수대로(공삼), 아니면 수로(10=십, 108=백팔) · - 는 다시
function _fnSegSpeak(seg){if(/^0/.test(seg))return seg.split('').map(function(ch){return _FN_DIGIT[ch]||ch;}).join('');var n=parseInt(seg,10);return isNaN(n)?seg:_fnNumK(n);}
function _fnCodeSpeak(code){return String(code||'').split('-').map(_fnSegSpeak).join('다시');} // 03-05→공삼다시공오 · 10-10→십다시십
function _fnSay(f){ // 음성용 라벨(짧게)
  if(_fnIsSign(f)){var c=_fnCode(f);return '표지판 '+(c?_fnCodeSpeak(c):'');}
  return (String(f.type||'시설').split(/[ /]/)[0]);
}
function _fnDistTxt(d){return d>=1000?(d/1000).toFixed(1)+'킬로미터':(Math.round(d/10)*10)+'미터';}
function _fnDistShort(d){return d>=1000?(d/1000).toFixed(1)+'km':Math.round(d)+'m';}
var _fnVoice=null;
function _facNavLoadVoices(){
  try{var vs=(window.speechSynthesis&&window.speechSynthesis.getVoices())||[];if(!vs.length)return;
    var ko=vs.filter(function(v){return /ko(-|_)?kr/i.test(v.lang)||/korea|한국/i.test(v.name);});
    if(!ko.length){_fnVoice=null;return;}
    var pri=['yuna','유나','sora','소라','nara','heami','google','microsoft','samsung'];
    ko.sort(function(a,b){function s(v){var n=(v.name||'').toLowerCase();for(var i=0;i<pri.length;i++)if(n.indexOf(pri[i])>=0)return i;return 50;}return s(a)-s(b);});
    _fnVoice=ko[0];
  }catch(e){}
}
function _facNavSpeak(t){try{if(!('speechSynthesis'in window))return;var u=new SpeechSynthesisUtterance(t);u.lang='ko-KR';if(_fnVoice)u.voice=_fnVoice;u.rate=0.96;u.pitch=1.0;window.speechSynthesis.cancel();window.speechSynthesis.speak(u);}catch(e){}}
function openFacNav(){
  var facs=(DB.g('facilities')||[]).filter(function(f){return f.lat&&f.lng;});
  if(!facs.length){toast('⚠️ 좌표가 등록된 시설물이 없습니다');return;}
  if(!navigator.geolocation){toast('⚠️ 이 기기는 GPS 미지원');return;}
  var ov=document.getElementById('facNavOv');if(ov)ov.remove();
  ov=document.createElement('div');ov.id='facNavOv';
  ov.style.cssText='position:fixed;inset:0;z-index:9700;background:#0b0e13;display:flex;flex-direction:column;color:#eef0f2;';
  ov.innerHTML=''+
  '<div style="display:flex;align-items:center;gap:8px;padding:calc(8px + env(safe-area-inset-top)) 12px 9px;border-bottom:1px solid rgba(255,255,255,.12);flex-shrink:0;">'+
    '<button onclick="history.back()" style="background:none;border:none;color:#3182f6;font-size:14px;font-weight:800;cursor:pointer;">← 닫기</button>'+
    '<span style="font-size:15px;font-weight:800;">🧭 시설물 내비</span>'+
    '<span style="flex:1;"></span>'+
    '<button id="fnSimBtn" onclick="facNavSimToggle()" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);color:#eef0f2;border-radius:8px;padding:5px 9px;font-size:11px;font-weight:800;cursor:pointer;">🧪 시뮬</button>'+
    '<button id="fnAnnBtn" onclick="facNavAnnSheet()" title="울림 대상 시설물" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);color:#eef0f2;border-radius:8px;padding:5px 9px;font-size:11px;font-weight:800;cursor:pointer;">🔔</button>'+
    '<button id="fnVoiceBtn" onclick="facNavToggleVoice()" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);color:#eef0f2;border-radius:8px;padding:5px 9px;font-size:11px;font-weight:800;cursor:pointer;">🔊 음성</button>'+
    '<button id="fnSignBtn" onclick="facNavToggleSign()" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);color:#eef0f2;border-radius:8px;padding:5px 9px;font-size:11px;font-weight:800;cursor:pointer;">전체</button>'+
  '</div>'+
  '<div id="fnMap" style="flex:0 0 44%;min-height:180px;background:#0c0f14;position:relative;">'+
    '<button onclick="_facNavRecenter()" title="내 위치로" style="position:absolute;right:9px;bottom:9px;z-index:5;width:40px;height:40px;border-radius:50%;background:#1c1c1e;color:#3182f6;border:1.5px solid rgba(255,255,255,.35);font-size:16px;cursor:pointer;">📍</button>'+
    '<div id="fnTurnBanner" style="display:none;position:absolute;left:8px;right:8px;top:8px;z-index:6;background:rgba(11,31,58,.95);border:1px solid rgba(61,139,255,.55);border-radius:13px;padding:9px 13px;align-items:center;gap:11px;box-shadow:0 5px 18px rgba(0,0,0,.55);"></div>'+
  '</div>'+
  '<div style="flex-shrink:0;display:flex;align-items:center;gap:6px;padding:6px 12px;border-bottom:1px solid rgba(255,255,255,.08);background:#0c0f14;">'+
    '<span style="font-size:10.5px;color:#8b95a1;font-weight:700;white-space:nowrap;">🧪 시뮬 속도</span>'+
    '<button id="fnSpd0" onclick="facNavSetSpeed(0)" style="flex:1;padding:6px 2px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#c9dcec;font-size:11px;font-weight:800;cursor:pointer;">🚶 느림</button>'+
    '<button id="fnSpd1" onclick="facNavSetSpeed(1)" style="flex:1;padding:6px 2px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#c9dcec;font-size:11px;font-weight:800;cursor:pointer;">🏃 보통</button>'+
    '<button id="fnSpd2" onclick="facNavSetSpeed(2)" style="flex:1;padding:6px 2px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#c9dcec;font-size:11px;font-weight:800;cursor:pointer;">🚗 빠름</button>'+
  '</div>'+
  '<div style="flex-shrink:0;padding:8px 12px 9px;border-bottom:1px solid rgba(255,255,255,.08);background:#0c0f14;position:relative;">'+
    '<div style="display:flex;gap:6px;align-items:center;margin-bottom:6px;">'+
      '<span style="font-size:10px;font-weight:800;color:#8fd6a8;width:26px;flex-shrink:0;">출발</span>'+
      '<input id="fnStartSearch" oninput="facNavSearch(this.value,\'origin\')" placeholder="📍 내 위치 (바꾸려면 검색)" style="flex:1;min-width:0;box-sizing:border-box;background:#141a15;color:#eef0f2;border:1px solid rgba(94,207,143,.28);border-radius:9px;padding:8px 10px;font-size:12px;">'+
      '<button onclick="facNavResetOrigin()" title="내 위치로" style="flex-shrink:0;background:rgba(94,207,143,.14);color:#8fe0ab;border:1px solid rgba(94,207,143,.3);border-radius:8px;padding:7px 9px;font-size:12px;cursor:pointer;">📍</button>'+
    '</div>'+
    '<div style="display:flex;gap:6px;align-items:center;">'+
      '<span style="font-size:10px;font-weight:800;color:#ff9a90;width:26px;flex-shrink:0;">도착</span>'+
      '<input id="fnSearch" oninput="facNavSearch(this.value,\'dest\')" placeholder="🔍 목적지 검색 (봉정암·비선대·10-16 …)" style="flex:1;min-width:0;box-sizing:border-box;background:#16161a;color:#eef0f2;border:1px solid rgba(255,255,255,.2);border-radius:9px;padding:8px 10px;font-size:12px;">'+
      '<button id="fnMapPickBtn" onclick="facNavArmMapPick()" title="지도에서 지점 찍기" style="flex-shrink:0;background:rgba(255,90,70,.14);color:#ff9a90;border:1px solid rgba(255,90,70,.3);border-radius:8px;padding:7px 9px;font-size:12px;cursor:pointer;">🗺️</button>'+
    '</div>'+
    '<div id="fnSearchRes" style="position:absolute;left:12px;right:12px;top:82px;z-index:9;background:#16161a;border:1px solid rgba(255,255,255,.18);border-radius:10px;max-height:220px;overflow-y:auto;box-shadow:0 12px 28px rgba(0,0,0,.72);display:none;"></div>'+
  '</div>'+
  '<div style="flex:1;overflow-y:auto;padding:12px 14px;">'+
    '<div id="fnPrimary" style="text-align:center;padding:6px 10px 10px;">'+
      '<div style="font-size:12px;color:#8b95a1;">GPS 잡는 중…</div>'+
    '</div>'+
    '<div id="fnList" style="margin-top:6px;"></div>'+
    '<div id="fnAcc" style="text-align:center;font-size:10.5px;color:#565f6b;margin-top:12px;"></div>'+
    '<div style="text-align:center;font-size:10.5px;color:#565f6b;margin-top:6px;line-height:1.7;">지도에 내 위치(파란 화살표)·목적지까지 파란 경로선.<br>진행방향 앞 시설을 음성 안내 · 지도 길게눌러 임의 지점 지정.</div>'+
  '</div>'+
  '<div id="fnBottomBar" style="display:none;flex-shrink:0;align-items:center;gap:10px;padding:10px 16px calc(10px + env(safe-area-inset-bottom));border-top:1px solid rgba(255,255,255,.12);background:#0c0f14;"></div>';
  (document.getElementById('app')||document.body).appendChild(ov);
  try{history.pushState({view:'facnav'},'','');}catch(e){}
  _facNav.on=true;_facNav.announced={};_facNav.heading=null;_facNav.lastLa=null;_facNav.lastLn=null;
  _facNav._priKey='';_facNav._listKey=null;_facNav._mkKey='';_facNav._fullRef=null;_facNav._fullN=-1;_facNav._doneN=-1; // 렌더 캐시 리셋(재진입 시 스킵 오판 방지)
  _facNavAnnLoad();_facNavSyncBtns();_facNavSpdSync();
  try{_facNavLoadVoices();if(window.speechSynthesis)window.speechSynthesis.onvoiceschanged=_facNavLoadVoices;}catch(e){}
  try{window.speechSynthesis&&window.speechSynthesis.resume();}catch(e){}
  _facNavKeepAlive(true); // 무음 오디오로 백그라운드 유지 시도(안드로이드)
  if(_facNav.voice)_facNavSpeak('시설물 안내를 시작합니다');
  try{if(navigator.wakeLock&&navigator.wakeLock.request)navigator.wakeLock.request('screen').then(function(w){_facNav.wake=w;}).catch(function(){});}catch(e){}
  _facNav.watch=navigator.geolocation.watchPosition(_facNavOnPos,_facNavOnErr,{enableHighAccuracy:true,timeout:20000,maximumAge:1500});
}
function closeFacNav(){
  _facNav.on=false;
  if(_facNav.simIv){clearInterval(_facNav.simIv);_facNav.simIv=null;}_facNav.sim=null;
  _facNavKeepAlive(false);
  try{if(_facNav.watch!=null)navigator.geolocation.clearWatch(_facNav.watch);}catch(e){}_facNav.watch=null;
  var tb=document.getElementById('fnTurnBanner');if(tb)tb.style.display='none';var bb=document.getElementById('fnBottomBar');if(bb)bb.style.display='none';
  try{if(_facNav.thMk)_facNav.thMk.setMap(null);}catch(e){}
  try{_fnMyPathIdx._c=null;_fnRemainWalk._c=null;}catch(e){} // 경로 메모 해제(메모리)
  _facNav.map=null;_facNav.meMk=null;_facNav.meEl=null;_facNav.line=null;_facNav.lineCase=null;_facNav.lineDone=null;_facNav.lineCar=null;_facNav.thMk=null;_facNav.facMks=[];_facNav.trailLines=[];_facNav.dest=null;_facNav.destPt=null;_facNav.oriMk=null;_facNav.origin=null;_facNav.walkRoute=null;
  _facNav._priKey='';_facNav._listKey=null;_facNav._mkKey='';_facNav._fullRef=null;_facNav._fullN=-1;_facNav._doneN=-1;
  try{window.speechSynthesis&&window.speechSynthesis.cancel();}catch(e){}
  try{if(_facNav.wake&&_facNav.wake.release)_facNav.wake.release();}catch(e){}_facNav.wake=null;
  var sh=document.getElementById('fnAnnSheet');if(sh)sh.remove();var wsh=document.getElementById('fnWpSheet');if(wsh)wsh.remove();
  var ov=document.getElementById('facNavOv');if(ov)ov.remove();
}
function facNavToggleVoice(){_facNav.voice=!_facNav.voice;if(!_facNav.voice){try{window.speechSynthesis&&window.speechSynthesis.cancel();}catch(e){}}_facNavSyncBtns();}
function facNavToggleSign(){_facNav.signOnly=!_facNav.signOnly;_facNav.announced={};_facNavSyncBtns();if(_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);}
function _facNavSyncBtns(){
  var v=document.getElementById('fnVoiceBtn');if(v){v.textContent=_facNav.voice?'🔊 음성':'🔇 꺼짐';v.style.background=_facNav.voice?'rgba(94,207,143,.16)':'rgba(255,255,255,.08)';v.style.borderColor=_facNav.voice?'rgba(94,207,143,.5)':'rgba(255,255,255,.2)';v.style.color=_facNav.voice?'#8fe0ab':'#8b95a1';}
  var s=document.getElementById('fnSignBtn');if(s){s.textContent=_facNav.signOnly?'📍 표지판만':'전체';s.style.background=_facNav.signOnly?'rgba(240,184,64,.16)':'rgba(255,255,255,.08)';s.style.borderColor=_facNav.signOnly?'rgba(240,184,64,.5)':'rgba(255,255,255,.2)';s.style.color=_facNav.signOnly?'#f0c060':'#eef0f2';}
  var sm=document.getElementById('fnSimBtn');if(sm){var run=!!_facNav.simIv;sm.textContent=run?'⏹ 시뮬중':'🧪 시뮬';sm.style.background=run?'rgba(255,107,91,.18)':'rgba(255,255,255,.08)';sm.style.borderColor=run?'rgba(255,107,91,.5)':'rgba(255,255,255,.2)';sm.style.color=run?'#ff9a90':'#eef0f2';}
}
function _facNavOnErr(e){var p=document.getElementById('fnPrimary');if(p)p.innerHTML='<div style="font-size:13px;color:#ffb0a0;">⚠️ GPS 오류 — 위치 권한을 확인하세요</div>';}
function _facNavOnPos(pos){
  if(_facNav.simIv)return; // 시뮬 중엔 실제 GPS 무시
  var la=pos.coords.latitude,ln=pos.coords.longitude;
  var hd=(pos.coords.heading!=null&&!isNaN(pos.coords.heading)&&pos.coords.speed>0.6)?pos.coords.heading:null;
  // 헤딩 미제공(정지)이면 직전 위치로 이동방향 추정
  if(hd==null&&_facNav.lastLa!=null){var moved=_haversine(_facNav.lastLa,_facNav.lastLn,la,ln);if(moved>4)hd=_fnBearing(_facNav.lastLa,_facNav.lastLn,la,ln);}
  if(hd!=null)_facNav.heading=hd;
  _facNav.lastLa=la;_facNav.lastLn=ln;
  _facNavCompute(la,ln,_facNav.heading,pos.coords.accuracy);
}
function _facNavCompute(la,ln,hd,acc){
  var facs=(DB.g('facilities')||[]).filter(function(f){return f.lat&&f.lng&&(typeof _facVisibleTo!=='function'||_facVisibleTo(f));});
  if(_facNav.signOnly)facs=facs.filter(_fnIsSign);
  var en=facs.map(function(f){var d=_haversine(la,ln,f.lat,f.lng);var b=_fnBearing(la,ln,f.lat,f.lng);return{f:f,d:d,b:b,rel:_fnRel(b,hd)};});
  en.sort(function(a,b){return a.d-b.d;});
  var ahead=en.filter(function(e){return e.rel==null||Math.abs(e.rel)<80;});
  var use=ahead.length?ahead:en;
  var list=use.slice(0,5);
  // 목적지(시설 또는 지도 지점) 우선 안내
  var primary=null,isDest=false;
  var target=_fnDestF();
  if(target){var b=_fnBearing(la,ln,target.lat,target.lng);primary={f:target,d:_haversine(la,ln,target.lat,target.lng),b:b,rel:_fnRel(b,hd)};isDest=true;}
  if(!primary)primary=list[0]||null;
  if(isDest)_facNavRequestWalk(); // 카카오 도보경로 요청(있으면 실경로 사용)
  var walkOn=isDest&&_fnWalkActive();
  if(primary){
    if(walkOn){primary._walk=true;primary._wtime=_facNav.walkRoute.time;primary._ori=!!_facNav.walkRoute.fixed;
      primary._td=primary._ori?_facNav.walkRoute.dist:_fnRemainWalk(la,ln,_facNav.walkRoute.path);} // 지정출발=총거리, 내위치=남은거리
    else if(isDest){primary._route=_fnTrailRoute(la,ln,primary.f);primary._td=primary._route.dist;} // 목적지 있을 때만 경로
    else{primary._td=primary.d;} // 앰비언트(목적지 없음): 가까운 시설 거리만, 경로 없음
  }
  _facNav.list=list;_facNav.primary=primary;
  _facNavRender(list,acc,hd,primary,isDest);
  _facNavUpdateMap(la,ln,hd,list,primary);
  _facNavUpdateNavUI(la,ln,primary,walkOn);
  // 경로 이탈 자동 재탐색(경로에서 60m 이상 벗어남)
  if(walkOn&&!_facNav.walkLoading&&!_facNav.walkRoute.fixed){var _m=_fnMyPathIdx(la,ln,_facNav.walkRoute.path);if(_m.md>60){_facNav.walkRoute=null;_facNavRequestWalk();}}
  // 음성: 실경로면 카카오 턴바이턴, 아니면 거리 임계 안내
  if(primary&&_facNav.voice){
    if(walkOn){_facNavWalkGuide(la,ln);if(primary.d<20&&!_facNav.announced['arr:'+_facNav.dest]){_facNav.announced['arr:'+_facNav.dest]=1;_facNavSpeak(_fnDisp(primary.f).main+' 도착입니다');}}
    else _facNavMaybeAnnounce(primary);
  }
  // 목적지로 가는 중이면 지나치는 표지판도 "통과" 안내(내 위치 파악용)
  if(isDest&&list[0]&&_facNav.voice&&String(list[0].f.id)!==String(primary.f.id))_facNavMaybeAnnouncePass(list[0]);
  // 목적지 도착 → 해제하고 일반 안내로
  if(isDest&&primary&&primary.d<20){_facNav.dest=null;_facNav.destPt=null;_facNav.walkRoute=null;}
}
// ── 진짜 네비: 다음 회전 배너 · 하단 ETA · 경로이탈 ──
function _fnTurnIcon(g){g=String(g||'');if(/유턴|되돌/.test(g))return '⤾';if(/오른|우측|우회전/.test(g))return '↱';if(/왼|좌측|좌회전/.test(g))return '↰';if(/도착|목적지/.test(g))return '🏁';return '↑';}
function _fnMyPathIdx(la,ln,path){var c=_fnMyPathIdx._c;if(c&&c.la===la&&c.ln===ln&&c.path===path)return c.r;var mi=0,md=Infinity;for(var i=0;i<path.length;i++){var d=_haversine(la,ln,path[i][0],path[i][1]);if(d<md){md=d;mi=i;}}c=_fnMyPathIdx._c={la:la,ln:ln,path:path,r:{mi:mi,md:md}};return c.r;} // 같은 틱 반복호출 메모
function _fnNextTurn(la,ln){
  var wr=_facNav.walkRoute;if(!wr||!wr.path||!wr.steps||!wr.steps.length)return null;
  var path=wr.path,m=_fnMyPathIdx(la,ln,path),best=null;
  for(var s=0;s<wr.steps.length;s++){var stp=wr.steps[s];if(stp.pi==null)continue;if(stp.pi>m.mi+1&&(!best||stp.pi<best.pi))best=stp;}
  if(!best)return null;
  var dd=m.md;for(var j=m.mi;j<best.pi&&j<path.length-1;j++)dd+=_haversine(path[j][0],path[j][1],path[j+1][0],path[j+1][1]);
  return{icon:_fnTurnIcon(best.g),dist:dd,text:_fnCleanGuide(best.g)};
}
function _facNavUpdateNavUI(la,ln,primary,walkOn){
  var tb=document.getElementById('fnTurnBanner'),bb=document.getElementById('fnBottomBar');
  if(!walkOn||!primary){if(tb)tb.style.display='none';if(bb)bb.style.display='none';return;}
  var wr=_facNav.walkRoute;
  var nt=_fnNextTurn(la,ln);
  if(tb){if(nt){tb.style.display='flex';tb.innerHTML='<div style="font-size:34px;line-height:1;width:44px;text-align:center;flex-shrink:0;color:#8fc0ff;">'+nt.icon+'</div><div style="flex:1;min-width:0;"><div style="font-size:21px;font-weight:900;color:#fff;line-height:1.1;">'+_fnDistShort(nt.dist)+'</div><div style="font-size:11.5px;color:rgba(255,255,255,.82);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+_esc(nt.text||'경로를 따라 이동')+'</div></div>';}else tb.style.display='none';}
  if(bb){
    var rem=(primary._td!=null?primary._td:primary.d);
    var totalT=wr.time||0,totalD=wr.dist||1,remT=totalT*(rem/Math.max(1,totalD));
    var eta=new Date(Date.now()+remT*1000),p=function(n){return (n<10?'0':'')+n;};
    bb.style.display='flex';
    bb.innerHTML='<div style="flex:1;min-width:0;"><div style="font-size:17px;font-weight:900;color:#eef0f2;">'+p(eta.getHours())+':'+p(eta.getMinutes())+' 도착</div><div style="font-size:11px;color:#8b95a1;">남은 '+_fnDistShort(rem)+' · 약 '+_fnTimeStr(remT)+'</div></div><button onclick="_facNavClearDest()" style="flex-shrink:0;background:rgba(255,80,60,.16);color:#ff8a80;border:1px solid rgba(255,80,60,.4);border-radius:9px;padding:9px 15px;font-size:12.5px;font-weight:800;cursor:pointer;">안내 종료</button>';
  }
}
// 시설 종류키(색·필터 공용) · 울림 대상 여부
function _fnTypeKey(f){var t=String(f&&f.type||'');var lbl=(t.split(' ').slice(1).join(' ')||t).trim();return lbl||'기타';}
function _fnAnnOn(f){return !_facNav.annOff[_fnTypeKey(f)];}
function _facNavMaybeAnnouncePass(e){
  if(!_fnAnnOn(e.f))return; // 울림 끈 종류는 건너뜀
  var id='pass:'+e.f.id;if(e.d>60)return;if(_facNav.announced[id])return;_facNav.announced[id]=1;
  _facNavSpeak(_fnSay(e.f)+' 통과');
}
function _facNavMaybeAnnounce(e){
  if(!_fnDestKey()&&!_fnAnnOn(e.f))return; // 목적지 없을 때(앰비언트)만 울림필터 적용
  var id=String(e.f.id),d=(e._td!=null?e._td:e.d);
  var idx=-1;for(var i=0;i<_FN_TH.length;i++){if(d<=_FN_TH[i])idx=i;}
  if(idx<0)return; // 아직 1km 밖
  var prev=_facNav.announced[id];
  if(prev!=null&&prev>=idx)return; // 이미 이 거리대(또는 더 가까이) 안내함
  _facNav.announced[id]=idx;
  var say=_fnSay(e.f);
  var dloc='';
  if(e.rel!=null){var a=e.rel;dloc=Math.abs(a)<22?'':(a>=110?'뒤쪽 오른편 ':a<=-110?'뒤쪽 왼편 ':a>0?'오른편 ':'왼편 ');}
  if(d<30)_facNavSpeak((dloc||'')+say+', 도착입니다');
  else if(d<80)_facNavSpeak('잠시 후, '+(dloc||'')+say+' 입니다');
  else _facNavSpeak(_fnDistTxt(d)+' 앞, '+(dloc||'')+say+' 입니다');
}
function _facNavRender(list,acc,hd,primary,isDest){
  var pe=document.getElementById('fnPrimary');if(!pe)return;
  var pr=primary||list[0];
  if(!pr){pe.innerHTML='<div style="font-size:13px;color:#8b95a1;">주변 시설물이 없습니다</div>';document.getElementById('fnList').innerHTML='';_facNav._listKey=null;_facNav._priKey='';return;}
  var disp=_fnDisp(pr.f),col=(typeof _facTypeColor==='function')?_facTypeColor(pr.f.type):'#3182f6';
  var td=(pr._td!=null?pr._td:pr.d),trail=pr._route&&pr._route.trail;
  var wr0=_facNav.walkRoute,modeLbl;
  if(pr._walk&&wr0&&wr0.multi)modeLbl='🚗 '+_fnDistShort(wr0.carDist)+' + 🥾 '+_fnDistShort(wr0.walkDist)+(pr._wtime?' · 약 '+_fnTimeStr(pr._wtime):'');
  else if(pr._walk&&wr0&&wr0.carOnly)modeLbl='🚗 카카오 차량경로'+(pr._wtime?' · 약 '+_fnTimeStr(pr._wtime):'');
  else if(pr._walk)modeLbl='🥾 카카오 도보경로'+(pr._wtime?' · 약 '+_fnTimeStr(pr._wtime):'');
  else modeLbl=(isDest&&_facNav.walkLoading?'🥾 도보경로 계산 중…':(trail?'🥾 탐방로 따라':'')); // 직선 표기 제거
  var modeCol=pr._walk?'#8fe0ab':(trail?'#8fd6a8':'#6b7684');
  var carB=(typeof _fnCarOk==='function'&&_fnCarOk(pr.f))?'<span style="font-size:10px;font-weight:800;color:#ffd23f;background:rgba(255,214,0,.16);border-radius:6px;padding:2px 7px;margin-left:6px;">🚗 차량 진입</span>':'';
  var deg=(pr.rel!=null)?pr.rel:null;
  var dw=(deg==null)?'':(Math.abs(deg)<22?'직진':deg>=110?'뒤 오른쪽':deg<=-110?'뒤 왼쪽':deg>0?'오른쪽':'왼쪽');
  // 구조가 같으면 innerHTML 재작성 생략, 숫자·화살표만 갱신(GPS 틱마다 DOM 전체 재생성 → 지연·버벅임 방지)
  var pk=[String(pr.f.id||'pt'),isDest?1:0,(_facNav.origin?String(_facNav.origin.id):''),modeLbl,(deg==null)?0:1,disp.main,carB?1:0].join('|');
  var dEl=document.getElementById('fnDistBig');
  if(pk===_facNav._priKey&&dEl){
    dEl.textContent=_fnDistShort(td);
    if(deg!=null){var aI=document.getElementById('fnArrowIco');if(aI)aI.style.transform='rotate('+deg+'deg)';var aD=document.getElementById('fnArrowDir');if(aD)aD.textContent=dw;}
  }else{
  _facNav._priKey=pk;
  var arrow='';
  if(deg!=null)arrow='<div style="margin:6px auto 2px;width:60px;height:60px;display:flex;align-items:center;justify-content:center;"><div id="fnArrowIco" style="font-size:46px;line-height:1;transform:rotate('+deg+'deg);color:'+col+';">⬆️</div></div><div id="fnArrowDir" style="font-size:12px;color:#a5abb3;font-weight:700;">'+dw+'</div>';
  else arrow='<div style="font-size:11px;color:#6b7684;margin:4px 0;">움직이면 방향이 표시됩니다</div>';
  pe.innerHTML=''+
    (_facNav.origin?'<div style="display:inline-flex;align-items:center;gap:5px;background:rgba(94,207,143,.12);border:1px solid rgba(94,207,143,.4);border-radius:20px;padding:3px 8px 3px 11px;margin:0 4px 8px 0;"><span style="font-size:11px;font-weight:800;color:#8fe0ab;">🚩 '+_esc(_facNav.origin.name)+'</span><span onclick="facNavResetOrigin()" style="cursor:pointer;color:#8fe0ab;font-size:13px;line-height:1;">✕</span></div>':'')+
    (isDest?'<div style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,90,70,.12);border:1px solid rgba(255,90,70,.4);border-radius:20px;padding:3px 10px 3px 12px;margin-bottom:8px;"><span style="font-size:11px;font-weight:800;color:#ff8a80;">🎯 목적지</span><span onclick="_facNavClearDest()" style="cursor:pointer;color:#ff8a80;font-size:14px;line-height:1;">✕</span></div>':'')+
    '<div style="font-size:12px;color:#8b95a1;margin-bottom:4px;">'+(disp.sub?_esc(disp.sub):'&nbsp;')+'</div>'+
    '<div style="display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;"><span style="width:11px;height:11px;border-radius:50%;background:'+col+';flex-shrink:0;"></span><span style="font-size:19px;font-weight:800;">'+_esc(disp.main)+'</span>'+carB+'</div>'+
    '<div id="fnDistBig" style="font-size:44px;font-weight:900;letter-spacing:-1px;margin:8px 0 0;color:#eef0f2;">'+_fnDistShort(td)+'</div>'+
    (modeLbl?'<div style="font-size:10.5px;color:'+modeCol+';margin-bottom:2px;">'+modeLbl+'</div>':'<div style="height:4px;"></div>')+
    arrow;
  }
  var fnList=document.getElementById('fnList');
  if(fnList){
    // 내용 키가 같으면 목록 재작성 생략(틱마다 50행 innerHTML 재생성 방지)
    var lk=(_fnWalkActive()&&_facNav.walkRoute.waypoints)?_facNav.walkRoute.waypoints:(_facNav.dest?('prep:'+(_facNav.walkLoading?1:0)):'amb');
    if(lk===_facNav._listKey){/* 그대로 유지 */}
    else{_facNav._listKey=lk;
    if(_fnWalkActive()&&_facNav.walkRoute.waypoints){
      // 🥾 실경로 통과 지점 목록(출발→…→도착) — 카카오맵식
      var wps=_facNav.walkRoute.waypoints;
      var oName=_facNav.origin?_facNav.origin.name:'내 위치';var dName=_fnDisp(pr.f).main;
      var node=function(dotHtml,txt,sub,cls,onclick){return '<div '+(onclick?'onclick="'+onclick+'" ':'')+'style="display:flex;align-items:center;gap:10px;padding:7px 4px;'+(onclick?'cursor:pointer;':'')+'">'+dotHtml+'<span style="flex:1;min-width:0;font-size:'+(cls==='end'?'13px;font-weight:800;color:#eef0f2':'12px;font-weight:600;color:#c9dcec')+';white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+_esc(txt)+(sub?' <span style="font-size:10px;color:#6b7684;font-weight:500;">'+_esc(sub)+'</span>':'')+'</span></div>';};
      var big=function(color,icon){return '<span style="width:22px;flex-shrink:0;display:flex;justify-content:center;font-size:15px;">'+icon+'</span>';};
      var sm=function(color){return '<span style="width:22px;flex-shrink:0;display:flex;justify-content:center;"><span style="width:9px;height:9px;border-radius:50%;background:'+color+';box-shadow:0 0 0 3px #0c0f14;"></span></span>';};
      var h='<div style="font-size:11px;color:#8b95a1;margin:14px 2px 6px;font-weight:700;">🥾 경유 지점 <span style="color:#565f6b;font-weight:500;">('+wps.length+'곳 통과 · 순서대로 · 눌러서 그곳까지)</span></div>';
      h+='<div style="position:relative;background:#12151b;border:1px solid rgba(255,255,255,.07);border-radius:11px;padding:6px 10px;">';
      h+='<div style="position:absolute;left:14.5px;top:20px;bottom:20px;width:2px;background:rgba(255,214,0,.35);"></div>'; // 세로 연결선
      h+=node(big('#8fe0ab','🚩'),'출발 · '+oName,'','',null);
      h+=wps.map(function(w){var c=(typeof _facTypeColor==='function')?_facTypeColor(w.type):'#7fd0ff';return node(sm(c),w.name,'','',"_facNavWpInfo('"+_escq(w.id)+"')");}).join('');
      h+=node(big('#ff8a80','🎯'),'도착 · '+dName,(pr._wtime?'약 '+_fnTimeStr(pr._wtime):''),'end',null);
      h+='</div>';
      fnList.innerHTML=h;
    }else if(_facNav.dest){
      // 목적지 있으나 실경로 준비 전/불가 — 직선 목록 안 띄움
      fnList.innerHTML='<div style="text-align:center;color:#6b7684;font-size:11.5px;padding:14px 0;">'+(_facNav.walkLoading?'🥾 도보경로 계산 중…':'경로 준비 중… (프록시 미설정 시 지도 선 없이 방향·거리로 안내)')+'</div>';
    }else{
      // 앰비언트(목적지 없음): 직선 거리 목록 제거 → 검색 안내
      fnList.innerHTML='<div style="text-align:center;color:#6b7684;font-size:12px;padding:18px 12px;line-height:1.8;">🔍 <b style="color:#9fb0bf;">도착</b>을 검색하거나 <b style="color:#9fb0bf;">지도를 길게 눌러</b><br>실제 <b style="color:#8fd6a8;">등산로 경로</b>로 안내받으세요.<br><span style="font-size:10.5px;color:#565f6b;">움직이면 가까운 시설을 음성으로 알려줘요.</span></div>';
    }
    }
  }
  var ae=document.getElementById('fnAcc');if(ae)ae.textContent=acc!=null?('GPS 정확도 ±'+Math.round(acc)+'m'+(hd!=null?' · 방향 '+Math.round(hd)+'°':'')):'';
}
// ── 앱 내부 카카오맵: 내 위치(화살표)·목표까지 선 실시간 표시 ──
function _facNavInitMap(la,ln){
  if(_facNav.map)return;
  if(!(window.kakao&&kakao.maps&&kakao.maps.Map))return;
  var el=document.getElementById('fnMap');if(!el)return;
  _facNav.map=new kakao.maps.Map(el,{center:new kakao.maps.LatLng(la,ln),level:4});
  try{_facNav.map.setMapTypeId(kakao.maps.MapTypeId.HYBRID);}catch(e){}
  // 내 위치 화살표(파란 퍽)
  var me=document.createElement('div');
  me.style.cssText='position:relative;width:30px;height:30px;';
  me.innerHTML='<div style="position:absolute;inset:0;border-radius:50%;background:rgba(49,130,246,.28);box-shadow:0 0 0 2px rgba(49,130,246,.55);"></div>'+
    '<div id="fnMeArrow" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(0deg);font-size:22px;line-height:1;color:#3182f6;text-shadow:0 0 3px #000;">▲</div>';
  _facNav.meEl=me;
  _facNav.meMk=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(la,ln),content:me,zIndex:200,xAnchor:0.5,yAnchor:0.5});
  _facNav.meMk.setMap(_facNav.map);
  // 배경 근사 탐방로(표지판 열 초록선) 미표시 — HYBRID 지도의 카카오 등산로 표기 사용. 잔여 선 정리만.
  _facNav.trailLines.forEach(function(l){try{l.setMap(null);}catch(e){}});_facNav.trailLines=[];
  // 경로선: 외곽선(어두운 casing) + 본선(파란색) — 실제 내비 앱 느낌
  _facNav.lineCase=new kakao.maps.Polyline({strokeWeight:11,strokeColor:'#0b1f3a',strokeOpacity:.9,strokeStyle:'solid',zIndex:2});
  _facNav.lineCase.setMap(_facNav.map);
  _facNav.lineDone=new kakao.maps.Polyline({strokeWeight:6,strokeColor:'#59636f',strokeOpacity:.85,strokeStyle:'solid',zIndex:3}); // 지나온 구간(회색)
  _facNav.lineDone.setMap(_facNav.map);
  _facNav.lineCar=new kakao.maps.Polyline({strokeWeight:6,strokeColor:'#ff8c1a',strokeOpacity:.98,strokeStyle:'solid',zIndex:4}); // 차량 구간(주황)
  _facNav.lineCar.setMap(_facNav.map);
  _facNav.line=new kakao.maps.Polyline({strokeWeight:6,strokeColor:'#3d8bff',strokeOpacity:.98,strokeStyle:'solid',zIndex:5}); // 도보 남은 구간(파랑)
  _facNav.line.setMap(_facNav.map);
  kakao.maps.event.addListener(_facNav.map,'dragstart',function(){_facNav.follow=false;});
  kakao.maps.event.addListener(_facNav.map,'rightclick',function(me){try{var ll=me.latLng;facNavPickPoint(ll.getLat(),ll.getLng());}catch(e){}}); // 길게 눌러 임의 지점 목적지
  kakao.maps.event.addListener(_facNav.map,'click',function(me){if(!_facNav.armPick)return;_facNav.armPick=false;var b=document.getElementById('fnMapPickBtn');if(b){b.style.background='rgba(255,90,70,.14)';b.style.color='#ff9a90';}try{var ll=me.latLng;facNavPickPoint(ll.getLat(),ll.getLng());}catch(e){}}); // 🗺️ 찍기 무장 후 탭
  setTimeout(function(){try{_facNav.map.relayout();_facNav.map.setCenter(new kakao.maps.LatLng(la,ln));}catch(e){}},120);
}
function _facNavUpdateMap(la,ln,hd,list,primary){
  if(!_facNav.map)_facNavInitMap(la,ln);
  if(!_facNav.map)return;
  var meLL=new kakao.maps.LatLng(la,ln);
  if(_facNav.meMk)_facNav.meMk.setPosition(meLL);
  var ar=document.getElementById('fnMeArrow');if(ar)ar.style.transform='translate(-50%,-50%) rotate('+(hd==null?0:hd)+'deg)';
  if(_facNav.follow){try{_facNav.map.setCenter(meLL);}catch(e){}}
  var pr=primary||list[0];
  // 경로선: casing(외곽) + 지나온(회색) + 남은(파랑). 실경로 진행표시 · 직선 X
  if(_facNav.line){
    var toLL=function(p){return new kakao.maps.LatLng(p[0],p[1]);};
    var full=[],done=[],ahead=[],carAhead=[],stat=false;
    if(!_fnDestKey()){}
    else if(_fnWalkActive()){
      var wrk=_facNav.walkRoute,P=wrk.path;
      if(!wrk._ll)wrk._ll=P.map(toLL); // 경로 LatLng 1회 변환 캐시(틱마다 수천 개 재생성 방지)
      full=wrk._ll;
      var ce=wrk.multi?wrk.carEnd:(wrk.carOnly?P.length:0); // 차량 구간 끝 인덱스
      if(wrk.fixed){stat=true; // 지정출발=경로 정적 → 경로 바뀔 때만 그리기
        if(ce>0)carAhead=full.slice(0,ce);
        ahead=wrk.carOnly?[]:full.slice(ce>0?ce-1:0);
      }else{
        var mm=_fnMyPathIdx(la,ln,P).mi;done=full.slice(0,mm+1);
        if(mm<ce){carAhead=[meLL].concat(full.slice(mm,ce));ahead=wrk.carOnly?[]:full.slice(ce-1);} // 아직 차량 구간
        else ahead=[meLL].concat(full.slice(mm)); // 도보 구간
      }
    }else{} // 실경로(프록시) 없으면 근사(표지판 열)·직선 선은 그리지 않음 — 방향 화살표·거리·음성으로만 안내
    var refChg=(_facNav._fullRef!==full);_facNav._fullRef=full;
    if(_facNav.lineCase&&(refChg||full.length!==_facNav._fullN)){_facNav._fullN=full.length;_facNav.lineCase.setPath(full);}
    if(_facNav.lineDone&&(refChg||done.length!==_facNav._doneN)){_facNav._doneN=done.length;_facNav.lineDone.setPath(done);}
    if(!stat||refChg){
      if(_facNav.lineCar)_facNav.lineCar.setPath(carAhead);
      _facNav.line.setPath(ahead);
    }
  }
  // 차→도보 전환점(진입점) 마커
  if(_fnWalkActive()&&_facNav.walkRoute.multi){
    var tLL=new kakao.maps.LatLng(_facNav.walkRoute.thLat,_facNav.walkRoute.thLng);
    if(!_facNav.thMk){var tel=document.createElement('div');tel.style.cssText='transform:translate(-50%,-100%);text-align:center;';tel.innerHTML='<div style="font-size:18px;text-shadow:0 0 3px #000;">🅿️</div><div style="font-size:9px;font-weight:800;color:#ffd23f;text-shadow:0 0 3px #000,0 0 3px #000;white-space:nowrap;">도보 시작</div>';_facNav.thMk=new kakao.maps.CustomOverlay({position:tLL,content:tel,zIndex:140,xAnchor:0.5,yAnchor:1});_facNav.thMk.setMap(_facNav.map);}
    else _facNav.thMk.setPosition(tLL);
  }else if(_facNav.thMk){try{_facNav.thMk.setMap(null);}catch(e){}_facNav.thMk=null;}
  // 출발지 마커(지정출발 🚩)
  if(_facNav.origin&&_facNav.origin.lat!=null){
    var oLL=new kakao.maps.LatLng(_facNav.origin.lat,_facNav.origin.lng);
    if(!_facNav.oriMk){var oel=document.createElement('div');oel.style.cssText='transform:translate(-50%,-100%);font-size:20px;text-shadow:0 0 3px #000;';oel.textContent='🚩';_facNav.oriMk=new kakao.maps.CustomOverlay({position:oLL,content:oel,zIndex:150,xAnchor:0.5,yAnchor:1});_facNav.oriMk.setMap(_facNav.map);}
    else _facNav.oriMk.setPosition(oLL);
  }else if(_facNav.oriMk){try{_facNav.oriMk.setMap(null);}catch(e){}_facNav.oriMk=null;}
  // 목표 핀(가까운 순 상위) 갱신 — 구성이 같으면 재생성 생략(틱마다 오버레이 파괴·재생성 방지)
  var mkKey=list.map(function(e){return String(e.f.id);}).join(',');
  if(mkKey!==_facNav._mkKey){
  _facNav._mkKey=mkKey;
  _facNav.facMks.forEach(function(m){try{m.setMap(null);}catch(e){}});_facNav.facMks=[];
  list.forEach(function(e,i){
    var col=(typeof _facTypeColor==='function')?_facTypeColor(e.f.type):'#3182f6';
    var lbl=_fnIsSign(e.f)?_fnCode(e.f):'';
    var el=document.createElement('div');
    el.style.cssText='transform:translate(-50%,-100%);text-align:center;';
    el.innerHTML='<div style="min-width:14px;height:14px;padding:0 4px;border-radius:8px;background:'+col+';border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;color:#fff;">'+(i===0?'●':(i+1))+'</div>'+(lbl?'<div style="font-size:9px;font-weight:800;color:#fff;text-shadow:0 0 3px #000,0 0 3px #000;margin-top:1px;white-space:nowrap;">'+_esc(lbl)+'</div>':'');
    var ov=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(e.f.lat,e.f.lng),content:el,zIndex:120,xAnchor:0.5,yAnchor:1});
    ov.setMap(_facNav.map);_facNav.facMks.push(ov);
  });
  }
}
function _facNavRecenter(){_facNav.follow=true;if(_facNav.map&&_facNav.lastLa!=null){try{_facNav.map.setCenter(new kakao.maps.LatLng(_facNav.lastLa,_facNav.lastLn));}catch(e){}}}

// ── 🧪 시뮬레이션: 실제 이동 없이 '가고 있다고 가정'하고 지도·화살표·거리·음성 재생 ──
function _fnDest(la,ln,brg,d){var R=6371000,r=Math.PI/180,b=brg*r,la1=la*r,dr=d/R;var la2=Math.asin(Math.sin(la1)*Math.cos(dr)+Math.cos(la1)*Math.sin(dr)*Math.cos(b));var ln2=ln*r+Math.atan2(Math.sin(b)*Math.sin(dr)*Math.cos(la1),Math.cos(dr)-Math.sin(la1)*Math.sin(la2));return{lat:la2/r,lng:((ln2/r+540)%360)-180};}
function _fnInterp(a,b,f){return{lat:a.lat+(b.lat-a.lat)*f,lng:a.lng+(b.lng-a.lng)*f};}
// ── 탐방로: 표지판(구역별 번호순)을 이어 실제 등산로에 가깝게 ──
function _fnSignZone(f){var m=String(f.loc||f.name||'').match(/(?:^|\D)(\d{2})-\d/);return m?m[1]:null;}
function _fnSignNum(f){var m=String(f.loc||f.name||'').match(/\d{2}-(\d{1,3})/);return m?parseInt(m[1],10):0;}
function _fnBuildTrails(){
  var t={};
  (DB.g('facilities')||[]).forEach(function(f){if(!f.lat||!f.lng||!_fnIsSign(f))return;var z=_fnSignZone(f);if(!z)return;(t[z]=t[z]||[]).push({lat:f.lat,lng:f.lng,n:_fnSignNum(f)});});
  Object.keys(t).forEach(function(z){t[z].sort(function(a,b){return a.n-b.n;});});
  _facNav.trails=t;return t;
}
// me → 목표까지 탐방로(같은 구역 표지판 열)를 따라가는 경로 + 그 거리
function _fnTrailRoute(mLat,mLng,tf){
  var t=_facNav.trails||_fnBuildTrails();
  var z=_fnIsSign(tf)?_fnSignZone(tf):null;
  var arr=z&&t[z]&&t[z].length>1?t[z]:null;
  if(arr){
    var ti=0,td=Infinity,mi=0,md=Infinity;
    for(var i=0;i<arr.length;i++){var d1=_haversine(tf.lat,tf.lng,arr[i].lat,arr[i].lng);if(d1<td){td=d1;ti=i;}var d2=_haversine(mLat,mLng,arr[i].lat,arr[i].lng);if(d2<md){md=d2;mi=i;}}
    var lo=Math.min(mi,ti),hi=Math.max(mi,ti),seg=arr.slice(lo,hi+1);if(mi>ti)seg.reverse();
    var pts=[{lat:mLat,lng:mLng}];seg.forEach(function(p){pts.push({lat:p.lat,lng:p.lng});});pts.push({lat:tf.lat,lng:tf.lng});
    var path=[],dist=0,prev=null;
    for(var k=0;k<pts.length;k++){if(prev){var dd=_haversine(prev.lat,prev.lng,pts[k].lat,pts[k].lng);if(dd<1.5&&k<pts.length-1)continue;dist+=dd;}path.push(new kakao.maps.LatLng(pts[k].lat,pts[k].lng));prev=pts[k];}
    return{path:path,dist:dist,trail:true};
  }
  return{path:[new kakao.maps.LatLng(mLat,mLng),new kakao.maps.LatLng(tf.lat,tf.lng)],dist:_haversine(mLat,mLng,tf.lat,tf.lng),trail:false};
}
function _facNavClearDest(){_facNav.dest=null;_facNav.destPt=null;_facNav.walkRoute=null;_facNav.announced={};if(_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);}
function facNavArmMapPick(){_facNav.armPick=!_facNav.armPick;var b=document.getElementById('fnMapPickBtn');if(b){b.style.background=_facNav.armPick?'#ff5a46':'rgba(255,90,70,.14)';b.style.color=_facNav.armPick?'#fff':'#ff9a90';}toast(_facNav.armPick?'🗺️ 지도에서 목적지 지점을 탭하세요':'지점찍기 취소');}
// 지도 길게눌러(또는 🗺️ 후 탭) 임의 지점을 목적지로(목록에 없는 카카오맵 위치도)
function facNavPickPoint(lat,lng){
  _facNav.destPt={lat:lat,lng:lng,name:'선택 지점'};_facNav.dest=null;_facNav.walkRoute=null;_facNav.announced={};
  if(_facNav.map){_facNav.follow=false;try{_facNav.map.setCenter(new kakao.maps.LatLng(lat,lng));}catch(e){}}
  try{toast('🎯 지도 지점을 목적지로 — 경로 계산');}catch(e){}
  if(_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);
}
// 경유 시설물 상세정보 시트(등급·종류 등) — 목적지는 바꾸지 않음
function _facNavWpInfo(id){
  var f=(DB.g('facilities')||[]).find(function(x){return String(x.id)===String(id);});if(!f)return;
  var ex=document.getElementById('fnWpSheet');if(ex)ex.remove();
  var col=(typeof _facTypeColor==='function')?_facTypeColor(f.type):'#3182f6';
  var info=(typeof _facInfoHtml==='function')?_facInfoHtml(f):'';
  var sh=document.createElement('div');sh.id='fnWpSheet';
  sh.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:9810;background:#15181d;border-top:1px solid rgba(255,255,255,.15);border-radius:16px 16px 0 0;box-shadow:0 -8px 30px rgba(0,0,0,.6);max-height:74%;overflow-y:auto;padding:14px 16px calc(16px + env(safe-area-inset-bottom));';
  sh.innerHTML='<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span style="width:11px;height:11px;border-radius:50%;background:'+col+';flex-shrink:0;"></span><span style="flex:1;min-width:0;font-size:15px;font-weight:800;color:#eef0f2;">'+_esc(_fnDisp(f).main)+'</span><button onclick="var s=document.getElementById(\'fnWpSheet\');if(s)s.remove();" style="background:none;border:none;color:#3182f6;font-size:13px;font-weight:800;cursor:pointer;">닫기</button></div>'+info+
    '<button onclick="facNavPickDest(\''+_escq(f.id)+'\');var s=document.getElementById(\'fnWpSheet\');if(s)s.remove();" style="width:100%;margin-top:12px;background:rgba(255,90,70,.14);color:#ff9a90;border:1px solid rgba(255,90,70,.35);border-radius:9px;padding:11px;font-size:12.5px;font-weight:800;cursor:pointer;">🎯 여기를 목적지로 변경</button>';
  document.body.appendChild(sh);
}
function _fnChain(anchor,cands,n){var pool=cands.slice(),chain=[],cur=anchor;for(var k=0;k<n&&pool.length;k++){var bi=-1,bd=Infinity;for(var i=0;i<pool.length;i++){var d=_haversine(cur.lat,cur.lng,pool[i].lat,pool[i].lng);if(d>0.5&&d<bd){bd=d;bi=i;}}if(bi<0)break;var nx=pool.splice(bi,1)[0];chain.push({lat:nx.lat,lng:nx.lng});cur=nx;}return chain;}
function facNavSetSpeed(i){_facNav.spdIdx=i;_facNavSpdSync();}
function _facNavSpdSync(){for(var i=0;i<3;i++){var b=document.getElementById('fnSpd'+i);if(!b)continue;var on=_facNav.spdIdx===i;b.style.background=on?'rgba(94,207,143,.18)':'rgba(255,255,255,.06)';b.style.borderColor=on?'rgba(94,207,143,.55)':'rgba(255,255,255,.15)';b.style.color=on?'#8fe0ab':'#c9dcec';}}
function _fnSimStep(){return Math.max(0.4,_FN_SPD[_facNav.spdIdx].v*(_FN_SIM_MS/1000));}
function facNavSimToggle(){ if(_facNav.simIv)return _facNavSimStop(false); _facNavSimStart(); }
function _facNavSimStart(){
  var all=(DB.g('facilities')||[]).filter(function(f){return f.lat&&f.lng;});
  var t=_facNav.trails||_fnBuildTrails();
  var chain=null,label='백담계곡';
  var df=_fnDestF();
  if(df){
    label=_fnDisp(df).main;
    var z=_fnIsSign(df)?_fnSignZone(df):null;
    if(_fnWalkActive()){ // 카카오 도보 실경로가 있으면 그 길로 시뮬(실제 등산로)
      chain=_facNav.walkRoute.path.map(function(p){return{lat:p[0],lng:p[1]};});
    }else if(z&&t[z]&&t[z].length>1){ // 목적지 구역의 표지판 열을 트레일 초입→목적지 순서로
      var arr=t[z],ti=0,td=Infinity;
      for(var i=0;i<arr.length;i++){var d=_haversine(df.lat,df.lng,arr[i].lat,arr[i].lng);if(d<td){td=d;ti=i;}}
      chain=arr.slice(0,ti+1).map(function(p){return{lat:p.lat,lng:p.lng};});
      chain.push({lat:df.lat,lng:df.lng}); // 정확한 목적지 끝점
    }else{ // 표지판이 아니면 인근 시설로 접근 방향 잡아 2점 경로
      var near=all.filter(function(x){return x!==df;}).reduce(function(m,x){return _haversine(df.lat,df.lng,x.lat,x.lng)<_haversine(df.lat,df.lng,m.lat,m.lng)?x:m;},all[0]);
      var b2=near?_fnBearing(df.lat,df.lng,near.lat,near.lng):0;var s2=_fnDest(df.lat,df.lng,b2,500);
      chain=[{lat:s2.lat,lng:s2.lng},{lat:df.lat,lng:df.lng}];
    }
  }
  if(!chain||chain.length<2){ // 목적지 없음 → 백담계곡(10구역) 기본 데모
    chain=all.filter(function(f){return /(^|\s)10-\d/.test(String(f.loc||f.name||''));})
      .sort(function(a,b){return String(a.loc||a.name).localeCompare(String(b.loc||b.name),'ko',{numeric:true});})
      .slice(0,14).map(function(f){return{lat:f.lat,lng:f.lng};});
    label='백담계곡';
  }
  if(chain.length<2){ // 최후 폴백: 최근접 체인
    var facs=all;var anchor=(_facNav.lastLa!=null)?facs.reduce(function(m,f){return _haversine(_facNav.lastLa,_facNav.lastLn,f.lat,f.lng)<_haversine(_facNav.lastLa,_facNav.lastLn,m.lat,m.lng)?f:m;},facs[0]):(facs.filter(_fnIsSign)[0]||facs[0]);
    if(anchor)chain=_fnChain({lat:anchor.lat,lng:anchor.lng},facs,7);
  }
  if(!chain||chain.length<2){toast('⚠️ 시뮬 경로를 만들 시설이 부족합니다');return;}
  var brg01=_fnBearing(chain[0].lat,chain[0].lng,chain[1].lat,chain[1].lng);
  var start=_fnDest(chain[0].lat,chain[0].lng,(brg01+180)%360,400); // 첫 지점 400m 앞에서 출발
  _facNav.sim={pts:[start].concat(chain),seg:0,into:0};
  _facNav.announced={};_facNav.follow=true;
  _facNavSyncBtns();
  if(_facNav.voice)_facNavSpeak(label+(df?'까지':' 방향')+' 안내를 시작합니다');
  _facNavFeed(start.lat,start.lng,brg01);
  _facNav.simIv=setInterval(_facNavSimTick,_FN_SIM_MS);
}
function _facNavSimTick(){
  var s=_facNav.sim;if(!s){return;}
  var rem=_fnSimStep();
  while(rem>0&&s.seg<s.pts.length-1){
    var a=s.pts[s.seg],b=s.pts[s.seg+1];
    var segLen=_haversine(a.lat,a.lng,b.lat,b.lng)||0.1;
    var left=segLen-s.into;
    if(rem<left){s.into+=rem;rem=0;}else{rem-=left;s.seg++;s.into=0;}
  }
  if(s.seg>=s.pts.length-1){var last=s.pts[s.pts.length-1];_facNavFeed(last.lat,last.lng,_facNav.heading||0);_facNavSimStop(true);return;}
  var a2=s.pts[s.seg],b2=s.pts[s.seg+1];
  var segLen2=_haversine(a2.lat,a2.lng,b2.lat,b2.lng)||0.1;
  var cur=_fnInterp(a2,b2,s.into/segLen2);
  var hd=_fnBearing(a2.lat,a2.lng,b2.lat,b2.lng);
  _facNavFeed(cur.lat,cur.lng,hd);
}
function _facNavFeed(la,ln,hd){_facNav.heading=hd;_facNav.lastLa=la;_facNav.lastLn=ln;_facNavCompute(la,ln,hd,5);}
function _facNavSimStop(done){if(_facNav.simIv){clearInterval(_facNav.simIv);_facNav.simIv=null;}_facNav.sim=null;_facNavSyncBtns();if(done&&_facNav.voice)_facNavSpeak('시뮬레이션 종료');}

// 직원 차량 진입 가능 지점(등산로 초입까지 차로 접근) — 표시용
var _FN_CAR=['비선대','백담탐방지원센터','안양암','나동휴게소','나동 휴게소'];
function _fnCarOk(f){var n=(String(f.name||'')+String(f.type||'')).replace(/\s/g,'');return _FN_CAR.some(function(k){return n.indexOf(k.replace(/\s/g,''))>=0;});}
// 목록의 시설을 목적지로 지정(앱 내부 지도에 탐방로 경로 표시) — 외부 앱 없음
function _facNavFocus(id){
  var f=(DB.g('facilities')||[]).find(function(x){return String(x.id)===String(id);});
  if(!f||!f.lat)return;
  _facNav.dest=(String(_facNav.dest)===String(id))?null:String(id); // 같은 걸 다시 누르면 해제
  _facNav.walkRoute=null;_facNav.destPt=null;_facNav.announced={};
  if(_facNav.map){_facNav.follow=false;try{_facNav.map.setCenter(new kakao.maps.LatLng(f.lat,f.lng));}catch(e){}}
  if(_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);
}
// 🔍 검색 — which='dest'(도착) | 'origin'(출발)
function facNavSearch(q,which){
  which=which||'dest';
  var res=document.getElementById('fnSearchRes');if(!res)return;
  var k=String(q||'').trim().replace(/\s/g,'').toLowerCase();
  if(!k){res.style.display='none';res.innerHTML='';return;}
  var facs=(DB.g('facilities')||[]).filter(function(f){return f.lat&&f.lng&&(typeof _facVisibleTo!=='function'||_facVisibleTo(f));});
  var hits=facs.filter(function(f){var s=((f.name||'')+(f.loc||'')+(f.type||'')).replace(/\s/g,'').toLowerCase();return s.indexOf(k)>=0;});
  if(_facNav.lastLa!=null)hits.sort(function(a,b){return _haversine(_facNav.lastLa,_facNav.lastLn,a.lat,a.lng)-_haversine(_facNav.lastLa,_facNav.lastLn,b.lat,b.lng);});
  hits=hits.slice(0,20);
  if(!hits.length){res.style.display='block';res.innerHTML='<div style="padding:11px 12px;font-size:12px;color:#8b95a1;">검색 결과 없음</div>';return;}
  res.style.display='block';
  res.innerHTML='<div style="padding:6px 11px;font-size:10px;font-weight:800;color:'+(which==='origin'?'#8fd6a8':'#ff9a90')+';background:rgba(255,255,255,.03);">'+(which==='origin'?'🚩 출발지로 지정':'🎯 도착지로 지정')+'</div>'+hits.map(function(f){var d=_fnDisp(f),c=(typeof _facTypeColor==='function')?_facTypeColor(f.type):'#3182f6';var dist=(_facNav.lastLa!=null)?_fnDistShort(_haversine(_facNav.lastLa,_facNav.lastLn,f.lat,f.lng)):'';return '<div onclick="facNavPick(\''+_escq(f.id)+'\',\''+which+'\')" style="display:flex;align-items:center;gap:8px;padding:9px 11px;border-bottom:1px solid rgba(255,255,255,.06);cursor:pointer;"><span style="width:8px;height:8px;border-radius:50%;background:'+c+';flex-shrink:0;"></span><span style="flex:1;min-width:0;font-size:12.5px;font-weight:700;color:#eef0f2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+_esc(d.main)+'</span>'+(typeof _fnCarOk==='function'&&_fnCarOk(f)?'<span style="font-size:9px;color:#ffd23f;flex-shrink:0;">🚗</span>':'')+(dist?'<span style="font-size:10.5px;color:#7fd0ff;flex-shrink:0;">'+dist+'</span>':'')+'</div>';}).join('');
}
function facNavResetOrigin(){_facNav.origin=null;_facNav.walkRoute=null;var si=document.getElementById('fnStartSearch');if(si)si.value='';var res=document.getElementById('fnSearchRes');if(res){res.style.display='none';res.innerHTML='';}toast('🚩 출발: 내 위치');if(_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);}
// 🔔 울림 대상 시설물 설정 (지나갈 때 어떤 종류를 음성으로 알릴지)
function facNavAnnSheet(){var ex=document.getElementById('fnAnnSheet');if(ex){ex.remove();return;}_facNavAnnBuild();}
function _facNavAnnBuild(){
  var ex=document.getElementById('fnAnnSheet');if(ex)ex.remove();
  var facs=(DB.g('facilities')||[]).filter(function(f){return f.type;});
  var types={};facs.forEach(function(f){var k=_fnTypeKey(f);types[k]=(types[k]||0)+1;});
  var keys=Object.keys(types).sort(function(a,b){return types[b]-types[a];});
  var muted=Object.keys(_facNav.annOff).length;
  var rows=keys.map(function(k){var on=!_facNav.annOff[k];var col=(typeof _facTypeColor==='function')?_facTypeColor('_ '+k):'#3182f6';
    return '<div onclick="facNavAnnToggle(\''+_escq(k)+'\')" style="display:flex;align-items:center;gap:10px;padding:11px 8px;border-bottom:1px solid rgba(255,255,255,.06);cursor:pointer;"><span style="width:11px;height:11px;border-radius:50%;background:'+col+';flex-shrink:0;"></span><span style="flex:1;min-width:0;font-size:13px;font-weight:700;color:'+(on?'#eef0f2':'#6b7684')+';">'+_esc(k)+' <span style="font-size:10px;color:#565f6b;">'+types[k]+'</span></span><span style="font-size:19px;">'+(on?'🔔':'🔕')+'</span></div>';}).join('');
  var sh=document.createElement('div');sh.id='fnAnnSheet';
  sh.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:9800;background:#12151b;border-top:1px solid rgba(255,255,255,.15);border-radius:16px 16px 0 0;box-shadow:0 -8px 30px rgba(0,0,0,.6);max-height:72%;overflow-y:auto;padding:14px 16px calc(16px + env(safe-area-inset-bottom));';
  sh.innerHTML='<div style="display:flex;align-items:center;margin-bottom:6px;"><span style="font-size:14px;font-weight:800;color:#eef0f2;">🔔 울림 대상 시설물</span><span style="flex:1;"></span>'+(muted?'<button onclick="facNavAnnAll()" style="background:rgba(94,207,143,.14);color:#8fe0ab;border:1px solid rgba(94,207,143,.3);border-radius:7px;padding:5px 9px;font-size:11px;font-weight:800;cursor:pointer;margin-right:6px;">전체 켜기</button>':'')+'<button onclick="facNavAnnSheet()" style="background:none;border:none;color:#3182f6;font-size:13px;font-weight:800;cursor:pointer;">닫기</button></div><div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">지나갈 때 음성으로 알릴 시설 종류를 켜고(🔔) 끄세요(🔕). 목적지 안내는 항상 울립니다.</div>'+rows;
  document.body.appendChild(sh);
}
function facNavAnnToggle(k){if(_facNav.annOff[k])delete _facNav.annOff[k];else _facNav.annOff[k]=1;_facNavAnnSave();_facNavAnnBuild();}
function facNavAnnAll(){_facNav.annOff={};_facNavAnnSave();_facNavAnnBuild();}
function _facNavAnnSave(){try{localStorage.setItem('_fnAnnOff',JSON.stringify(_facNav.annOff));}catch(e){}}
function _facNavAnnLoad(){try{_facNav.annOff=JSON.parse(localStorage.getItem('_fnAnnOff')||'{}')||{};}catch(e){_facNav.annOff={};}}
function facNavPick(id,which){
  var f=(DB.g('facilities')||[]).find(function(x){return String(x.id)===String(id);});
  if(!f)return;
  var res=document.getElementById('fnSearchRes');if(res){res.style.display='none';res.innerHTML='';}
  _facNav.walkRoute=null;_facNav.announced={};
  if(which==='origin'){
    _facNav.origin={id:String(id),lat:f.lat,lng:f.lng,name:_fnDisp(f).main};
    var so=document.getElementById('fnStartSearch');if(so)so.value=_fnDisp(f).main;
    if(_facNav.map&&f.lat){_facNav.follow=false;try{_facNav.map.setCenter(new kakao.maps.LatLng(f.lat,f.lng));}catch(e){}}
    try{toast('🚩 출발: '+_fnDisp(f).main);}catch(e){}
    if(_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);
    return;
  }
  return facNavPickDest(id);
}
function facNavPickDest(id){
  var f=(DB.g('facilities')||[]).find(function(x){return String(x.id)===String(id);});
  if(!f)return;
  _facNav.dest=String(id);_facNav.destPt=null;_facNav.walkRoute=null;_facNav.announced={};
  var si=document.getElementById('fnSearch');if(si)si.value='';
  var res=document.getElementById('fnSearchRes');if(res){res.style.display='none';res.innerHTML='';}
  if(_facNav.map&&f.lat){_facNav.follow=false;try{_facNav.map.setCenter(new kakao.maps.LatLng(f.lat,f.lng));}catch(e){}}
  if(_facNav.lastLa!=null)_facNavCompute(_facNav.lastLa,_facNav.lastLn,_facNav.heading,null);
  try{toast('🎯 목적지: '+_fnDisp(f).main+' — 🧪 시뮬 또는 이동하면 탐방로로 안내');}catch(e){}
}
// ── 시설물 종류별 고정 색 (핀·목록·팝업 공통 — 종류를 색으로 즉시 구분) ──
const FAC_TYPE_COLORS={'다목적위치표지판':'#6b7684','교량':'#3182f6','데크/계단':'#e67e22','안전난간':'#46ad5f','대피소':'#7ec8a0','탐방지원센터':'#f0c060','사찰':'#c8845a','건축물':'#d4699b','목재계단':'#a5912c','계곡시설':'#2fa3c4','장소':'#b055c9'};
function _facTypeColor(t){
  const label=(String(t||'').split(' ').slice(1).join(' ')||t||'').trim();
  if(FAC_TYPE_COLORS[label])return FAC_TYPE_COLORS[label];
  let h=0;for(let i=0;i<label.length;i++)h=(h*31+label.charCodeAt(i))>>>0; // 사용자 정의 종류도 항상 같은 색
  return ['#3182f6','#e67e22','#b055c9','#46ad5f','#f0c060','#2fa3c4','#d4699b','#a5912c'][h%8];
}
// ── 시설물 현재 안전등급: 최신 점검(조치후>재평가>점검) 등급 우선, 없으면 시설물 자체 등급(관리대장) ──
function _facCurGrade(f){
  let g='',at=0,src='';
  (DB.g('facIssues')||[]).forEach(i=>{
    if(i.facId!==f.id)return;
    [i.dept&&i.dept.grade&&{g:i.dept.grade,at:i.dept.at||i.id||0,src:'조치후'},
     i.mgr&&i.mgr.grade&&{g:i.mgr.grade,at:i.mgr.at||i.id||0,src:'재평가'},
     i.grade&&{g:i.grade,at:i.id||0,src:'점검'}].forEach(c=>{if(c&&c.at>=at){at=c.at;g=c.g;src=c.src;}});
  });
  if(g)return{g,src};
  if(f.grade)return{g:f.grade,src:f.gradeBy||'관리대장'};
  return null;
}
function _facGradeBadge(f){
  const cg=_facCurGrade(f);if(!cg)return'';
  const c=_gColor(cg.g);
  return `<span style="display:inline-flex;align-items:center;background:${c}22;border:1.5px solid ${c};color:${c};border-radius:7px;padding:1px 8px;font-size:11px;font-weight:900;vertical-align:middle;">${_esc(cg.g)}</span>`;
}
// 사진 전체 보기 (탭하면 크게)
function _facPhotoView(url){
  const ov=document.createElement('div');
  ov.style.cssText='position:fixed;inset:0;z-index:99000;background:rgba(0,0,0,.92);display:flex;align-items:center;justify-content:center;cursor:pointer;';
  ov.innerHTML=`<img src="${_esc(url)}" style="max-width:100%;max-height:92%;object-fit:contain;">`;
  ov.onclick=()=>ov.remove();
  document.body.appendChild(ov);
}
// 관리 액션 소형 버튼 (한 줄 · 화면 안 가리게)
const _mBtnS=c=>`flex:1;padding:6px 2px;border-radius:8px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:${c};font-size:10px;font-weight:700;cursor:pointer;-webkit-appearance:none;appearance:none;`;
// ── 시설물 정보 공용 빌더 (지도 팝업 · 목록 상세 동일 내용) ──
function _facInfoHtml(f){
  const w=_facWarn(f);
  const col=_facTypeColor(f.type);
  // 짧은 정보(우측 열): 사진 옆에 나란히 — 세로 공간 절약
  const sRow=(k,v)=>v?`<div style="display:flex;gap:6px;padding:2px 0;"><span style="width:46px;flex-shrink:0;font-size:10px;color:#5d86a3;font-weight:700;">${k}</span><span style="flex:1;min-width:0;font-size:11px;color:#c9dcec;line-height:1.45;word-break:break-all;">${v}</span></div>`:'';
  const shortRows=[
    sRow('종류',`<span style="color:${col};font-weight:700;">${_esc(f.type)}</span>`),
    sRow('위치',_esc(_facZoneLbl(f)||'')),
    sRow('지점',_esc(_facSignDesc(f))),
    sRow('관리번호',f.mgmt?`<span style="font-family:monospace;font-size:10.5px;letter-spacing:.2px;">${_esc(f.mgmt)}</span>`:''),
    sRow('좌표',f.lat?`<span style="font-family:monospace;font-size:10.5px;">${f.lat.toFixed(5)}, ${f.lng.toFixed(5)}</span>`:''),
    sRow('설치',_esc(f.install||'')),
    sRow('등록',_esc(f.author||''))
  ].join('');
  // 긴 정보(하단 전폭)
  const rows=[];
  const row=(k,v)=>{if(v)rows.push(`<div style="display:flex;gap:8px;padding:2.5px 0;"><span style="min-width:50px;flex-shrink:0;font-size:10.5px;color:#5d86a3;font-weight:700;">${k}</span><span style="flex:1;font-size:11.5px;color:#c9dcec;line-height:1.5;word-break:break-all;">${v}</span></div>`);};
  row('규격',_esc(f.spec||''));
  row('구조',_esc(f.struct||''));
  row('비고',_esc(f.note||''));
  const iss=(DB.g('facIssues')||[]).filter(i=>i.facId===f.id).sort((a,b)=>(b.id||0)-(a.id||0)).slice(0,2);
  const issHtml=iss.map(i=>`<div onclick="event.stopPropagation();openFacIssueDetail(${i.id})" style="display:flex;align-items:center;gap:7px;background:rgba(255,255,255,.03);border-radius:8px;padding:6px 9px;margin-top:5px;cursor:pointer;">
      <span style="background:${_gColor(i.grade)}26;color:${_gColor(i.grade)};font-weight:900;border-radius:6px;padding:1px 7px;font-size:11px;flex-shrink:0;">${_esc(i.grade||'-')}</span>
      <span style="flex:1;font-size:10.5px;color:#a5abb3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${_esc(i.desc||(i.tags&&i.tags.join(', '))||'점검')}</span>
      <span style="font-size:9px;color:#6b7684;flex-shrink:0;">${i.id?new Date(i.id).toLocaleDateString('ko-KR',{month:'2-digit',day:'2-digit'}):''}</span>
    </div>`).join('');
  return `
    ${w?`<div style="background:rgba(224,80,80,.1);border:1px solid rgba(224,80,80,.4);border-radius:9px;padding:7px 10px;margin-bottom:8px;font-size:11px;color:#ffb0a5;line-height:1.6;"><b style="color:#ff5a45;">⚠️ 경고표시</b>${w.reason?' — '+_esc(w.reason):''} <span style="color:#c98;font-size:10px;">${_esc(_warnPeriodStr(w))}</span></div>`:''}
    <div style="display:flex;gap:9px;margin-bottom:${rows.length||issHtml?'8px':'0'};align-items:stretch;">
      ${f.photo?`<img src="${_esc(f.photo)}" loading="lazy" onclick="_facPhotoView('${_escq(f.photo)}')" style="width:42%;max-width:150px;aspect-ratio:4/3;object-fit:cover;border-radius:10px;cursor:pointer;flex-shrink:0;align-self:center;display:block;" alt="">`:''}
      <div style="flex:1;min-width:0;background:#0f0f11;border-radius:10px;padding:7px 9px;display:flex;flex-direction:column;justify-content:center;">${shortRows}</div>
    </div>
    ${rows.length?`<div style="background:#0f0f11;border-radius:10px;padding:7px 11px;">${rows.join('')}</div>`:''}
    ${issHtml?`<div style="font-size:10px;color:#5d86a3;font-weight:800;margin-top:8px;">🔧 최근 점검</div>${issHtml}`:''}`;
}
// 선택된 시설 핀 강조 — 팝업이 어떤 핀을 가리키는지 물결 링으로 표시
function _facPinHighlight(id){try{iEls.forEach(el=>{if(el&&el.classList)el.classList.toggle('mpin-sel',el._facId===id);});}catch(e){}}
function _facPinUnhighlight(){try{iEls.forEach(el=>{if(el&&el.classList)el.classList.remove('mpin-sel');});}catch(e){}}
function openFacFromMap(id){
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  selFacId=id;window._selFacDetailId=id;
  _facPinHighlight(id);
  const col=_facTypeColor(f.type);
  document.getElementById('facPopTitle').innerHTML=
    `<span style="display:inline-flex;align-items:center;gap:7px;flex-wrap:wrap;"><span style="width:25px;height:25px;border-radius:50%;background:${col}33;border:2px solid ${col};display:inline-flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;">${_esc(f.type.split(' ')[0])}</span><span>${_esc(_facDispName(f))}</span>${_facGradeBadge(f)}${f.hidden?'<span style="font-size:9px;color:#8a6d3b;">🙈 숨김중</span>':''}</span>`;
  document.getElementById('facPopMeta').innerHTML=_facInfoHtml(f);
  const _bw=document.getElementById('facPopBtns');
  const mng=_canManageFac();
  // 이전/다음: 탐방로 연속 체인(가까운 시설 순) — 누르면 지도가 그 시설로 이동
  const _ord=(typeof _facMapOrderCompute==='function'?_facMapOrderCompute():window._facMapOrder)||[];const _oi=_ord.indexOf(String(id));
  const _pv=_oi>0?_ord[_oi-1]:'',_nx=(_oi>=0&&_oi<_ord.length-1)?_ord[_oi+1]:'';
  const _navRow=(_ord.length>1&&_oi>=0)?`<div style="display:flex;align-items:center;gap:8px;">
      <button class="navbtn" ${_pv?`onclick="_facMapNav(${_pv})"`:'disabled'} style="padding:7px 4px;font-size:11.5px;">◀ 이전</button>
      <span style="font-size:10px;color:#5d86a3;font-weight:800;white-space:nowrap;">${_oi+1} / ${_ord.length}</span>
      <button class="navbtn" ${_nx?`onclick="_facMapNav(${_nx})"`:'disabled'} style="padding:7px 4px;font-size:11.5px;">다음 ▶</button>
    </div>`:'';
  if(_bw)_bw.innerHTML=_navRow
    +`<button class="btn" style="width:100%;padding:11px;background:rgba(255,255,255,.16);color:#3182f6;border:1px solid rgba(255,255,255,.4);font-weight:800;" onclick="openFacIssueReport(${f.id})">🔧 점검 등록</button>`
    +(mng?`<div style="display:flex;gap:5px;">
      <button onclick="openFacWarn(${f.id})" style="${_mBtnS('#f0a500')}">⚠️ 경고</button>
      <button onclick="toggleFacHide(${f.id})" style="${_mBtnS(f.hidden?'#f0a500':'#949aa2')}">${f.hidden?'👁️ 표시':'🙈 숨김'}</button>
      <button onclick="openEditFac(${f.id})" style="${_mBtnS('#949aa2')}">✏️ 수정</button>
      <button onclick="deleteFac(${f.id})" style="${_mBtnS('#ff8a73')}">🗑 삭제</button>
    </div>`:'');
  document.getElementById('resPopup').classList.remove('on');
  document.getElementById('facPopup').classList.add('on');
  _panPinAbovePopup(f.lat,f.lng); // 핀이 팝업에 가리지 않게 화면 위쪽으로
}
// 이전/다음으로 인접 시설 이동 — 지도도 함께 이동
function _facMapNav(id){
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  openFacFromMap(id);
}
// 열린 팝업(하단 시트)이 핀을 가리지 않도록 — 팝업 실제 높이를 재서 '팝업 위 남는 지도 영역'의 가운데로 팬
function _panPinAbovePopup(lat,lng){
  try{
    if(!mapI||!lat||!lng)return;
    const host=document.getElementById('v-inspect-map');
    if(!host||!host.classList.contains('on'))return;
    setTimeout(function(){
      try{
        const proj=mapI.getProjection();
        const pt=proj.containerPointFromCoords(new kakao.maps.LatLng(lat,lng));
        const w=host.clientWidth||window.innerWidth,h=host.clientHeight||window.innerHeight;
        const pop=document.getElementById('facPopup');
        const ph=(pop&&pop.classList.contains('on'))?pop.offsetHeight:0;
        const vis=Math.max(120,h-ph);
        const targetY=Math.max(50,vis*0.45);
        const dx=pt.x-w/2,dy=pt.y-targetY;
        if(Math.abs(dx)>40||Math.abs(dy)>40){
          const c=proj.containerPointFromCoords(mapI.getCenter());
          mapI.panTo(proj.coordsFromContainerPoint(new kakao.maps.Point(c.x+dx,c.y+dy)));
        }
      }catch(e){}
    },60);
  }catch(e){}
}
let _facListLimit=50,_facListSig='';
function _moreFacList(){_facListLimit+=50;renderFacList();}
function renderFacList(){
  _facMigrateV2();
  const _admin=isAdminUser();const _meta=DB.g('catFacMeta')||{};
  const facs=(DB.g('facilities')||[]).filter(f=>_admin||!(_meta[f.type]||{}).adminOnly);
  const types=[...new Set(facs.map(f=>{const t=String(f.type||'');return t.split(' ').slice(1).join(' ')||t;}).filter(Boolean))];
  const _sf=(DB.g('facilities')||[]).filter(f=>f.type&&f.type.includes('다목적위치표지판'));
  const locs=[...new Set(_sf.map(f=>(String(f.name||'').match(/\d+/)||[''])[0]).filter(Boolean))].sort();
  _updateFacListFilterPanel(types,locs);
  const filtered=facs.filter(f=>{
    if(!_facVisibleTo(f))return false;
    const sOk=facMapStatusF.size===0||(facMapStatusF.has('warn')&&!!_facWarn(f));
    const tOk=facMapTypeF.size===0||[...facMapTypeF].some(t=>f.type.includes(t));
    const lOk=facMapLocF.size===0||[...facMapLocF].some(v=>_facInZone(f,v));
    const _cg=facMapGradeF.size?_facCurGrade(f):null;
    const gOk=facMapGradeF.size===0||(_cg&&facMapGradeF.has(_cg.g));
    return sOk&&tOk&&lOk&&gOk;
  });
  // 경고표시 활성 우선 정렬
  filtered.sort((a,b)=>(_facWarn(b)?1:0)-(_facWarn(a)?1:0));
  _navOrder.fac=filtered.map(f=>String(f.id)); // 상세 이전/다음 순서 = 목록(필터·정렬) 순서
  // 필터가 바뀌면 페이지 한도 리셋
  const _sig=[...facMapStatusF].join()+'|'+[...facMapTypeF].join()+'|'+[...facMapLocF].join();
  if(_sig!==_facListSig){_facListSig=_sig;_facListLimit=50;}
  const _tot=filtered.length;
  let html=filtered.slice(0,_facListLimit).map(f=>{
    const w=_facWarn(f);
    const col=w?'#e05050':_facTypeColor(f.type);
    const cg=_facCurGrade(f);
    return `<div class="lcard" style="padding:7px 10px;border-left:3px solid ${col};" onclick="openFacDetail(${f.id})">
      <div class="lico" style="width:30px;height:30px;font-size:14px;border-color:${col};color:${col};background:${col}1e;">${_esc(f.type.split(' ')[0])}</div>
      <div class="linfo"><div class="lname" style="font-size:12px;">${_esc(_facDispName(f))}${f.hidden?' <span style="font-size:9px;color:#8a6d3b;">🙈 숨김</span>':''}</div>
        <div class="lmeta">${_esc(f.type.split(' ').slice(1).join(' ')||f.type)} · ${_esc(_facZoneLbl(f)||'-')} · ${f.lat?'📍':''}</div>
        ${w&&w.reason?`<span style="font-size:9px;color:#e05050;margin-top:2px;display:block;">⚠️ ${_esc(w.reason)}</span>`:''}
      </div>
      ${cg?`<span class="lbadge" style="background:${_gColor(cg.g)}22;color:${_gColor(cg.g)};font-weight:900;">${_esc(cg.g)}</span>`:''}
      ${w?`<span class="lbadge" style="background:#e0505022;color:#e05050;">⚠️ 경고</span>`:''}
    </div>`;
  }).join('');
  if(_tot>_facListLimit){
    html+=`<button onclick="_moreFacList()" style="width:100%;margin-top:8px;padding:11px;border-radius:10px;border:1px solid rgba(255,255,255,.3);background:rgba(255,255,255,.08);color:#3182f6;font-size:13px;font-weight:700;cursor:pointer;">▾ 더 보기 (${_tot-_facListLimit}건 더)</button>`;
  }
  document.getElementById('facListWrap').innerHTML=html||'<div class="empty"><div class="empty-ico">🛠️</div><div class="empty-txt">해당 조건 없음</div><button onclick="resetFacListFilter()" style="margin-top:10px;padding:7px 16px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.35);color:#3182f6;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">🔄 필터 초기화</button></div>';
}

function renderInspectStats(){
  _facMigrateV2();
  const facs=DB.g('facilities')||[];
  const warned=facs.filter(f=>_facWarn(f));
  const noGps=facs.filter(f=>!f.lat||!f.lng).length;
  const se=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  se('fs-tot',facs.length);se('fs-warn',warned.length);se('fs-nogps',noGps);
  // 안전등급 분포 (현재 등급 = 최신 점검>관리대장)
  {
    const gw=document.getElementById('facGradeStatWrap');
    if(gw){
      const gc={A:0,B:0,C:0,D:0,E:0};let none=0;
      facs.forEach(f=>{const cg=_facCurGrade(f);if(cg&&gc[cg.g]!==undefined)gc[cg.g]++;else none++;});
      const gmax=Math.max(...Object.values(gc),1);
      gw.innerHTML=['A','B','C','D','E'].map(g=>{
        const v=gc[g],c=_gColor(g);
        return `<div onclick="facMapGradeF=new Set(['${g}']);_persistFilters();switchTab(2,document.getElementById('nv2'));" style="display:flex;align-items:center;gap:8px;padding:4px 0;cursor:pointer;">
          <span style="min-width:70px;font-size:11px;color:${c};font-weight:800;">${g} ${_gLabel(g)}</span>
          <div style="flex:1;height:8px;background:rgba(255,255,255,.05);border-radius:4px;overflow:hidden;"><div style="height:100%;width:${v?Math.max(3,Math.round(v/gmax*100)):0}%;background:${c};border-radius:4px;"></div></div>
          <span style="font-size:11px;color:#eaecef;font-weight:800;min-width:34px;text-align:right;">${v}개</span>
        </div>`;
      }).join('')+(none?`<div style="font-size:9.5px;color:#565f6b;margin-top:4px;">등급 미지정 ${none}개 (다목적위치표지판 등)</div>`:'');
    }
  }
  const tm={};facs.forEach(f=>{tm[f.type]=(tm[f.type]||0)+1;});
  {// 종류별 분포 — 안전등급 분포와 같은 색 막대 스타일. 탭하면 그 종류만 지도에서 필터
    const rows=Object.entries(tm).sort((a,b)=>b[1]-a[1]);
    const tmax=Math.max(...rows.map(r=>r[1]),1);
    const PAL=['#3182f6','#5fcf8f','#f0c050','#e8879c','#b08ae8','#f0965a','#aab4c0','#9fb6c8'];
    document.getElementById('facTypeStatWrap').innerHTML=rows.map(([k,v],i)=>{
      const c=PAL[i%PAL.length];const lbl=k.split(' ').slice(1).join(' ')||k;
      return `<div class="type-row" onclick="facMapTypeF=new Set(['${_escq(lbl)}']);_persistFilters();switchTab(2,document.getElementById('nv2'));">
        <span class="t-ico">${_esc(k.split(' ')[0])}</span><span class="t-lbl" style="flex:none;width:104px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${_esc(lbl)}</span>
        <div style="flex:1;height:8px;background:rgba(255,255,255,.05);border-radius:4px;overflow:hidden;"><div style="height:100%;width:${Math.max(4,Math.round(v/tmax*100))}%;background:${c};border-radius:4px;"></div></div>
        <span class="t-cnt" style="color:${c};min-width:40px;text-align:right;">${v}<span style="font-size:10px;color:#949aa2;font-weight:600;">개</span></span></div>`;
    }).join('');
  }
  try{renderFacIssues();}catch(e){}
  const wr=document.getElementById('facWarnWrap');
  if(wr)wr.innerHTML=warned.length?warned.map(f=>{const w=_facWarn(f);
    return `<div onclick="openFacDetail(${f.id})" style="background:#0f0f11;border-radius:8px;padding:9px 11px;margin-bottom:5px;cursor:pointer;border-left:3px solid #e05050;"><div style="font-size:12px;font-weight:700;color:#ff7a6e;">⚠️ ${_esc(f.type.split(' ')[0])} ${_esc(f.name)}</div>${w.reason?`<div style="font-size:11px;color:rgba(255,255,255,.55);margin-top:2px;">${_esc(w.reason)}</div>`:''}<div style="font-size:10px;color:#8a6;margin-top:2px;">${_esc(_warnPeriodStr(w))}</div></div>`;
  }).join(''):'<div class="muted" style="font-size:12px;padding:5px 0;">경고표시된 시설 없음</div>';
}

// 시설물 상세 (목록 탭에서 탭하면 모달로 상세 + 점검/이력 버튼)
function openFacDetail(id){
  const facs=DB.g('facilities')||[];const f=facs.find(x=>x.id===id);if(!f)return;
  selFacId=id;window._selFacDetailId=id;
  // 점검이력(history)은 최근 90일만 실시간 구독 — 상세를 열면 과거 이력을 지연 로드(캐시 우선) 후 한 번 다시 그림
  if(typeof _ARCHIVE_COLLS!=='undefined'&&_ARCHIVE_COLLS.includes('history')&&!_archiveLoaded['history']){
    _loadArchive('history').then(()=>{try{if(window._selFacDetailId===id)openFacDetail(id);}catch(e){}});
  }
  // 상세 ◀▶: 목록 정렬(이름·가까운순 등)과 무관하게 트레일 순(구간→표지판 번호→인접 거리)으로 통일
  try{
    const _meta=DB.g('catFacMeta')||{};const _adm=isAdminUser();
    _navOrder.fac=_facTrailSort(facs.filter(x=>_facVisibleTo(x)&&(_adm||!(_meta[x.type]||{}).adminOnly))).map(x=>String(x.id));
  }catch(e){}
  const w=_facWarn(f);const canMng=_canManageFac();
  document.getElementById('facDetailTitle').textContent=_facDispName(f);
  const _dcol=_facTypeColor(f.type);
  document.getElementById('facDetailContent').innerHTML=`
    ${_navBtns('fac',id,'openFacDetail')}
    ${(()=>{try{ // 현재 구간 내 위치 표시: '10 (백담계곡) 구간 · 7/54번째' — ◀▶가 어디를 도는지 한눈에
      const z=_facZoneCode(f);if(!z)return '';
      const same=(_navOrder.fac||[]).map(s=>facs.find(x=>String(x.id)===s)).filter(x=>x&&_facZoneCode(x)===z);
      const zi=same.findIndex(x=>String(x.id)===String(id));
      return zi<0?'':`<div style="text-align:center;font-size:10px;color:#6b7684;margin:-4px 0 8px;">🗺 ${_esc(_zoneLbl(z))} 구간 · ${zi+1}/${same.length}</div>`;
    }catch(e){return '';}})()}
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
      <div style="width:38px;height:38px;border-radius:50%;background:${_dcol}33;border:2px solid ${_dcol};display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">${_esc(f.type.split(' ')[0])}</div>
      <div style="flex:1;min-width:0;"><div style="font-size:14px;font-weight:700;color:#eaecef;">${_esc(_facDispName(f))} ${_facGradeBadge(f)}</div>
        <div style="font-size:11px;color:${_dcol};margin-top:2px;">${_esc(f.type.split(' ').slice(1).join(' ')||f.type)}${f.hidden?' <span style="color:#8a6d3b;">· 🙈 숨김중</span>':''}</div>
      </div>
    </div>
    ${_facInfoHtml(f)}
    ${_facEditReqHtml(f,canMng)}
    <button class="btn" style="width:100%;margin-top:10px;background:rgba(255,255,255,.16);color:#3182f6;border:1px solid rgba(255,255,255,.4);font-weight:800;" onclick="openFacIssueReport(${f.id})">🔧 점검 등록 (사진·등급·점검내용)</button>
    ${(!canMng&&_isMemberSafe())?`<button class="btn" style="width:100%;margin-top:7px;background:rgba(94,207,143,.13);color:#5fcf8f;border:1px solid rgba(94,207,143,.4);font-weight:800;" onclick="openFacEditReq(${f.id})">✏️ 시설물 정보 수정 요청 (이름·종류·위치 등)</button>`:''}
    ${canMng?`<div style="display:flex;gap:5px;margin-top:7px;">
      <button onclick="openEditFac(${f.id})" style="${_mBtnS('#3182f6')}">✏️ 정보 수정</button>
      <button onclick="openFacWarn(${f.id})" style="${_mBtnS('#f0a500')}">⚠️ 경고 ${w?'수정/해제':''}</button>
      <button onclick="toggleFacHide(${f.id})" style="${_mBtnS(f.hidden?'#f0a500':'#949aa2')}">${f.hidden?'👁️ 표시':'🙈 숨김'}</button>
    </div>`:''}`;
  const mapBtn=document.getElementById('facDetailMapBtn');
  if(mapBtn)mapBtn.style.display=(f.lat&&f.lng)?'block':'none';
  const adminBtns=document.getElementById('facDetailAdminBtns');
  if(adminBtns)adminBtns.style.display=canMng?'flex':'none';
  document.getElementById('modalFacDetail').classList.add('on');
  document.getElementById('facPopup').classList.remove('on');
}
// ── 시설물 정보 수정 요청 (멤버 → 담당자) — 멤버는 직접 수정 대신 요청을 보내고, 담당자가 확인 후 반영 ──
function _isMemberSafe(){try{return (typeof _isMember==='function')?_isMember():true;}catch(e){return false;}}
// 상세 화면에 대기 중인 수정요청 표시 — 담당자에겐 모든 요청+반영버튼, 멤버에겐 본인 요청 상태만
function _facEditReqHtml(f,canMng){
  const reqs=(f.editReqs||[]).filter(r=>r&&r.status!=='done');
  if(!reqs.length)return '';
  const myK=String((DB.g('currentUser')||{}).kakaoId||'');
  if(!canMng){
    const mine=reqs.filter(r=>String(r.byKakaoId||'')===myK);
    if(!mine.length)return '';
    return `<div style="margin-top:10px;background:rgba(94,207,143,.08);border:1px solid rgba(94,207,143,.28);border-radius:11px;padding:10px 12px;">
      <div style="font-size:11px;font-weight:800;color:#5fcf8f;margin-bottom:5px;">✏️ 내 수정 요청 ${mine.length}건 · 검토 대기</div>
      ${mine.map(r=>`<div style="font-size:11.5px;color:#cbd6cf;line-height:1.5;padding:3px 0;border-top:1px solid rgba(255,255,255,.05);">${_esc(r.text)}<span style="display:block;font-size:9.5px;color:#6b7684;margin-top:1px;">${_fmtWhen(r.at)} 요청</span></div>`).join('')}
    </div>`;
  }
  return `<div style="margin-top:10px;background:rgba(94,207,143,.1);border:1px solid rgba(94,207,143,.4);border-radius:11px;padding:11px 12px;">
    <div style="font-size:12px;font-weight:800;color:#5fcf8f;margin-bottom:7px;">✏️ 수정 요청 ${reqs.length}건 — 확인 후 반영하세요</div>
    ${reqs.map(r=>`<div style="display:flex;gap:8px;align-items:flex-start;padding:6px 0;border-top:1px solid rgba(255,255,255,.06);">
      <span style="flex:1;min-width:0;font-size:12px;color:#e3eaef;line-height:1.5;">${_esc(r.text)}<span style="display:block;font-size:9.5px;color:#6b7684;margin-top:2px;">👤 ${_esc(r.by||'-')} · ${_fmtWhen(r.at)}</span></span>
      <button onclick="_facEditReqResolve(${f.id},${r.id})" style="flex-shrink:0;padding:5px 9px;border-radius:7px;border:1px solid rgba(94,207,143,.5);background:rgba(94,207,143,.14);color:#5fcf8f;font-size:10.5px;font-weight:800;cursor:pointer;">반영 완료</button>
    </div>`).join('')}
  </div>`;
}
function openFacEditReq(id){
  if(!_isMemberSafe()){toast('⚠️ 승인된 멤버만 요청할 수 있습니다');return;}
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  const old=document.getElementById('facEditReqOv');if(old)old.remove();
  const ov=document.createElement('div');ov.id='facEditReqOv';
  ov.style.cssText='position:fixed;inset:0;z-index:9860;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:18px;';
  ov.innerHTML=`<div style="background:#16161a;border:1px solid rgba(94,207,143,.4);border-radius:14px;max-width:360px;width:100%;padding:16px;">
    <div style="font-size:14px;font-weight:800;color:#5fcf8f;margin-bottom:3px;">✏️ 시설물 정보 수정 요청</div>
    <div style="font-size:11px;color:#8b95a1;margin-bottom:12px;">${_esc(f.type.split(' ')[0])} ${_esc(_facDispName(f))} — 담당자가 확인 후 반영합니다</div>
    <div style="font-size:11px;color:#a5abb3;font-weight:700;margin-bottom:4px;">어떤 정보가 잘못됐나요? <span style="color:#6b7684;font-weight:400;">(이름·종류·위치·등급 등)</span></div>
    <textarea id="ferText" class="fi" rows="4" placeholder="예: 이름이 '백운동교량'이 아니라 '백운교량'입니다 / 위치가 실제보다 계곡 위쪽에 찍혀 있습니다" style="width:100%;box-sizing:border-box;resize:vertical;margin-bottom:12px;"></textarea>
    <div style="display:flex;gap:7px;">
      <button onclick="document.getElementById('facEditReqOv').remove()" style="flex:1;padding:11px;border-radius:9px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.05);color:#c4c8ce;font-size:13px;font-weight:700;cursor:pointer;">취소</button>
      <button onclick="submitFacEditReq(${id})" style="flex:2;padding:11px;border-radius:9px;border:none;background:#2f9e5f;color:#fff;font-size:13px;font-weight:800;cursor:pointer;">요청 보내기</button>
    </div>
  </div>`;
  ov.onclick=function(e){if(e.target===ov)ov.remove();};
  document.body.appendChild(ov);
  setTimeout(()=>{try{document.getElementById('ferText').focus();}catch(e){}},50);
}
function submitFacEditReq(id){
  if(!_isMemberSafe()){toast('⚠️ 승인된 멤버만 요청할 수 있습니다');return;}
  const text=(document.getElementById('ferText')?.value||'').trim();
  if(text.length<4){toast('⚠️ 수정할 내용을 조금 더 자세히 적어주세요');return;}
  const facs=DB.g('facilities')||[];const idx=facs.findIndex(x=>x.id===id);if(idx<0)return;
  const u=DB.g('currentUser')||{};
  const req={id:Date.now(),by:getAuthor(),byKakaoId:String(u.kakaoId||''),at:Date.now(),text,status:'open'};
  facs[idx].editReqs=(facs[idx].editReqs||[]).concat([req]);
  DB.s('facilities',facs);
  const ov=document.getElementById('facEditReqOv');if(ov)ov.remove();
  toast('✅ 수정 요청을 보냈습니다 — 담당자 확인 후 반영됩니다');
  try{_notiFacManagers('✏️ 시설물 수정 요청: '+(_facDispName(facs[idx])||'시설물')+' — '+text.slice(0,40),{app:'inspect',id:id});}catch(e){}
  try{openFacDetail(id);}catch(e){}
}
function _facEditReqResolve(facId,reqId){
  if(!(_canManageFac()||_isMasterAdmin())){toast('⚠️ 담당자만 처리할 수 있습니다');return;}
  const facs=DB.g('facilities')||[];const idx=facs.findIndex(x=>x.id===facId);if(idx<0)return;
  const r=(facs[idx].editReqs||[]).find(x=>x.id===reqId);if(!r)return;
  r.status='done';r.doneBy=getAuthor();r.doneAt=Date.now();
  DB.s('facilities',facs);
  toast('✅ 반영 완료로 표시했습니다');
  try{openFacDetail(facId);}catch(e){}
}
// ── 경고표시 설정/수정/해제 (탐방시설과·개발자) — 사유는 선택, 기간(무제한/종료일) ──
function openFacWarn(id){
  if(!_canManageFac()){toast('⚠️ 탐방시설과·개발자만 가능');return;}
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  const w=f.warn||{};const active=!!_facWarn(f);
  const untilVal=w.until?new Date(w.until-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10):'';
  const unlimited=!w.until&&(w.on||false);
  const old=document.getElementById('facWarnOv');if(old)old.remove();
  const ov=document.createElement('div');ov.id='facWarnOv';
  ov.style.cssText='position:fixed;inset:0;z-index:9850;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:18px;';
  ov.innerHTML=`<div style="background:#16161a;border:1px solid rgba(224,80,80,.35);border-radius:14px;max-width:340px;width:100%;padding:16px;">
    <div style="font-size:14px;font-weight:800;color:#ff7a6e;margin-bottom:3px;">⚠️ 경고표시 설정</div>
    <div style="font-size:11px;color:#8b95a1;margin-bottom:12px;">${_esc(f.type.split(' ')[0])} ${_esc(f.name)} — 켜면 지도에 빨간색으로 깜빡입니다</div>
    <div style="font-size:11px;color:#a5abb3;font-weight:700;margin-bottom:4px;">사유 <span style="color:#6b7684;font-weight:400;">(선택 — 안 써도 됨)</span></div>
    <input type="text" id="fwReason" class="fi" placeholder="예: 데크 파손 통제, 낙석 위험" value="${_esc(w.reason||'')}" style="width:100%;box-sizing:border-box;margin-bottom:11px;">
    <div style="font-size:11px;color:#a5abb3;font-weight:700;margin-bottom:4px;">기간</div>
    <label style="display:flex;align-items:center;gap:7px;font-size:12px;color:#d5d8dc;margin-bottom:8px;cursor:pointer;">
      <input type="checkbox" id="fwUnlimited" ${unlimited?'checked':''} onchange="var d=document.getElementById('fwUntilWrap');if(d)d.style.display=this.checked?'none':'block';"> 무제한
    </label>
    <div id="fwUntilWrap" style="display:${unlimited?'none':'block'};margin-bottom:12px;">
      <div style="font-size:10px;color:#6b7684;margin-bottom:3px;">종료일 (이 날짜가 지나면 자동 해제)</div>
      <input type="date" id="fwUntil" class="fi" value="${untilVal}" style="width:100%;box-sizing:border-box;">
    </div>
    <div style="display:flex;gap:7px;">
      ${active?`<button onclick="clearFacWarn(${id})" style="flex:1;padding:11px;border-radius:9px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.05);color:#c4c8ce;font-size:13px;font-weight:700;cursor:pointer;">해제</button>`:''}
      <button onclick="saveFacWarn(${id})" style="flex:2;padding:11px;border-radius:9px;border:none;background:#c0392b;color:#fff;font-size:13px;font-weight:800;cursor:pointer;">${active?'변경 저장':'경고표시 켜기'}</button>
    </div>
    <button onclick="document.getElementById('facWarnOv').remove()" style="width:100%;margin-top:8px;padding:8px;border:none;background:none;color:#8b95a1;font-size:12px;cursor:pointer;">취소</button>
  </div>`;
  ov.onclick=function(e){if(e.target===ov)ov.remove();};
  document.body.appendChild(ov);
  setTimeout(()=>{try{document.getElementById('fwReason').focus();}catch(e){}},50);
}
function saveFacWarn(id){
  if(!_canManageFac()){toast('⚠️ 권한 없음');return;}
  const facs=DB.g('facilities')||[];const idx=facs.findIndex(x=>x.id===id);if(idx<0)return;
  const reason=(document.getElementById('fwReason')?.value||'').trim();
  const unlimited=document.getElementById('fwUnlimited')?.checked;
  let until=null;
  if(!unlimited){
    const dv=document.getElementById('fwUntil')?.value||'';
    if(!dv){toast('⚠️ 종료일을 정하거나 무제한을 선택하세요');return;}
    until=new Date(dv+'T23:59:59').getTime();
    if(until<Date.now()){toast('⚠️ 종료일이 과거입니다');return;}
  }
  const prev=facs[idx].warn||{};
  facs[idx].warn={on:true,reason,from:prev.from||Date.now(),until,by:getAuthor(),at:Date.now()};
  DB.s('facilities',facs);
  const ov=document.getElementById('facWarnOv');if(ov)ov.remove();
  try{renderInspectMap();}catch(e){}try{renderFacList();}catch(e){}try{_refreshFacSurface(id);}catch(e){}
  toast('⚠️ 경고표시 켜짐');updateSummary();
}
function clearFacWarn(id){
  if(!_canManageFac()){toast('⚠️ 권한 없음');return;}
  const facs=DB.g('facilities')||[];const idx=facs.findIndex(x=>x.id===id);if(idx<0)return;
  facs[idx].warn={on:false,clearedBy:getAuthor(),clearedAt:Date.now()};
  DB.s('facilities',facs);
  const ov=document.getElementById('facWarnOv');if(ov)ov.remove();
  try{renderInspectMap();}catch(e){}try{renderFacList();}catch(e){}try{_refreshFacSurface(id);}catch(e){}
  toast('✅ 경고표시 해제');updateSummary();
}
function viewOnFacMap(){
  const f=(DB.g('facilities')||[]).find(x=>x.id===selFacId);
  if(!f||!f.lat)return;
  closeM('modalFacDetail');
  if(curApp!=='inspect'){openApp('inspect');}
  else{switchTab(1,document.getElementById('nv1'));}
  setTimeout(function(){
    try{if(mapI){mapI.setCenter(new kakao.maps.LatLng(f.lat,f.lng));mapI.setLevel(4);}renderInspectMap();}catch(e){}
    openFacFromMap(f.id);
  },220);
}

// ══════════════════════════════════════════
// 시설물 점검 4단계 처리 워크플로
//  1 점검 등록(누구나: 사진 필수·등급·점검내용) → 2 담당자 재평가·의견 → 3 지역담당구역자 현장확인 → 4 시설과 조치·종료
//  · 등록 즉시 '시설물 담당자'에게만 알림(전체 진동 없음)
//  · 등급 A~E = 시설물 안전등급 (A 우수 ~ E 불량)
// ══════════════════════════════════════════
const FAC_GRADES={
  A:{l:'A 우수',c:'#27ae60',d:'문제 없음·양호'},
  B:{l:'B 양호',c:'#7ec8a0',d:'경미한 결함 — 관찰'},
  C:{l:'C 보통',c:'#f0c040',d:'보조부재 손상 — 주의'},
  D:{l:'D 미흡',c:'#e67e22',d:'주요부재 손상 — 긴급 보수'},
  E:{l:'E 불량',c:'#e05050',d:'심각 — 즉시 사용제한·조치'},
};
const FAC_ISTAGE={
  1:{l:'접수',ico:'📥',c:'#3182f6',who:'시설물 담당자 검토 대기'},
  2:{l:'담당자 검토',ico:'🔎',c:'#f0a500',who:'시설물 담당자 재평가 중'},
  3:{l:'구역 현장확인',ico:'🥾',c:'#9b59b6',who:'지역담당구역자 현장확인 중'},
  4:{l:'시설과 조치',ico:'🔧',c:'#e67e22',who:'탐방시설과 현장확인·조치 중'},
};
function _fmtWhen(ms){if(!ms)return '-';const d=new Date(ms);const p=n=>String(n).padStart(2,'0');return `${p(d.getMonth()+1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;}
function _fmtDateK(ms){if(!ms)return '-';const d=new Date(ms);return (d.getMonth()+1)+'/'+d.getDate();}
function _facIssues(){return DB.g('facIssues')||[];}
function _facIssueById(id){return _facIssues().find(x=>String(x.id)===String(id));}
function _facIssueOpen(){return _facIssues().filter(x=>x.status!=='closed');}
function _gLabel(g){return (FAC_GRADES[g]||{}).l||(g||'-');}
function _gColor(g){return (FAC_GRADES[g]||{}).c||'#8b95a1';}
// 내 검토 대기(담당자 배정됨 + 2단계 이하) 개수 — 배지용
function _facIssueMineWaiting(){
  if(!(_isFacManager()||_isMasterAdmin()))return 0;
  return _facIssueOpen().filter(it=>Number(it.stage||1)<=2).length;
}
function _issueLog(it,act){(it.log=it.log||[]).push({at:Date.now(),by:getAuthor(),act});}
function _saveFacIssue(it){
  const arr=_facIssues();const i=arr.findIndex(x=>String(x.id)===String(it.id));
  if(i>=0)arr[i]=it;else arr.push(it);
  DB.s('facIssues',arr);
}
function _facIssueLink(id){return {app:'inspect',issue:id};}
// 담당자에게만(없으면 관리자에게) 점검 알림 — 전체 진동/FCM 없음
function _notiFacManagers(msg,link){
  const mgrs=_facManagers();
  if(mgrs.length)pushNoti(msg,'🚨','fac_issue',link,null,{targetKakaoIds:mgrs});
  else pushNoti(msg,'🚨','fac_issue',link,null,{adminOnly:true}); // 담당자 미지정 시 관리자에게
}
// 담당자 + 신고자에게 진행 알림
function _notiFacFollow(msg,link,it){
  const ids=_facManagers().slice();
  if(it&&it.reporterKakaoId)ids.push(String(it.reporterKakaoId));
  const uniq=[...new Set(ids.filter(Boolean))];
  if(uniq.length)pushNoti(msg,'🏗️','fac_issue',link,null,{targetKakaoIds:uniq});
}

// 점검내용 빠른 선택 태그 (다중 선택 + 상세는 자유 입력)
const INSPECT_TAGS=['이상없음','노후화','파손','부식','균열','도색벗겨짐','기울어짐','침하','기타'];
let _facIssueTags=new Set();
let _facIssueGrade='';     // 점검 폼에서 선택한 등급
let _facIssueForFacId=null;// 점검 대상 시설 id
function _toggleInspTag(t){
  if(_facIssueTags.has(t))_facIssueTags.delete(t);else _facIssueTags.add(t);
  const el=document.getElementById('fiTag_'+t);
  if(el){const on=_facIssueTags.has(t);
    el.style.background=on?'rgba(255,255,255,.2)':'rgba(255,255,255,.03)';
    el.style.color=on?'#3182f6':'rgba(255,255,255,.5)';
    el.style.borderColor=on?'rgba(255,255,255,.5)':'rgba(255,255,255,.12)';
    el.style.fontWeight=on?'800':'700';
  }
}
function _renderInspTags(){
  const wrap=document.getElementById('fiTagRow');if(!wrap)return;
  wrap.innerHTML=INSPECT_TAGS.map(t=>{const on=_facIssueTags.has(t);
    return `<div id="fiTag_${t}" onclick="_toggleInspTag('${_escq(t)}')" style="cursor:pointer;border-radius:18px;font-size:11px;font-weight:${on?'800':'700'};padding:6px 12px;border:1px solid ${on?'rgba(255,255,255,.5)':'rgba(255,255,255,.12)'};background:${on?'rgba(255,255,255,.2)':'rgba(255,255,255,.03)'};color:${on?'#3182f6':'rgba(255,255,255,.5)'};">${_esc(t)}</div>`;
  }).join('');
}
function _pickIssueGrade(g){
  _facIssueGrade=g;
  ['A','B','C','D','E'].forEach(k=>{
    const el=document.getElementById('fiG_'+k);if(!el)return;
    const on=k===g;const c=_gColor(k);
    el.style.background=on?c:'rgba(255,255,255,.03)';
    el.style.color=on?'#08121e':(k===g?'#fff':'rgba(255,255,255,.55)');
    el.style.borderColor=on?c:'rgba(255,255,255,.12)';
    el.style.fontWeight=on?'900':'700';
  });
  const d=document.getElementById('fiGradeDesc');
  if(d)d.innerHTML=g?`<span style="color:${_gColor(g)};font-weight:700;">${_gLabel(g)}</span> — ${(FAC_GRADES[g]||{}).d||''}`:'등급을 선택하세요';
}
// 점검 등록 폼 열기 — 반드시 등록된 시설물 기준(위치·GPS는 시설 고정, 수정 불가)
function openFacIssueReport(facId){
  const f=facId?(DB.g('facilities')||[]).find(x=>x.id===facId):null;
  if(!f){toast('⚠️ 지도·목록에서 시설물을 선택해 점검하세요');return;}
  _facIssueForFacId=f.id;
  _facIssueGrade='';
  _facIssueTags=new Set();
  const fixed=document.getElementById('fiFacFixed');
  fixed.innerHTML=`<div style="font-size:13px;font-weight:800;color:#eaecef;">${_esc(f.type.split(' ')[0])} ${_esc(f.name)}</div>
    <div style="font-size:11px;color:#8b95a1;margin-top:3px;">📍 ${_esc(f.loc||'위치정보 없음')}</div>
    <div style="font-size:10px;color:#6b7684;margin-top:2px;font-family:monospace;">${f.lat?'GPS '+f.lat.toFixed(5)+', '+f.lng.toFixed(5):'GPS 미등록'} <span style="font-family:inherit;">· 시설 고정(수정 불가)</span></div>`;
  document.getElementById('fiDesc').value='';
  _renderInspTags();
  const pv=document.getElementById('prevFacIssue');if(pv){pv.innerHTML='📸 촬영 또는 앨범 (필수)';pv.dataset.url='';}
  const fi=document.getElementById('fileFacIssue');if(fi)fi.value='';
  _pickIssueGrade('');
  try{closeM('modalFacDetail');}catch(e){}
  try{document.getElementById('facPopup').classList.remove('on');}catch(e){}
  document.getElementById('modalFacIssue').classList.add('on');
}
function submitFacIssue(){
  const f=_facIssueForFacId?(DB.g('facilities')||[]).find(x=>x.id===_facIssueForFacId):null;
  if(!f){toast('⚠️ 시설물을 선택해 점검하세요');return;}
  if(!_facIssueGrade){toast('⚠️ 등급(A~E)을 선택하세요');return;}
  // 현장사진 필수 — 업로드 중(pending)이어도 선택된 것으로 인정
  const praw=document.getElementById('prevFacIssue')?.dataset?.url||'';
  if(!praw){toast('⚠️ 현장사진은 필수입니다 (촬영/앨범)');return;}
  const facName=f.type.split(' ')[0]+' '+f.name;
  const desc=(document.getElementById('fiDesc')?.value||'').trim();
  const tags=[...INSPECT_TAGS].filter(t=>_facIssueTags.has(t)); // 순서 고정
  const loc=f.loc||''; const lat=f.lat||null, lng=f.lng||null; // 위치·GPS는 시설 고정
  const u=DB.g('currentUser')||{};
  const id=Date.now();
  const it={
    id,facId:f.id,facName,facType:f.type,
    grade:_facIssueGrade,tags,desc,loc,lat,lng,
    photo:_photoUrl('prevFacIssue'),
    reporter:getAuthor(),reporterKakaoId:String(u.kakaoId||''),
    createdAt:id,stage:2,status:'open',log:[]  // 등록 완료 → 담당자 검토(2단계) 대기
  };
  _issueLog(it,`점검 등록 (등급 ${it.grade}${tags.length?' · '+tags.join(','):''})`);
  _saveFacIssue(it);
  // D·E 등급 점검 → 경고표시 자동 켜기 (조치 완료로 A~C 회복 시 자동 해제)
  try{
    if(it.grade==='D'||it.grade==='E'){
      const _fs2=DB.g('facilities')||[];const _fi=_fs2.findIndex(x=>x.id===f.id);
      if(_fi>=0&&!_facWarn(_fs2[_fi])){
        _fs2[_fi].warn={on:true,reason:'점검 '+it.grade+'등급'+(desc?' — '+desc:''),from:Date.now(),until:null,by:getAuthor(),at:Date.now(),auto:true};
        DB.s('facilities',_fs2);
        toast('⚠️ '+it.grade+'등급 — 경고표시 자동 설정');
      }
    }
  }catch(e){}
  try{_registerPendingPhoto('prevFacIssue',{key:'facIssues',id,field:'photo'});}catch(e){}
  _notiFacManagers(`🔧 시설물 점검 [${it.grade}등급] ${facName}${tags.length?' · '+tags.join(','):''} — ${it.reporter}`,_facIssueLink(id));
  closeM('modalFacIssue');
  toast('✅ 점검 등록 — 담당자 검토 요청');
  try{renderFacIssues();}catch(e){}try{renderInspectMap();}catch(e){}
}

// ── 점검 상세 + 단계별 조치 ──
function _issueStageBar(cur,closed){
  return `<div style="display:flex;gap:3px;margin:10px 0;">`+[1,2,3,4].map(s=>{
    const st=FAC_ISTAGE[s];const done=closed?(cur>=s):(cur>s);const active=!closed&&cur===s;
    const bg=done?'rgba(39,174,96,.18)':active?st.c:'rgba(255,255,255,.04)';
    const col=done?'#7ec8a0':active?'#08121e':'rgba(255,255,255,.35)';
    return `<div style="flex:1;text-align:center;background:${bg};color:${col};border-radius:6px;padding:5px 2px;font-size:9px;font-weight:800;line-height:1.3;">${done?'✓':st.ico}<br>${st.l}</div>`;
  }).join('')+`</div>`;
}
function openFacIssueDetail(id){
  const it=_facIssueById(id);if(!it){toast('점검 기록을 찾을 수 없습니다');return;}
  const closed=it.status==='closed';const stage=Number(it.stage||1);
  const canReview=_isFacManager()||_isMasterAdmin();
  const canZone=(typeof _isMember==='function')?_isMember():true;
  const canDept=_canManageFac();
  const gc=_gColor(it.grade);
  let h=`
    <div style="display:flex;align-items:center;gap:9px;margin-bottom:4px;">
      <div style="background:${gc};color:#08121e;font-weight:900;border-radius:8px;padding:4px 10px;font-size:15px;">${_esc(it.grade)}</div>
      <div style="flex:1;min-width:0;"><div style="font-size:14px;font-weight:800;color:#eaecef;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(it.facName)}</div>
        <div style="font-size:10px;color:#8b95a1;">점검 등급: <span style="color:${gc};font-weight:700;">${_gLabel(it.grade)}</span></div></div>
      ${closed?'<span style="background:rgba(39,174,96,.18);color:#7ec8a0;font-size:11px;font-weight:800;border-radius:7px;padding:4px 9px;">✅ 종료</span>':`<span style="background:${FAC_ISTAGE[stage].c};color:#08121e;font-size:11px;font-weight:800;border-radius:7px;padding:4px 9px;">${FAC_ISTAGE[stage].ico} ${FAC_ISTAGE[stage].l}</span>`}
    </div>
    ${_issueStageBar(stage,closed)}
    ${closed?'':`<div style="font-size:11px;color:${FAC_ISTAGE[stage].c};text-align:center;margin-bottom:8px;">▶ ${FAC_ISTAGE[stage].who}</div>`}`;

  // 1) 점검 내용
  const _tagChips=(it.tags&&it.tags.length)?`<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px;">${it.tags.map(t=>`<span style="background:rgba(255,255,255,.15);color:#3182f6;font-size:11px;font-weight:700;border-radius:14px;padding:3px 10px;">${_esc(t)}</span>`).join('')}</div>`:'';
  h+=`<div style="background:#0f0f11;border-radius:10px;padding:11px;margin-bottom:9px;">
    <div style="font-size:11px;font-weight:800;color:#3182f6;margin-bottom:6px;">📥 1. 점검 등록 <span style="color:#6b7684;font-weight:400;">· ${_esc(it.reporter||'-')} · ${_fmtWhen(it.createdAt)}</span></div>
    ${it.photo?`<img src="${_esc(it.photo)}" style="width:100%;border-radius:8px;margin-bottom:7px;max-height:240px;object-fit:cover;cursor:pointer;" onclick="_facPhotoView('${_escq(it.photo)}')">`:''}
    ${_tagChips}
    <div style="font-size:12px;color:#d5d8dc;line-height:1.6;">${it.desc?_esc(it.desc):(it.tags&&it.tags.length?'':'<span style="color:#6b7684;">상세 설명 없음</span>')}</div>
    <div style="font-size:11px;color:#8b95a1;margin-top:5px;">📍 ${_esc(it.loc||'-')}${it.lat?` <span style="font-family:monospace;color:#565f6b;">(${it.lat.toFixed(4)}, ${it.lng.toFixed(4)})</span>`:''}</div>
  </div>`;

  // 2) 담당자 검토
  if(it.mgr){
    const mg=it.mgr;const mgc=_gColor(mg.grade);
    h+=`<div style="background:#0f0f11;border-radius:10px;padding:11px;margin-bottom:9px;border-left:3px solid ${mg.decision==='ok'?'#27ae60':'#f0a500'};">
      <div style="font-size:11px;font-weight:800;color:#f0a500;margin-bottom:6px;">🔎 2. 담당자 검토 <span style="color:#6b7684;font-weight:400;">· ${_esc(mg.by||'-')} · ${_fmtWhen(mg.at)}</span></div>
      <div style="font-size:12px;color:#d5d8dc;margin-bottom:4px;">재평가 등급: <b style="color:${mgc};">${_gLabel(mg.grade)}</b> · 판정: <b style="color:${mg.decision==='ok'?'#7ec8a0':'#ff9a6e'};">${mg.decision==='ok'?'이상없음 회신·종료':'D·E 판정 → 현장확인'}</b></div>
      ${mg.opinion?`<div style="font-size:12px;color:#d5d8dc;line-height:1.6;">💬 ${_esc(mg.opinion)}</div>`:''}
    </div>`;
  } else if(stage===2 && !closed && canReview){
    const _rg=it.grade;const _rde=_rg==='D'||_rg==='E';
    h+=`<div style="background:rgba(240,165,0,.06);border:1px solid rgba(240,165,0,.3);border-radius:10px;padding:11px;margin-bottom:9px;">
      <div style="font-size:11px;font-weight:800;color:#f0a500;margin-bottom:7px;">🔎 2. 담당자 재평가</div>
      <div style="font-size:10px;color:#a5abb3;margin-bottom:4px;">재평가 등급 <span style="color:#6b7684;font-weight:400;">— 등급에 따라 처리 경로가 정해집니다</span></div>
      <select id="fiMgrGrade" class="fsel" onchange="_fiMgrUpdate()" style="margin-bottom:6px;">${['A','B','C','D','E'].map(g=>`<option value="${g}"${g===it.grade?' selected':''}>${_gLabel(g)}</option>`).join('')}</select>
      <div id="fiMgrHint" style="font-size:10px;line-height:1.5;margin-bottom:8px;color:${_rde?'#ff9a6e':'#7ec8a0'};">${_rde?'D·E 등급: <b>지역담당구역자 현장확인</b> 단계로 넘어갑니다':'A·B·C 등급: 판정 사유를 회신하고 <b>이상없음 종료</b>됩니다 (사유 필수)'}</div>
      <textarea id="fiMgrOpinion" class="fta" rows="2" placeholder="${_rde?'검토 의견 (선택 — 예: 데크 침하 심함, 통제 검토)':'판정 사유 (필수 — 왜 이 등급인지 회신)'}" style="margin-bottom:8px;"></textarea>
      <button id="fiMgrBtn" onclick="facIssueReview(${it.id})" style="width:100%;background:${_rde?'#c0392b':'#1e7a4e'};color:#fff;border:none;border-radius:8px;padding:10px;font-size:12px;font-weight:800;cursor:pointer;">${_rde?'⚠️ '+_rg+'등급 확정 → 지역담당 현장확인 요청':'✅ '+_rg+'등급 · 사유 회신 후 이상없음 종료'}</button>
    </div>`;
  } else if(stage<2){
    h+=`<div style="background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.1);border-radius:10px;padding:10px;margin-bottom:9px;font-size:11px;color:#6b7684;">🔎 2. 담당자 검토 — 대기 중${canReview?' (담당자: 위 알림/목록에서 검토)':''}</div>`;
  }

  // 3) 지역담당구역자 현장확인
  if(it.zone){
    h+=`<div style="background:#0f0f11;border-radius:10px;padding:11px;margin-bottom:9px;border-left:3px solid #9b59b6;">
      <div style="font-size:11px;font-weight:800;color:#b07cd0;margin-bottom:6px;">🥾 3. 구역 현장확인 <span style="color:#6b7684;font-weight:400;">· ${_esc(it.zone.by||'-')} · ${_fmtWhen(it.zone.at)}</span></div>
      <div style="font-size:12px;color:#d5d8dc;line-height:1.6;">${it.zone.note?_esc(it.zone.note):'<span style="color:#6b7684;">확인 완료</span>'}</div>
    </div>`;
  } else if(stage===3 && !closed && canZone){
    h+=`<div style="background:rgba(155,89,182,.07);border:1px solid rgba(155,89,182,.3);border-radius:10px;padding:11px;margin-bottom:9px;">
      <div style="font-size:11px;font-weight:800;color:#b07cd0;margin-bottom:7px;">🥾 3. 지역담당구역자 현장확인</div>
      <textarea id="fiZoneNote" class="fta" rows="2" placeholder="현장 확인 결과 (예: 데크 3판 파손 확인, 임시 통제 설치)" style="margin-bottom:8px;"></textarea>
      <button onclick="facIssueZone(${it.id})" style="width:100%;background:#7a4a9e;color:#fff;border:none;border-radius:8px;padding:9px;font-size:12px;font-weight:800;cursor:pointer;">현장확인 완료 → 시설과 이관</button>
    </div>`;
  } else if(stage<3 && !closed){
    h+=`<div style="background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.1);border-radius:10px;padding:10px;margin-bottom:9px;font-size:11px;color:#6b7684;">🥾 3. 구역 현장확인 — 담당자 확인 후 진행</div>`;
  }

  // 4) 시설과 조치 — 완료 시 조치 후 등급(A~E) 선택, 오래 걸리면 조치 예정일 등록
  const planBanner=(!closed&&it.plan&&it.plan.until)?(()=>{const od=it.plan.until<Date.now();
    return `<div style="background:${od?'rgba(224,80,80,.08)':'rgba(255,255,255,.07)'};border:1px solid ${od?'rgba(224,80,80,.35)':'rgba(255,255,255,.25)'};border-radius:9px;padding:8px 11px;margin-bottom:8px;">
      <div style="font-size:11px;font-weight:800;color:${od?'#ff7a6e':'#3182f6'};">🗓️ ${_fmtDateK(it.plan.until)}까지 조치 예정${od?' — 예정일 지남':''}</div>
      ${it.plan.note?`<div style="font-size:11px;color:#a5abb3;margin-top:3px;">${_esc(it.plan.note)}</div>`:''}
      <div style="font-size:9px;color:#6b7684;margin-top:2px;">${_esc(it.plan.by||'')} · ${_fmtWhen(it.plan.at)}</div>
    </div>`;})():'';
  if(it.dept){
    h+=`<div style="background:#0f0f11;border-radius:10px;padding:11px;margin-bottom:9px;border-left:3px solid #27ae60;">
      <div style="font-size:11px;font-weight:800;color:#7ec8a0;margin-bottom:6px;">🔧 4. 시설과 조치 <span style="color:#6b7684;font-weight:400;">· ${_esc(it.dept.by||'-')} · ${_fmtWhen(it.dept.at)}</span></div>
      ${it.dept.grade?`<div style="font-size:12px;color:#d5d8dc;margin-bottom:4px;">조치 후 등급: <b style="color:${_gColor(it.dept.grade)};">${_gLabel(it.dept.grade)}</b></div>`:''}
      <div style="font-size:12px;color:#d5d8dc;line-height:1.6;">${it.dept.note?_esc(it.dept.note):'<span style="color:#6b7684;">조치 완료</span>'}</div>
    </div>`;
  } else if(stage===4 && !closed && canDept){
    const defG=(it.mgr&&it.mgr.grade)||it.grade;
    const planVal=it.plan&&it.plan.until?new Date(it.plan.until-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10):'';
    h+=`<div style="background:rgba(39,174,96,.06);border:1px solid rgba(39,174,96,.3);border-radius:10px;padding:11px;margin-bottom:9px;">
      <div style="font-size:11px;font-weight:800;color:#7ec8a0;margin-bottom:7px;">🔧 4. 탐방시설과 현장확인·조치</div>
      ${planBanner}
      <div style="font-size:10px;color:#a5abb3;margin-bottom:4px;">조치 후 등급 (A~E)</div>
      <select id="fiDeptGrade" class="fsel" style="margin-bottom:8px;">${['A','B','C','D','E'].map(g=>`<option value="${g}"${g===defG?' selected':''}>${_gLabel(g)}</option>`).join('')}</select>
      <textarea id="fiDeptNote" class="fta" rows="2" placeholder="조치 내용 (예: 데크 교체 완료 / 예산 반영 예정)" style="margin-bottom:8px;"></textarea>
      <button onclick="facIssueDept(${it.id})" style="width:100%;background:#0c4838;color:#fff;border:none;border-radius:8px;padding:10px;font-size:12px;font-weight:800;cursor:pointer;">✅ 조치 완료 → 종료</button>
      <div style="display:flex;align-items:center;gap:8px;margin:10px 0 7px;"><div style="flex:1;height:1px;background:rgba(255,255,255,.08);"></div><span style="font-size:10px;color:#6b7684;white-space:nowrap;">고치는 데 시간이 오래 걸리면</span><div style="flex:1;height:1px;background:rgba(255,255,255,.08);"></div></div>
      <div style="display:flex;gap:6px;">
        <input type="date" id="fiDeptUntil" class="fi" style="flex:1;box-sizing:border-box;" value="${planVal}">
        <button onclick="facIssueDeptPlan(${it.id})" style="flex-shrink:0;background:rgba(255,255,255,.15);color:#3182f6;border:1px solid rgba(255,255,255,.4);border-radius:8px;padding:0 13px;font-size:11px;font-weight:800;cursor:pointer;">🗓️ ${it.plan?'예정 변경':'예정 등록'}</button>
      </div>
      <div style="font-size:9px;color:#6b7684;margin-top:4px;">예정 등록 시 종료되지 않고 '${'~'}까지 조치 예정'으로 표시됩니다</div>
    </div>`;
  } else if(stage===4 && !closed){
    h+=`<div style="background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.1);border-radius:10px;padding:10px;margin-bottom:9px;">
      <div style="font-size:11px;color:#6b7684;margin-bottom:${it.plan?'7px':'0'};">🔧 4. 시설과 조치 — 탐방시설과 처리 대기 중</div>${planBanner}</div>`;
  } else if(stage<4 && !closed){
    h+=`<div style="background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.1);border-radius:10px;padding:10px;margin-bottom:9px;font-size:11px;color:#6b7684;">🔧 4. 시설과 조치 — 현장확인 후 진행</div>`;
  }

  if(closed){
    h+=`<div style="background:rgba(39,174,96,.08);border:1px solid rgba(39,174,96,.3);border-radius:10px;padding:10px 12px;margin-bottom:9px;text-align:center;">
      <div style="font-size:12px;font-weight:800;color:#7ec8a0;">✅ 처리 종료</div>
      <div style="font-size:10px;color:#8b95a1;margin-top:3px;">${_esc(it.closeReason||'')}${it.closedBy?' · '+_esc(it.closedBy):''}${it.closedAt?' · '+_fmtWhen(it.closedAt):''}</div>
    </div>`;
  }

  // 관리(종료·삭제) — 시설과·마스터, 또는 접수 단계 신고자 본인
  const isReporter=String((DB.g('currentUser')||{}).kakaoId||'')===String(it.reporterKakaoId||'##');
  const canDelete=canDept||_isMasterAdmin()||(isReporter&&stage===1&&!closed);
  h+=`<div style="display:flex;gap:6px;margin-top:4px;">`;
  if(!closed&&(canReview||canDept))h+=`<button onclick="facIssueClose(${it.id})" style="flex:1;background:rgba(255,255,255,.05);color:#c4c8ce;border:1px solid rgba(255,255,255,.15);border-radius:8px;padding:8px;font-size:11px;cursor:pointer;">조기 종료</button>`;
  if(closed&&canDept)h+=`<button onclick="facIssueReopen(${it.id})" style="flex:1;background:rgba(240,165,0,.1);color:#f0a500;border:1px solid rgba(240,165,0,.3);border-radius:8px;padding:8px;font-size:11px;cursor:pointer;">재개</button>`;
  if(canDelete)h+=`<button onclick="facIssueDelete(${it.id})" style="flex:1;background:rgba(224,80,80,.1);color:#ff8a80;border:1px solid rgba(224,80,80,.25);border-radius:8px;padding:8px;font-size:11px;cursor:pointer;">🗑️ 삭제</button>`;
  h+=`</div>`;

  // 처리 이력
  if(it.log&&it.log.length){
    h+=`<div style="margin-top:10px;border-top:1px solid rgba(255,255,255,.06);padding-top:8px;"><div style="font-size:10px;color:#6b7684;font-weight:700;margin-bottom:4px;">📜 처리 이력</div>`
      +it.log.slice().reverse().map(l=>`<div style="font-size:10px;color:#6a8296;line-height:1.6;">· ${_fmtWhen(l.at)} · ${_esc(l.by||'')} — ${_esc(l.act||'')}</div>`).join('')+`</div>`;
  }

  document.getElementById('facIssueDetailBody').innerHTML=h;
  document.getElementById('modalFacIssueDetail').classList.add('on');
}
// 재평가 등급 선택에 따라 안내문·버튼을 즉시 갱신 (D·E=현장확인 / A·B·C=사유 회신·종료)
function _fiMgrUpdate(){
  const g=document.getElementById('fiMgrGrade')?.value||'';
  const de=g==='D'||g==='E';
  const hint=document.getElementById('fiMgrHint');
  if(hint){hint.style.color=de?'#ff9a6e':'#7ec8a0';
    hint.innerHTML=de?'D·E 등급: <b>지역담당구역자 현장확인</b> 단계로 넘어갑니다':'A·B·C 등급: 판정 사유를 회신하고 <b>이상없음 종료</b>됩니다 (사유 필수)';}
  const ta=document.getElementById('fiMgrOpinion');
  if(ta)ta.placeholder=de?'검토 의견 (선택 — 예: 데크 침하 심함, 통제 검토)':'판정 사유 (필수 — 왜 이 등급인지 회신)';
  const b=document.getElementById('fiMgrBtn');
  if(b){b.style.background=de?'#c0392b':'#1e7a4e';
    b.textContent=de?('⚠️ '+g+'등급 확정 → 지역담당 현장확인 요청'):('✅ '+g+'등급 · 사유 회신 후 이상없음 종료');}
}
// 담당자 재평가 — 등급이 경로를 결정: D·E → 3단계(현장확인) / A·B·C → 사유 회신 후 이상없음 종료
// 상세 모달·담당 업무함 양쪽에서 호출 — 값은 래퍼가 읽고 코어가 처리
function _facIssueReviewCore(id,grade,opinion,fromWork){
  if(!(_isFacManager()||_isMasterAdmin())){toast('⚠️ 시설물 담당자만 검토할 수 있습니다');return;}
  const it=_facIssueById(id);if(!it)return;
  grade=grade||it.grade;
  const de=grade==='D'||grade==='E';
  if(!de&&!opinion){toast('⚠️ A·B·C 판정은 사유(왜 이 등급인지)를 적어 회신하세요');return;}
  it.mgr={grade,opinion,by:getAuthor(),at:Date.now(),decision:de?'problem':'ok'};
  if(!de){
    it.status='closed';it.stage=2;it.closeReason='담당자 '+grade+'등급 판정 — 이상없음 회신';it.closedBy=getAuthor();it.closedAt=Date.now();
    _issueLog(it,`담당자 검토 — ${_gLabel(grade)} 사유 회신·이상없음 종료`);
    _saveFacIssue(it);
    // 담당자가 A·B·C로 재평가 = 이상없음 → 점검(D·E)이 자동으로 켰던 경고표시 해제
    // (예전엔 여기서 안 지워, 등급은 우수인데 지도·목록에 빨간 경고가 영구 잔존하던 문제)
    try{
      const _fs2=DB.g('facilities')||[];const _fi=_fs2.findIndex(x=>x.id===it.facId);
      if(_fi>=0&&_fs2[_fi].warn&&_fs2[_fi].warn.on&&_fs2[_fi].warn.auto){
        _fs2[_fi].warn={on:false,clearedBy:getAuthor(),clearedAt:Date.now()};
        DB.s('facilities',_fs2);
      }
    }catch(e){}
    _notiFacFollow(`✅ 점검 검토 종료(${_gLabel(grade)}) · ${it.facName} — ${getAuthor()}`,_facIssueLink(id),it);
    toast('✅ '+grade+'등급 회신 — 이상없음 종료');
  }else{
    it.stage=3;
    _issueLog(it,`담당자 검토 — ${_gLabel(grade)} 확정, 지역담당 현장확인 요청`);
    _saveFacIssue(it);
    _notiFacFollow(`🥾 점검 현장확인 요청 · ${it.facName} (${_gLabel(grade)}) — 지역담당구역자 확인 필요`,_facIssueLink(id),it);
    toast('⚠️ '+grade+'등급 — 현장확인 단계로');
  }
  _facIssueAfterAction(id,fromWork);
}
function facIssueReview(id){
  _facIssueReviewCore(id,document.getElementById('fiMgrGrade')?.value||'',(document.getElementById('fiMgrOpinion')?.value||'').trim(),false);
}
function _facIssueZoneCore(id,note,fromWork){
  if(!((typeof _isMember==='function')?_isMember():true)){toast('⚠️ 멤버만 가능');return;}
  const it=_facIssueById(id);if(!it)return;
  if(Number(it.stage)!==3){toast('현재 단계가 아닙니다');return;}
  it.zone={note,by:getAuthor(),at:Date.now()};it.stage=4;
  _issueLog(it,'지역담당구역자 현장확인 완료 → 시설과 이관');
  _saveFacIssue(it);
  _notiFacFollow(`🔧 점검 시설과 이관 · ${it.facName} — 현장확인 완료`,_facIssueLink(id),it);
  toast('✅ 현장확인 완료 — 시설과 이관');
  _facIssueAfterAction(id,fromWork);
}
function facIssueZone(id){_facIssueZoneCore(id,(document.getElementById('fiZoneNote')?.value||'').trim(),false);}
function _facIssueDeptCore(id,note,grade,fromWork){
  if(!_canManageFac()){toast('⚠️ 탐방시설과·개발자만 가능');return;}
  const it=_facIssueById(id);if(!it)return;
  grade=grade||(it.mgr&&it.mgr.grade)||it.grade; // 조치 후 최종 등급 (미선택 시 직전 등급 유지)
  it.dept={note,grade,by:getAuthor(),at:Date.now()};
  delete it.plan; // 예정 상태 해소
  it.status='closed';it.closeReason='시설과 조치 완료 ('+grade+'등급)';it.closedBy=getAuthor();it.closedAt=Date.now();
  _issueLog(it,`시설과 조치 완료 — ${_gLabel(grade)} · 종료`);
  _saveFacIssue(it);
  _notiFacFollow(`✅ 점검 조치 완료(${_gLabel(grade)}) · ${it.facName} — ${getAuthor()}`,_facIssueLink(id),it);
  // 조치 후 A~C 회복 → 점검이 자동으로 켰던 경고표시 해제
  try{
    if(['A','B','C'].indexOf(grade)>=0){
      const _fs2=DB.g('facilities')||[];const _fi=_fs2.findIndex(x=>x.id===it.facId);
      if(_fi>=0&&_fs2[_fi].warn&&_fs2[_fi].warn.on&&_fs2[_fi].warn.auto){
        _fs2[_fi].warn={on:false,clearedBy:getAuthor(),clearedAt:Date.now()};
        DB.s('facilities',_fs2);
        toast('✅ 등급 회복 — 경고표시 자동 해제');
      }
    }
  }catch(e){}
  toast('✅ 조치 완료('+grade+'등급) — 종료');
  _facIssueAfterAction(id,fromWork);
}
function facIssueDept(id){_facIssueDeptCore(id,(document.getElementById('fiDeptNote')?.value||'').trim(),document.getElementById('fiDeptGrade')?.value||'',false);}
// 조치 예정 등록 — 수리에 시간이 걸릴 때 '언제까지 조치하겠다'를 남김 (종료 안 됨, 예정일 지나면 배지 재점등)
function _facIssueDeptPlanCore(id,dateVal,note,fromWork){
  if(!_canManageFac()){toast('⚠️ 탐방시설과·개발자만 가능');return;}
  const it=_facIssueById(id);if(!it)return;
  if(!dateVal){toast('⚠️ 조치 예정일을 선택하세요');return;}
  const until=new Date(dateVal+'T23:59:59').getTime();
  if(until<Date.now()){toast('⚠️ 예정일이 과거입니다');return;}
  it.plan={until,note,by:getAuthor(),at:Date.now()};
  _issueLog(it,'조치 예정 등록 — '+_fmtDateK(until)+'까지'+(note?' ('+note+')':''));
  _saveFacIssue(it);
  _notiFacFollow(`🗓️ 조치 예정 · ${it.facName} — ${_fmtDateK(until)}까지 (${getAuthor()})`,_facIssueLink(id),it);
  toast('🗓️ '+_fmtDateK(until)+'까지 조치 예정 등록');
  _facIssueAfterAction(id,fromWork);
}
function facIssueDeptPlan(id){_facIssueDeptPlanCore(id,document.getElementById('fiDeptUntil')?.value||'',(document.getElementById('fiDeptNote')?.value||'').trim(),false);}
// 조치 후 공통 새로고침 — 업무함에서 처리했으면 목록에 남고, 모달에서 했으면 모달 갱신
function _facIssueAfterAction(id,fromWork){
  if(!fromWork)try{openFacIssueDetail(id);}catch(e){}
  try{renderFacIssues();}catch(e){}
  try{renderInspectMap();}catch(e){}
  try{renderFacWork();}catch(e){}
  try{_updateFacWorkBadge();}catch(e){}
}
function facIssueClose(id){
  if(!(_isFacManager()||_canManageFac()||_isMasterAdmin())){toast('⚠️ 권한 없음');return;}
  if(!confirm('이 점검 건을 종료할까요?'))return;
  const it=_facIssueById(id);if(!it)return;
  it.status='closed';it.closeReason='관리자 조기 종료';it.closedBy=getAuthor();it.closedAt=Date.now();
  _issueLog(it,'조기 종료');
  _saveFacIssue(it);
  toast('종료됨');openFacIssueDetail(id);try{renderFacIssues();}catch(e){}try{renderInspectMap();}catch(e){}
}
function facIssueReopen(id){
  if(!_canManageFac()){toast('⚠️ 권한 없음');return;}
  const it=_facIssueById(id);if(!it)return;
  it.status='open';delete it.closeReason;delete it.closedBy;delete it.closedAt;
  if(!it.stage||it.stage<1)it.stage=1;
  _issueLog(it,'재개');
  _saveFacIssue(it);
  toast('재개됨');openFacIssueDetail(id);try{renderFacIssues();}catch(e){}
}
function facIssueDelete(id){
  const it=_facIssueById(id);if(!it)return;
  const isReporter=String((DB.g('currentUser')||{}).kakaoId||'')===String(it.reporterKakaoId||'##');
  if(!(_canManageFac()||_isMasterAdmin()||(isReporter&&Number(it.stage)===1&&it.status!=='closed'))){toast('⚠️ 삭제 권한 없음');return;}
  if(!confirm('이 점검 기록을 삭제할까요?'))return;
  DB.s('facIssues',_facIssues().filter(x=>String(x.id)!==String(id)));
  try{closeM('modalFacIssueDetail');}catch(e){}
  toast('🗑️ 삭제');try{renderFacIssues();}catch(e){}try{renderInspectMap();}catch(e){}
}
// ── 점검 목록 (시설 통계 탭 상단 카드) ──
function renderFacIssues(){
  const wrap=document.getElementById('facIssueWrap');if(!wrap)return;
  const all=_facIssues();
  const open=all.filter(x=>x.status!=='closed').sort((a,b)=>(Number(a.stage||1)-Number(b.stage||1))||(b.createdAt-a.createdAt));
  const closed=all.filter(x=>x.status==='closed').sort((a,b)=>(b.closedAt||b.createdAt)-(a.closedAt||a.createdAt));
  const mineWait=_facIssueMineWaiting();
  let h='';
  if(mineWait&&(_isFacManager()||_isMasterAdmin())){
    h+=`<div style="background:rgba(240,165,0,.1);border:1px solid rgba(240,165,0,.4);border-radius:9px;padding:9px 11px;margin-bottom:9px;font-size:12px;font-weight:700;color:#f0a500;">🔧 검토 대기 ${mineWait}건 — 시설물 담당자 확인 필요</div>`;
  }
  if(!open.length){
    h+=`<div class="muted" style="font-size:12px;padding:5px 0;">진행 중인 점검 건 없음</div>`;
  }else{
    h+=open.map(it=>{
      const st=FAC_ISTAGE[Number(it.stage||1)]||FAC_ISTAGE[1];const gc=_gColor(it.grade);
      return `<div onclick="openFacIssueDetail(${it.id})" style="background:#0f0f11;border-radius:9px;padding:9px 11px;margin-bottom:6px;cursor:pointer;border-left:3px solid ${gc};display:flex;align-items:center;gap:9px;">
        <div style="background:${gc};color:#08121e;font-weight:900;border-radius:6px;padding:2px 7px;font-size:12px;flex-shrink:0;">${_esc(it.grade)}</div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:700;color:#eaecef;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(it.facName)}</div>
          <div style="font-size:10px;color:#8b95a1;margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${it.tags&&it.tags.length?'<span style="color:#3182f6;">'+_esc(it.tags.join(', '))+'</span> · ':''}${_esc(it.loc||'')}${it.reporter?' · '+_esc(it.reporter):''}</div>
          ${it.plan&&it.plan.until?`<div style="font-size:9px;font-weight:700;color:${it.plan.until<Date.now()?'#ff7a6e':'#3182f6'};margin-top:2px;">🗓️ ${_fmtDateK(it.plan.until)}까지 조치 예정${it.plan.until<Date.now()?' — 지남':''}</div>`:''}
        </div>
        <span style="background:${st.c}22;color:${st.c};font-size:9px;font-weight:800;border-radius:6px;padding:3px 7px;flex-shrink:0;">${st.ico} ${st.l}</span>
      </div>`;
    }).join('');
  }
  if(closed.length){
    h+=`<div style="font-size:10px;color:#6b7684;margin-top:9px;">✅ 종료 ${closed.length}건`+
      (closed.length?` <span onclick="_toggleClosedIssues()" id="fiClosedToggle" style="color:#3182f6;cursor:pointer;">· 보기</span>`:'')+`</div>`
      +`<div id="fiClosedList" style="display:none;margin-top:5px;">`+closed.slice(0,30).map(it=>{
        const gc=_gColor(it.grade);
        return `<div onclick="openFacIssueDetail(${it.id})" style="background:rgba(255,255,255,.02);border-radius:8px;padding:7px 10px;margin-bottom:4px;cursor:pointer;opacity:.7;display:flex;align-items:center;gap:8px;">
          <div style="background:${gc}55;color:#d5d8dc;font-weight:800;border-radius:5px;padding:1px 6px;font-size:11px;">${_esc(it.grade)}</div>
          <div style="flex:1;min-width:0;font-size:11px;color:#a5abb3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(it.facName)}</div>
          <span style="font-size:9px;color:#6b7684;">${_esc(it.closeReason||'종료')}</span>
        </div>`;
      }).join('')+`</div>`;
  }
  wrap.innerHTML=h;
}
function _toggleClosedIssues(){
  const l=document.getElementById('fiClosedList');const t=document.getElementById('fiClosedToggle');
  if(!l)return;const show=l.style.display==='none';l.style.display=show?'block':'none';if(t)t.textContent=show?'· 숨기기':'· 보기';
}

// ══════════════════════════════════════════
// 담당 업무함 (하단 네비 4번째 탭 — 담당자·시설과·개발자만)
// 검토 회신·현장확인·조치를 목록에서 바로 처리
// ══════════════════════════════════════════
function _facWorkVisible(){return _isFacManager()||_canManageFac()||_isMasterAdmin();}
// 내가 지금 답할 수 있는 건수 (탭 배지)
function _facWorkCount(){
  const canReview=_isFacManager()||_isMasterAdmin();
  const canDept=_canManageFac();
  let n=0;
  _facIssueOpen().forEach(it=>{const s=Number(it.stage||1);
    if(s<=2){if(canReview)n++;}
    else if(s===3)n++;                 // 현장확인은 멤버 누구나 기록 가능
    else if(s===4){if(canDept&&!(it.plan&&it.plan.until>Date.now()))n++;} // 조치 예정 등록분은 예정일 지나면 재점등
  });
  return n;
}
function _updateFacWorkBadge(){
  const b=document.getElementById('nv4Badge');if(!b)return;
  const n=_facWorkVisible()?_facWorkCount():0;
  b.style.display=n?'block':'none';b.textContent=n>99?'99+':String(n);
}
// 업무함 인라인 폼 래퍼 (요소 ID가 항목별 fw*_id — 모달의 fi*와 충돌 없음)
function fwReview(id){_facIssueReviewCore(id,document.getElementById('fwMgrGrade_'+id)?.value||'',(document.getElementById('fwMgrOpinion_'+id)?.value||'').trim(),true);}
function fwZone(id){_facIssueZoneCore(id,(document.getElementById('fwZoneNote_'+id)?.value||'').trim(),true);}
function fwDept(id){_facIssueDeptCore(id,(document.getElementById('fwDeptNote_'+id)?.value||'').trim(),document.getElementById('fwDeptGrade_'+id)?.value||'',true);}
function fwDeptPlan(id){_facIssueDeptPlanCore(id,document.getElementById('fwDeptUntil_'+id)?.value||'',(document.getElementById('fwDeptNote_'+id)?.value||'').trim(),true);}
function _fwMgrUpdate(id){
  const g=document.getElementById('fwMgrGrade_'+id)?.value||'';
  const de=g==='D'||g==='E';
  const hint=document.getElementById('fwMgrHint_'+id);
  if(hint){hint.style.color=de?'#ff9a6e':'#7ec8a0';
    hint.innerHTML=de?'D·E: <b>지역담당 현장확인</b>으로 넘어갑니다':'A·B·C: 사유 회신 후 <b>이상없음 종료</b> (사유 필수)';}
  const ta=document.getElementById('fwMgrOpinion_'+id);
  if(ta)ta.placeholder=de?'검토 의견 (선택)':'판정 사유 (필수 — 왜 이 등급인지)';
  const b=document.getElementById('fwMgrBtn_'+id);
  if(b){b.style.background=de?'#c0392b':'#1e7a4e';
    b.textContent=de?('⚠️ '+g+'등급 확정 → 현장확인 요청'):('✅ '+g+'등급 · 회신 후 종료');}
}
function renderFacWork(){
  const wrap=document.getElementById('facWorkWrap');if(!wrap)return;
  const canReview=_isFacManager()||_isMasterAdmin();
  const canDept=_canManageFac();
  const open=_facIssueOpen().sort((a,b)=>b.createdAt-a.createdAt);
  const s2=open.filter(it=>Number(it.stage||1)<=2);
  const s3=open.filter(it=>Number(it.stage)===3);
  const s4=open.filter(it=>Number(it.stage)===4);
  const closed=_facIssues().filter(x=>x.status==='closed').sort((a,b)=>(b.closedAt||b.createdAt)-(a.closedAt||a.createdAt)).slice(0,10);

  const head=(ico,title,cnt,c)=>`<div style="font-size:12px;font-weight:800;color:${c};margin:15px 0 7px;">${ico} ${title}${cnt?` <span style="background:${c};color:#08121e;border-radius:9px;padding:0 7px;font-size:10px;margin-left:2px;">${cnt}</span>`:''}</div>`;
  const card=(it,body)=>{
    const gc=_gColor(it.grade);
    return `<div style="background:#16161a;border:1px solid rgba(255,255,255,.06);border-left:3px solid ${gc};border-radius:11px;padding:11px;margin-bottom:9px;">
      <div style="display:flex;align-items:center;gap:9px;cursor:pointer;" onclick="openFacIssueDetail(${it.id})">
        ${it.photo?`<img src="${_esc(it.photo)}" style="width:44px;height:44px;border-radius:8px;object-fit:cover;flex-shrink:0;">`:`<div style="width:44px;height:44px;border-radius:8px;background:#0f0f11;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">🏗️</div>`}
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:700;color:#eaecef;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><span style="color:${gc};font-weight:900;">${_esc(it.grade)}</span> · ${_esc(it.facName)}</div>
          <div style="font-size:10px;color:#8b95a1;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${it.tags&&it.tags.length?'<span style="color:#3182f6;">'+_esc(it.tags.join(', '))+'</span> · ':''}${_esc(it.reporter||'')} · ${_fmtWhen(it.createdAt)}</div>
        </div>
        <span style="font-size:10px;color:#3182f6;flex-shrink:0;">상세 ›</span>
      </div>
      ${it.desc?`<div style="font-size:11px;color:#a5abb3;margin-top:6px;line-height:1.5;">${_esc(it.desc)}</div>`:''}
      ${body||''}
    </div>`;
  };
  const formWrap=inner=>`<div style="margin-top:9px;border-top:1px dashed rgba(255,255,255,.08);padding-top:9px;">${inner}</div>`;

  let h=`<div style="font-size:11px;color:#a5abb3;line-height:1.6;background:rgba(240,165,0,.05);border:1px solid rgba(240,165,0,.15);border-radius:9px;padding:8px 11px;">🔧 <b style="color:#f0a500;">담당 업무함</b> — 점검 회신·현장확인·조치를 여기서 바로 처리합니다.</div>`;

  // ── 1. 담당자 검토 대기 (인라인 회신) ──
  h+=head('🔎','담당자 검토 대기',s2.length,'#f0a500');
  if(!s2.length)h+=`<div class="muted" style="font-size:11px;">검토 대기 없음</div>`;
  else h+=s2.map(it=>{
    if(!canReview)return card(it,formWrap(`<div style="font-size:10px;color:#6b7684;">담당자 회신 대기 중</div>`));
    const de0=it.grade==='D'||it.grade==='E';
    return card(it,formWrap(`
      <div style="font-size:10px;color:#a5abb3;margin-bottom:4px;">재평가 등급 — 등급이 처리 경로를 정합니다</div>
      <select id="fwMgrGrade_${it.id}" class="fsel" onchange="_fwMgrUpdate(${it.id})" style="margin-bottom:5px;">${['A','B','C','D','E'].map(g=>`<option value="${g}"${g===it.grade?' selected':''}>${_gLabel(g)}</option>`).join('')}</select>
      <div id="fwMgrHint_${it.id}" style="font-size:10px;line-height:1.5;margin-bottom:6px;color:${de0?'#ff9a6e':'#7ec8a0'};">${de0?'D·E: <b>지역담당 현장확인</b>으로 넘어갑니다':'A·B·C: 사유 회신 후 <b>이상없음 종료</b> (사유 필수)'}</div>
      <textarea id="fwMgrOpinion_${it.id}" class="fta" rows="2" placeholder="${de0?'검토 의견 (선택)':'판정 사유 (필수 — 왜 이 등급인지)'}" style="margin-bottom:7px;"></textarea>
      <button id="fwMgrBtn_${it.id}" onclick="fwReview(${it.id})" style="width:100%;background:${de0?'#c0392b':'#1e7a4e'};color:#fff;border:none;border-radius:8px;padding:9px;font-size:12px;font-weight:800;cursor:pointer;">${de0?'⚠️ '+it.grade+'등급 확정 → 현장확인 요청':'✅ '+it.grade+'등급 · 회신 후 종료'}</button>`));
  }).join('');

  // ── 2. 지역담당 현장확인 대기 ──
  h+=head('🥾','지역담당 현장확인 대기',s3.length,'#b07cd0');
  if(!s3.length)h+=`<div class="muted" style="font-size:11px;">현장확인 대기 없음</div>`;
  else h+=s3.map(it=>card(it,formWrap(`
      ${it.mgr&&it.mgr.opinion?`<div style="font-size:10px;color:#f0a500;margin-bottom:6px;">🔎 담당자 의견: ${_esc(it.mgr.opinion)}</div>`:''}
      <textarea id="fwZoneNote_${it.id}" class="fta" rows="2" placeholder="현장 확인 결과 (예: 데크 3판 파손 확인, 임시 통제 설치)" style="margin-bottom:7px;"></textarea>
      <button onclick="fwZone(${it.id})" style="width:100%;background:#7a4a9e;color:#fff;border:none;border-radius:8px;padding:9px;font-size:12px;font-weight:800;cursor:pointer;">현장확인 완료 → 시설과 이관</button>`))).join('');

  // ── 3. 시설과 조치 대기 ──
  h+=head('🔧','시설과 조치 대기',s4.length,'#e67e22');
  if(!s4.length)h+=`<div class="muted" style="font-size:11px;">조치 대기 없음</div>`;
  else h+=s4.map(it=>{
    const pb=(it.plan&&it.plan.until)?(()=>{const od=it.plan.until<Date.now();
      return `<div style="font-size:10px;font-weight:800;color:${od?'#ff7a6e':'#3182f6'};margin-bottom:6px;">🗓️ ${_fmtDateK(it.plan.until)}까지 조치 예정${od?' — 예정일 지남':''}${it.plan.note?` <span style="color:#8b95a1;font-weight:400;">· ${_esc(it.plan.note)}</span>`:''}</div>`;})():'';
    if(!canDept)return card(it,formWrap(`${pb}<div style="font-size:10px;color:#6b7684;">탐방시설과 조치 대기 중${it.zone&&it.zone.note?' · 🥾 '+_esc(it.zone.note):''}</div>`));
    const defG=(it.mgr&&it.mgr.grade)||it.grade;
    const planVal=it.plan&&it.plan.until?new Date(it.plan.until-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10):'';
    return card(it,formWrap(`
      ${pb}${it.zone&&it.zone.note?`<div style="font-size:10px;color:#b07cd0;margin-bottom:6px;">🥾 현장확인: ${_esc(it.zone.note)}</div>`:''}
      <div style="font-size:10px;color:#a5abb3;margin-bottom:4px;">조치 후 등급 (A~E)</div>
      <select id="fwDeptGrade_${it.id}" class="fsel" style="margin-bottom:6px;">${['A','B','C','D','E'].map(g=>`<option value="${g}"${g===defG?' selected':''}>${_gLabel(g)}</option>`).join('')}</select>
      <textarea id="fwDeptNote_${it.id}" class="fta" rows="2" placeholder="조치 내용 (예: 데크 교체 완료 / 예산 반영 예정)" style="margin-bottom:7px;"></textarea>
      <button onclick="fwDept(${it.id})" style="width:100%;background:#0c4838;color:#fff;border:none;border-radius:8px;padding:9px;font-size:12px;font-weight:800;cursor:pointer;">✅ 조치 완료 → 종료</button>
      <div style="display:flex;gap:6px;margin-top:7px;">
        <input type="date" id="fwDeptUntil_${it.id}" class="fi" style="flex:1;box-sizing:border-box;" value="${planVal}">
        <button onclick="fwDeptPlan(${it.id})" style="flex-shrink:0;background:rgba(255,255,255,.15);color:#3182f6;border:1px solid rgba(255,255,255,.4);border-radius:8px;padding:0 12px;font-size:11px;font-weight:800;cursor:pointer;">🗓️ ${it.plan?'예정 변경':'예정 등록'}</button>
      </div>`));
  }).join('');

  // ── 4. 최근 종료 ──
  if(closed.length){
    h+=head('✅','최근 종료',0,'#7ec8a0');
    h+=closed.map(it=>`<div onclick="openFacIssueDetail(${it.id})" style="background:rgba(255,255,255,.02);border-radius:9px;padding:8px 11px;margin-bottom:5px;cursor:pointer;opacity:.75;display:flex;align-items:center;gap:8px;">
      <span style="color:${_gColor(it.grade)};font-weight:900;font-size:12px;flex-shrink:0;">${_esc(it.grade)}</span>
      <span style="flex:1;min-width:0;font-size:11px;color:#a5abb3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(it.facName)}</span>
      <span style="font-size:9px;color:#6b7684;flex-shrink:0;">${_esc(it.closeReason||'종료')}</span>
    </div>`).join('');
  }
  wrap.innerHTML=h;
  try{_updateFacWorkBadge();}catch(e){}
}

var _editFacId=null;
function openAddFac(){
  _editFacId=null;
  document.getElementById('addFacModalTitle').textContent='🆕 시설물 등록';
  const _catMeta=DB.g('catFacMeta')||{};const _cats=(DB.g('catFac')||[]).filter(c=>isAdminUser()||!(_catMeta[c]||{}).adminOnly);
  fillSel('facTypeSel',_cats);
  document.getElementById('facInstall').value=today();
  ['facNameIn','facGpsIn','facNote','facMgmtIn','facSpecIn','facStructIn'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';});
  {const g=document.getElementById('facGradeSel');if(g)g.value='';}
  const _fa=document.getElementById('facAuthor');_fa.value=getAuthor();_fa.disabled=true;
  {const pv=document.getElementById('prevFac');pv.dataset.url='';pv.innerHTML='📸 촬영 또는 앨범';} // 이전 편집 사진 잔재 제거
  try{gpsFromMap('facGpsIn','inspect');}catch(e){}
  {const g=document.getElementById('facGpsIn');if(g){g.readOnly=true;g.style.opacity='.75';g.placeholder='🗺 지도·📍GPS 또는 탭하여 직접 입력';}}
  try{_resetFacFormMap();}catch(e){} // 지도 선택기 초기화(🗺 버튼으로 열림)
  // 위치: 구간 선택식 — 지도 십자선 근처 표지판의 구간을 기본 선택(수기 입력 폐지 → 데이터 통일)
  const _ic=window._lastInspectCrosshairCoord;
  let _zone='';
  try{const _ls=_ic?_nearestSign(_ic.lat,_ic.lng):null;const m=(_ls||'').match(/^(\d{2})-/);if(m&&typeof _zoneLbl==='function')_zone=_zoneLbl(m[1]);}catch(e){}
  _fillFacLocSel(_zone);
  document.getElementById('modalAddFac').classList.add('on');
}
// 위치(구간) 셀렉트 채우기 — ZONE_NAMES 기준 'NN (구간명)' 옵션(01→14 정렬).
// 레거시 값 정규화: '10'·'백담계곡'처럼 저장된 옛 값도 '10 (백담계곡)' 옵션에 자동 매칭(불일치 '(기존값)' 중복 제거)
function _fillFacLocSel(cur){
  const sel=document.getElementById('facLocIn');if(!sel)return;
  cur=String(cur||'').trim();
  let opts='<option value="">위치 미지정</option>';
  try{Object.keys(ZONE_NAMES).sort().forEach(z=>{const v=_zoneLbl(z);opts+=`<option value="${_esc(v)}">${_esc(v)}</option>`;});}catch(e){}
  sel.innerHTML=opts;
  if(!cur)return;
  // 레거시 표기 정규화 → 표준 라벨
  try{
    const mNum=cur.match(/^(\d{1,2})$/); // '10'
    if(mNum&&ZONE_NAMES[mNum[1].padStart(2,'0')])cur=_zoneLbl(mNum[1].padStart(2,'0'));
    else{
      const hit=Object.keys(ZONE_NAMES).find(z=>ZONE_NAMES[z]===cur||cur.indexOf(ZONE_NAMES[z])>=0&&cur.indexOf(z)>=0);
      if(hit)cur=_zoneLbl(hit);
    }
  }catch(e){}
  if(![...sel.options].some(o=>o.value===cur))sel.insertAdjacentHTML('beforeend',`<option value="${_esc(cur)}">${_esc(cur)} (기존값)</option>`);
  sel.value=cur;
}
function openEditFac(id){
  if(!_canManageFac()){toast('⚠️ 탐방시설과·개발자만 수정 가능');return;}
  const f=(DB.g('facilities')||[]).find(x=>x.id===id);if(!f)return;
  _editFacId=id;
  document.getElementById('addFacModalTitle').textContent='✏️ 시설물 수정';
  fillSel('facTypeSel',DB.g('catFac')||[]);
  {const ts=document.getElementById('facTypeSel'); // 종류가 목록에 없어도(레거시) 빈값으로 안 날아가게 옵션 보존
   if(f.type&&![...ts.options].some(o=>o.value===f.type))ts.insertAdjacentHTML('beforeend',`<option value="${_esc(f.type)}">${_esc(f.type)}</option>`);
   ts.value=f.type||'';}
  document.getElementById('facNameIn').value=f.name||'';
  _fillFacLocSel(f.loc||''); // 구간 셀렉트 — 레거시 자유입력 값은 '(기존값)' 옵션으로 유지
  document.getElementById('facGpsIn').value=f.lat&&f.lng?f.lat.toFixed(5)+', '+f.lng.toFixed(5):'';
  {const g=document.getElementById('facGpsIn');if(g){g.readOnly=true;g.style.opacity='.75';g.placeholder='🗺 지도·📍GPS 또는 탭하여 직접 입력';}}
  document.getElementById('facInstall').value=f.install||'';
  {const g=document.getElementById('facGradeSel');if(g)g.value=f.grade||'';}
  {const e=document.getElementById('facMgmtIn');if(e)e.value=f.mgmt||'';}
  {const e=document.getElementById('facSpecIn');if(e)e.value=f.spec||'';}
  {const e=document.getElementById('facStructIn');if(e)e.value=f.struct||'';}
  document.getElementById('facNote').value=f.note||'';
  const _fa=document.getElementById('facAuthor');_fa.value=f.author||getAuthor();_fa.disabled=true;
  // 기존 사진 유지 — 미리보기에 그대로 실어 저장 시 빈값으로 덮이지 않게(사진 사라짐 버그 수정)
  {const pv=document.getElementById('prevFac');
   if(f.photo){pv.dataset.url=f.photo;pv.innerHTML=`<img src="${_esc(f.photo)}" style="max-width:100%;max-height:110px;border-radius:8px;">`;}
   else{pv.dataset.url='';pv.innerHTML='📸 촬영 또는 앨범';}}
  try{_resetFacFormMap();}catch(e){} // 지도 선택기 초기화(🗺 버튼으로 열림 — 저장 좌표에서 시작)
  closeM('modalFacDetail');
  document.getElementById('modalAddFac').classList.add('on');
}
function deleteFac(id){
  if(!_canManageFac()){toast('⚠️ 시설과·시설담당자·개발자만 삭제 가능');return;}
  const facs=DB.g('facilities')||[];const i=facs.findIndex(f=>f.id===id);if(i<0)return;
  if(!confirm('이 시설물을 삭제하시겠습니까?\n(관리자 → 시스템의 🗑 휴지통에서 복구할 수 있습니다)'))return;
  const rec=facs.splice(i,1)[0];
  DB.s('facilities',facs);
  // 휴지통 보관(실수 방지 — 복구 가능) — 최근 100건 유지
  try{
    const tr=DB.g('facTrash')||[];
    tr.unshift({rec:rec,at:Date.now(),by:getAuthor()});
    if(tr.length>100)tr.length=100;
    DB.s('facTrash',tr);
  }catch(e){}
  closeM('modalFacDetail');
  try{document.getElementById('facPopup').classList.remove('on');}catch(e){}
  try{renderInspectMap();}catch(e){}renderFacList();toast('🗑️ 삭제 — 휴지통에 보관됨');updateSummary();
}
// 휴지통 복구/영구삭제 (관리자 → 시스템)
function restoreFac(at){
  if(!_canManageFac()){toast('⚠️ 권한 없음');return;}
  const tr=DB.g('facTrash')||[];const i=tr.findIndex(t=>t.at===at);if(i<0)return;
  const rec=tr[i].rec;if(!rec){tr.splice(i,1);DB.s('facTrash',tr);return;}
  const facs=DB.g('facilities')||[];
  if(facs.some(f=>f.id===rec.id))rec.id=Date.now(); // 그 사이 같은 id가 생겼으면 새 id로 복구
  facs.push(rec);DB.s('facilities',facs);
  tr.splice(i,1);DB.s('facTrash',tr);
  toast('♻️ 복구됨: '+(rec.name||''));
  try{renderInspectMap();}catch(e){}try{renderFacList();}catch(e){}try{renderAdmSys();}catch(e){}
}
function purgeFacTrash(at){
  if(!(typeof _isMasterAdmin==='function'&&_isMasterAdmin())){toast('⚠️ 개발자만 영구 삭제 가능');return;}
  const tr=DB.g('facTrash')||[];const i=tr.findIndex(t=>t.at===at);if(i<0)return;
  if(!confirm('영구 삭제하시겠습니까? 복구할 수 없습니다.\n('+(((tr[i]||{}).rec||{}).name||'')+')'))return;
  tr.splice(i,1);DB.s('facTrash',tr);
  try{renderAdmSys();}catch(e){}
}
function submitAddFac(){
  const name=document.getElementById('facNameIn').value.trim();if(!name){toast('⚠️ 명칭 입력');return;}
  const gs=document.getElementById('facGpsIn').value;
  let lat=null,lng=null;
  if(gs){const p=gs.split(',');lat=parseFloat(p[0]);lng=parseFloat(p[1]);if(isNaN(lat)||isNaN(lng)){lat=null;lng=null;}}
  const facs=DB.g('facilities')||[];
  const data={type:document.getElementById('facTypeSel').value,name,loc:document.getElementById('facLocIn').value,lat,lng,install:document.getElementById('facInstall').value,note:document.getElementById('facNote').value,author:document.getElementById('facAuthor').value,photo:_photoUrl('prevFac'),
    grade:(document.getElementById('facGradeSel')?.value||''),mgmt:(document.getElementById('facMgmtIn')?.value||'').trim(),spec:(document.getElementById('facSpecIn')?.value||'').trim(),struct:(document.getElementById('facStructIn')?.value||'').trim()};
  // 등급을 새로 지정/변경했으면 출처를 등록자로 기록 (기존 등급 유지 시 출처 유지)
  {const _pf=_editFacId?(facs.find(x=>x.id===_editFacId)||{}):{};if(data.grade&&data.grade!==_pf.grade)data.gradeBy=getAuthor();}
  if(_editFacId){
    const idx=facs.findIndex(f=>f.id===_editFacId);
    // 안전망: 수정 시 사진·종류가 비면 기존 값 유지(빈값 덮어쓰기로 사라지던 버그 방지)
    if(idx!==-1){
      if(!data.photo&&facs[idx].photo)data.photo=facs[idx].photo;
      if(!data.type&&facs[idx].type)data.type=facs[idx].type;
      facs[idx]=Object.assign(facs[idx],data);
    }
    _editFacId=null;
    DB.s('facilities',facs);
    try{renderInspectMap();}catch(e){}renderFacList();closeM('modalAddFac');toast('✅ 시설물 수정');updateSummary();
  } else {
    facs.push(Object.assign({id:Date.now()},data));
    DB.s('facilities',facs);
    try{renderInspectMap();}catch(e){}try{renderFacList();}catch(e){}closeM('modalAddFac');toast('✅ 시설물 등록');updateSummary();
  }
}

// [기능 제거 2026-08-06] 🌀 특보운영 본체(ALERT_REQS·발령단계·통계·입력 탭) 제거
// [기능 제거 2026-08-06] 특보 발효 이력 로그(alertLog) 제거
// [기능 제거 2026-08-06] 특보운영 부속(체류인원·위기경보 배너·정기 기상 브리핑·탐방로 통제) 제거
// [기능 제거 2026-08-06] 특보운영 사고기록 연동·보관함(종료 운영 열람) 제거
// [기능 제거 2026-08-06] 특보운영 원탭 응소 체크인·기상 관측기록·관측보고 알림 제거
// ══════════════════════════════════════════
// 관리자
// ══════════════════════════════════════════
function admTab(tab,el){
  document.querySelectorAll('.adm-tab').forEach(t=>{t.classList.remove('on');t.style.color='';t.style.borderBottomColor='';});
  el.classList.add('on');if(tab==='ctrl'){el.style.color='#c0392b';el.style.borderBottomColor='#c0392b';}
  document.querySelectorAll('.adm-sec').forEach(s=>s.classList.remove('on'));
  document.getElementById('adm-'+tab).classList.add('on');
  ({ctrl:renderAdmCtrl,members:renderAdmMembers,cat:renderAdmCat,sheets:renderAdmSheets,sys:renderAdmSys,staff:renderAdmMembers})[tab]?.();
}
let _admResLimit=15; // 관리자 구조이력 표시 개수(더보기로 증가)
// ── 관제: 서브탭(현황/구조/시설물/위험상황)으로 분리 — 한 화면에 전부 쏟아붓지 않고 필터·페이지로 관리
let _admFacLimit=50;
function admCtrlTab(t){if(t==='haz'&&typeof _HAZ_OFF!=='undefined'&&_HAZ_OFF){toast('⚠️ 위험상황 기능은 비활성화되어 있습니다');return;}window._admCtrlTab=t;_admResLimit=15;_admFacLimit=50;renderAdmCtrl();}
function renderAdmCtrl(){
  const facs=DB.g('facilities')||[];const res=DB.g('rescues')||[];const haz=DB.g('hazards')||[];
  const t=window._admCtrlTab||'dash';
  const ongoing=res.filter(r=>r.status==='ongoing');
  const warned=facs.filter(f=>_facWarn(f));
  const hazOpen=haz.filter(h=>!h.hazStatus||h.hazStatus==='미조치'||h.hazStatus==='조치중');
  const seg=(lbl,k,n,col)=>`<button onclick="admCtrlTab('${k}')" style="flex:1;padding:9px 4px;border:none;border-radius:8px;font-size:11.5px;font-weight:800;cursor:pointer;white-space:nowrap;background:${t===k?'rgba(255,255,255,.18)':'transparent'};color:${t===k?'#a5abb3':'#6a8296'};">${lbl}${n?` <span style="background:${col||'#e05050'};color:#fff;border-radius:8px;padding:0 5px;font-size:9px;">${n}</span>`:''}</button>`;
  const chip=(lbl,on,onclick,col)=>`<span onclick="${onclick}" style="cursor:pointer;display:inline-block;padding:5px 11px;margin:0 4px 4px 0;border-radius:13px;font-size:11px;font-weight:700;border:1px solid ${on?(col||'#3182f6'):'rgba(255,255,255,.12)'};background:${on?'rgba(255,255,255,.16)':'transparent'};color:${on?(col||'#a5abb3'):'#6a8296'};">${lbl}</span>`;
  const inp='background:#0f0f11;border:1px solid rgba(255,255,255,.12);color:#d5d8dc;border-radius:8px;padding:7px 9px;font-size:12px;width:100%;box-sizing:border-box;margin-bottom:7px;';
  let html=`<div style="display:flex;gap:3px;background:#131316;border:1px solid rgba(255,255,255,.15);border-radius:10px;padding:3px;margin-bottom:11px;">${seg('📊 현황','dash')}${seg('🚨 구조','res',ongoing.length)}${seg('🛠️ 시설물','fac',warned.length,'#e67e22')}${seg('⚠️ 위험','haz',hazOpen.length,'#e67e22')}</div>`;
  if(t==='dash'){
    html+=`<div class="scard" style="margin-bottom:8px;">
      <div class="stitle">📊 전체 현황</div>
      <div class="stat-grid">
        <div class="stat-box" onclick="admCtrlTab('fac')" style="cursor:pointer;"><div class="stat-num">${facs.length}</div><div class="stat-lbl">시설물</div></div>
        <div class="stat-box" onclick="window._admFacF='경고';admCtrlTab('fac')" style="cursor:pointer;"><div class="stat-num bad">${warned.length}</div><div class="stat-lbl">경고표시</div></div>
        <div class="stat-box" onclick="admCtrlTab('res')" style="cursor:pointer;"><div class="stat-num">${res.length}</div><div class="stat-lbl">구조이력</div></div>
        <div class="stat-box" onclick="window._admResF='진행중';admCtrlTab('res')" style="cursor:pointer;border-color:#c0392b;"><div class="stat-num bad">${ongoing.length}</div><div class="stat-lbl">진행중</div></div>
      </div>
      ${(typeof _HAZ_OFF!=='undefined'&&_HAZ_OFF)?'':`<div onclick="admCtrlTab('haz')" style="cursor:pointer;margin-top:8px;font-size:11px;color:#8b95a1;">위험상황 보고 ${haz.length}건 · <span style="color:${hazOpen.length?'#e67e22':'#5dbf8a'};font-weight:700;">미조치·조치중 ${hazOpen.length}건</span> ›</div>`}
    </div>
    <div style="font-size:10px;color:#6b7684;margin:4px 2px 0;">숫자를 누르면 해당 탭으로 이동합니다. 긴급 항목만 아래에 표시됩니다.</div>
    <div class="sec-label">⚠️ 경고표시 시설물 (${warned.length})</div>
    ${warned.slice(0,5).map(f=>{const w=_facWarn(f);return `<div class="adm-row"><div class="adm-info"><div class="adm-name">⚠️ ${f.type.split(' ')[0]} ${_esc(_facDispName(f))}</div><div class="adm-meta">${_esc(_facZoneLbl(f)||'-')}${w.reason?' · '+_esc(w.reason):''}</div></div><button class="abtn" onclick="openFacDetail(${f.id})">보기</button></div>`;}).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">경고표시된 시설 없음</div>'}
    ${warned.length>5?`<button class="abtn" style="width:100%;margin-top:4px;" onclick="window._admFacF='경고';admCtrlTab('fac')">전체 ${warned.length}건 보기 →</button>`:''}
    <div class="sec-label">🚨 진행중 구조 (${ongoing.length})</div>
    ${ongoing.map(r=>{const ti=RES_TYPES[r.type]||RES_TYPES['기타'];return`<div class="adm-row"><div class="adm-info"><div class="adm-name">${ti.ico} ${_esc(r.title)}</div><div class="adm-meta">${_esc(r.type)} · ${_esc(r.date)} · ${_esc(r.vName||'미상')}</div></div><div class="adm-btns"><button class="abtn" onclick="admEndRes(${r.id})">상황종료</button><button class="abtn del" onclick="admDelRes(${r.id})">삭제</button></div></div>`;}).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">진행중 없음</div>'}`;
  } else if(t==='res'){
    const f=window._admResF||'전체',q=(window._admResQ||'').trim();
    let list=res.slice().sort((a,b)=>(b.id||0)-(a.id||0));
    if(f==='진행중')list=list.filter(r=>r.status==='ongoing');
    else if(f==='종료')list=list.filter(r=>r.status!=='ongoing');
    if(q)list=list.filter(r=>[r.title,r.vName,r.type,r.location].some(v=>String(v||'').indexOf(q)>=0));
    html+=`<div style="margin-bottom:4px;">${chip('전체 '+res.length,f==='전체',"window._admResF='전체';renderAdmCtrl();")}${chip('🔴 진행중 '+ongoing.length,f==='진행중',"window._admResF='진행중';renderAdmCtrl();",'#ff8a73')}${chip('종료',f==='종료',"window._admResF='종료';renderAdmCtrl();",'#5dbf8a')}</div>
    <input type="search" placeholder="🔍 사건명·사고자·장소 검색 (Enter)" value="${_esc(q)}" onchange="window._admResQ=this.value;renderAdmCtrl();" style="${inp}">
    <div class="sec-label">📒 구조 이력 (${list.length}건)</div>
    ${list.slice(0,_admResLimit).map(r=>{const ti=RES_TYPES[r.type]||RES_TYPES['기타'];const og=r.status==='ongoing';return`<div class="adm-row"><div class="adm-info"><div class="adm-name">${ti.ico} ${_esc(r.title)} ${og?'<span style="font-size:9px;color:#ff6b5e;font-weight:700;">●진행중</span>':'<span style="font-size:9px;color:#3ad17a;">종료</span>'}</div><div class="adm-meta">${_esc(r.type)} · ${_esc(r.date)} · ${_esc(r.vName||'미상')}</div></div><div class="adm-btns">${og?`<button class="abtn" onclick="admEndRes(${r.id})">종료</button>`:''}<button class="abtn del" onclick="admDelRes(${r.id})">삭제</button></div></div>`;}).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">해당 조건 없음</div>'}
    ${list.length>_admResLimit?`<button class="abtn" style="width:100%;margin-top:6px;" onclick="_admResLimit+=30;renderAdmCtrl();">▾ 더 보기 (${list.length-_admResLimit}건)</button>`:''}`;
  } else if(t==='fac'){
    const f=window._admFacF||'전체',ty=window._admFacType||'전체',q=(window._admFacQ||'').trim();
    const types=['전체',...new Set(facs.map(x=>x.type).filter(Boolean))];
    let list=facs.slice();
    if(f==='경고')list=list.filter(x=>_facWarn(x));
    if(ty!=='전체')list=list.filter(x=>x.type===ty);
    if(q)list=list.filter(x=>[x.name,x.loc,x.mgmt].some(v=>String(v||'').indexOf(q)>=0));
    html+=`<div style="margin-bottom:4px;">${chip('전체 '+facs.length,f==='전체',"window._admFacF='전체';renderAdmCtrl();")}${chip('⚠️ 경고만 '+warned.length,f==='경고',"window._admFacF='경고';renderAdmCtrl();",'#e67e22')}</div>
    <select onchange="window._admFacType=this.value;renderAdmCtrl();" style="${inp}">${types.map(x=>`<option${x===ty?' selected':''}>${_esc(x)}</option>`).join('')}</select>
    <input type="search" placeholder="🔍 명칭·위치·관리번호 검색 (Enter)" value="${_esc(q)}" onchange="window._admFacQ=this.value;renderAdmCtrl();" style="${inp}">
    <div class="sec-label">📋 시설물 (${list.length}개)</div>
    ${list.slice(0,_admFacLimit).map(fc=>`<div class="adm-row"><div class="adm-info"><div class="adm-name">${fc.type.split(' ')[0]} ${_esc(_facDispName(fc))}</div><div class="adm-meta">${_facWarn(fc)?'<span style="color:#e05050;">⚠️ 경고</span> · ':''}${_esc(_facZoneLbl(fc)||'-')} · ${_esc(fc.author||'-')}</div></div><div class="adm-btns"><button class="abtn" onclick="openFacDetail(${fc.id})">보기</button>${_canManageFac()?`<button class="abtn del" onclick="admDelFac(${fc.id})">삭제</button>`:''}</div></div>`).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">해당 조건 없음</div>'}
    ${list.length>_admFacLimit?`<button class="abtn" style="width:100%;margin-top:6px;" onclick="_admFacLimit+=100;renderAdmCtrl();">▾ 더 보기 (${list.length-_admFacLimit}개)</button>`:''}`;
  } else {
    const f=window._admHazF||'전체';
    let list=haz.slice().sort((a,b)=>(b.id||0)-(a.id||0));
    const st=h=>h.hazStatus||'미조치';
    if(f!=='전체')list=f==='완료'?list.filter(h=>st(h)!=='미조치'&&st(h)!=='조치중'):list.filter(h=>st(h)===f);
    html+=`<div style="margin-bottom:4px;">${chip('전체 '+haz.length,f==='전체',"window._admHazF='전체';renderAdmCtrl();")}${chip('미조치',f==='미조치',"window._admHazF='미조치';renderAdmCtrl();",'#ff8a73')}${chip('조치중',f==='조치중',"window._admHazF='조치중';renderAdmCtrl();",'#e6b800')}${chip('완료',f==='완료',"window._admHazF='완료';renderAdmCtrl();",'#5dbf8a')}</div>
    <div class="sec-label">⚠️ 위험상황 (${list.length}건)</div>
    ${list.map(h=>{const s=st(h);const sc=s==='미조치'?'#ff6b5e':s==='조치중'?'#e6b800':'#3ad17a';return`<div class="adm-row"><div class="adm-info"><div class="adm-name">${_esc(h.hazType||'위험상황')} <span style="font-size:9px;color:${sc};font-weight:700;">●${_esc(s)}</span></div><div class="adm-meta">${_esc(h.date||'')} · ${_esc(h.location||h.loc||'-')}</div></div><div class="adm-btns"><button class="abtn" onclick="openHazDetail(${h.id})">보기</button><button class="abtn del" onclick="admDelHaz(${h.id})">삭제</button></div></div>`;}).join('')||'<div class="muted" style="font-size:12px;padding:5px 0;">해당 조건 없음</div>'}`;
  }
  document.getElementById('admCtrlWrap').innerHTML=html;
}
function admDelHaz(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const hz=DB.g('hazards')||[];const h=hz.find(x=>x.id===id);if(!h)return;
  if(!confirm("'"+(h.hazType||'위험상황')+"' 보고를 삭제하시겠습니까?"))return;
  DB.s('hazards',hz.filter(x=>x.id!==id));
  renderAdmCtrl();try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}toast('🗑️ 삭제');updateSummary();
}
function admDelFac(id){
  if(!_canManageFac()){toast('⚠️ 탐방시설과·개발자만 삭제 가능');return;}
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  if(!confirm('삭제?'))return;
  DB.s('facilities',(DB.g('facilities')||[]).filter(f=>f.id!==id));
  // 1년 이전 점검이력도 함께 정리되도록 먼저 로드 후 삭제(미로드 시 최근 구간만 지워져 과거 이력이 고아로 남음)
  _loadArchive('history').then(()=>{DB.s('history',(DB.g('history')||[]).filter(h=>h.facId!==id));});
  renderAdmCtrl();try{renderInspectMap();}catch(e){}toast('🗑️ 삭제');updateSummary();
}
function admEndRes(id){if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}const res=DB.g('rescues')||[];const i=res.findIndex(x=>x.id===id);if(i===-1)return;if(!confirm("'"+(res[i].title||'')+"' 상황을 종료 처리하겠습니까?"))return;res[i].status='done';DB.s('rescues',res);try{if(typeof _closeLinkedSos==='function')_closeLinkedSos(res[i]);}catch(e){}renderAdmCtrl();try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}toast('✅ 상황 종료');}
function admDelRes(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const res=DB.g('rescues')||[];const r=res.find(x=>x.id===id);if(!r)return;
  if(!confirm("'"+(r.title||'구조 기록')+"' 을(를) 삭제하시겠습니까?\n삭제 후 5초 안에 되돌릴 수 있습니다."))return;
  // 목록에서 즉시 제거(되돌리기 대비 사본 보관). 사진 등 비가역 삭제는 5초 후 확정 시에만.
  const backup=JSON.parse(JSON.stringify(r));
  DB.s('rescues',(DB.g('rescues')||[]).filter(x=>x.id!==id));
  renderAdmCtrl();try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}updateSummary();
  _undoToast("🗑️ '"+(r.title||'구조 기록')+"' 삭제됨",
    function(){ // 되돌리기
      const cur=DB.g('rescues')||[];
      if(!cur.some(x=>x.id===backup.id)){cur.push(backup);DB.s('rescues',cur);}
      renderAdmCtrl();try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}updateSummary();toast('↩ 삭제 취소됨');
    },
    function(){ // 5초 후 실제 확정: 사진·댓글 영구 삭제 + 연계 SOS 링크 종료
      if(backup&&_fst){
        [backup.injuryPhoto,backup.transPhoto,...((backup.reports||[]).map(p=>p.photo)),...((backup.photos||[]).map(p=>p.url))]
          .filter(u=>u&&String(u).startsWith('http'))
          .forEach(u=>{try{_fst.refFromURL(u).delete().catch(()=>{});}catch(e){}});
      }
      try{if(typeof _closeLinkedSos==='function')_closeLinkedSos(backup);}catch(e){}
      try{localStorage.removeItem('v7_comments_'+id);}catch(e){}
    });
}
function renderAdmMembers(){
  try{_logAccess&&_logAccess('직원 개인정보','직원 명단 열람');}catch(e){}
  // 자동 승인 ON이면 목록을 그리기 직전에 로그인 이력까지 전원 멤버로 일괄 처리(승인버튼 잔존 방지)
  if(typeof isAdminUser==='function'&&isAdminUser()&&_isAutoApprove()){try{_autoApproveSweep();}catch(e){}}
  const pending=DB.g('pendingUsers')||[];
  const loginLog=(DB.g('loginLog')||[]).slice().sort((a,b)=>(b.at||0)-(a.at||0));
  const acl=_getAcl();
  const roleOf=id=>{const s=String(id||'');return acl.admins.includes(s)?'admin':(acl.members.includes(s)?'member':'none');};

  // 통합 목록: loginLog 우선, pendingUsers에서 보완
  const seen={};const unified=[];
  loginLog.forEach(e=>{
    const kid=String(e.kakaoId||'');if(!kid||seen[kid])return;seen[kid]=1;
    const pu=pending.find(p=>String(p.kakaoId||p.id)===kid);
    unified.push({kakaoId:kid,name:(pu&&(pu.realName||pu.name))||e.name||'',dept:(pu&&pu.dept)||e.dept||'',rank:(pu&&pu.rank)||e.rank||'',grade:(pu&&pu.grade)||e.grade||'',kakaoImg:(pu&&pu.kakaoImg)||'',approvalStatus:(pu&&pu.approvalStatus)||'',puId:(pu&&pu.id)||'',reg:(pu&&pu.submittedAt)||e.at||0});
  });
  pending.forEach(p=>{
    const kid=String(p.kakaoId||p.id);if(seen[kid])return;seen[kid]=1;
    unified.push({kakaoId:kid,name:p.realName||p.name||'',dept:p.dept||'',rank:p.rank||'',grade:p.grade||'',kakaoImg:p.kakaoImg||'',approvalStatus:p.approvalStatus||'',puId:p.id,reg:p.submittedAt||0});
  });
  // 급수·직위 보완: 저장값이 없으면 직원 명부(이름·소속 일치)에서 채워 표시
  const _rst0=(typeof _staffRoster!=='undefined'&&_staffRoster&&_staffRoster.staff)||null;
  unified.forEach(u=>{
    if((!u.grade||!u.rank)&&_rst0&&u.name){
      const m=_rst0.filter(s=>s.n===u.name&&(!u.dept||s.d===u.dept));
      const s=(m.length===1)?m[0]:(_rst0.filter(s=>s.n===u.name).length===1?_rst0.find(s=>s.n===u.name):null);
      if(s){if(!u.grade)u.grade=s.g||'';if(!u.rank&&typeof _rankFromGrade==='function')u.rank=_rankFromGrade(s.g,u.name)||'';}
    }
  });

  const usedDepts=[...new Set(unified.map(u=>u.dept).filter(Boolean))];
  const chips=['전체',...usedDepts];
  const fu=_admMemberFilter==='전체'?unified.slice():unified.filter(u=>u.dept===_admMemberFilter);
  // 정렬: 최신순(등록시각)·짬순(연공)·가나다순
  const _sort=window._admMemberSort||'recent';
  if(_sort==='senior'&&typeof _staffSenScore==='function'){
    fu.sort((a,b)=>{const d=_staffSenScore(a.name)-_staffSenScore(b.name);return d!==0?d:String(a.name).localeCompare(String(b.name),'ko');});
  }else if(_sort==='name'){
    fu.sort((a,b)=>String(a.name||'힣').localeCompare(String(b.name||'힣'),'ko'));
  }else{
    fu.sort((a,b)=>(b.reg||0)-(a.reg||0));
  }
  const adminCnt=fu.filter(u=>roleOf(u.kakaoId)==='admin').length;
  const memberCnt=fu.filter(u=>roleOf(u.kakaoId)==='member').length;
  const facMgrs=_facManagers();
  const facMgrCnt=fu.filter(u=>facMgrs.indexOf(String(u.kakaoId))>=0).length;

  const deptOpts=['행정과','재난안전과','탐방시설과','자원보전과','특수산악구조대','대청분소','백담분소','오색분소','한계산성분소','점봉산분소'];
  const rankOpts=['주임','계장','팀장','과장','분소장','소장'];

  // 신규(아직 미등록=승인 대기) — 로그인했지만 멤버/관리자가 아닌 사람
  const pendingNew=fu.filter(u=>roleOf(u.kakaoId)==='none');
  const autoOn=_isAutoApprove();

  let html=`
  <div class="scard" style="margin-bottom:10px;border:1px solid ${autoOn?'rgba(46,204,113,.4)':'rgba(255,255,255,.08)'};background:${autoOn?'rgba(46,204,113,.06)':'rgba(255,255,255,.02)'};">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
      <div style="flex:1;min-width:0;">
        <div style="font-size:12px;font-weight:700;color:${autoOn?'#5dbf8a':'#d5d8dc'};">${autoOn?'✅ 자동 승인 켜짐':'🔒 수동 승인 모드'}</div>
        <div style="font-size:10px;color:#8b95a1;margin-top:3px;line-height:1.5;">${autoOn?'지금 로그인하는 직원은 대기 없이 바로 입장합니다. 발표·행사가 끝나면 꺼주세요.':'새 직원은 아래 ‘신규 승인 대기’에서 승인해야 입장합니다.'}</div>
      </div>
      <button onclick="toggleAutoApprove()" style="flex-shrink:0;background:${autoOn?'#27ae60':'#1a4a6e'};color:#fff;border:none;border-radius:18px;padding:8px 14px;font-size:12px;font-weight:800;cursor:pointer;">${autoOn?'끄기':'자동 승인 켜기'}</button>
    </div>
  </div>
  <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;line-height:1.6;">카카오 로그인 이력 + DB 접근 권한을 한 곳에서 관리합니다. 역할을 지정하면 즉시 적용됩니다.</div>
  <div style="font-size:11px;color:#a5abb3;margin-bottom:8px;">총 <b style="color:#eaecef;">${fu.length}</b>명 · 관리자 <b style="color:#5dbf8a;">${adminCnt}</b> · 멤버 <b style="color:#3182f6;">${memberCnt}</b>${facMgrCnt?` · 🔧담당 <b style="color:#f0a500;">${facMgrCnt}</b>`:''}${pendingNew.length?` · <b style="color:#e67e22;">신규 ${pendingNew.length}</b>`:''}</div>
  <div style="font-size:10px;color:#8b95a1;background:rgba(240,165,0,.06);border:1px solid rgba(240,165,0,.18);border-radius:8px;padding:7px 9px;margin-bottom:10px;line-height:1.55;">🔧 <b style="color:#f0a500;">시설물 담당자</b>: 순찰자가 올린 <b>시설물 점검</b>을 재평가·회신하는 사람입니다. 지정된 담당자에게만 점검 알림이 갑니다. 이름 옆 🔧 버튼으로 지정하세요.</div>`;

  // 📋 직원 명부 대조 배지 — 명부(일반직·특정직)에 있는 이름이면 초록, 없으면 확인 필요(기간제·외부·개명 가능성)
  if(typeof _loadRoster==='function'&&typeof _staffRoster!=='undefined'&&!_staffRoster){_loadRoster(j=>{if(j)try{renderAdmMembers();}catch(e){}});}
  const _rstList=(typeof _staffRoster!=='undefined'&&_staffRoster&&_staffRoster.staff)||null;
  const rosterBadge=u=>{
    if(!_rstList||!u.name)return '';
    const hitD=_rstList.some(s=>s.n===u.name&&s.d===u.dept);
    const hitN=hitD||_rstList.some(s=>s.n===u.name);
    return hitD?'<span style="color:#5dbf8a;font-size:9px;font-weight:700;">📋명부일치</span>'
      :hitN?'<span style="color:#e8c84a;font-size:9px;font-weight:700;">📋이름만 일치(소속 확인)</span>'
      :'<span style="color:#e6a23c;font-size:9px;font-weight:700;">❔명부에 없음</span>';
  };
  // ── 신규 승인 대기 섹션 (최상단 강조) ──
  if(pendingNew.length){
    html+=`<div style="background:rgba(230,126,34,.07);border:1px solid rgba(230,126,34,.3);border-radius:11px;padding:11px;margin-bottom:12px;">
      <div style="font-size:12px;font-weight:800;color:#e67e22;margin-bottom:9px;">🆕 신규 승인 대기 <span style="background:#e67e22;color:#fff;border-radius:10px;padding:0 7px;font-size:10px;margin-left:3px;">${pendingNew.length}</span></div>`
      +pendingNew.map(u=>`<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-top:1px solid rgba(255,255,255,.05);">
        ${u.kakaoImg?`<img src="${_esc(_imgHttps(u.kakaoImg))}" style="width:34px;height:34px;border-radius:50%;object-fit:cover;flex-shrink:0;" onerror="this.style.display='none'">`:`<div style="width:34px;height:34px;border-radius:50%;background:#3a2a18;display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;">🆕</div>`}
        <div style="flex:1;min-width:0;">
          <div style="font-size:13px;font-weight:700;color:#eaecef;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(u.name||'이름없음')} ${rosterBadge(u)}</div>
          <div style="font-size:10px;color:#9c8060;margin-top:1px;">${_esc(u.dept||'소속 미입력')}${u.rank?' · '+_esc(u.rank):''}${u.grade?' · '+_esc(u.grade):''} <span style="font-family:monospace;color:#6a5030;">ID ${_esc(u.kakaoId)}</span></div>
        </div>
        <button onclick="grantMember('${_escq(u.kakaoId)}')" style="flex-shrink:0;background:#27ae60;color:#fff;border:none;border-radius:8px;padding:8px 13px;font-size:12px;font-weight:800;cursor:pointer;">✅ 승인</button>
        ${u.puId?`<button onclick="deleteUser('${_escq(u.puId)}')" style="flex-shrink:0;background:rgba(192,57,43,.15);color:#ff8a80;border:1px solid rgba(192,57,43,.25);border-radius:8px;padding:8px 10px;font-size:11px;cursor:pointer;">거부</button>`:''}
      </div>`).join('')
      +`</div>`;
  }

  html+=`
  <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;">
    ${chips.map(d=>`<div onclick="setAdmMemberFilter('${d}')" style="padding:4px 10px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;${d===_admMemberFilter?'background:#1a4a6e;color:#3182f6;':'background:#1c1c1e;color:#565f6b;border:1px solid #1a3a5a;'}">${d}</div>`).join('')}
  </div>
  <div style="display:flex;align-items:center;gap:5px;margin-bottom:10px;">
    <span style="font-size:10px;color:#565f6b;font-weight:700;flex-shrink:0;">정렬</span>
    ${[['recent','🕑 최신순'],['senior','🎖 직급순'],['name','가나다순']].map(([v,l])=>`<div onclick="setAdmMemberSort('${v}')" style="padding:4px 10px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;${_sort===v?'background:#1a4a6e;color:#3182f6;':'background:#1c1c1e;color:#565f6b;border:1px solid #1a3a5a;'}">${l}</div>`).join('')}
  </div>`;

  if(!fu.length){
    html+=`<div style="font-size:11px;color:#565f6b;padding:8px 0;">카카오 로그인 이력이 없습니다. 직원들이 카카오 로그인하면 자동으로 표시됩니다.</div>`;
  } else {
    html+=fu.map(u=>{
      const role=roleOf(u.kakaoId);
      const roleBadge=role==='admin'?'<span style="color:#5dbf8a;font-size:10px;font-weight:700;">관리자</span>':role==='member'?'<span style="color:#3182f6;font-size:10px;font-weight:700;">멤버</span>':'<span style="color:#7a5040;font-size:10px;">미등록</span>';
      const isFacMgr=facMgrs.indexOf(String(u.kakaoId))>=0;
      const facMgrBadge=isFacMgr?'<span style="color:#f0a500;font-size:10px;font-weight:700;">🔧담당</span>':'';
      const appBadge=u.approvalStatus==='approved'?'<span style="color:#7ec8a0;font-size:9px;">✅승인</span>':(u.approvalStatus?'<span style="color:#e67e22;font-size:9px;">⏳대기</span>':'');
      const editId='adme_'+u.kakaoId;
      return `<div style="padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <div style="display:flex;align-items:center;gap:8px;">
          ${u.kakaoImg?`<img src="${_esc(_imgHttps(u.kakaoImg))}" style="width:32px;height:32px;border-radius:50%;object-fit:cover;flex-shrink:0;" onerror="this.style.display='none'">`:`<div style="width:32px;height:32px;border-radius:50%;background:#1a3a5a;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;">👤</div>`}
          <div style="flex:1;min-width:0;">
            <div style="font-size:12px;font-weight:700;color:#eaecef;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${_esc(u.name||'이름없음')} ${roleBadge} ${facMgrBadge} ${appBadge} ${rosterBadge(u)}</div>
            <div style="font-size:10px;color:#565f6b;margin-top:1px;">${_esc(u.dept)}${u.rank?' · '+_esc(u.rank):''}${u.grade?' · <b style="color:#7a8a99;">'+_esc(u.grade)+'</b>':''} <span style="font-family:monospace;color:#2a5060;">ID ${_esc(u.kakaoId)}</span></div>
            ${u.reg?`<div style="font-size:9px;color:#3a5a6a;margin-top:1px;">📅 등록 ${new Date(u.reg).toLocaleString('ko-KR',{year:'2-digit',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}</div>`:''}
          </div>
          <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;">
            ${_isDeveloper(u.kakaoId)
              ?`<span style="font-size:10px;color:#5dbf8a;font-weight:800;background:rgba(39,174,96,.12);border:1px solid rgba(39,174,96,.3);border-radius:7px;padding:4px 8px;">👨‍💻 개발자</span>`
              :`<select onchange="_aclSetRole('${_escq(u.kakaoId)}',this.value)" style="background:#131316;color:#d5d8dc;border:1px solid rgba(255,255,255,.25);border-radius:7px;padding:4px 5px;font-size:10px;cursor:pointer;">
              <option value="none"${role==='none'?' selected':''}>미등록</option>
              <option value="member"${role==='member'?' selected':''}>멤버</option>
              <option value="admin"${role==='admin'?' selected':''}>관리자</option>
            </select>`}
            <button onclick="_toggleFacManager('${_escq(u.kakaoId)}')" title="시설물 점검 담당자 지정/해제" style="background:${isFacMgr?'rgba(240,165,0,.18)':'rgba(255,255,255,.04)'};color:${isFacMgr?'#f0a500':'#6a8296'};border:1px solid ${isFacMgr?'rgba(240,165,0,.4)':'rgba(255,255,255,.12)'};border-radius:6px;padding:4px 7px;font-size:10px;cursor:pointer;">🔧</button>
            <button onclick="_toggleAdmMemberEdit('${_escq(editId)}')" style="background:rgba(255,255,255,.12);color:#3182f6;border:1px solid rgba(255,255,255,.25);border-radius:6px;padding:4px 7px;font-size:10px;cursor:pointer;">수정</button>
            ${role==='none'&&!_isDeveloper(u.kakaoId)?`<button onclick="grantMember('${_escq(u.kakaoId)}')" style="background:rgba(39,174,96,.15);color:#7ec8a0;border:1px solid rgba(39,174,96,.3);border-radius:6px;padding:4px 7px;font-size:10px;cursor:pointer;">승인</button>`:''}
            ${!_isDeveloper(u.kakaoId)?`<button onclick="removeStaff('${_escq(u.kakaoId)}')" style="background:rgba(192,57,43,.15);color:#ff8a80;border:1px solid rgba(192,57,43,.25);border-radius:6px;padding:4px 7px;font-size:10px;cursor:pointer;">탈퇴</button>`:''}
          </div>
        </div>
        <div id="admMemberEdit_${editId}" style="display:none;margin-top:8px;background:rgba(0,0,0,.25);border-radius:9px;padding:10px;">
          <div style="font-size:10px;color:#565f6b;font-weight:600;margin-bottom:7px;">✏️ 직원 정보 수정</div>
          <input id="admME_name_${editId}" class="fi" value="${_esc(u.name||'')}" placeholder="이름" style="margin-bottom:6px;">
          <select id="admME_dept_${editId}" class="fsel" style="margin-bottom:6px;">
            ${deptOpts.map(d=>`<option value="${d}"${u.dept===d?' selected':''}>${d}</option>`).join('')}
          </select>
          <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;" id="admME_ranks_${editId}">
            ${rankOpts.map(r=>`<div onclick="_toggleAdmRank('${_escq(editId)}','${r}')" id="admMER_${editId}_${r}" data-sel="${u.rank===r?'1':''}" style="cursor:pointer;border-radius:20px;font-size:10px;font-weight:700;padding:4px 10px;border:1px solid;${u.rank===r?'background:rgba(255,255,255,.2);color:#3182f6;border-color:rgba(255,255,255,.5);':'background:rgba(255,255,255,.04);color:rgba(255,255,255,.4);border-color:rgba(255,255,255,.12);'}">${r}</div>`).join('')}
          </div>
          <div style="display:flex;gap:6px;">
            <button onclick="_saveAdmMemberByKakao('${_escq(u.kakaoId)}','${_escq(editId)}')" style="flex:1;background:#1a4a6e;color:#fff;border:none;padding:7px;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;">저장</button>
            <button onclick="_toggleAdmMemberEdit('${_escq(editId)}')" style="background:none;border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.4);padding:7px 10px;border-radius:7px;font-size:11px;cursor:pointer;">취소</button>
          </div>
        </div>
      </div>`;
    }).join('');

    // 카카오 ID 직접 추가
    html+=`<div style="display:flex;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.06);">
      <input id="aclAddIdInp" class="fi" placeholder="카카오 ID 직접 추가 (숫자)" style="flex:1;font-family:monospace;font-size:12px;">
      <button onclick="_aclAddById()" style="background:#1a4a6e;color:#fff;border:none;padding:8px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;">＋ 멤버</button>
    </div>`;
  }
  document.getElementById('admMembersWrap').innerHTML=html;
}
// 통합 직원 정보 저장 (kakaoId 기반으로 pendingUsers 찾거나 새로 생성)
function _saveAdmMemberByKakao(kakaoId,editId){
  const list=DB.g('pendingUsers')||[];
  const name=(document.getElementById('admME_name_'+editId)||{}).value?.trim();
  const dept=(document.getElementById('admME_dept_'+editId)||{}).value||'';
  const rankEl=document.querySelector('#admME_ranks_'+editId+' [data-sel="1"]');
  const rank=rankEl?rankEl.textContent.trim():'';
  if(!name){toast('⚠️ 이름을 입력하세요');return;}
  const idx=list.findIndex(u=>String(u.kakaoId||u.id)===String(kakaoId));
  if(idx>=0){
    // 직위 미선택 시 기존 값 보존 — 이름만 고치려다 직위가 지워지던 문제 방지
    list[idx]={...list[idx],realName:name,name,dept,rank:rank||list[idx].rank||''};
  } else {
    list.push({id:Date.now(),kakaoId:String(kakaoId),realName:name,name,dept,rank,approvalStatus:'approved',createdAt:now()});
  }
  DB.s('pendingUsers',list);
  // loginLog도 갱신
  const log=(DB.g('loginLog')||[]).slice();
  const li=log.findIndex(e=>String(e.kakaoId)===String(kakaoId));
  if(li>=0){log[li]={...log[li],name,dept,rank};DB.s('loginLog',log);}
  const me=DB.g('currentUser')||{};
  if(String(me.kakaoId)===String(kakaoId)){DB.s('currentUser',{...me,realName:name,name,dept,rank});updateUserUI();}
  renderAdmMembers();
  toast('✅ 직원 정보 저장됨');
}
var _admMemberFilter='전체';
function setAdmMemberFilter(f){_admMemberFilter=f;renderAdmMembers();}
function setAdmMemberSort(s){window._admMemberSort=s;renderAdmMembers();}
function _toggleAdmMemberEdit(id){
  const el=document.getElementById('admMemberEdit_'+id);
  if(el)el.style.display=el.style.display==='none'?'block':'none';
}
function _toggleAdmRank(uid,rank){
  const rankOpts=['주임','계장','팀장','과장','분소장','소장'];
  rankOpts.forEach(r=>{
    const el=document.getElementById(`admMER_${uid}_${r}`);
    if(!el)return;
    const on=r===rank;
    el.style.background=on?'rgba(255,255,255,.2)':'rgba(255,255,255,.04)';
    el.style.color=on?'#3182f6':'rgba(255,255,255,.4)';
    el.style.borderColor=on?'rgba(255,255,255,.5)':'rgba(255,255,255,.12)';
    el.dataset.sel=on?'1':'';
  });
}
function renderAdmCat(){
  const cats=DB.g('catFac')||[];
  const meta=DB.g('catFacMeta')||{};
  const togHtml=(id,label,checked)=>`<label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#8b95a1;cursor:pointer;margin-top:5px;"><input type="checkbox" id="${id}"${checked?' checked':''}> ${label}</label>`;
  const rowsHtml=cats.map((c,i)=>{
    const m=meta[c]||{};
    const badges=(m.rescue?'<span style="font-size:9px;background:rgba(255,255,255,.15);color:#3182f6;border:1px solid rgba(255,255,255,.3);border-radius:3px;padding:1px 5px;margin-right:3px;">🗺 재난</span>':'')+(m.adminOnly?'<span style="font-size:9px;background:rgba(192,57,43,.12);color:#e05050;border:1px solid rgba(192,57,43,.3);border-radius:3px;padding:1px 5px;">🔒 관리자</span>':'');
    return `<div style="border-bottom:1px solid rgba(255,255,255,.05);padding:6px 0;">
      <div class="adm-row" style="margin-bottom:0;">
        <div class="adm-info" style="flex:1;min-width:0;">
          <div class="adm-name" style="font-size:12px;">${_esc(c)}</div>
          <div style="margin-top:3px;">${badges||'<span style="font-size:9px;color:#454e5a;">일반</span>'}</div>
        </div>
        <button class="abtn" style="font-size:10px;" onclick="toggleCatEdit(${i})">수정</button>
        <button class="abtn del" style="font-size:10px;" onclick="delCat(${i})">삭제</button>
      </div>
      <div id="catEdit${i}" style="display:none;padding:8px;background:rgba(0,0,0,.2);border-radius:7px;margin-top:4px;">
        <input type="text" id="catEditName${i}" class="fi" value="" style="margin-bottom:4px;">
        ${togHtml('catER'+i,'🗺 재난관리지도에 표시',m.rescue)}
        ${togHtml('catEA'+i,'🔒 관리자만 볼 수 있음',m.adminOnly)}
        <div style="display:flex;gap:6px;margin-top:8px;">
          <button onclick="submitEditCat(${i})" style="flex:1;background:#1a4a6e;color:#fff;border:none;padding:7px;border-radius:7px;font-size:11px;cursor:pointer;">저장</button>
          <button onclick="toggleCatEdit(${i})" style="background:none;border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.4);padding:7px 10px;border-radius:7px;font-size:11px;cursor:pointer;">취소</button>
        </div>
      </div>
    </div>`;
  }).join('');
  const addHtml=`<div id="catAddForm" style="display:none;padding:10px;background:rgba(0,0,0,.2);border-radius:9px;margin-top:8px;">
    <input type="text" id="newCatName" class="fi" placeholder="이모지 포함 이름 예: 🛖 야영시설" style="margin-bottom:4px;">
    ${togHtml('newCatRescue','🗺 재난관리지도에 표시',false)}
    ${togHtml('newCatAdmin','🔒 관리자만 볼 수 있음',false)}
    <div style="display:flex;gap:6px;margin-top:8px;">
      <button onclick="submitAddCat()" style="flex:1;background:#0c4838;color:#fff;border:none;padding:8px;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;">추가</button>
      <button onclick="document.getElementById('catAddForm').style.display='none';document.getElementById('catAddBtn').style.display='block';" style="background:none;border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.4);padding:8px 10px;border-radius:7px;font-size:11px;cursor:pointer;">취소</button>
    </div>
  </div>
  <button id="catAddBtn" class="btn btn-ghost" style="width:100%;padding:9px;border-radius:8px;margin-top:8px;font-size:12px;" onclick="this.style.display='none';document.getElementById('catAddForm').style.display='block';">＋ 카테고리 추가</button>`;
  document.getElementById('admCatWrap').innerHTML=`<div style="font-size:10px;color:#454e5a;margin-bottom:7px;font-weight:600;">시설물 카테고리</div>${rowsHtml}${addHtml}`;
  // 수정 폼 name 값 채우기 (innerHTML escaping 우회)
  cats.forEach((c,i)=>{const el=document.getElementById('catEditName'+i);if(el)el.value=c;});
}
function toggleCatEdit(i){const el=document.getElementById('catEdit'+i);if(el)el.style.display=el.style.display==='none'?'block':'none';}
function submitAddCat(){
  const n=(document.getElementById('newCatName').value||'').trim();
  if(!n){toast('⚠️ 카테고리명 입력');return;}
  const cats=DB.g('catFac')||[];
  if(cats.includes(n)){toast('⚠️ 이미 존재');return;}
  cats.push(n);DB.s('catFac',cats);
  const meta=DB.g('catFacMeta')||{};
  meta[n]={rescue:!!document.getElementById('newCatRescue').checked,adminOnly:!!document.getElementById('newCatAdmin').checked};
  DB.s('catFacMeta',meta);renderAdmCat();toast('✅ 추가');
}
function submitEditCat(i){
  const cats=DB.g('catFac')||[];const oldName=cats[i];
  const newName=(document.getElementById('catEditName'+i).value||'').trim();
  if(!newName){toast('⚠️ 카테고리명 입력');return;}
  cats[i]=newName;DB.s('catFac',cats);
  const meta=DB.g('catFacMeta')||{};
  if(oldName!==newName)delete meta[oldName];
  meta[newName]={rescue:!!document.getElementById('catER'+i).checked,adminOnly:!!document.getElementById('catEA'+i).checked};
  DB.s('catFacMeta',meta);renderAdmCat();toast('✅ 수정');
}
function delCat(i){if(!confirm('삭제?'))return;const cats=DB.g('catFac')||[];const name=cats[i];cats.splice(i,1);DB.s('catFac',cats);const meta=DB.g('catFacMeta')||{};delete meta[name];DB.s('catFacMeta',meta);renderAdmCat();}
function renderAdmSheets(){
  const url=DB.g('sheetsUrl')||'';
  document.getElementById('admSheetsWrap').innerHTML=`
    <div class="scard" style="margin-bottom:8px;"><div class="stitle">🔗 Google Sheets 자동 동기화</div>
      <div style="font-size:12px;color:#8b95a1;line-height:1.6;margin-bottom:10px;">구조보고·시설점검 저장 시 자동으로 스프레드시트에 기록됩니다.</div>
      <div class="fg"><span class="fl">Apps Script 배포 URL</span><input type="text" id="sheetsUrlIn" class="fi" placeholder="https://script.google.com/macros/s/..." value="${url}"></div>
      <button onclick="saveSheetsUrl()" style="width:100%;background:${url?'#0c4838':'#1a4a6e'};color:#fff;border:none;padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">${url?'✅ 저장됨 (재입력하여 변경)':'저장'}</button>
    </div>
    <div class="scard" style="margin-bottom:8px;"><div class="stitle">📌 Google Sheets 설정 방법</div>
      <div style="font-size:11px;color:#8b95a1;line-height:1.8;">1. Google Sheets 열기<br>2. 확장 프로그램 → Apps Script<br>3. 코드 작성 → 배포 → 웹앱으로 배포<br>4. 생성된 URL을 위에 입력</div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🚒 외부기관 관리</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">119·산악구조대·특수대응단 등 기관별로 추가하세요. 각 기관에 코드를 전달하면 해당 기관명으로 접수됩니다 (접수·조회·댓글만 가능).</div>
      <div id="extAgencyListWrap">${_extAgencyRowsHtml()}</div>
      <div style="display:flex;gap:6px;margin-top:8px;">
        <button onclick="addExtAgencyRow()" style="flex:1;background:rgba(255,255,255,.05);color:#a5abb3;border:1px dashed rgba(255,120,30,.3);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">＋ 기관 추가</button>
        <button onclick="saveExtAgencies()" style="flex:1;background:#7a3010;color:#fff;border:none;padding:9px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">💾 전체 저장</button>
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🤖 AI 출동지령서 스캔 키</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">Google Gemini API 키 (무료) — <a href="https://aistudio.google.com/app/apikey" target="_blank" style="color:#c4b5fd;">aistudio.google.com</a>에서 발급</div>
      <div style="display:flex;gap:6px;">
        <input id="geminiKeyInp" type="password" class="fi" value="${DB.g('geminiApiKey')||''}" placeholder="AIza..." style="flex:1;font-family:monospace;font-size:13px;">
        <button onclick="saveGeminiKey()" style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">저장</button>
      </div>
      <div style="font-size:10px;color:#3a4a6a;margin-top:7px;">무료 티어: 1일 1,500회 · 분당 100만 토큰 · 결제 불필요</div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🔔 아이폰·웹 푸시 키 (VAPID)</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">Firebase 콘솔 → ⚙️ 프로젝트 설정 → <b>클라우드 메시징</b> → 웹 푸시 인증서 → <b>키 쌍 생성</b> 후 그 키(B로 시작)를 붙여넣고 저장. 전 기기에 자동 반영되며, 아이폰은 <b>홈 화면 앱으로 실행 + 알림 허용</b>(설정 탭) 시 꺼진 폰에도 푸시가 갑니다.</div>
      <div style="display:flex;gap:6px;">
        <input id="vapidKeyInp" type="text" class="fi" value="${DB.g('fcmVapidKey')||''}" placeholder="B로 시작하는 88자 키" style="flex:1;font-family:monospace;font-size:12px;">
        <button onclick="(function(){var v=(document.getElementById('vapidKeyInp').value||'').trim();DB.s('fcmVapidKey',v);try{if(v&&typeof _initFCM==='function')_initFCM();}catch(e){}toast(v?'✅ 저장 — 전 기기 자동 반영, 각 기기는 알림 허용 시 푸시 등록':'키 삭제됨');})()" style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">저장</button>
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🎯 커스텀 사고유형 아이콘</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">'기타'로 직접 입력해 쓰는 사고유형(예: 낙석, 화재)에 전용 지도 아이콘을 지정. 등록하면 전 기기에 공유됩니다.</div>
      <div id="customTypeList">${(DB.g('customResTypes')||[]).map((t,i)=>`<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:#1c1c1e;border-radius:7px;margin-bottom:4px;border:1px solid rgba(255,255,255,.07);">
        <span style="font-size:16px;">${_esc(t.ico||'⚠️')}</span><span style="flex:1;font-size:12px;color:#eaecef;font-weight:600;">${_esc(t.name||'')}</span>
        <button onclick="delCustomResType(${i})" style="background:rgba(192,57,43,.15);color:#c0392b;border:none;border-radius:5px;padding:3px 9px;font-size:11px;cursor:pointer;">삭제</button>
      </div>`).join('')||'<div style="font-size:11px;color:#3a4a6a;padding:4px 2px;">등록된 커스텀 유형 없음</div>'}</div>
      <div style="display:flex;gap:6px;margin-top:8px;">
        <input id="ctypeName" type="text" class="fi" placeholder="유형 이름 (예: 낙석)" style="flex:2;">
        <input id="ctypeIco" type="text" class="fi" placeholder="이모지" maxlength="4" style="flex:1;text-align:center;">
        <button onclick="addCustomResType()" style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">추가</button>
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">📄 한글 보고서 서식 (hwpx)</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;line-height:1.6;">실제 결재 서식(.hwpx)을 등록하면 보고서 버튼이 <b style="color:#a5abb3;">그 서식 그대로</b> 데이터를 채운 한글파일을 만듭니다.<br>
      ① 한글에서 서식 문서를 열고, 값이 들어갈 칸에 <b style="color:#e8b34a;">{{사고일시}}</b> 같은 자리표시자를 입력<br>
      ② 다른 이름으로 저장 → <b>HWPX</b> 형식 선택 ③ 아래에서 업로드</div>
      <button onclick="copyTplPlaceholders()" style="width:100%;margin-bottom:8px;background:rgba(232,179,74,.1);border:1px solid rgba(232,179,74,.35);color:#e8b34a;padding:8px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">📋 자리표시자 전체 목록 복사</button>
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
        <span style="font-size:12px;color:#d5d8dc;flex:1;">📑 처리현황: <span id="tplName_status" style="color:#8b95a1;">확인중…</span></span>
        <label style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:7px 12px;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;">업로드<input type="file" accept=".hwpx" style="display:none;" onchange="uploadHwpxTpl('status',this)"></label>
      </div>
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="font-size:12px;color:#d5d8dc;flex:1;">📈 동향보고: <span id="tplName_trend" style="color:#8b95a1;">확인중…</span></span>
        <label style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:7px 12px;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;">업로드<input type="file" accept=".hwpx" style="display:none;" onchange="uploadHwpxTpl('trend',this)"></label>
      </div>
    </div>
    <div class="scard">
      <div class="stitle">🌦️ 기상청 프록시 주소</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">실제 기상청 데이터를 안정적으로 받기 위한 본인 소유 프록시(Cloudflare Worker) 주소. 비우면 공개 프록시로 동작. 설정법: 저장소 <b>cloudflare-worker/README.md</b></div>
      <div style="display:flex;gap:6px;">
        <input id="kmaProxyInp" type="text" class="fi" value="${_esc(DB.g('kmaProxyUrl')||'')}" placeholder="https://seoraksan-kma.xxx.workers.dev" style="flex:1;font-family:monospace;font-size:11px;">
        <button onclick="saveKmaProxy()" style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">저장</button>
      </div>
      <div style="font-size:10px;color:#3a4a6a;margin-top:7px;">Cloudflare Workers 무료: 1일 10만 요청 · 설정 후 날씨 상세 출처가 '기상청'으로 표시</div>
    </div>
    <div class="scard">
      <div class="stitle">🥾 도보경로 프록시 주소</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">시설물 내비에서 <b>카카오 도보(등산로) 경로</b>를 받기 위한 본인 소유 프록시(Cloudflare Worker). REST키는 워커 시크릿에 저장돼 안전. 설정법: 저장소 <b>cloudflare-worker/kakao-walk-proxy.js</b></div>
      <div style="display:flex;gap:6px;">
        <input id="walkProxyInp" type="text" class="fi" value="${_esc(DB.g('walkProxyUrl')||'')}" placeholder="https://seoraksan-walk.xxx.workers.dev" style="flex:1;font-family:monospace;font-size:11px;">
        <button onclick="saveWalkProxy()" style="background:#1a3a20;color:#86efac;border:1px solid rgba(74,222,128,.3);padding:8px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">저장</button>
      </div>
      <div style="font-size:10px;color:#3a4a6a;margin-top:7px;">설정하면 내비 목적지까지 <b>실제 등산로 경로·거리·시간</b> 표시. 비우면 표지판 근사경로로 동작.</div>
    </div>`;
  setTimeout(_loadTplNames,80); // hwpx 서식 등록 상태 비동기 표시
}
// ── 한글 서식(hwpx) 템플릿 관리 ──
function _loadTplNames(){
  if(typeof _fdb==='undefined'||!_fdb)return;
  ['status','trend'].forEach(k=>{
    _fdb.collection('tpl').doc(k).get().then(d=>{
      const el=document.getElementById('tplName_'+k);if(!el)return;
      const dt=d.exists?d.data():null;
      if(dt&&dt.b64){el.textContent='✅ '+(dt.name||'등록됨')+(dt.by?' · '+dt.by:'');el.style.color='#86efac';}
      else{el.textContent='미등록 (HTML 방식으로 동작)';el.style.color='#8b95a1';}
    }).catch(()=>{const el=document.getElementById('tplName_'+k);if(el)el.textContent='조회 실패';});
  });
}
async function uploadHwpxTpl(kind,input){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');input.value='';return;}
  const f=input.files&&input.files[0];if(!f)return;
  if(!/\.hwpx$/i.test(f.name)){toast('⚠️ .hwpx 파일만 가능 — 한글에서 [다른 이름으로 저장 → HWPX]');input.value='';return;}
  if(f.size>700*1024){toast('⚠️ 700KB 이하만 가능 — 서식에서 큰 이미지를 빼주세요');input.value='';return;}
  try{
    const buf=await f.arrayBuffer();
    // hwpx(zip) 유효성 간단 확인
    try{await _zipRead(buf.slice(0));}catch(e){toast('⚠️ 올바른 hwpx가 아닙니다: '+e.message);input.value='';return;}
    const u8=new Uint8Array(buf);let b64='';const CH=0x8000;
    for(let i=0;i<u8.length;i+=CH)b64+=String.fromCharCode.apply(null,u8.subarray(i,i+CH));
    b64=btoa(b64);
    await _fdb.collection('tpl').doc(kind).set({b64:b64,name:f.name,at:Date.now(),by:getAuthor()});
    toast('✅ 서식 등록됨: '+f.name+' — 이제 보고서 버튼이 이 서식으로 생성합니다',5000);
    _loadTplNames();
  }catch(e){toast('⚠️ 업로드 실패: '+(e&&e.message||e));}
  input.value='';
}
function copyTplPlaceholders(){
  const list=(typeof HWPX_PLACEHOLDERS!=='undefined'?HWPX_PLACEHOLDERS:[]).map(k=>'{{'+k+'}}').join('\n');
  const txt='── 한글 서식 자리표시자 목록 (원하는 칸에 붙여넣기) ──\n'+list+'\n\n※ 여러 줄 항목: {{조치내용}} {{동원인원}} {{사고경위}}\n※ 서식에 없는 자리표시자는 빈칸으로 처리됩니다';
  if(navigator.clipboard)navigator.clipboard.writeText(txt).then(()=>toast('📋 자리표시자 목록 복사됨 — 한글 서식에 붙여넣어 배치하세요',5000)).catch(()=>_fallbackCopy(txt));
  else _fallbackCopy(txt);
}
// 커스텀 사고유형 아이콘 등록/삭제 (공유 customResTypes → RES_TYPES 병합)
function addCustomResType(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const name=(document.getElementById('ctypeName')?.value||'').trim();
  const ico=(document.getElementById('ctypeIco')?.value||'').trim();
  if(!name){toast('유형 이름을 입력하세요');return;}
  if(!ico){toast('이모지를 입력하세요');return;}
  const list=(DB.g('customResTypes')||[]).filter(t=>t&&t.name!==name);
  list.push({name:name.slice(0,12),ico:ico.slice(0,4)});
  DB.s('customResTypes',list);
  try{_mergeCustomResTypes();}catch(e){}
  toast('✅ 커스텀 유형 등록: '+ico+' '+name);
  try{renderAdmSheets();}catch(e){}
  try{renderRescueMap();}catch(e){}
}
function delCustomResType(i){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const list=DB.g('customResTypes')||[];
  const t=list[i];if(!t)return;
  if(!confirm("'"+(t.ico||'')+' '+(t.name||'')+"' 커스텀 유형을 삭제할까요? (기존 기록은 기타 아이콘으로 표시)"))return;
  list.splice(i,1);
  DB.s('customResTypes',list);
  try{delete RES_TYPES[t.name];}catch(e){}
  toast('🗑 삭제됨');
  try{renderAdmSheets();}catch(e){}
  try{renderRescueMap();}catch(e){}
}
function saveSheetsUrl(){const url=document.getElementById('sheetsUrlIn')?.value?.trim();if(!url){toast('⚠️ URL 입력');return;}DB.s('sheetsUrl',url);toast('✅ URL 저장');renderAdmSheets();}
// ── 전체 데이터 백업/복원 (JSON) ──
const _BACKUP_KEYS=['rescues','hazards','facilities','history','catFac','catFacMeta','pendingUsers','approvedUsers','deletedKakaoIds'];
function toggleSosBlock(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const cur=!!DB.g('sosBlocked');
  if(!confirm(cur?'조난·사고자 접수를 다시 허용할까요?':'조난·사고자 접수를 차단할까요?\n차단 중엔 위치가 들어오지 않습니다(악용 방지).'))return;
  DB.s('sosBlocked',!cur);
  toast(cur?'✅ 조난 접수 허용됨':'⛔ 조난 접수 차단됨');
  try{renderAdmSys();}catch(e){}try{_sosPings=[];_drawSosPins();_updateSosFab();}catch(e){}
}
function exportAllData(){
  const data={};
  _BACKUP_KEYS.forEach(k=>{data[k]=DB.g(k);});
  const out={app:'seoraksan',ver:APP_VER,exportedAt:now(),data};
  const blob=new Blob(['\uFEFF'+JSON.stringify(out,null,1)],{type:'application/json'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='설악산백업_'+today()+'.json';
  a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);
  toast('⬇️ 백업 파일 다운로드');
}
function importAllData(inp){
  const f=inp.files&&inp.files[0];inp.value='';
  if(!f)return;
  const rd=new FileReader();
  rd.onload=()=>{
    try{
      const out=JSON.parse(String(rd.result).replace(/^\uFEFF/,''));
      if(!out||out.app!=='seoraksan'||!out.data){toast('⚠️ 올바른 백업 파일이 아닙니다');return;}
      const counts=_BACKUP_KEYS.map(k=>{const v=out.data[k];return v&&v.length?k+' '+v.length+'건':null;}).filter(Boolean).join(', ');
      if(!confirm('백업 시점: '+(out.exportedAt||'?')+'\n'+counts+'\n\n현재 데이터를 이 백업으로 덮어씁니다. 계속할까요?'))return;
      if(!confirm('⚠️ 마지막 확인 — 복원 후 되돌릴 수 없습니다.'))return;
      _BACKUP_KEYS.forEach(k=>{if(out.data[k]!==undefined&&out.data[k]!==null)DB.s(k,out.data[k]);});
      toast('✅ 복원 완료');
      renderAdmCtrl();try{renderRescueMap();}catch(e){}updateSummary();
    }catch(e){toast('⚠️ 파일을 읽을 수 없습니다');}
  };
  rd.readAsText(f);
}

// ── 허용목록(_acl) 관리 ──
function _getAcl(){
  const a=DB.g('_acl')||{};
  const norm=x=>(Array.isArray(x)?x:[]).map(String).filter(Boolean);
  // 탈퇴자(deletedKakaoIds)는 _acl에 남아 있어도 무시 — 옛 캐시를 가진 기기가 _acl을 통째로
  // 덮어써 탈퇴 관리자가 '부활'하는 사고가 실제 발생(2026-07 점검). 권한 판정에서 원천 차단하고,
  // 다음 역할 변경 저장 때 문서도 자연히 정화된다. (정식 재가입 승인 시엔 deletedKakaoIds에서
  // 제거되므로 필터에 걸리지 않음)
  const del=new Set((DB.g('deletedKakaoIds')||[]).map(String));
  return {members:norm(a.members).filter(id=>!del.has(id)),admins:norm(a.admins).filter(id=>!del.has(id))};
}
function _aclSetRole(kakaoId,role){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  kakaoId=String(kakaoId);
  const acl=_getAcl();
  acl.members=acl.members.filter(id=>id!==kakaoId);
  acl.admins=acl.admins.filter(id=>id!==kakaoId);
  if(role==='member')acl.members.push(kakaoId);
  else if(role==='admin')acl.admins.push(kakaoId);
  DB.s('_acl',acl);
  renderAdmSys();
  toast(role==='none'?'제거됨':role==='admin'?'관리자로 설정':'멤버로 설정');
}
function _aclAddById(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const inp=document.getElementById('aclAddIdInp');
  const id=(inp&&inp.value||'').trim();
  if(!id){toast('⚠️ 카카오 ID를 입력하세요');return;}
  if(!/^\d+$/.test(id)){toast('⚠️ 카카오 ID는 숫자여야 합니다');return;}
  _aclSetRole(id,'member');
}
// ── 시설물 담당자 지정/해제 (관리자만) — 점검 등록 시 이들에게만 알림, 재평가 권한 ──
function _toggleFacManager(kakaoId){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  kakaoId=String(kakaoId);
  const list=(DB.g('facManagers')||[]).map(String).filter(Boolean);
  const i=list.indexOf(kakaoId);
  if(i>=0){list.splice(i,1);toast('🔧 시설물 담당자 해제');}
  else{list.push(kakaoId);toast('🔧 시설물 담당자 지정 — 점검 알림 대상');}
  DB.s('facManagers',list);
  try{renderAdmMembers();}catch(e){}
}
// ── 자동 승인 모드 ── (발표·대량 가입 시 1탭으로 이후 가입자 전원 자동 입장)
function _isAutoApprove(){return !!DB.g('autoApprove');}
function toggleAutoApprove(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const cur=_isAutoApprove();
  if(!confirm(cur
      ?'자동 승인을 끌까요?\n이후 가입자는 다시 관리자가 직접 승인해야 입장합니다.'
      :'자동 승인을 켤까요?\n지금부터 카카오 로그인한 직원은 승인 대기 없이 바로 입장합니다.\n(발표·대량 가입용 — 끝나면 다시 끄세요)'))return;
  DB.s('autoApprove',!cur);
  if(!cur){try{_autoApproveSweep();}catch(e){}} // 켜는 즉시 대기자 일괄 승인
  toast(cur?'🔒 자동 승인 꺼짐 — 수동 승인 모드':'✅ 자동 승인 켜짐 — 이후 가입자 자동 입장');
  try{renderAdmMembers();}catch(e){}
}
// 관리자 기기: 대기 중인 신청자를 모두 멤버로 등록(자동 승인 ON일 때)
function _autoApproveSweep(){
  // 로그인 이력(loginLog) + 가입신청(pendingUsers)의 모든 kakaoId를 멤버로 등록.
  // (이전엔 pendingUsers만 훑어, 로그인만 하고 신청레코드 없는 사용자가 누락 → 승인버튼 잔존·입장불가)
  const acl=_getAcl();let n=0;
  const deleted=new Set((DB.g('deletedKakaoIds')||[]).map(String)); // 관리자가 내보낸 사람은 제외
  const ids=new Set();
  (DB.g('loginLog')||[]).forEach(function(e){if(e&&e.kakaoId)ids.add(String(e.kakaoId));});
  (DB.g('pendingUsers')||[]).forEach(function(p){const k=String(p.kakaoId||p.id||'');if(k)ids.add(k);});
  ids.forEach(function(k){
    if(!k||deleted.has(k))return;
    if(acl.admins.indexOf(k)<0&&acl.members.indexOf(k)<0){acl.members.push(k);n++;}
  });
  if(n){DB.s('_acl',acl);
    // pendingUsers 상태도 approved로 갱신
    const list=(DB.g('pendingUsers')||[]).map(function(p){
      const kid=String(p.kakaoId||p.id);
      if(acl.members.indexOf(kid)>=0||acl.admins.indexOf(kid)>=0)return Object.assign({},p,{approvalStatus:'approved',seen:true});
      return p;
    });
    DB.s('pendingUsers',list);
  }
  return n;
}
// 본인 기기: 자동 승인 모드면 스스로 멤버 등록(관리자 부재여도 입장). _acl 쓰기는 인증사용자 누구나 허용.
function _aclSelfApprove(kakaoId){
  kakaoId=String(kakaoId||'');if(!kakaoId)return false;
  // 탈퇴자는 자동승인 모드에서도 스스로 멤버가 될 수 없음(부활 방지). 정식 재가입 승인 시 deletedKakaoIds에서 제거됨.
  var _del=new Set((DB.g('deletedKakaoIds')||[]).map(String));if(_del.has(kakaoId))return false;
  const acl=_getAcl();
  if(acl.members.indexOf(kakaoId)<0&&acl.admins.indexOf(kakaoId)<0){acl.members.push(kakaoId);DB.s('_acl',acl);}
  // pendingUsers 상태도 approved로 — 자동승인으로 들어왔는데 관리자 화면에 '승인' 버튼이 남던 문제 방지
  try{
    const list=DB.g('pendingUsers')||[];const i=list.findIndex(p=>String(p.kakaoId||p.id)===kakaoId);
    if(i>=0&&list[i].approvalStatus!=='approved'){list[i]=Object.assign({},list[i],{approvalStatus:'approved',seen:true});DB.s('pendingUsers',list);}
  }catch(e){}
  _markMemberOk();
  return true;
}
// 승인 대기 화면 폴링: 관리자가 승인(또는 자동 승인)하면 재로그인 없이 자동 입장
var _approvalPollTimer=null;
function _startApprovalPoll(){
  if(_approvalPollTimer)return;
  _approvalPollTimer=setInterval(function(){
    var gate=document.getElementById('approvalGate');
    if(!gate||gate.style.display==='none'){_stopApprovalPoll();return;}
    // 자동 승인 모드로 바뀌었으면 스스로 입장
    if(_isAutoApprove()){var u=DB.g('currentUser')||{};if(u.kakaoId)_aclSelfApprove(u.kakaoId);}
    if(_isMember()){
      _markMemberOk();_stopApprovalPoll();
      gate.style.display='none';
      try{updateUserUI();}catch(e){}try{goHome();}catch(e){}
      toast('✅ 승인 완료 — 환영합니다');
    }
  },3500);
}
function _stopApprovalPoll(){if(_approvalPollTimer){clearInterval(_approvalPollTimer);_approvalPollTimer=null;}}
// 전체 기기 오류 모아보기 (관리자 전용) — errLogs 컬렉션에서 최근순
// 전체 기기 오류 기록 삭제(관리자) — 최근 분량 일괄 삭제
function _clearAllErrLogs(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  if(!_fdb){toast('서버 미연결');return;}
  if(!confirm('전체 기기의 오류 기록을 모두 삭제할까요?'))return;
  const el=document.getElementById('allErrLogs');if(el)el.innerHTML='<div style="font-size:11px;color:#6b7684;">삭제 중…</div>';
  _fdb.collection('errLogs').limit(400).get().then(function(snap){
    let n=0;const ps=[];snap.docs.forEach(function(d){n++;ps.push(d.ref.delete().catch(function(){}));});
    Promise.all(ps).then(function(){
      if(el)el.innerHTML='<div style="font-size:11px;color:rgba(255,255,255,.25);">기록 없음 ✅</div>';
      toast('🗑️ 오류 기록 '+n+'건 삭제됨'+(n>=400?' (많아서 더 있으면 한 번 더 눌러주세요)':''));
    });
  }).catch(function(){toast('삭제 실패');if(el)el.innerHTML='';});
}
function _loadAllErrLogs(){
  const el=document.getElementById('allErrLogs');
  if(!_fdb){if(el)el.innerHTML='<div style="font-size:11px;color:#e05050;">서버 미연결</div>';return;}
  if(el)el.innerHTML='<div style="font-size:11px;color:#6b7684;">불러오는 중…</div>';
  _fdb.collection('errLogs').orderBy('at','desc').limit(80).get().then(function(snap){
    if(!el)return;
    const rows=snap.docs.map(d=>d.data());
    if(!rows.length){el.innerHTML='<div style="font-size:11px;color:rgba(255,255,255,.25);">기록 없음 ✅</div>';return;}
    el.innerHTML=rows.map(function(r){
      const t=r.at?new Date(r.at).toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}):'';
      const who=(r.by||'미상')+(r.dept?'·'+r.dept:'');
      const plat=r.plat==='APP'?'📱앱':'🌐웹';
      return '<div style="font-size:10px;font-family:monospace;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04);">'
        +'<span style="color:#aab4c0;">'+plat+'</span> <span style="color:#a5abb3;">'+_esc(who)+'</span> <span style="color:#6b7684;">'+t+'</span><br>'
        +'<span style="color:#b8856a;">'+_esc(r.m||'')+'</span></div>';
    }).join('');
    // 7일 지난 오래된 기록 정리(한 번에 소량)
    try{_fdb.collection('errLogs').where('at','<',Date.now()-7*86400000).limit(40).get().then(function(s){s.docs.forEach(function(d){d.ref.delete().catch(function(){});});}).catch(function(){});}catch(e){}
  }).catch(function(){if(el)el.innerHTML='<div style="font-size:11px;color:#e05050;">불러오기 실패(색인 생성 중일 수 있음 — 잠시 후 재시도)</div>';});
}
// 푸시 보낸 내역 비우기
function _clearPushLog(){if(!confirm('푸시 보낸 내역을 모두 지울까요?'))return;DB.s('pushLog',[]);try{renderAdmSys();}catch(e){}toast('🗑 보낸 내역 삭제됨');}
// 개인 지정 시 위 소속·전체 선택 해제(개인 발송이 우선함을 시각적으로 명확히)
function _pushPersonChanged(sel){if(sel&&sel.value){const a=document.getElementById('pushAll');if(a)a.checked=false;document.querySelectorAll('.pushDept:checked').forEach(c=>{c.checked=false;});}}
// ── 개인정보 접근 기록 조회/정리 (관리자) — accessLog 컬렉션 최근순 ──
function _loadAccessLog(){
  const el=document.getElementById('accessLogWrap');
  if(!_fdb){if(el)el.innerHTML='<div style="font-size:11px;color:#e05050;">서버 미연결</div>';return;}
  if(el)el.innerHTML='<div style="font-size:11px;color:#6b7684;">불러오는 중…</div>';
  _fdb.collection('accessLog').orderBy('at','desc').limit(100).get().then(function(snap){
    if(!el)return;
    const rows=snap.docs.map(d=>d.data());
    if(!rows.length){el.innerHTML='<div style="font-size:11px;color:rgba(255,255,255,.25);">기록 없음</div>';return;}
    el.innerHTML=rows.map(function(r){
      const t=r.at?new Date(r.at).toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}):'';
      const who=(r.by||'미상')+(r.dept?'·'+r.dept:'');
      const plat=r.plat==='APP'?'📱':'🌐';
      const act=r.act||'열람';
      const actCol=act==='삭제'?'#e0857a':(act==='수정'?'#f0b95f':(act==='입력'?'#8bd4a0':'#7f93a8'));
      const ip=r.ip?' · '+_esc(r.ip):'';
      return '<div style="font-size:10.5px;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.04);">'
        +'<span style="color:#a5abb3;font-weight:700;">'+_esc(who)+'</span> <span style="color:#6b7684;">'+plat+' '+t+ip+'</span><br>'
        +'<span style="color:#7fb0e0;">'+_esc(r.what||'')+'</span> <span style="color:'+actCol+';font-weight:700;">['+_esc(act)+']</span>'+(r.detail?' <span style="color:#8b95a1;">· '+_esc(r.detail)+'</span>':'')+'</div>';
    }).join('');
  }).catch(function(){if(el)el.innerHTML='<div style="font-size:11px;color:#e05050;">조회 실패</div>';});
}
function _clearAccessLog(){
  if(!(typeof _isMasterAdmin==='function'&&_isMasterAdmin())){toast('⚠️ 마스터 관리자만 가능');return;}
  if(!_fdb){toast('서버 미연결');return;}
  if(!confirm('개인정보 접근 기록을 삭제할까요?\n※ 감사 증적이므로 법정 보관기간을 먼저 확인하세요.'))return;
  const el=document.getElementById('accessLogWrap');if(el)el.innerHTML='<div style="font-size:11px;color:#6b7684;">삭제 중…</div>';
  _fdb.collection('accessLog').limit(400).get().then(function(snap){
    let n=0;const ps=[];snap.docs.forEach(function(d){n++;ps.push(d.ref.delete().catch(function(){}));});
    Promise.all(ps).then(function(){if(el)el.innerHTML='<div style="font-size:11px;color:rgba(255,255,255,.25);">기록 없음</div>';toast('🗑️ 접근 기록 '+n+'건 삭제됨'+(n>=400?' (더 있으면 한 번 더)':''));});
  }).catch(function(){toast('삭제 실패');if(el)el.innerHTML='';});
}
// 🔕 검증 모드 토글 — 켜면 60분간 이 기기 발신 알림의 공유 브로드캐스트·OS푸시 차단 (app.core.js _testSilentOn 참조)
function _toggleTestSilent(){
  const on=(typeof _testSilentOn==='function')&&_testSilentOn();
  if(on){DB.s('testSilentUntil',0);toast('🔔 검증 모드 해제 — 알림이 정상 발송됩니다');}
  else{DB.s('testSilentUntil',Date.now()+60*60000);toast('🔕 검증 모드 켜짐 — 60분간 이 기기의 작업 알림이 직원들에게 발송되지 않습니다',4000);}
  try{renderAdmSys();}catch(e){}
}
function renderAdmSys(){
  // pushLog는 온디맨드 문서 — 화면 열 때 1회 갱신(60초 내 재렌더는 캐시 재사용)
  if(typeof _refreshDoc==='function'&&(!window._pushLogFreshAt||Date.now()-window._pushLogFreshAt>60000)){
    window._pushLogFreshAt=Date.now();
    _refreshDoc('pushLog').then(()=>{try{if(document.getElementById('admSysWrap'))renderAdmSys();}catch(e){}});
  }
  const unseenCnt=_getUnseenCount();
  document.getElementById('admSysWrap').innerHTML=`
    <div class="scard" style="margin-bottom:8px;background:rgba(26,74,110,.15);border:1px solid rgba(49,130,246,.35);">
      <button onclick="var c=document.getElementById('pushComposeCard');if(c)c.scrollIntoView({behavior:'smooth',block:'start'});" style="width:100%;background:#1a4a6e;color:#fff;border:none;padding:13px;border-radius:9px;font-size:13.5px;font-weight:800;cursor:pointer;">📲 직원에게 알림 보내기 →</button>
      <div style="font-size:10.5px;color:#6b7684;margin-top:6px;text-align:center;">전체·소속·개인 지정 발송 · 꺼진 폰까지 도달</div>
    </div>
    ${(()=>{try{ // 🔕 검증 모드 — 이 기기의 작업 알림을 직원들에게 안 보냄 (기기 로컬, 60분 자동 해제)
      const on=(typeof _testSilentOn==='function')&&_testSilentOn();
      const until=+DB.g('testSilentUntil')||0;
      const remain=on?Math.max(1,Math.ceil((until-Date.now())/60000)):0;
      return `<div class="scard" style="margin-bottom:8px;${on?'background:rgba(255,170,0,.10);border:1px solid rgba(255,170,0,.45);':''}">
        <div class="stitle">🔕 검증 모드 (알림 무음) ${on?`<span style="font-size:10px;color:#ffb020;font-weight:800;">켜짐 · ${remain}분 남음</span>`:''}</div>
        <div style="font-size:11px;color:#8a94a3;line-height:1.5;margin:4px 0 8px;">기능 점검·테스트할 때 켜세요. <b>이 기기에서 하는 작업의 알림·OS푸시가 다른 직원들에게 발송되지 않습니다</b> (내 기기 벨 표시는 유지). 60분 뒤 자동으로 꺼집니다.</div>
        <button onclick="_toggleTestSilent()" style="width:100%;padding:11px;border-radius:9px;border:none;font-size:13px;font-weight:800;cursor:pointer;${on?'background:#ffb020;color:#1a1a1e;':'background:rgba(255,170,0,.14);color:#ffb020;border:1px solid rgba(255,170,0,.4);'}">${on?'🔔 검증 모드 끄기 (알림 정상화)':'🔕 검증 모드 켜기'}</button>
      </div>`;
    }catch(e){return '';}})()}
    ${(()=>{try{ // 🗑 시설물 휴지통 — 삭제된 시설 복구(시설과·담당자), 영구삭제(개발자)
      const tr=DB.g('facTrash')||[];
      if(!tr.length)return '';
      const canPurge=(typeof _isMasterAdmin==='function'&&_isMasterAdmin());
      return `<div class="scard" style="margin-bottom:8px;">
        <div class="stitle">🗑 시설물 휴지통 <span style="font-size:9px;font-weight:400;color:#6b7684;">삭제된 시설 — ♻️로 복구 (최근 100건 보관)</span></div>
        ${tr.map(t=>{const r=t.rec||{};const d=new Date(t.at);const ds=(d.getMonth()+1)+'/'+d.getDate();
          return `<div style="display:flex;align-items:center;gap:7px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);font-size:11.5px;color:#d5d8dc;">
            <span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${_esc((r.type||'').split(' ')[0])} ${_esc(r.name||'-')} <span style="color:#6b7684;font-size:10px;">${ds} · ${_esc(t.by||'')}</span></span>
            <button onclick="restoreFac(${t.at})" style="background:rgba(94,207,143,.12);color:#5fcf8f;border:1px solid rgba(94,207,143,.3);border-radius:7px;padding:4px 10px;font-size:11px;font-weight:700;cursor:pointer;flex-shrink:0;">♻️ 복구</button>
            ${canPurge?`<button onclick="purgeFacTrash(${t.at})" style="background:none;color:#ff8a80;border:1px solid rgba(255,107,91,.3);border-radius:7px;padding:4px 8px;font-size:11px;cursor:pointer;flex-shrink:0;" title="영구 삭제">✕</button>`:''}
          </div>`;}).join('')}
      </div>`;
    }catch(e){return '';}})()}
    ${(()=>{try{
      if(typeof HOME_MENUS==='undefined')return'';
      const hid=_homeHiddenSet();
      return `<div class="scard" style="margin-bottom:8px;">
        <div class="stitle">🏠 홈 화면 메뉴 표시</div>
        <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">완성 전인(미완성) 메뉴를 <b style="color:#d5d8dc;">전 직원 홈 화면</b>에서 숨깁니다. 숨겨도 데이터는 보존되며, 다시 표시하면 그대로 나타납니다. <span style="color:#6b7684;">(‘내 설정’·‘관리자 전용’은 잠금 방지를 위해 항상 표시)</span></div>
        ${HOME_MENUS.map(m=>{const h=hid.has(m.k);return `<div style="display:flex;align-items:center;gap:8px;padding:8px 2px;border-bottom:1px solid rgba(255,255,255,.04);">
          <span style="flex:1;font-size:12.5px;color:${h?'#6a8296':'#eaecef'};">${m.label}${h?' <span style="font-size:10px;color:#e0857a;font-weight:800;">· 숨김</span>':''}</span>
          <button onclick="_setHomeMenuHidden('${m.k}',${h?'false':'true'})" style="background:${h?'rgba(94,207,143,.12)':'rgba(192,57,43,.1)'};color:${h?'#5fcf8f':'#e0857a'};border:1px solid ${h?'rgba(94,207,143,.35)':'rgba(192,57,43,.3)'};border-radius:8px;padding:6px 13px;font-size:11.5px;font-weight:800;cursor:pointer;white-space:nowrap;">${h?'👁️ 표시하기':'🙈 숨기기'}</button>
        </div>`;}).join('')}
      </div>`;
    }catch(e){return'';}})()}
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">💾 데이터 백업 / 복원</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">전체 데이터를 파일로 내려받아 보관하세요 (사진 원본은 서버에 별도 저장)</div>
      <div style="display:flex;gap:6px;">
        <button onclick="exportAllData()" style="flex:1;background:rgba(39,174,96,.1);color:#27ae60;border:1px solid rgba(39,174,96,.3);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">⬇️ 전체 백업</button>
        <button onclick="document.getElementById('restoreFileInp').click()" style="flex:1;background:rgba(230,126,34,.08);color:#e67e22;border:1px solid rgba(230,126,34,.28);padding:9px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">⬆️ 복원</button>
        <input type="file" id="restoreFileInp" accept=".json" style="display:none;" onchange="importAllData(this)">
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;display:none;">
      <div class="stitle">🔄 앱 업데이트</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">현재 버전 <b style="color:#d5d8dc;">${OTA_VER}</b> · 앱(APK)은 재설치 없이 최신 코드로 자체 업데이트됩니다. (웹은 새로고침 시 자동)</div>
      <button onclick="_otaCheck(true)" style="width:100%;padding:11px;border-radius:8px;border:1px solid rgba(255,255,255,.4);background:rgba(255,255,255,.12);color:#3182f6;font-size:13px;font-weight:700;cursor:pointer;">🔄 업데이트 확인 / 적용</button>
    </div>
    <div class="scard sel-ok" style="margin-bottom:8px;">
      <div class="stitle">🐞 오류 기록 <button onclick="localStorage.removeItem('_errLog');renderAdmSys();" style="float:right;background:none;border:none;color:rgba(255,255,255,.3);font-size:10px;cursor:pointer;">내 기록 비우기</button></div>
      <div style="font-size:10px;color:#6b7684;font-weight:700;margin:4px 0 3px;">📱 내 기기</div>
      ${(()=>{try{const log=JSON.parse(localStorage.getItem('_errLog')||'[]');return log.length?log.slice(0,8).map(e=>`<div style="font-size:10px;color:#b8856a;font-family:monospace;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04);">${e.t} ${_esc(e.m)}</div>`).join(''):'<div style="font-size:11px;color:rgba(255,255,255,.25);">기록된 오류 없음 ✅</div>';}catch(e){return'';}})()}
      <div style="display:flex;justify-content:space-between;align-items:center;margin:9px 0 3px;">
        <span style="font-size:10px;color:#6b7684;font-weight:700;">🌐 전체 기기 (누가·웹/앱)</span>
        <span style="display:flex;gap:5px;">
          <button onclick="_loadAllErrLogs()" style="background:rgba(255,255,255,.12);color:#3182f6;border:1px solid rgba(255,255,255,.28);border-radius:14px;padding:3px 10px;font-size:10px;font-weight:700;cursor:pointer;">불러오기 ↻</button>
          <button onclick="_clearAllErrLogs()" style="background:rgba(192,57,43,.1);color:#e0857a;border:1px solid rgba(192,57,43,.28);border-radius:14px;padding:3px 10px;font-size:10px;font-weight:700;cursor:pointer;">전체 비우기</button>
        </span>
      </div>
      <div id="allErrLogs" style="max-height:220px;overflow-y:auto;"><div style="font-size:11px;color:rgba(255,255,255,.25);">‘불러오기’를 누르면 모든 기기의 오류를 모아 봅니다(관리자 전용)</div></div>
    </div>
    <div class="scard sel-ok" style="margin-bottom:8px;">
      <div class="stitle">🔎 개인정보 접근 기록 <span style="font-size:9px;font-weight:400;color:#6b7684;">누가·언제·무엇을 열람</span></div>
      <div style="font-size:10.5px;color:#8b95a1;margin-bottom:7px;line-height:1.6;">암벽 이용자 명단·조난자 정보·직원 개인정보 열람 이력입니다. <span style="color:#6b7684;">(개인정보보호법 접근기록 보관용)</span></div>
      <div style="display:flex;justify-content:flex-end;gap:5px;margin-bottom:6px;">
        <button onclick="_loadAccessLog()" style="background:rgba(255,255,255,.12);color:#3182f6;border:1px solid rgba(255,255,255,.28);border-radius:14px;padding:3px 10px;font-size:10px;font-weight:700;cursor:pointer;">불러오기 ↻</button>
        <button onclick="_clearAccessLog()" style="background:rgba(192,57,43,.1);color:#e0857a;border:1px solid rgba(192,57,43,.28);border-radius:14px;padding:3px 10px;font-size:10px;font-weight:700;cursor:pointer;">삭제</button>
      </div>
      <div id="accessLogWrap" style="max-height:240px;overflow-y:auto;"><div style="font-size:11px;color:rgba(255,255,255,.25);">‘불러오기’를 누르면 개인정보 열람 이력을 모아 봅니다(관리자 전용)</div></div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">🔔 알림 받는 대상 안내</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:10px;">기본적으로 <b style="color:#5dbf8a;">모든 직원</b>이 받습니다. 아래 일부만 <b style="color:#aab4c0;">관리자 전용</b>입니다. (각자 [내 설정 → 알림]에서 자기 알림을 끄고 켤 수 있어요)</div>
      <div style="background:rgba(39,174,96,.06);border:1px solid rgba(39,174,96,.25);border-radius:9px;padding:10px 11px;margin-bottom:8px;">
        <div style="font-size:12px;font-weight:800;color:#5dbf8a;margin-bottom:5px;">👥 모두에게</div>
        <div style="font-size:11px;color:#c4c8ce;line-height:1.85;">안전사고·낙석·위험수목·화재 등 현장 위험상황 · 응소 요청 · 진행중 경과/상황 종료 · 위험 시설물 · 기상특보·재난위기경보·탐방로 통제·기상 브리핑</div>
      </div>
      <div style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.25);border-radius:9px;padding:10px 11px;">
        <div style="font-size:12px;font-weight:800;color:#aab4c0;margin-bottom:5px;">🔑 관리자에게만</div>
        <div style="font-size:11px;color:#c4c8ce;line-height:1.85;">새 직원 가입 승인 요청 · 관리자 권한 요청 · 정보 정정 요청</div>
      </div>
    </div>
    <div class="scard" id="pushComposeCard" style="margin-bottom:8px;">
      <div class="stitle">📲 푸시 알림 (꺼진 폰까지)</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:8px;">구조 1보·위험상황 발생 시 자동 발송됩니다. 아래에서 <b style="color:#5dbf8a;">받는 대상을 골라</b> 직접 작성해 푸시할 수 있습니다.</div>
      <div class="fg"><span class="fl">받는 대상 <span style="color:#6b7684;font-weight:400;">(소속 선택 · 복수 가능, 비우면 전체)</span></span>
        ${(()=>{
          const depts=new Set();
          [].concat(DB.g('loginLog')||[],DB.g('pendingUsers')||[]).forEach(e=>{if(e&&e.dept)depts.add(e.dept);});
          const lbl='display:inline-flex;align-items:center;gap:5px;background:#1c1c1e;border:1px solid rgba(255,255,255,.25);border-radius:18px;padding:7px 12px;font-size:12px;color:#d5d8dc;cursor:pointer;';
          const chips=[...depts].sort().map(d=>`<label style="${lbl}"><input type="checkbox" class="pushDept" value="${_esc(d)}" onchange="_pushDeptChanged()" style="width:15px;height:15px;">${_esc(d)}</label>`).join('');
          return `<div id="pushTargetChips" style="display:flex;flex-wrap:wrap;gap:7px;">
            <label style="${lbl}background:rgba(255,255,255,.12);"><input type="checkbox" id="pushAll" checked onchange="_pushToggleAll(this)" style="width:15px;height:15px;">📢 전체</label>
            ${chips}
          </div>`;
        })()}
      </div>
      <div class="fg"><span class="fl">특정 개인에게만 <span style="color:#6b7684;font-weight:400;">(선택하면 위 소속·전체는 무시)</span></span>
        ${(()=>{
          const seen={};const ppl=[];
          [].concat(DB.g('members')||[],DB.g('loginLog')||[]).forEach(e=>{if(!e||!e.name)return;const nm=String(e.name).trim();if(!nm)return;const kk=String(e.kakaoId||'');const key=kk||nm;if(seen[key])return;seen[key]=1;ppl.push({nm,kk,dept:e.dept||''});});
          ppl.sort((a,b)=>a.nm.localeCompare(b.nm,'ko'));
          return `<select id="pushPerson" class="fi" onchange="_pushPersonChanged(this)" style="font-size:13px;">
            <option value="">— 개인 지정 안 함 —</option>
            ${ppl.map(p=>`<option value="${_esc(p.nm)}" data-kakao="${_esc(p.kk)}">${_esc(p.nm)}${p.dept?' · '+_esc(p.dept):''}</option>`).join('')}
          </select>`;
        })()}
      </div>
      <div class="fg"><span class="fl">제목</span>
        <input id="pushTitleInp" class="fi" type="text" value="설악산 현장관리" maxlength="40" style="font-size:13px;">
      </div>
      <div class="fg"><span class="fl">내용</span>
        <textarea id="pushBodyInp" class="fi" rows="2" placeholder="보낼 메시지를 입력하세요" maxlength="200" style="font-size:13px;resize:vertical;"></textarea>
      </div>
      <div style="display:flex;gap:6px;margin-top:4px;">
        <button onclick="sendCustomPush()" style="flex:2;background:#1a4a6e;color:#fff;border:none;padding:10px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">📨 발송</button>
        <button onclick="renderAdmSys()" style="background:rgba(255,255,255,.05);color:#8b95a1;border:1px solid rgba(255,255,255,.1);padding:10px 12px;border-radius:8px;font-size:12px;cursor:pointer;">↻ 새로고침</button>
      </div>
      ${(()=>{const log=DB.g('pushLog')||[];if(!log.length)return '';
        return `<div style="margin-top:11px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;"><span style="font-size:10px;color:#6b7684;font-weight:700;">🕘 보낸 내역</span><button onclick="_clearPushLog()" style="background:rgba(192,57,43,.1);color:#e0857a;border:1px solid rgba(192,57,43,.28);border-radius:12px;padding:2px 10px;font-size:9.5px;font-weight:700;cursor:pointer;">🗑 지우기</button></div>`
          +log.slice(0,8).map(p=>`<div style="font-size:10px;color:#a5abb3;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.04);"><span style="color:#aab4c0;font-weight:700;">${_esc(p.target||'전체')}</span> · ${_esc(p.body||'')}<br><span style="color:#6b7684;font-size:9px;">${p.by?_esc(p.by)+' · ':''}${p.at?new Date(p.at).toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}):''}${p.sent!=null?' · '+p.sent+'대 발송':''}</span></div>`).join('')
          +`</div>`;
      })()}
      <div id="fcmStatus" style="font-size:10px;color:#454e5a;margin-top:8px;line-height:1.7;">등록된 기기 확인 중…</div>
    </div>
    <div class="scard" style="margin-bottom:8px;"><div class="stitle">📊 데이터 현황</div>
      <div style="font-size:12px;color:#c4c8ce;line-height:2.1;">시설물 <b>${(DB.g('facilities')||[]).length}개</b> · 경고표시 <b>${(DB.g('facilities')||[]).filter(f=>_facWarn(f)).length}건</b><br>구조이력 <b>${(DB.g('rescues')||[]).length}건</b> · 위험상황 <b>${(DB.g('hazards')||[]).length}건</b> · 대원 <b>${(DB.g('members')||[]).length}명</b></div>
      <div style="margin-top:8px;display:flex;align-items:center;gap:6px;font-size:11px;">
        <span style="width:8px;height:8px;border-radius:50%;background:${_fdb?'#27ae60':'#e05050'};display:inline-block;flex-shrink:0;"></span>
        <span style="color:${_fdb?'#5dbf8a':'#e05050'};font-weight:700;">Firebase ${_fdb?'연결됨':'미연결'}</span>
        ${_fdb?'<span style="color:#565f6b;">· 모든 데이터 실시간 동기화 중</span>':'<span style="color:#7a3020;">· 오프라인 상태입니다</span>'}
      </div>
    </div>
    <div class="scard" style="margin-bottom:8px;">
      <div class="stitle">📁 데이터 백업 / 복원</div>
      <div style="font-size:11px;color:#8b95a1;margin-bottom:10px;">시설물·구조이력·위키 전체를 JSON 파일로 내보내거나 복원합니다</div>
      <div style="display:flex;flex-direction:column;gap:7px;">
        <button onclick="exportAllData()" style="width:100%;background:rgba(39,174,96,.12);color:#5dbf8a;border:1px solid rgba(39,174,96,.3);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">📤 JSON 내보내기 (백업)</button>
        <label style="width:100%;background:rgba(255,255,255,.1);color:#3182f6;border:1px solid rgba(255,255,255,.28);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;text-align:center;display:block;">
          📥 JSON 가져오기 (복원)
          <input type="file" accept=".json" style="display:none;" onchange="importAllData(this)">
        </label>
        <button onclick="forceSyncFirestore()" style="width:100%;background:rgba(255,165,0,.1);color:#f0a020;border:1px solid rgba(255,165,0,.28);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">🔄 Firebase 강제 동기화</button>
      </div>
    </div>
    <div class="scard"><div class="stitle" style="color:#c0392b;">⚠️ 위험 작업</div>
      <div style="display:flex;flex-direction:column;gap:7px;">
        ${_isMasterAdmin()
          ?`<button onclick="resetAll()" style="width:100%;background:rgba(192,57,43,.1);color:#c0392b;border:1px solid rgba(192,57,43,.28);padding:10px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;">전체 데이터 초기화 (개발자)</button>`
            +(()=>{const b=_resetBackupInfo();return b?`<button onclick="restoreReset()" style="width:100%;background:rgba(39,174,96,.12);color:#5dbf8a;border:1px solid rgba(39,174,96,.35);padding:10px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;">↩ 초기화 복구 (${b})</button>`:'';})()
          :`<div style="font-size:11px;color:#9c8060;padding:9px 10px;border:1px dashed rgba(192,57,43,.25);border-radius:8px;line-height:1.6;">🔒 전체 데이터 초기화는 <b style="color:#d5d8dc;">개발자</b>만 할 수 있습니다.</div>`}
        <button onclick="clearNotisOnly()" style="width:100%;background:rgba(255,255,255,.05);color:#c4c8ce;border:none;padding:10px;border-radius:8px;font-size:12px;cursor:pointer;">알림 이력만 삭제</button>
      </div>
    </div>`;
  setTimeout(_refreshFcmStatus,100);
}
// 관리자: 대상별 기본 알림 정책 설정(공유)
function setNotiPolicy(grp,lv){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const p=DB.g('notiPolicy')||{};p[grp]=lv;DB.s('notiPolicy',p);
  try{_updateFcmTokenSettings();}catch(e){}
  try{renderAdmSys();}catch(e){}
  toast('📢 '+grp+' 기본 알림 = '+({all:'전체',recommended:'추천',min:'최소'}[lv]||lv));
}
// 푸시 받는 대상(소속 체크박스) 토글
function _pushToggleAll(el){if(el&&el.checked){document.querySelectorAll('.pushDept').forEach(c=>{c.checked=false;});}else if(el&&![...document.querySelectorAll('.pushDept')].some(c=>c.checked)){el.checked=true;}}
function _pushDeptChanged(){const any=[...document.querySelectorAll('.pushDept')].some(c=>c.checked);const all=document.getElementById('pushAll');if(all)all.checked=!any;}
// 카카오ID 기준 직원 삭제 — 가입신청(pendingUsers) 없이 로그인 이력만 있는 사람도 삭제 가능
function removeStaff(kakaoId){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  kakaoId=String(kakaoId||'');if(!kakaoId)return;
  if(_isDeveloper(kakaoId)){toast('⚠️ 개발자는 삭제할 수 없습니다');return;}
  const pu=(DB.g('pendingUsers')||[]).find(p=>String(p.kakaoId||p.id)===kakaoId);
  const ll=(DB.g('loginLog')||[]).find(e=>String(e.kakaoId)===kakaoId);
  const nm=(pu&&(pu.realName||pu.name))||(ll&&ll.name)||'이 사용자';
  if(!confirm(nm+'을(를) 탈퇴 처리하시겠습니까?\n· 즉시 로그아웃되고 멤버에서 빠집니다\n· 작성한 데이터는 유지됩니다\n· 다시 로그인하면 신규 승인 대기로 재신청할 수 있습니다(영구 차단 아님)'))return;
  try{_logAccess&&_logAccess('직원 개인정보',nm+' 탈퇴 처리','삭제');}catch(e){}
  // 탈퇴 대상에게 OS 푸시 통보 — 앱이 꺼져 있어도 수신(안드로이드 APK). 데이터 변경 전에 토큰 조회.
  try{if(typeof _sendFcmPushToKakao==='function')_sendFcmPushToKakao(kakaoId,'설악산 현장관리','⚠️ 관리자에 의해 탈퇴 처리되었습니다.');}catch(e){}
  const del=DB.g('deletedKakaoIds')||[];if(!del.includes(kakaoId)){del.push(kakaoId);DB.s('deletedKakaoIds',del);}
  DB.s('pendingUsers',(DB.g('pendingUsers')||[]).filter(p=>String(p.kakaoId||p.id)!==kakaoId));
  DB.s('loginLog',(DB.g('loginLog')||[]).filter(e=>String(e.kakaoId)!==kakaoId));
  const acl=_getAcl();acl.members=acl.members.filter(x=>x!==kakaoId);acl.admins=acl.admins.filter(x=>x!==kakaoId);DB.s('_acl',acl);
  renderAdmMembers();try{renderAdmSys();}catch(e){}
  toast('✅ 탈퇴 처리 완료');
}
function deleteUser(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const list=DB.g('pendingUsers')||[];
  const u=list.find(function(p){return p.id===id;});
  if(!u)return;
  if(u.kakaoId&&_isDeveloper(u.kakaoId)){toast('⚠️ 개발자는 삭제할 수 없습니다');return;}
  if(!confirm((u.realName||u.name||'이 사용자')+'을(를) 삭제하시겠습니까?\n(작성한 데이터는 유지됩니다)'))return;
  if(u.kakaoId){
    const deleted=DB.g('deletedKakaoIds')||[];
    if(!deleted.includes(String(u.kakaoId)))deleted.push(String(u.kakaoId));
    DB.s('deletedKakaoIds',deleted);
  }
  DB.s('pendingUsers',list.filter(function(p){return p.id!==id;}));
  renderAdmSys();
  try{renderAdmMembers();}catch(e){}
  toast('🗑️ 삭제 완료');
}
function approveUser(id){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const list=DB.g('pendingUsers')||[];
  const idx=list.findIndex(function(p){return p.id===id;});
  if(idx===-1)return;
  list[idx].approvalStatus='approved';
  list[idx].seen=true;
  DB.s('pendingUsers',list);
  // 승인 = 실제 멤버십 부여(_acl). 이전엔 상태만 바꿔 앱 접근이 안 열리던 문제 해결.
  const kid=String(list[idx].kakaoId||'');
  if(kid){const acl=_getAcl();if(acl.admins.indexOf(kid)<0&&acl.members.indexOf(kid)<0){acl.members.push(kid);DB.s('_acl',acl);}}
  renderAdmMembers();
  try{renderAdmSys();}catch(e){}
  toast('✅ 승인 완료 — 앱 접근 허용됨');
}
// 승인 = 멤버십 부여(puId 유무와 무관하게 kakaoId 기준). 신규 섹션·자동승인에서 공용 사용.
function grantMember(kakaoId){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  kakaoId=String(kakaoId||'');if(!kakaoId)return;
  const acl=_getAcl();
  if(acl.admins.indexOf(kakaoId)<0&&acl.members.indexOf(kakaoId)<0){acl.members.push(kakaoId);DB.s('_acl',acl);}
  const list=(DB.g('pendingUsers')||[]).map(function(p){
    if(String(p.kakaoId||p.id)===kakaoId)return Object.assign({},p,{approvalStatus:'approved',seen:true});
    return p;
  });
  DB.s('pendingUsers',list);
  renderAdmMembers();try{renderAdmSys();}catch(e){}
  toast('✅ 승인 — 앱 접근 허용됨');
}
function _checkDeletedUser(){
  if(DB.g('authType')!=='kakao')return;
  var u=DB.g('currentUser')||{};
  if(!u.kakaoId)return;
  var deleted=DB.g('deletedKakaoIds')||[];
  if(!deleted.includes(String(u.kakaoId)))return;
  DB.s('authType','');
  DB.s('currentUser',{});
  if(window.showLoginScreen)window.showLoginScreen();
  updateUserUI();
  toast('⚠️ 관리자에 의해 탈퇴 처리되었습니다');
}
// 전체 초기화: 개발자만, 2단계 확인, 24시간 복구 백업 보관
const _RESET_BACKUP_KEYS=['members','catFac','catFacMeta','facilities','rescues','hazards','history','pendingUsers','approvedUsers','deletedKakaoIds','loginLog','_acl','extAgencies'];
function _resetBackupInfo(){
  try{const b=JSON.parse(localStorage.getItem('_resetBackup')||'null');if(!b||!b.at)return null;
    const dh=Date.now()-b.at;if(dh>24*3600000)return null;
    const h=Math.floor(dh/3600000),m=Math.floor((dh%3600000)/60000);
    return (h>0?h+'시간 ':'')+m+'분 전 · 24시간 내 복구가능';
  }catch(e){return null;}
}
function resetAll(){
  if(!_isMasterAdmin()){toast('⚠️ 전체 초기화는 개발자만 가능합니다');return;}
  if(!confirm('⚠️ 전체 데이터 초기화\n구조·위험·시설·점검·직원·기록이 모두 삭제됩니다.\n\n정말 하시겠습니까?'))return;
  if(!confirm('마지막 확인입니다.\n정말로 전체 데이터를 초기화할까요?\n(초기화 후 24시간 안에는 복구할 수 있습니다)'))return;
  // 복구용 백업(기기 로컬에 보관 — 복구 시 Firestore로 되돌림)
  try{const snap={};_RESET_BACKUP_KEYS.forEach(k=>{snap[k]=DB.g(k);});localStorage.setItem('_resetBackup',JSON.stringify({at:Date.now(),data:snap}));}catch(e){}
  ['members','catFac','facilities','rescues','hazards','history','notis','notiSetting','currentUser','sheetsUrl'].forEach(k=>DB.d(k));
  initDB();toast('✅ 초기화 완료 — 24시간 내 복구 가능',6000);renderAdmSys();updateSummary();
}
function restoreReset(){
  if(!_isMasterAdmin()){toast('⚠️ 개발자만 가능합니다');return;}
  let b;try{b=JSON.parse(localStorage.getItem('_resetBackup')||'null');}catch(e){}
  if(!b||!b.data){toast('복구할 백업이 없습니다');return;}
  if(Date.now()-b.at>24*3600000){toast('⚠️ 복구 가능 시간(24시간)이 지났습니다');localStorage.removeItem('_resetBackup');return;}
  if(!confirm('초기화 직전 상태로 되돌릴까요?\n현재 데이터는 백업 시점으로 덮어쓰여집니다.'))return;
  Object.keys(b.data).forEach(k=>{if(b.data[k]!=null)DB.s(k,b.data[k]);});
  localStorage.removeItem('_resetBackup');
  toast('↩ 복구 완료',5000);renderAdmSys();updateSummary();
  try{renderRescueMap();}catch(e){}try{renderResList();}catch(e){}
}
function clearNotisOnly(){DB.s('notis',[]);updateBell();toast('🗑️ 알림 이력 삭제');renderAdmSys();}

// (구버전 exportAllData/importAllData 중복 정의 제거 — 권한 데이터 누락·복원버튼 버그 유발.
//  더 완전한 상단 정의(_BACKUP_KEYS 기반, app 마커·검증·이중확인)로 일원화)

function forceSyncFirestore(){
  if(!_fdb){toast('⚠️ Firebase 미연결 — 인터넷 연결 확인');return;}
  const keys=['facilities','history','catFac','catFacMeta'];
  let cnt=0;
  keys.forEach(k=>{
    const v=_fs[k];
    if(v===undefined||v===null)return;
    if(_SHARED_COLL.includes(k)){
      v.forEach(r=>{if(r&&r.id!=null)_txMergeSet(k,String(r.id),r).catch(()=>{});}); // 건별 콜렉션은 _txMergeDoc(단일문서) 대상이 아님 — per-record 병합으로 분리
    }else{
      _txMergeDoc(k,_fsDocBase[k],v).catch(()=>{});
    }
    cnt++;
  });
  toast('🔄 Firebase에 '+cnt+'개 항목 동기화 중...');
  setTimeout(()=>toast('✅ 동기화 완료'),1500);
}

// 잘못 사찰로 분류된 암지형 다목적표지판 복구
// "암"으로 끝나는 이름이 다목적위치표지판인데 사찰로 잘못 변경된 것을 되돌림
// 다목적위치표지판 권위 좌표 (2024~2025 지형지물 엑셀 기준, 12-08 lat=lng 오류 보정)
const _SIGN_COORD_FIX={"01-01":[38.173718,128.480326],"01-02":[38.173346,128.47574],"01-03":[38.170381,128.473421],"01-04":[38.166325,128.471024],"01-05":[38.162865,128.466413],"01-06":[38.159572,128.469408],"01-07":[38.155681,128.470476],"01-08":[38.152346,128.469876],"01-09":[38.150047,128.472944],"01-10":[38.146238,128.473648],"01-11":[38.143603,128.474455],"01-12":[38.139774,128.47469],"01-13":[38.136418,128.473544],"01-14":[38.13374,128.469714],"01-15":[38.135076,128.46466],"01-16":[38.132853,128.464842],"01-17":[38.13034,128.461456],"01-18":[38.12721,128.458564],"01-19":[38.12373,128.457235],"01-20":[38.120766,128.462003],"02-01":[38.164229,128.463435],"02-02":[38.165649,128.462028],"02-03":[38.16608,128.457469],"02-04":[38.163876,128.452519],"02-05":[38.161342,128.447673],"02-06":[38.161155,128.44155],"02-07":[38.158086,128.437903],"02-08":[38.156006,128.43436],"02-09":[38.153822,128.431494],"02-10":[38.153225,128.430556],"02-11":[38.151083,128.427951],"02-12":[38.152069,128.420109],"02-13":[38.152974,128.416565],"02-14":[38.15252,128.411329],"03-01":[38.154916,128.438841],"03-02":[38.153187,128.441108],"03-03":[38.150306,128.443895],"03-04":[38.14833,128.450044],"03-05":[38.146088,128.453457],"03-06":[38.142938,128.454629],"03-07":[38.140757,128.45799],"03-08":[38.13874,128.461976],"03-09":[38.135323,128.463904],"04-01":[38.177708,128.483462],"04-02":[38.180858,128.479667],"04-03":[38.183441,128.476513],"04-04":[38.187867,128.475315],"04-05":[38.190873,128.473491],"05-01":[38.170065,128.495219],"05-02":[38.168687,128.500664],"05-03":[38.165785,128.501889],"05-04":[38.162964,128.502201],"06-01":[38.087797,128.448537],"06-02":[38.092245,128.450126],"06-03":[38.096467,128.451558],"06-04":[38.098362,128.454893],"06-05":[38.103345,128.456638],"06-06":[38.105879,128.459868],"06-07":[38.108556,128.459998],"06-08":[38.113456,128.460649],"06-09":[38.115969,128.46315],"07-01":[38.077336,128.442598],"07-02":[38.076182,128.439941],"07-03":[38.078343,128.437413],"07-04":[38.080587,128.43512],"07-05":[38.082892,128.432072],"07-06":[38.083242,128.430483],"08-01":[38.081944,128.427122],"08-02":[38.07937,128.42608],"08-03":[38.08044,128.423813],"08-04":[38.080789,128.419306],"08-05":[38.083671,128.417325],"08-06":[38.086039,128.416179],"08-07":[38.087871,128.417377],"08-08":[38.088614,128.421311],"09-01":[38.100203,128.409455],"09-02":[38.10358,128.41206],"09-03":[38.108377,128.410679],"09-04":[38.110374,128.410132],"09-05":[38.112063,128.410236],"09-06":[38.111282,128.416645],"09-07":[38.110274,128.421674],"09-08":[38.109432,128.427041],"09-09":[38.110071,128.43061],"09-10":[38.112214,128.437488],"09-11":[38.115139,128.441708],"09-12":[38.11617,128.448039],"09-13":[38.116624,128.451661],"09-14":[38.119302,128.45463],"10-01":[38.175507,128.372925],"10-02":[38.170978,128.372351],"10-03":[38.168363,128.371283],"10-04":[38.169578,128.375608],"10-05":[38.167891,128.37936],"10-06":[38.164905,128.376207],"10-07":[38.160108,128.374905],"10-08":[38.157452,128.375296],"10-09":[38.15628,128.380897],"10-10":[38.156816,128.386082],"10-11":[38.153276,128.389078],"10-12":[38.152989,128.394159],"10-13":[38.152579,128.399891],"10-14":[38.153527,128.405154],"10-15":[38.150234,128.408359],"10-16":[38.146899,128.411954],"10-17":[38.145418,128.415471],"10-18":[38.143215,128.415628],"10-19":[38.14128,128.415185],"10-20":[38.138748,128.416747],"10-21":[38.136607,128.419145],"10-22":[38.135785,128.423366],"10-23":[38.133644,128.425945],"10-24":[38.132595,128.430374],"10-25":[38.131196,128.433501],"10-26":[38.130203,128.437931],"10-27":[38.128132,128.444052],"10-28":[38.128647,128.44671],"10-29":[38.127557,128.450982],"11-01":[38.121889,128.344708],"11-02":[38.125471,128.343197],"11-03":[38.129012,128.34192],"11-04":[38.131772,128.344916],"11-05":[38.135334,128.346584],"11-06":[38.138627,128.342389],"11-07":[38.139779,128.338168],"11-08":[38.14262,128.338272],"11-09":[38.143772,128.334077],"11-10":[38.147519,128.332045],"11-11":[38.151637,128.332957],"11-12":[38.155404,128.331654],"11-13":[38.157977,128.327798],"11-14":[38.159973,128.323186],"11-15":[38.16166,128.321206],"11-16":[38.164666,128.318731],"11-17":[38.171418,128.314666],"11-18":[38.174361,128.312035],"11-19":[38.17541,128.307736],"11-20":[38.174627,128.305625],"11-21":[38.175862,128.303593],"11-22":[38.179465,128.301717],"12-01":[38.153952,128.375739],"12-02":[38.153951,128.372482],"12-03":[38.15045,128.368105],"12-05":[38.148019,128.359142],"12-06":[38.145115,128.355129],"12-07":[38.142191,128.352446],"12-08":[38.139514,128.349736],"12-09":[38.136837,128.347365],"12-10":[38.135458,128.350726],"12-11":[38.135027,128.356094],"12-12":[38.131322,128.357709],"12-13":[38.128851,128.359585],"12-14":[38.128235,128.364041],"12-15":[38.124532,128.377693],"12-16":[38.123467,128.382941],"12-17":[38.123319,128.387724],"12-18":[38.124021,128.393508],"12-19":[38.122416,128.397052],"12-20":[38.119884,128.398954],"12-21":[38.116487,128.401664],"12-22":[38.114141,128.406223],"13-01":[38.148634,128.43165],"13-02":[38.146721,128.435845],"13-03":[38.145281,128.439232],"13-04":[38.143017,128.444416],"13-05":[38.141041,128.445433],"13-06":[38.137665,128.445745],"13-07":[38.132538,128.446319]};
// 표지판 loc 코드 추출: f.loc 우선, 없으면 이름 앞 'NN-NN' 패턴
function _signLocCode(f){
  if(f.loc&&/^\d{2}-\d{2}$/.test(String(f.loc).trim()))return String(f.loc).trim();
  const m=String(f.name||'').match(/(\d{2}-\d{2})/);
  return m?m[1]:'';
}
// 라이브 시설물 좌표를 권위 좌표로 일괄 덮어쓰기 (지도에 즉시 반영)
function updateSignCoords(){
  if(!isAdminUser()){toast('⚠️ 관리자만 가능');return;}
  const facs=DB.g('facilities');if(!facs||!facs.length){toast('⚠️ 시설물 데이터 없음');return;}
  const changes=[];
  facs.forEach(f=>{
    if(!f.type||!f.type.includes('다목적위치표지판'))return;
    const code=_signLocCode(f);if(!code||!_SIGN_COORD_FIX[code])return;
    const [lat,lng]=_SIGN_COORD_FIX[code];
    if(Math.abs((+f.lat||0)-lat)>0.00001||Math.abs((+f.lng||0)-lng)>0.00001){
      changes.push({code,from:[+f.lat,+f.lng],to:[lat,lng]});
    }
  });
  if(!changes.length){toast('✅ 이미 모든 좌표가 최신입니다');return;}
  const preview=changes.slice(0,8).map(c=>c.code).join(', ')+(changes.length>8?` 외 ${changes.length-8}개`:'');
  if(!confirm(`표지판 ${changes.length}개의 좌표를 최신 데이터로 덮어씁니다.\n\n변경: ${preview}\n\n진행할까요? (모든 기기에 즉시 반영)`))return;
  const f2=facs.map(f=>{
    if(!f.type||!f.type.includes('다목적위치표지판'))return f;
    const code=_signLocCode(f);if(!code||!_SIGN_COORD_FIX[code])return f;
    const [lat,lng]=_SIGN_COORD_FIX[code];
    return Object.assign({},f,{lat,lng});
  });
  DB.s('facilities',f2);
  try{_invalidateSignCache&&_invalidateSignCache();}catch(e){}
  try{if(typeof renderFacList==='function')renderFacList();}catch(e){}
  toast('✅ '+changes.length+'개 표지판 좌표 최신화 완료');
}
// 부팅 시 1회 자동: 라이브 표지판 좌표를 권위 좌표(엑셀)로 최신화.
// 시설물이 Firestore에서 로드된 뒤 실행. 기기당 1회(버전 플래그), 변경분만 기록.
function _autoApplyCoordFix(){
  if(localStorage.getItem('_coordFixVer')==='2')return;
  let tries=0;
  (function poll(){
    const facs=DB.g('facilities')||[];
    const signs=facs.filter(f=>f.type&&f.type.includes('다목적위치표지판'));
    if(signs.length<10){ if(tries++<20){setTimeout(poll,1500);} return; } // 아직 로드 안 됨
    let changed=0;
    const f2=facs.map(f=>{
      if(!f.type||!f.type.includes('다목적위치표지판'))return f;
      const code=_signLocCode(f);if(!code||!_SIGN_COORD_FIX[code])return f;
      const [lat,lng]=_SIGN_COORD_FIX[code];
      if(Math.abs((+f.lat||0)-lat)>0.00001||Math.abs((+f.lng||0)-lng)>0.00001){changed++;return Object.assign({},f,{lat,lng});}
      return f;
    });
    if(changed>0){
      DB.s('facilities',f2);
      try{_invalidateSignCache&&_invalidateSignCache();}catch(e){}
      setTimeout(function(){try{toast('🪧 표지판 좌표 '+changed+'개 자동 최신화됨');}catch(e){}},900);
    }
    localStorage.setItem('_coordFixVer','2');
  })();
}
function fixMisclassifiedTemples(){
  const facs=DB.g('facilities');if(!facs){toast('⚠️ 시설물 데이터 없음');return;}
  // 실제 사찰/암자 이름 목록 (오색암 등 정확한 사찰만 포함)
  const REAL_TEMPLES=['봉정암','오세암','오색암','백담사','신흥사','계조암','내원암','안양암','극락암'];
  const SIGN_TYPE='🪧 다목적위치표지판';
  const TEMPLE_TYPE='🛕 사찰';
  let fixed=0;
  const f2=facs.map(f=>{
    if(f.type===TEMPLE_TYPE&&f.name){
      const isRealTemple=REAL_TEMPLES.some(t=>f.name.includes(t));
      if(!isRealTemple){
        fixed++;
        return Object.assign({},f,{type:SIGN_TYPE});
      }
    }
    return f;
  });
  if(fixed===0){toast('수정이 필요한 항목 없음');return;}
  DB.s('facilities',f2);
  toast('✅ '+fixed+'개 항목을 다목적위치표지판으로 복구');
}

