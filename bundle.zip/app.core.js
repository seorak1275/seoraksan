'use strict';
// ── 전역 오류 기록: 현장에서 "삐걱거림" 원인 추적용 (관리자 → 시스템 탭) ──
// 알려진 무해한 잡음(브라우저/파이어베이스 내부) — 로그에 안 남김
const _ERR_IGNORE=/in-progress transaction|IndexedDB|transaction (is|was|has been) (inactive|finished|aborted)|ResizeObserver loop|^Script error\.?\s*@?:?\s*$|cross-origin|Load failed$/i;
function _logErr(msg){
  const sm=String(msg);
  if(_ERR_IGNORE.test(sm))return; // 무해한 잡음 무시
  try{
    const log=JSON.parse(localStorage.getItem('_errLog')||'[]');
    log.unshift({t:new Date().toISOString().slice(5,16).replace('T',' '),m:sm.slice(0,180)});
    localStorage.setItem('_errLog',JSON.stringify(log.slice(0,30)));
  }catch(e){}
  try{_uploadErr(sm);}catch(e){} // 관리자가 모든 기기 오류를 모아볼 수 있도록 서버에도 기록(웹/앱·작성자 포함)
}
// 오류를 Firestore(errLogs)에 업로드 — 폭주 방지(같은 오류 세션당 1회 + 최소 3초 간격)
var _errUpLast=0,_errUpSeen={};
function _uploadErr(msg){
  try{
    var db=(typeof _fdb!=='undefined'&&_fdb)?_fdb:null;if(!db)return;
    var key=String(msg).slice(0,80);
    if(_errUpSeen[key])return;
    var nowMs=Date.now();if(nowMs-_errUpLast<3000)return;
    // 세션이 바뀌어도(새로고침) 같은 오류는 24시간 1건만 — 반복 오류 도배 방지
    try{
      var dd=JSON.parse(localStorage.getItem('_errUpDay')||'{}');
      if(dd[key]&&nowMs-dd[key]<86400000)return;
      dd[key]=nowMs;
      var trimmed={};Object.keys(dd).forEach(function(k){if(nowMs-dd[k]<86400000)trimmed[k]=dd[k];});
      localStorage.setItem('_errUpDay',JSON.stringify(trimmed));
    }catch(e){}
    _errUpSeen[key]=1;_errUpLast=nowMs;
    var u={};try{u=DB.g('currentUser')||{};}catch(e){}
    db.collection('errLogs').add({
      m:String(msg).slice(0,200),
      dev:(typeof _MY_DEVICE_ID!=='undefined'?_MY_DEVICE_ID:''),
      by:(u.realName||u.name||''),dept:(u.dept||''),
      plat:(typeof _isNativeApp==='function'&&_isNativeApp())?'APP':'WEB',
      at:nowMs
    }).catch(function(){});
  }catch(e){}
}
// ── 개인정보 접근 감사 로그 — 누가·언제·무엇을·어떤 행위(열람/수정/삭제/입력)로 접근했는지 기록(이벤트당 1문서).
//    개인정보보호법·공단 개인정보 침해대응 절차서: 접속기록에 접속ID·접속지 IP·접속일시·수행업무 포함, 6개월 이상 보관.
//    ※ IP는 클라이언트가 직접 못 얻으므로 외부 조회(best-effort). 서버측 정식 IP기록은 인프라 이전(공공전용 클라우드) 시 완성.
var _accSeen={},_accIP=null;
function _fetchAccessIP(){
  if(_accIP!==null)return; _accIP=''; // 세션당 1회만 시도(중복 요청 방지)
  try{fetch('https://api.ipify.org?format=json',{cache:'no-store'}).then(function(r){return r.json();}).then(function(j){if(j&&j.ip)_accIP=String(j.ip).slice(0,45);}).catch(function(){});}catch(e){}
}
function _logAccess(what,detail,act){
  try{
    var db=(typeof _fdb!=='undefined'&&_fdb)?_fdb:null;if(!db)return;
    _fetchAccessIP();
    var u={};try{u=DB.g('currentUser')||{};}catch(e){}
    var nowMs=Date.now(); var a=act||'열람';
    var key=String(u.kakaoId||'')+'|'+what+'|'+(detail||'')+'|'+a;
    if(a==='열람'){ // 열람만 5분 중복 제거 — 수정·삭제·입력 등 변경행위는 항상 기록(감사 무결성)
      if(_accSeen[key]&&nowMs-_accSeen[key]<5*60000)return;
      _accSeen[key]=nowMs;
    }
    db.collection('accessLog').add({
      what:String(what||'').slice(0,60),
      detail:String(detail||'').slice(0,120),
      act:a,
      by:(u.realName||u.name||''),dept:(u.dept||''),
      kakaoId:String(u.kakaoId||''),
      ip:_accIP||'',
      dev:(typeof _MY_DEVICE_ID!=='undefined'?_MY_DEVICE_ID:''),
      plat:(typeof _isNativeApp==='function'&&_isNativeApp())?'APP':'WEB',
      at:nowMs
    }).catch(function(){});
  }catch(e){}
}
// 카카오 프로필 사진 URL은 http:// 로 오는데, 앱이 https://localhost 출처라 혼합콘텐츠로 차단됨 → https로 승격
function _imgHttps(u){return String(u||'').replace(/^http:\/\//i,'https://');}
// 개발자(나) 카카오ID — 항상 관리자·삭제/역할변경 불가·전체초기화 권한. (재등록 불필요)
const _DEV_KAKAO_ID='4896979764';
window.addEventListener('error',e=>{_logErr((e.message||'오류')+' @'+(e.filename||'').split('/').pop()+':'+(e.lineno||''));});
window.addEventListener('unhandledrejection',e=>{_logErr('Promise: '+((e.reason&&e.reason.message)||e.reason||'거부'));});

// ── 앱 버전 (CI 빌드 시 릴리스 태그로 자동 스탬프됨) ──
const APP_VER='v0';
try{document.getElementById('appVerLabel').textContent='설악산 현장관리 '+APP_VER;}catch(e){}

// ── 새 버전 알림: 네이티브 앱에서만, GitHub 최신 릴리스 태그와 비교 ──
function _checkAppUpdate(){
  try{
    const Cap=window.Capacitor;
    if(!Cap||!Cap.isNativePlatform||!Cap.isNativePlatform())return;
    if(!/^v\d{8}-\d{4}$/.test(APP_VER))return; // CI 스탬프 안 된 개발 빌드는 스킵
    const last=parseInt(localStorage.getItem('_updCheckAt')||'0',10);
    if(Date.now()-last<6*3600*1000)return; // 6시간에 한 번만 확인
    fetch('https://api.github.com/repos/seorak1275/seoraksan/releases/latest')
      .then(r=>r.ok?r.json():null)
      .then(rel=>{
        // 확인이 실제로 성공했을 때만 6시간 창을 소모(오프라인/실패 시 다음 호출에서 재시도)
        localStorage.setItem('_updCheckAt',String(Date.now()));
        if(!rel||!rel.tag_name)return;
        if(!/^v\d{8}-\d{4}$/.test(rel.tag_name))return; // 형식이 다른 태그는 비교하지 않음(오탐 방지)
        if(rel.tag_name>APP_VER)_showUpdateBanner(rel);
      }).catch(()=>{});
  }catch(e){}
}
function _showUpdateBanner(rel){
  if(document.getElementById('updateBanner'))return;
  const asset=(rel.assets||[]).find(a=>/\.apk$/i.test(a.name));
  const url=(asset&&asset.browser_download_url)||rel.html_url;
  const div=document.createElement('div');
  div.id='updateBanner';
  div.style.cssText='position:fixed;left:10px;right:10px;bottom:14px;z-index:99999;background:#1d6fa5;color:#fff;padding:12px 14px;border-radius:12px;font-size:13px;display:flex;align-items:center;justify-content:space-between;gap:10px;box-shadow:0 4px 14px rgba(0,0,0,.3);';
  div.innerHTML='<span>🆕 새 버전('+rel.tag_name+')이 있습니다</span>';
  const btnWrap=document.createElement('div');
  btnWrap.style.cssText='display:flex;gap:8px;flex-shrink:0;';
  const dlBtn=document.createElement('a');
  dlBtn.textContent='업데이트';
  dlBtn.href=url;
  dlBtn.style.cssText='background:#fff;color:#1d6fa5;padding:6px 12px;border-radius:6px;font-weight:700;text-decoration:none;white-space:nowrap;';
  const closeBtn=document.createElement('button');
  closeBtn.type='button';
  closeBtn.textContent='닫기';
  closeBtn.style.cssText='background:transparent;color:#fff;border:1px solid rgba(255,255,255,.5);padding:6px 10px;border-radius:6px;white-space:nowrap;';
  closeBtn.onclick=function(){div.remove();};
  btnWrap.appendChild(dlBtn);btnWrap.appendChild(closeBtn);
  div.appendChild(btnWrap);
  document.body.appendChild(div);
}
setTimeout(_checkAppUpdate,4000);
// ══════════════════════════════════════════
// DB
// ══════════════════════════════════════════
// ── Firebase 설정 ──
const _FB_CFG={
  apiKey:"AIzaSyACBoT-h2h0aQXYJpPyznc3JBzprEhhUAw",
  authDomain:"seoraksan.firebaseapp.com",
  projectId:"seoraksan",
  storageBucket:"seoraksan.firebasestorage.app",
  messagingSenderId:"457414135264",
  appId:"1:457414135264:web:4103268ba0702a95a12f85"
};
// 기기 간 공유할 키 목록
// _SHARED_COLL: 항목마다 개별 Firestore 문서 (Race Condition 방지)
// facilities: 시설물 다수(표지판 169+)·점검사진 누적으로 단일문서 1MB 한계·동시편집 덮어쓰기 위험 → 건별 문서로 전환
// history: 점검이력은 무제한으로 계속 쌓이는 로그성 데이터라 단일문서 그대로 두면 매 점검마다 전체가 전원에게 재전송됨 → 건별 문서로 전환
const _SHARED_COLL=['rescues','hazards','facilities','history','facIssues'];
// _SHARED_DOC: 단일 문서에 JSON 배열 저장 (관리자 전용, 동시 쓰기 없음)
const _SHARED_DOC=['alertOps','alertLog','catFac','catFacMeta','pendingUsers','approvedUsers','deletedKakaoIds','adminOwnerKakaoId','adminApprovalCode','extAgencies','extAgencyCode','extAgencyDisplayName','geminiApiKey','kmaProxyUrl','walkProxyUrl','_acl','loginLog','trailStatus','crisisLevel','weatherBrief','weatherLog','trailLog','sosBlocked','autoApprove','pushLog','devKakaoId','notiPolicy','customResTypes','facManagers','climbDates','climbCancels','homeHidden','climbAccidents','otaInfo','climbAgg','facTrash','fcmVapidKey','zoneEdits','zoneGeom'];
// otaInfo: ota.json의 Firestore 미러 {version,url,notes,at} — 웹 방문자가 자동 갱신. github 계열이 막힌 망의 APK가 업데이트 정보를 받는 최후 폴백 통로
// homeHidden: 관리자가 홈 화면에서 숨긴 메뉴 키 목록(미완성 기능 감추기용) — 전 직원 동기화 적용
// climbAccidents: 수동 등록한 암벽 사고자 [{id,date,name,note,by,at}] — 엑셀 상태값은 다운로드 시점따라 달라 신뢰 불가라 사고는 직접 등록
// climbAgg: 날짜별 인원 집계 {날짜:{t:팀수,p:인원}} (개인정보 없음) — 전체통계 등에서 명단 원본 없이 이용인원 표시용
// climbDates: 암벽 이용현황 업로드된 '이용일자' 목록(날짜만·개인정보 아님) — 홈 업로드알림용. 실제 명단(PII)은 climbUsage 컬렉션에 별도 저장(전체 동기화 X).
// climbCancels: 특보·우천 일괄취소한 이용일자 {날짜:{reason,by,at}} — 재업로드해도 유지, 통계에서 제외(날짜만·개인정보 아님).
// 시설물 레거시(단일문서) 폴백/시드 동기화 상태
let _legacyFacBackup=null; // appData/facilities(구버전)의 백업 — 컬렉션 비었을 때 화면 폴백
let _facSeedReady=false;   // 시설물 첫 스냅샷·레거시 백업 확인 완료(시드 레이스 방지)
let _facMigTried=false;    // 레거시→건별 이관 1회 시도 플래그
const _SHARED=[..._SHARED_COLL,..._SHARED_DOC]; // 하위 호환용
// ⚠️ 위험상황(hazard) 기능 임시 비활성화 — UI(등록 버튼·목록·핀·통계·관제)만 숨김, 데이터·동기화는 보존.
// 재활성화: 이 값만 false 로.
const _HAZ_OFF=true;
// 온디맨드 문서: 실시간 구독하지 않고 해당 화면을 열 때만 1회 읽음 — 관리자용 로그라 전 직원 실시간 수신이 낭비
// (예: 푸시 1건마다 전 기기가 1읽기씩 소모하던 것 제거). append 전용만 등록할 것(제자리 수정·삭제되는 문서는 금지)
const _ONDEMAND_DOC=['pushLog','weatherLog','trailLog'];
// 1년 이상 지난 구조/위험상황/점검이력 기록은 실시간 동기화 대상에서 빼고, 조회 시에만 1회 불러온다.
// (수백 명이 동시 접속해도 매번 전체 역대기록을 받지 않도록 — id가 Date.now() 기반이라 시간 필터에 그대로 쓸 수 있음)
const _ARCHIVE_COLLS=['rescues','hazards','history'];
const _ARCHIVE_CUTOFF_DAYS=90; // 실시간 구독 구간(일) — 365→90: 새 기기·새 브라우저 첫 동기화 비용 절감. 이전 기록은 통계·목록·상세에서 캐시 우선으로 지연 로드
let _fsRecent={},_fsArchive={}; // k별: 실시간 구간 / 1회 조회한 과거 구간
let _archiveLoaded={}; // k별: 과거 구간 로드 완료(또는 시도중) 여부
// 실시간 구간(_fsRecent)+과거 구간(_fsArchive)을 합쳐 _fs[k]/_fsSync[k] 재구성
// (id 중복 시 실시간 구간 우선 — 경계 시점에 양쪽에 다 걸려도 최신 데이터로 통일)
function _rebuildFsColl(k){
  const map=new Map();
  (_fsArchive[k]||[]).forEach(r=>map.set(String(r.id),r));
  (_fsRecent[k]||[]).forEach(r=>map.set(String(r.id),r));
  const list=Array.from(map.values());
  try{list.sort((a,b)=>(Number(b.id)||0)-(Number(a.id)||0));}catch{}
  _fs[k]=list;
  const syncMap=new Map();
  list.forEach(r=>{syncMap.set(String(r.id),JSON.stringify(r));});
  _fsSync[k]=syncMap;
}
// 온디맨드 문서 1회 읽기 — 해당 화면을 열 때 호출(실시간 구독 없음). 실패 시 기존 캐시 유지
function _refreshDoc(k){
  if(!_fdb||!_ONDEMAND_DOC.includes(k))return Promise.resolve(_fs[k]);
  return _fdb.collection('appData').doc(k).get().then(snap=>{
    _fs[k]=snap.exists?(()=>{try{return JSON.parse(snap.data().d);}catch(e){return null;}})():null;
    _fsDocBase[k]=_fs[k];
    return _fs[k];
  }).catch(()=>_fs[k]);
}
// 1년 이전 과거 기록을 1회 조회해 _fsArchive에 채운다(세션당 1회, 조회 시에만 호출)
// 아카이브는 사실상 불변 → IndexedDB(퍼시스턴스) 캐시 우선. 캐시에 있으면 서버 읽기 0건
// (통계 열 때마다 1,000건+ 서버 재조회로 일일 읽기쿼터를 태우던 문제의 해결)
function _loadArchive(k){
  if(!_ARCHIVE_COLLS.includes(k)||_archiveLoaded[k]||!_fdb)return Promise.resolve();
  _archiveLoaded[k]=true;
  const cutoff=Date.now()-_ARCHIVE_CUTOFF_DAYS*86400000;
  const ref=_fdb.collection(k).where('id','<',cutoff);
  const apply=snap=>{_fsArchive[k]=snap.docs.map(d=>d.data());_rebuildFsColl(k);};
  return ref.get({source:'cache'}).then(snap=>{
    if(snap.empty)return ref.get().then(apply); // 이 기기 첫 조회만 서버에서
    apply(snap);
  }).catch(()=>ref.get().then(apply)).catch(()=>{_archiveLoaded[k]=false;});
}
var _remoteUpdateTimer=null; // module scope: shared across all Firebase listeners
const _fs={};   // Firestore 인메모리 캐시
let _fdb=null;
let _fst=null;
let _fmsg=null;
let _authReady=false;  // 인증(익명 또는 커스텀 토큰) 성공 여부
let _authErrCode='';   // 인증 실패 코드 (auth/operation-not-allowed 등)
// PHASE B(개인정보 읽기잠금 규칙) 대응 플래그: 익명 상태로 부팅해 공유 리스너가
// permission-denied 로 죽었는지 기록. 강화규칙 미적용 시엔 절대 true가 되지 않는다(무변화).
let _sharedReadDenied=false;
let _authRole='';      // 커스텀 토큰 역할: 'admin' | 'member' | '' (익명/미인증)
let _authKakaoId='';   // 인증된 카카오 ID (커스텀 토큰 발급 시)
let _swReg=null;
// 기기 고유 ID (localStorage 영속, 알림 브로드캐스트 출처 구분용)
const _MY_DEVICE_ID=(function(){
  let id=localStorage.getItem('_deviceId');
  if(!id){id=Date.now().toString(36)+Math.random().toString(36).slice(2);localStorage.setItem('_deviceId',id);}
  return id;
})();
let _maxSharedNotiAt=0,_sharedNotiInited=false;

// 마지막 동기화 상태 스냅샷 (k → Map(id→json)) — DB.g가 캐시 참조를 그대로 반환하므로
// 호출부가 제자리 수정하면 _fs[k]와 새 값이 동일 객체가 되어 비교가 무의미해짐.
// 동기화 시점의 JSON을 따로 보관해 그것과 비교해야 변경이 정확히 감지됨.
const _fsSync={};
// _SHARED_DOC(단일문서 배열)의 동기화 기준 시점 스냅샷 — DB.s/원격 리스너에서만 갱신.
// 호출부가 DB.g 반환값을 push 등으로 제자리 수정해도 이 맵은 영향받지 않으므로,
// "직전 동기화 시점에 있었지만 지금 없는 항목 = 의도적 삭제"를 정확히 구분할 수 있다.
const _fsDocBase={};

// ── 저장 재시도 큐: Firebase 미준비/쓰기 거부 시 localStorage에 보관 후 자동 재전송 ──
// (오프라인 중 쓰기는 Firestore persistence가 자체 보존하므로, 여기서는
//  _fdb가 아직 null인 부팅 직후 호출과 권한 거부 등 하드 실패만 담당)
function _loadSyncQ(){try{return JSON.parse(localStorage.getItem('_syncQ')||'[]');}catch{return[];}}
function _saveSyncQ(q){try{localStorage.setItem('_syncQ',JSON.stringify(q));}catch{}_updateSyncBadge();}
function _updateSyncBadge(){
  const n=_loadSyncQ().length;
  const b=document.getElementById('syncBadge'),c=document.getElementById('syncBadgeN');
  if(b)b.style.display=n?'inline':'none';
  if(c)c.textContent=n;
  _updateHomeNetStatus();
}
// 홈 화면 상단의 항상 보이는 네트워크/동기화 상태 칩 (현장 신호 약한 환경 대비)
function _updateHomeNetStatus(){
  const el=document.getElementById('homeNetStatus');if(!el)return;
  const n=(typeof _loadSyncQ==='function')?_loadSyncQ().length:0;
  if(!navigator.onLine){
    el.textContent='📡 오프라인'+(n?' · 저장 '+n+'건 대기':'');
    el.style.color='#e74c3c';el.style.display='inline';
  }else if(n){
    // 일일 서버 읽기용량 소진이면 원인을 그대로 안내 (막연한 '동기화 대기'가 고장처럼 보이던 문제)
    const quotaHit=(window._syncQuotaUntil&&Date.now()<window._syncQuotaUntil)||_loadSyncQ().some(x=>/resource-exhausted/i.test(x._err||''));
    el.textContent=quotaHit?('⏳ 서버 일일용량 초과 — '+n+'건 보관, 16시 이후 자동 저장'):('⏳ 동기화 '+n+'건 ↻');
    el.style.color='#f0a500';el.style.display='inline';
  }else{
    el.style.display='none';
  }
}
let _syncQWarnedAt=0;
function _syncWriteFailed(item){ // item: {key, op:'set'|'del', coll?, id?, doc?, json?}
  const q=_loadSyncQ();
  const i=q.findIndex(x=>x.key===item.key);
  if(i>=0)q[i]=item;else q.push(item); // 같은 문서는 최신 내용으로 교체
  _saveSyncQ(q);
  if(Date.now()-_syncQWarnedAt>30000){
    // 인증이 안 된 상태면 원인을 명확히 안내 (콘솔 익명 인증 누락이 가장 흔함)
    // ※ 부팅 직후 '인증 대기'는 정상 과도상태(인증 완료 시 큐 자동 재전송) → 경고하지 않음(첫 진입에 오류처럼 보이던 문제).
    var msg=_authErrCode==='auth/operation-not-allowed'
      ?'⚠️ 동기화 차단: Firebase 익명 인증이 꺼져 있습니다 (관리자 설정 필요)'
      :(!_authReady?'':'⚠️ 서버 저장 대기 중 — 연결되면 자동 재시도');
    if(msg){_syncQWarnedAt=Date.now();try{toast(msg);}catch(e){}}
  }
}
let _syncQFlushing=false;
// 큐에서 특정 항목 제거 (key+json 동시 일치 — 플러시 중 갱신된 최신본 보호)
function _removeSyncItem(it){
  const cur=_loadSyncQ();const ci=cur.findIndex(x=>x.key===it.key&&x.json===it.json);
  if(ci>=0){cur.splice(ci,1);_saveSyncQ(cur);}
}
function _flushSyncQueue(force){
  if(_syncQFlushing||!_fdb)return;
  // 일일 읽기쿼터 소진 중엔 자동 재시도 억제(트랜잭션 읽기가 쿼터를 더 태움) — 칩 탭 등 수동 요청은 통과
  if(!force&&window._syncQuotaUntil&&Date.now()<window._syncQuotaUntil)return;
  // 자가치유: 빈 캐시 레이스로 쌓였던 '표지판 시드' 오염 항목은 전송하지 않고 제거
  // (전송되면 서버 표지판이 시드 원본으로 되돌려지거나 복제됨 — 시드 레코드는 레거시 status:'ok'가 서명)
  const q0=_loadSyncQ();
  const q=q0.filter(it=>{
    if(it.coll!=='facilities'||!it.json)return true;
    try{const o=JSON.parse(it.json);return !(o&&o.status==='ok'&&String(o.type||'').indexOf('다목적위치표지판')>=0);}catch(e){return true;}
  });
  if(q.length!==q0.length){_saveSyncQ(q);}
  if(!q.length){_updateSyncBadge();return;}
  _syncQFlushing=true;
  (async()=>{
    let ok=0;
    for(const it of q){
      try{
        if(it.doc!==undefined)await _txMergeDoc(it.doc,it.base!==undefined?JSON.parse(it.base):undefined,JSON.parse(it.json)); // 트랜잭션 병합(오프라인 큐도 통째 덮어쓰기 방지)
        else if(it.op==='del')await _fdb.collection(it.coll).doc(it.id).delete();
        else await _txMergeSet(it.coll,it.id,JSON.parse(it.json)); // 트랜잭션 병합(오프라인 변경분 재접속 시 서버 최신본과 합침)
        _removeSyncItem(it);ok++;
      }catch(e){
        const code=(e&&e.code)||'';
        // 일일 '읽기' 쿼터 소진(resource-exhausted): 트랜잭션(읽기 포함)만 실패하고 순수 쓰기는 살아있음(실측 확인).
        // 컬렉션 항목은 읽기 없는 서버측 병합(set merge)으로 폴백 → 현장 기록을 쿼터 소진 중에도 즉시 서버 보존.
        // (appData 단일문서는 병합 기준을 읽어야 안전해 폴백하지 않고 보존·대기 — 리셋 후 자동 저장)
        if(/resource-exhausted/i.test(code)&&it.doc===undefined&&it.op!=='del'){
          try{
            await _fdb.collection(it.coll).doc(it.id).set(JSON.parse(it.json),{merge:true});
            _removeSyncItem(it);ok++;
            window._syncQuotaUntil=Date.now()+600000;
            continue;
          }catch(e2){}
        }
        // 데이터 신뢰성 최우선 — 실패해도 절대 폐기하지 않고 큐에 보존, 무한 재시도.
        // 단 한 항목의 실패가 뒤 항목을 막지 않도록 break 대신 continue(head-of-line blocking 제거).
        console.warn('[syncQ] 저장 실패(보존·재시도 예정):',it.key,'code='+code,e&&e.message);
        if(/resource-exhausted/i.test(code))window._syncQuotaUntil=Date.now()+600000; // 10분간 자동 재시도 쉼
        _markSyncFail(it,code,e&&e.message);
      }
    }
    _syncQFlushing=false;
    // 동기화 완료 토스트는 띄우지 않음(반복 노이즈) — 대기 배지가 사라지는 것으로 충분.
    if(ok)try{_updateSyncBadge();}catch(e){}
  })();
}
// 실패 항목 처리 — 회복 가능한 실패는 큐에 보존·재시도, '영영 저장 불가'(터미널)는 데드레터로 격리해
// 무한 재시도·반복 경고를 중단(데이터는 _syncQDead에 별도 보존 — 폐기 아님).
//  터미널: 문서 1MB 초과(invalid-argument 등)·존재하지 않는 대상·10회 이상 실패
function _syncDead(){try{return JSON.parse(localStorage.getItem('_syncQDead')||'[]');}catch(e){return[];}}
function _markSyncFail(it,code,msg){
  const cur=_loadSyncQ();const ci=cur.findIndex(x=>x.key===it.key&&x.json===it.json);
  if(ci<0)return;
  const n=(cur[ci]._n||0)+1;
  // 일시적 실패(쿼터 소진·서버 불가·타임아웃)는 몇 번을 실패해도 데드레터로 보내지 않음 — 리셋·복구 후 반드시 저장돼야 함
  const transient=/resource-exhausted|unavailable|deadline-exceeded|aborted|cancelled/i.test(code||'');
  const terminal=!transient&&(/invalid-argument|not-found|failed-precondition|out-of-range/i.test(code||'')
    || /longer than|exceeds the maximum|maximum.*byte|1048|too large/i.test(msg||'')
    || n>=10); // 10회 재시도해도 안 되면 사실상 저장 불가
  if(terminal){
    const dead=Object.assign({},cur[ci],{_n:n,_err:code||'unknown',_errMsg:(msg||'').slice(0,140),_at:Date.now()});
    cur.splice(ci,1);_saveSyncQ(cur); // 활성 큐에서 제거 → 배지·경고 중단
    // 증분 _fsSync 가드: 재시도 커버리지가 사라진(데드레터) 항목의 낙관적 baseline을 정리 —
    //  set: 항목 제거 → 이후 동일 내용 재수정이 '변경 없음'으로 스킵되지 않고 다시 저장 시도됨
    //  del: 감지용 표식 복원 → 이후 저장 diff에서 삭제가 다시 시도됨 (전체 재구성 시절의 자가치유 동등 유지)
    try{
      if(dead.coll){const _bm=_fsSync[dead.coll];
        if(_bm instanceof Map){
          if(dead.op==='del')_bm.set(String(dead.id),'"__dead_del__"');
          else _bm.delete(String(dead.id));
        }
      }
    }catch(e){}
    try{const dl=_syncDead();if(!dl.some(x=>x.key===dead.key&&x.json===dead.json)){dl.push(dead);localStorage.setItem('_syncQDead',JSON.stringify(dl.slice(-300)));}}catch(e){}
    if(Date.now()-_syncQWarnedAt>30000){_syncQWarnedAt=Date.now();try{toast('⚠️ 서버 저장 불가한 변경을 대기목록에서 내렸습니다 (설정→시스템에서 확인·재시도)',4500);}catch(e){}}
  }else{
    cur[ci]=Object.assign({},cur[ci],{_n:n,_err:code||'unknown',_errMsg:(msg||'').slice(0,140),_at:Date.now()});_saveSyncQ(cur);
  }
}
// 대기 항목 상세 — 무엇이/왜 안 되는지 사용자가 직접 확인
function _showSyncQueueInfo(){
  const q=_loadSyncQ();
  if(!q.length){try{toast('대기 중인 변경 없음');}catch(e){}return;}
  const lines=q.map(function(it,i){
    var what=it.doc!==undefined?('문서 '+it.doc):((it.op==='del'?'삭제 ':'저장 ')+it.coll+'/'+it.id);
    var sz=it.json?(' ~'+Math.round(it.json.length/1024)+'KB'):'';
    var tries=it._n?(' · 시도 '+it._n+'회'):'';
    var err=it._err?('\n   사유: '+it._err+(it._errMsg?(' — '+it._errMsg):'')):'';
    return (i+1)+'. '+what+sz+tries+err;
  });
  // 권한 오류(permission-denied)가 끼어 있으면 = member 토큰 만료/누락 → 자동복구 시도 후, 실패 시 재로그인 유도
  var permErr=q.some(function(it){return /permission|insufficient/i.test(it._err||'')||/permission|insufficient/i.test(it._errMsg||'');});
  if(permErr){
    _ensureMemberAuth().then(function(okk){
      if(okk){setTimeout(_flushSyncQueue,400);try{toast('✅ 저장 권한 복구됨 — 동기화 재시도');}catch(e){}}
      else{ if(confirm('저장 권한이 만료된 것 같습니다('+q.length+'건 대기).\n카카오로 다시 로그인하면 즉시 동기화됩니다.\n\n지금 다시 로그인할까요? (데이터는 안전하게 보존됨)')){try{kakaoLogin();}catch(e){}} }
    });
    return;
  }
  const dead=_syncDead();
  const deadNote=dead.length?('\n\n───────\n⛔ 저장 불가로 내려둔 항목 '+dead.length+'건(문서 1MB 초과 등):\n'+dead.slice(0,8).map(function(it,i){return (i+1)+'. '+(it.doc!==undefined?('문서 '+it.doc):((it.op==='del'?'삭제 ':'저장 ')+it.coll+'/'+it.id))+(it.json?(' ~'+Math.round(it.json.length/1024)+'KB'):'')+(it._err?(' · '+it._err):'');}).join('\n')+(dead.length>8?('\n… 외 '+(dead.length-8)+'건'):'')):'';
  alert('서버에 아직 저장되지 못한 변경 '+q.length+'건:\n\n'+lines.join('\n\n')+'\n\n※ 자동으로 계속 재시도하며, 데이터는 이 기기에 안전하게 보존됩니다.\n※ 1000KB(1MB) 이상이면 Firestore 문서 한계로 저장 불가 — 사진을 줄여야 합니다.'+deadNote);
}
function _clearSyncQueue(){
  const dead=_syncDead();
  const n=_loadSyncQ().length;
  if(!n&&!dead.length){try{toast('대기 항목 없음');}catch(e){}return;}
  // 데드레터가 있으면 우선 재시도 옵션 제공
  if(dead.length&&confirm('저장 불가로 내려둔 항목 '+dead.length+'건이 있습니다.\n\n[확인] 다시 저장 시도 (사진 용량 등 해결됐을 때)\n[취소] 아래에서 삭제 여부 선택')){
    try{const cur=_loadSyncQ();dead.forEach(function(d){delete d._dead;cur.push(d);});_saveSyncQ(cur);localStorage.removeItem('_syncQDead');setTimeout(_flushSyncQueue,300);toast('↻ '+dead.length+'건 재시도 — 실패 시 다시 내려갑니다');}catch(e){}
    return;
  }
  if(!confirm('서버에 아직 전송되지 않은 변경 '+(n+dead.length)+'건을 삭제하시겠습니까?\n(이미 저장된 데이터는 영향 없음)'))return;
  _saveSyncQ([]);
  try{localStorage.removeItem('_syncQDead');}catch(e){}
  toast('✅ 대기 항목 삭제됨');
}
window.addEventListener('online',()=>setTimeout(_flushSyncQueue,1500));
setInterval(_flushSyncQueue,45000);
_updateSyncBadge(); // 이전 세션에서 남은 대기 건 표시
// 네트워크 끊김을 동기화 실패 전에 즉시 알림 (대기 큐 배지는 쓰기가 실패해야만 뜸)
function _updateOfflineBadge(){const b=document.getElementById('offlineBadge');if(b)b.style.display=navigator.onLine?'none':'inline';_updateHomeNetStatus();}
window.addEventListener('online',_updateOfflineBadge);
window.addEventListener('offline',_updateOfflineBadge);
_updateOfflineBadge(); // 시작 시 1회 — 오프라인 상태로 켜도 배지가 바로 뜨도록
_updateOfflineBadge();

// 사용자 입력에서 태그 주입 차단: 공유 데이터 저장 시 <,>를 전각 문자로 치환
function _stripTags(v){
  if(typeof v==='string')return v.replace(/</g,'\uFF1C').replace(/>/g,'\uFF1E');
  if(Array.isArray(v))return v.map(_stripTags);
  if(v&&typeof v==='object'){const o={};for(const k in v)o[k]=_stripTags(v[k]);return o;}
  return v;
}
const _SANITIZE_KEYS=['rescues','hazards','pendingUsers','facilities','facIssues','history']; // 사용자 자유입력이 담기는 전 컬렉션 — 저장 시 <> 전각 치환(스크립트 주입 차단)
// 정규화(키 순서 무관) 문자열 키 — Firestore 왕복 시 객체 키 순서가 바뀌어 JSON.stringify가 달라지면
// 같은 항목(타임라인 기록 등)이 병합 시 서로 다른 키로 취급돼 중복 누적되던 버그 방지. 키를 정렬해 안정화.
function _canonKey(o){
  if(o===null||typeof o!=='object')return JSON.stringify(o);
  if(Array.isArray(o))return '['+o.map(_canonKey).join(',')+']';
  return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+_canonKey(o[k])).join(',')+'}';
}
// 로그(타임라인·통과·공단) 의미 기반 서명 — 초·부수 필드 무시, 화면상 동일하면 같은 것으로 취급.
// 중복 자동 제거·삭제(툼스톤) 식별 공용. (timetable: 시각|단계|메모|작성자 / wpLog: 시각|코드|팀 / npsLog: 시각|내용|작성자)
function _logKey(e){
  if(!e||typeof e!=='object')return String(e);
  const t=String(e.time||e.at||e.repTime||'').replace('T',' ').slice(0,16); // 분 단위(초 무시)
  // e.re: '삭제했던 것과 같은 내용 재입력' 구분자 — 없으면 키 불변(기존 데이터 영향 없음).
  // 재입력에 re를 부여하면 삭제 툼스톤(_del)과 키가 달라져, 서버 병합으로 툼스톤이 되살아나도 새 항목은 안 가려짐
  const base=[t,e.stage||e.code||'',e.note||e.text||'',e.by||e.author||e.teamName||''].join('');
  return e.re?base+''+e.re:base; // re 없으면 예전 키와 완전 동일 — 기존 삭제표식·중복정리 호환 유지
}
// 타임라인 중복 청소(1회) — 위 병합키 버그로 timetable/wpLog/npsLog에 쌓인 동일 항목을 1개만 남김.
// 변경된 레코드만 저장(쿼터 최소화). rescues 미로드 시엔 플래그 미설정 → 다음 호출에서 재시도.
function _migrateDedupLogs(){
  try{
    if(localStorage.getItem('_logDedup_v3')==='1')return;
    const res=DB.g('rescues');if(!Array.isArray(res))return; // 아직 로드 전 — 다음 기회에 재시도
    const dd=arr=>{if(!Array.isArray(arr)||arr.length<2)return null;const seen=new Set();const out=[];arr.forEach(x=>{const k=_logKey(x);if(seen.has(k))return;seen.add(k);out.push(x);});return out.length!==arr.length?out:null;};
    let changed=false;
    res.forEach(r=>{['timetable','wpLog','npsLog'].forEach(f=>{const nu=dd(r[f]);if(nu){r[f]=nu;changed=true;}});});
    if(changed)DB.s('rescues',res);
    localStorage.setItem('_logDedup_v3','1');
  }catch(e){}
}
// 성별 표기 통일(1회) — 엑셀 임포트 등으로 '남성/여성'으로 저장된 것을 폼 표준 '남/여'로 정규화(통계·서식·표시 일관)
function _migrateGender(){
  try{
    if(localStorage.getItem('_genderNorm_v1')==='1')return;
    const res=DB.g('rescues');if(!Array.isArray(res))return;
    const nz=g=>{var s=String(g==null?'':g).trim();return s==='남성'?'남':s==='여성'?'여':g;};
    var changed=false;
    res.forEach(function(r){
      var ng=nz(r.vGender);if(ng!==r.vGender){r.vGender=ng;changed=true;}
      if(Array.isArray(r.victims2))r.victims2.forEach(function(v){if(v){var nv=nz(v.gender);if(nv!==v.gender){v.gender=nv;changed=true;}}});
    });
    if(changed)DB.s('rescues',res);
    localStorage.setItem('_genderNorm_v1','1');
  }catch(e){}
}
// ── 동시편집 병합: 누적 데이터(보고·댓글·타임라인·통과기록)는 합집합 보존, 단일값은 최신(로컬) 우선 ──
function _unionBy(server,local,keyFn){
  const map=new Map();let n=0;
  (server||[]).forEach(x=>{try{map.set(keyFn(x),x);}catch{map.set('_s'+(n++),x);}});
  (local||[]).forEach(x=>{try{map.set(keyFn(x),x);}catch{map.set('_l'+(n++),x);}});
  return [...map.values()];
}
// 로컬 레코드를 서버 최신본과 병합. 누적 배열은 합집합(의미키로 중복 자동 제거) + 삭제 툼스톤(_del)으로 삭제 반영.
function _mergeRecord(local,server){
  if(!server||typeof server!=='object')return local;
  // 서버본 위에 로컬을 덮는다: 공통 필드는 로컬 우선(기존 동작), 서버에만 있는 신규 필드(다른 대원이
  // 추가했으나 이 기기 로컬엔 없는 값)는 보존 — 예전엔 out={...local}이라 그런 필드가 병합 때 유실됐다.
  const out=Object.assign({},server,local);
  const fields=[
    ['reports',r=>r&&r.rid?('rid:'+r.rid):((r&&r.repTime||'')+'|'+(r&&r.author||'')+'|'+(r&&r.update||''))],
    ['comments',c=>(c&&c.id!=null)?('id:'+c.id):_canonKey(c)],
    ['timetable',e=>_logKey(e)],
    ['wpLog',e=>_logKey(e)],
    ['npsLog',e=>_logKey(e)],
    ['photos',p=>(p&&p.url)?('url:'+p.url):_canonKey(p)],
    ['mobilizeResp',m=>(m&&m.name)?('name:'+m.name):_canonKey(m)], // 응소 응답(이름별 1건, 본인 응답은 항상 최신 로컬값 우선)
    ['fireTL',e=>_canonKey(e)] // 산불 진행 타임라인(등록 후에도 계속 추가됨)
  ];
  fields.forEach(([f,keyFn])=>{
    if(!Array.isArray(local[f])&&!Array.isArray(server[f]))return; // 양쪽 다 없으면 손대지 않음
    // 합집합(정규화 키로 중복 자동 제거) — 절대 항목을 잃지 않음. 삭제는 아래 툼스톤(_del)으로만 반영해 '오삭제' 원천 차단.
    out[f]=_unionBy(server[f],local[f],keyFn);
  });
  // 삭제 툼스톤(_del): 사용자가 명시적으로 삭제한 기록의 정규화 키 목록. 합집합이 삭제분을 되살리는 것을 막되,
  // '명시적으로 삭제 처리한 키'만 제외하므로 다른 기록이 통째로 날아가는 오삭제가 구조적으로 불가능.
  const _delArr=Array.from(new Set([].concat(Array.isArray(local._del)?local._del:[],Array.isArray(server._del)?server._del:[])));
  if(_delArr.length){
    out._del=_delArr.slice(-500);
    const _ds=new Set(out._del);
    ['timetable','wpLog','npsLog'].forEach(f=>{if(Array.isArray(out[f]))out[f]=out[f].filter(x=>{try{return !_ds.has(_logKey(x));}catch(e){return true;}});});
  }
  if(Array.isArray(out.reports))out.reports.sort((a,b)=>String((a&&a.repTime)||'').localeCompare(String((b&&b.repTime)||'')));
  if(Array.isArray(out.fireTL))out.fireTL.sort((a,b)=>String((a&&a.time)||'').localeCompare(String((b&&b.time)||'')));
  // 추가 사고자(victims2): 병합된 보고 중 가장 최신 보고의 값을 신뢰
  // (한쪽 기기가 오프라인 중 작성한 stale 본으로 다른 기기가 추가한 사고자가 덮여 사라지는 것을 방지)
  if(Array.isArray(out.reports)&&out.reports.length){
    const latest=out.reports[out.reports.length-1];
    if(latest&&latest.victims2)out.victims2=latest.victims2;
  }
  // 종료 처리(status:'done')는 한쪽이라도 완료면 유지 — 동시편집으로 완료 처리가 되돌려지지 않게 함
  if(server.status==='done'||local.status==='done')out.status='done';
  // 시설 점검 상태: 두 기기가 같은 시설을 동시 점검하면 더 최근 점검(statusAt 큰 쪽)을 신뢰
  // — 트랜잭션 커밋 순서가 아니라 실제 점검 시각으로 승자를 정해 결과가 뒤바뀌지 않게 함
  if(server.statusAt!=null&&local.statusAt!=null&&server.statusAt>local.statusAt&&server.status){out.status=server.status;out.statusAt=server.statusAt;}
  // 환자 인계 기록은 더 최신 시각 쪽을 유지
  if(server.handover&&(!local.handover||String(server.handover.time||'')>String(local.handover.time||'')))out.handover=server.handover;
  return out;
}
// 건별 문서 1건을 트랜잭션으로 병합 저장(서버 최신본과 누적데이터 합침). 실패 시 reject → 호출부가 큐 보존.
function _txMergeSet(coll,id,localObj){
  const ref=_fdb.collection(coll).doc(id);
  return _fdb.runTransaction(t=>t.get(ref).then(snap=>{
    const merged=_mergeRecord(localObj,snap.exists?snap.data():null);
    t.set(ref,merged);
    return merged;
  }));
}
// 단일문서(JSON 배열) 항목 식별 키 — id 있으면 id, 없으면(문자열 등) 값 자체
function _sdItemKey(x){return(x&&typeof x==='object'&&x.id!=null)?('id:'+x.id):_canonKey(x);}
// 3-way 병합(base/local/server): base에는 있었지만 local에 없는 항목은 "의도적 삭제"로
// 보고 복원하지 않는다. base에 없던 항목이 local에 새로 생겼으면 추가, server에만 있는
// (다른 기기가 추가한) 항목은 그대로 보존 — 단순 합집합(union)과 달리 삭제가 안전하게 반영됨.
function _mergeSharedArray(base,local,server){
  const baseIds=new Set((base||[]).map(_sdItemKey));
  const localIds=new Set((local||[]).map(_sdItemKey));
  const removedIds=new Set([...baseIds].filter(id=>!localIds.has(id)));
  const localMap=new Map((local||[]).map(x=>[_sdItemKey(x),x]));
  const out=[];const seen=new Set();
  (server||[]).forEach(x=>{
    const id=_sdItemKey(x);
    if(removedIds.has(id))return; // 로컬에서 의도적으로 삭제한 항목 — 복원하지 않음
    out.push(localMap.has(id)?localMap.get(id):x); // 같은 id면 로컬 버전(수정분) 우선
    seen.add(id);
  });
  (local||[]).forEach(x=>{
    const id=_sdItemKey(x);
    if(!seen.has(id)){out.push(x);seen.add(id);} // 로컬에서 새로 추가된 항목
  });
  return out;
}
// appData/{key} 단일문서를 트랜잭션으로 병합 저장.
// base(직전 동기화 시점 스냅샷)가 있을 때만 3-way 병합 시도 — 여러 기기가 동시에
// 점검이력·가입신청 등을 추가해도 한쪽 기기의 덮어쓰기로 다른 기기의 항목이
// 통째로 사라지지 않는다. base가 없거나 배열이 아니면(딕셔너리/스칼라) 기존처럼 로컬 우선.
// 추가-전용 목록: base(직전 스냅샷)가 없어도 항상 서버와 합집합으로 병합.
// 예전엔 base 없는 기기가 저장하면 '로컬 우선'으로 서버 목록을 통째로 교체 →
// climbDates 63일이 새로 업로드한 기기의 4일로 덮어써지는 사고가 실제 발생(2026-07 점검에서 복구).
const _UNION_DOC=['climbDates'];
const _DICT_MERGE_DOC=['zoneEdits','zoneGeom']; // {키:값} 딕셔너리 문서 — 키 단위 3-way 병합(다른 관리자가 저장한 다른 구역 보정/경계 보존)
// 온디맨드 로그 문서: 실시간 구독 없이 '화면 열 때만' 읽는 append 전용 로그 — 병합은 객체 합집합(항목 유실 없음)
const _ONDEMAND_CAP={pushLog:30,weatherLog:60,trailLog:100};
function _txMergeDoc(key,base,localVal){
  const ref=_fdb.collection('appData').doc(key);
  return _fdb.runTransaction(t=>t.get(ref).then(snap=>{
    let serverVal=null;
    if(snap.exists){try{serverVal=JSON.parse(snap.data().d);}catch(e){serverVal=null;}}
    let merged;
    if(_UNION_DOC.includes(key)&&Array.isArray(localVal)){
      merged=Array.from(new Set([].concat(Array.isArray(serverVal)?serverVal:[],localVal).map(String))).sort();
    }else if(_ONDEMAND_DOC.includes(key)&&Array.isArray(localVal)){
      // 로그 합집합: 서버·로컬 어느 쪽이 오래됐어도 항목이 사라지지 않음(추가 전용). 최신순 정렬 후 상한 유지
      const seen=new Set();const out=[];
      [].concat(localVal,Array.isArray(serverVal)?serverVal:[]).forEach(x=>{const j=JSON.stringify(x);if(seen.has(j))return;seen.add(j);out.push(x);});
      out.sort((a,b)=>(((b&&(b.at||b.atMs))||0)-((a&&(a.at||a.atMs))||0)));
      merged=out.slice(0,_ONDEMAND_CAP[key]||100);
    }else if(_DICT_MERGE_DOC.includes(key)&&localVal&&typeof localVal==='object'&&!Array.isArray(localVal)){
      // 딕셔너리 키 단위 3-way 병합: 서버 상태에서 출발해 로컬에서 '실제 바뀐 키'만 반영, 로컬에서 지운 키(base에 있었는데 없음)만 삭제
      // → 오프라인 큐 재전송·동시 저장에서도 다른 관리자가 저장한 다른 구역 보정이 유실되지 않음
      const sv=(serverVal&&typeof serverVal==='object'&&!Array.isArray(serverVal))?serverVal:{};
      const bv=(base&&typeof base==='object'&&!Array.isArray(base))?base:{};
      merged=Object.assign({},sv);
      Object.keys(localVal).forEach(kk=>{if(JSON.stringify(localVal[kk])!==JSON.stringify(bv[kk]))merged[kk]=localVal[kk];});
      Object.keys(bv).forEach(kk=>{if(!(kk in localVal))delete merged[kk];});
    }else{
      merged=(Array.isArray(localVal)&&Array.isArray(serverVal)&&Array.isArray(base))
        ?_mergeSharedArray(base,localVal,serverVal):localVal;
    }
    t.set(ref,{d:JSON.stringify(merged)});
    return merged;
  }));
}
let _lsQuotaWarned=false; // localStorage 용량 초과 통지 1회 제한 플래그
const DB={
  g(k){
    if(_SHARED.includes(k)) return (_fs[k]!==undefined)?_fs[k]:null;
    try{return JSON.parse(localStorage.getItem('v7_'+k)||'null');}catch{return null;}
  },
  s(k,v){
    if(k==='facilities')_invalidateSignCache();
    if(_SANITIZE_KEYS.includes(k))v=_stripTags(v);
    if(_SHARED_COLL.includes(k)){
      _fs[k]=v||[];
      const prevJson=_fsSync[k]||new Map();
      const newJson=new Map();
      (v||[]).forEach(r=>{newJson.set(String(r.id),JSON.stringify(r));});
      // 새로 추가되거나 변경된 항목만 개별 문서에 저장 (실패 시 재시도 큐)
      newJson.forEach((json,id)=>{
        if(prevJson.get(id)===json)return;
        if(_fdb)_txMergeSet(k,id,JSON.parse(json)).catch(()=>_syncWriteFailed({key:k+'/'+id,op:'set',coll:k,id,json}));
        else _syncWriteFailed({key:k+'/'+id,op:'set',coll:k,id,json});
      });
      // 삭제된 항목 제거
      prevJson.forEach((_,id)=>{
        if(newJson.has(id))return;
        if(_fdb)_fdb.collection(k).doc(id).delete().catch(()=>_syncWriteFailed({key:k+'/'+id,op:'del',coll:k,id}));
        else _syncWriteFailed({key:k+'/'+id,op:'del',coll:k,id});
      });
      _fsSync[k]=newJson;
    }else if(_SHARED_DOC.includes(k)){
      const base=_fsDocBase[k]; // DB.s/원격 리스너에서만 갱신되는 기준 스냅샷(제자리수정 영향 없음)
      _fs[k]=v;_fsDocBase[k]=v;
      const json=JSON.stringify(v);
      if(_fdb)_txMergeDoc(k,base,v).catch(()=>_syncWriteFailed({key:'doc/'+k,doc:k,json,base:JSON.stringify(base===undefined?null:base)}));
      else _syncWriteFailed({key:'doc/'+k,doc:k,json,base:JSON.stringify(base===undefined?null:base)});
    }else{
      try{localStorage.setItem('v7_'+k,JSON.stringify(v));}
      catch(e){ // 저장 공간 초과 등으로 실패 시 조용히 넘어가지 않고 1회 통지
        if(!_lsQuotaWarned){_lsQuotaWarned=true;try{toast('⚠️ 기기 저장 공간 부족 — 일부 설정이 저장되지 않았습니다');}catch(_){}}
      }
    }
  },
  d(k){
    if(_SHARED_COLL.includes(k)){
      const prev=_fs[k]||[];
      _fs[k]=[];
      if(_fdb) prev.forEach(r=>_fdb.collection(k).doc(String(r.id)).delete().catch(()=>_syncWriteFailed({key:k+'/'+r.id,op:'del',coll:k,id:String(r.id)})));
      _fsSync[k]=new Map();
    }else if(_SHARED_DOC.includes(k)){
      _fs[k]=null;
      if(_fdb) _fdb.collection('appData').doc(k).delete().catch(()=>{});
    }else{
      localStorage.removeItem('v7_'+k);
    }
  },
  sync(){} // no-op (이전 코드 호환)
};

function initFirebase(onReady){
  try{
    if(!firebase.apps.length) firebase.initializeApp(_FB_CFG);
    // 익명 인증: Firestore 보안 규칙(request.auth != null)을 적용하기 위한 기반.
    // 인증 성공/실패를 추적하고, 성공 시 대기 큐를 즉시 재전송한다.
    try{
      firebase.auth().onAuthStateChanged(function(u){
        if(u){
          _authReady=true;_authErrCode='';
          // 커스텀 토큰(비익명) 세션이면 새로고침 후에도 클레임에서 역할 복원
          if(!u.isAnonymous){
            u.getIdTokenResult().then(function(r){
              var c=(r&&r.claims)||{};
              if(c.member){
                _authRole=c.admin?'admin':'member';
                _authKakaoId=c.kakaoId||'';
                if(c.admin)localStorage.setItem('_tokenAdmin','1');else localStorage.removeItem('_tokenAdmin');
                try{_markMemberOk();}catch(e){}
                // PHASE B 대응: 익명으로 부팅해 공유 리스너가 permission-denied로 죽은 세션이
                // 방금 멤버가 됐다면(최초 로그인·로그아웃 후 재로그인·세션 만료 복구),
                // 멤버 토큰으로 리스너를 다시 붙이기 위해 1회만 새로고침.
                //  · 강화규칙·클레임 미배포 상태에선 _sharedReadDenied가 절대 true가 안 됨 → 실행 안 함(무변화)
                //  · 세션이 유지되는 재방문 직원은 첫 리스너부터 멤버 토큰이라 여기 안 걸림
                //  · sessionStorage 가드로 무한 새로고침 방지(규칙 오설정으로 계속 거부돼도 1회만)
                try{
                  if(_sharedReadDenied&&!sessionStorage.getItem('_reloadedForMember')){
                    sessionStorage.setItem('_reloadedForMember','1');
                    setTimeout(function(){try{location.reload();}catch(e){}},400);
                  }
                }catch(e){}
              }else{
                // 비익명인데 member 클레임이 없는 비정상 세션 → 카카오로 재발급 시도
                setTimeout(function(){try{_ensureMemberAuth();}catch(e){}},400);
              }
              try{updateUserUI();}catch(e){}
              try{_enforceAccessGate();}catch(e){}
            }).catch(function(){});
          }else{
            // 익명 세션: 카카오 로그인 이력이 있으면 member 토큰으로 자동 승급
            // (새 규칙은 member 클레임 없는 쓰기를 거부하므로, 재로그인 없이 권한 복원)
            setTimeout(function(){try{_ensureMemberAuth();}catch(e){}},500);
          }
          setTimeout(_flushSyncQueue,300); // 인증 완료 → 막혔던 쓰기 즉시 재시도
        }else{
          // 로그인 세션이 전혀 없을 때만 익명 인증으로 폴백.
          // (커스텀 토큰 세션은 위 분기에서 유지되므로 덮어쓰지 않는다.)
          firebase.auth().signInAnonymously().catch(function(e){
            _authErrCode=(e&&e.code)||'auth/unknown';
            // 익명 인증이 콘솔에서 꺼져 있으면 모든 쓰기가 막힌다 → 사용자에게 명확히 안내
            if(_authErrCode==='auth/operation-not-allowed'){
              setTimeout(function(){try{toast('⚠️ Firebase 익명 인증이 꺼져 있어 동기화가 안 됩니다 (관리자: 콘솔에서 익명 로그인 활성화 필요)');}catch(e){}},2500);
            }
          });
        }
      });
    }catch(e){_authErrCode='auth/init-failed';}
    _fdb=firebase.firestore();
    // 기기 캐시 상한 해제 — 기본 40MB LRU라 사진 든 기록이 쌓이면 오래된 것부터 몰래 버리고
    // 나중에 그 기록을 볼 때 서버에서 다시 읽어옴(쿼터 재소모). 원칙: 한 번 받은 데이터는 기기에 남기고 변경분만 동기화.
    try{_fdb.settings({cacheSizeBytes:firebase.firestore.CACHE_SIZE_UNLIMITED,merge:true});}catch(e){}
    // synchronizeTabs: 웹에서 탭을 여러 개 열어도 IndexedDB 캐시 유지(없으면 두 번째 탭부터 캐시 꺼져 매번 전체 재다운로드)
    _fdb.enablePersistence({synchronizeTabs:true}).catch(()=>{});
    // 저장공간 부족 시 브라우저가 사이트 데이터(기록·타일 캐시)를 통째로 비우지 못하게 영구 저장 요청
    try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{});}catch(e){}
    _fst=firebase.storage();
    try{_fmsg=firebase.messaging();}catch(e){}
    setTimeout(_flushSyncQueue,3000); // 부팅 직후 대기 큐 재전송
    setTimeout(_processPhotoQueue,5000); // 이전 세션 오프라인 사진 이어서 업로드
    setTimeout(_cleanOldSharedNotis,8000); // 세션당 1회: 24h 지난 브로드캐스트 알림 정리(확률 의존 X)
    const totalKeys=_SHARED.length-_ONDEMAND_DOC.length; // 온디맨드 문서는 부팅 대기 대상 아님
    const loaded=new Set();
    function _checkReady(){if(loaded.size===totalKeys){
      window._dbFirstReady=true; // 첫 전체 동기화 완료 — 홈 스켈레톤을 실데이터로 교체
      onReady&&onReady();onReady=null;
      try{if(typeof updateSummary==='function')updateSummary();}catch(e){}
    }}
    function _onRemoteUpdate(){
      _checkDeletedUser();
      // 관리자에서 강등(_acl)되면 즉시 반영 — 옛 플래그 정리 + 관리자 화면이면 홈으로
      try{
        if(typeof isAdminUser==='function'&&!isAdminUser()){
          if(localStorage.getItem('_adminAuthed')==='1'||localStorage.getItem('_tokenAdmin')==='1'){
            localStorage.removeItem('_adminAuthed');localStorage.removeItem('_tokenAdmin');
            if(window.curApp==='admin'){try{toast('관리자 권한이 해제되었습니다');}catch(e){}try{goHome();}catch(e){}}
          }
        }
      }catch(e){}
      try{_checkNewJoinerAlert();}catch(e){}
      // 새 기기 첫 로그인: 동기화 전이라 프로필을 못 찾아 입력창이 떴어도, pendingUsers가 도착하면
      // 서버 기록에서 자동 복원하고 입력창을 닫음(개인정보 재입력 방지)
      try{
        var _cu=DB.g('currentUser')||{};
        if(_resolveAuthType()==='kakao'&&_cu.kakaoId&&!(_cu.dept&&(_cu.realName||_cu.name))){
          if(_restoreProfileFromServer(_cu.kakaoId)){
            updateUserUI();
            var _mu=document.getElementById('modalUser');
            if(_mu&&_mu.classList.contains('on')){window._requireProfile=false;window._needsCode=false;try{closeM('modalUser');}catch(e){}}
            try{_enforceAccessGate();}catch(e){}
          }
        }
      }catch(e){}
      // 승인 대기 중인 사용자: _acl 동기화 즉시 멤버 판정 → 재로그인 없이 자동 입장
      try{var _g=document.getElementById('approvalGate');if(_g&&_g.style.display!=='none'){if(_isAutoApprove()){var _u=DB.g('currentUser')||{};if(_u.kakaoId)_aclSelfApprove(_u.kakaoId);}if(_isMember()){_g.style.display='none';_stopApprovalPoll();updateUserUI();try{goHome();}catch(e){}toast('✅ 승인 완료 — 환영합니다');}}}catch(e){}
      try{_updateCrisisBanner();}catch(e){}
      try{if(!_fcmTokenCache)_initFCM();}catch(e){} // VAPID 키가 방금 동기화됐으면 재시작 없이 웹푸시 토큰 등록
      clearTimeout(_remoteUpdateTimer);
      _remoteUpdateTimer=setTimeout(function(){
        try{if(typeof updateSummary==='function')updateSummary();}catch(e){} // 홈 요약(카운트·응소배너)을 스냅샷 버스트당 1회로 배칭 — 매 스냅샷 동기 실행 제거
        try{if(typeof _applyHomeMenuVisibility==='function')_applyHomeMenuVisibility();}catch(e){} // 관리자의 홈메뉴 숨김 설정 동기화 즉시 반영
        if(window.curApp==='rescue'){renderResList();try{renderRescueMap();}catch(e){}}
        else if(window.curApp==='inspect'){renderFacList();renderInspectMap();try{renderFacIssues();}catch(e){}
          // 담당 업무함: 보이는 중이면 입력(회신 작성) 보호 위해 배지만 갱신, 숨겨져 있으면 재렌더
          try{var _vw=document.getElementById('v-inspect-work');
            if(_vw&&!_vw.classList.contains('on'))renderFacWork();else _updateFacWorkBadge();}catch(e){}}
        else if(window.curApp==='alert')renderAlertView();
        else if(window.curApp==='stats')renderFullStats();
        // 열려 있는 사고 상세(v-report): 원격 변경 즉시 타임라인 갱신 — 저장된 기록이 화면에 안 나타나던 핵심 원인.
        // 입력 보호: 입력칸 포커스 중이거나, 기록카드에 고르다 만 단계·메모·댓글 초안이 있으면 건너뜀(다음 변경 때 반영)
        try{
          var _vr=document.getElementById('v-report');
          if(_vr&&_vr.classList.contains('on')&&typeof curResId!=='undefined'&&curResId&&typeof renderTimeline==='function'&&typeof getRes==='function'){
            var _ae2=document.activeElement;
            var _typing2=_ae2&&_vr.contains(_ae2)&&/INPUT|TEXTAREA/.test(_ae2.tagName||'');
            // 단계가 렌더 자동 세팅값(_tlRecStageAuto)과 같으면 초안 아님 — 대기 상태에선 원격 기록이 즉시 그려지게
            var _draft2=window._tlRecDirty===true||(typeof _tlRecStage!=='undefined'&&_tlRecStage&&_tlRecStage!==window._tlRecStageAuto)||(typeof _tlRecTeam!=='undefined'&&_tlRecTeam)
              ||((document.getElementById('tlRecNote')||{}).value)||((document.getElementById('tlRecCustom')||{}).value)
              ||((document.getElementById('cmtInput_'+curResId)||{}).value)||((document.getElementById('cmtInput_adv_'+curResId)||{}).value);
            if(!_typing2&&!_draft2){var _rr2=getRes(curResId);if(_rr2&&_rr2.id)renderTimeline(_rr2,(typeof _tlViewMode!=='undefined'&&_tlViewMode)||'advanced');}
          }
        }catch(e){}
        // 상황판(모니터): 열려 있으면 원격 변경 '즉시' 반영 — 10초 폴링 대기 없이 실시간 동기화.
        // (핀은 데이터 서명 가드로 변경분만 다시 그림 · 상세 패널은 댓글 입력 중이면 건너뛰어 타이핑 보호)
        try{
          var _bv=document.getElementById('v-board');
          if(_bv&&_bv.classList.contains('on')){
            if(typeof renderBoard==='function')renderBoard();
            try{if(typeof _renderBoardPins==='function')_renderBoardPins(false);}catch(e){}
            if(typeof _boardDetailId!=='undefined'&&_boardDetailId!=null){
              var _bd=document.getElementById('boardDetail');
              var _br=(DB.g('rescues')||[]).find(function(x){return x.id===_boardDetailId;});
              var _ae=document.activeElement;
              var _typing=_ae&&_bd&&_bd.contains(_ae)&&/INPUT|TEXTAREA/.test(_ae.tagName||'');
              // 상황판에서도 기록카드 조작 중(_tlRecDirty)엔 재렌더 보류 — 포커스 없는 칩·시각 초안이 원격 에코로 초기화되는 것 방지
              if(_br&&_bd&&_bd.style.display!=='none'&&!_typing&&window._tlRecDirty!==true&&typeof renderTimeline==='function')
                renderTimeline(_br,(typeof _tlViewMode!=='undefined'&&_tlViewMode)||'advanced','boardDetailContent');
            }
          }
        }catch(e){}
      },400);
    }
    // ── 컬렉션 리스너: 항목마다 개별 문서 (rescues, hazards) ──
    // rescues/hazards는 최근 1년(_ARCHIVE_CUTOFF_DAYS)만 실시간 구독 — 수백 명 접속해도
    // 매번 전체 역대기록을 받지 않도록(id가 Date.now() 기반이라 그대로 범위 필터 가능).
    // 1년 이전 기록은 조회 시 _loadArchive()로 1회만 불러온다.
    _SHARED_COLL.forEach(k=>{
      const isArchived=_ARCHIVE_COLLS.includes(k);
      const ref=isArchived?_fdb.collection(k).where('id','>=',Date.now()-_ARCHIVE_CUTOFF_DAYS*86400000):_fdb.collection(k);
      ref.onSnapshot(snap=>{
        const docs=snap.docs.map(d=>d.data());
        if(isArchived){
          _fsRecent[k]=docs;
          _rebuildFsColl(k);
        }else{
          _fs[k]=docs;
          try{_fs[k].sort((a,b)=>(Number(b.id)||0)-(Number(a.id)||0));}catch{}
          // 동기화 기준 스냅샷 갱신 (서버 상태 = 마지막 동기화 상태)
          // 대량 컬렉션(시설물 등)에서 매 스냅샷마다 전체 레코드(사진 포함)를 재문자열화하지 않도록 변경분만 반영.
          // 첫 스냅샷(!loaded.has(k))은 빈 맵으로 시작 → docChanges()가 전 문서를 'added'로 통지하므로
          // 전체 집합이 그대로 복원되고, 이후 스냅샷은 added/modified→set·removed→delete를 누적 적용한다.
          // (유일 소비자 DB.s의 diff 결과 불변 — 데드레터 이관 시 _markSyncFail이 해당 항목을 지워 자가치유 유지)
          let sm=_fsSync[k];
          if(!(sm instanceof Map)||!loaded.has(k))sm=new Map();
          snap.docChanges().forEach(ch=>{
            const rec=ch.doc.data(),rid=String(rec.id);
            if(ch.type==='removed')sm.delete(rid);
            else sm.set(rid,JSON.stringify(rec));
          });
          _fsSync[k]=sm;
        }
        // 시설물: 컬렉션이 비어있으면 레거시 단일문서 백업으로 폴백 표시 + 1회 이관 시도
        if(k==='facilities'){
          if(_fs[k].length===0&&_legacyFacBackup&&_legacyFacBackup.length){
            _fs[k]=_legacyFacBackup.slice(); // 화면 폴백(동기화 끊겨도 데이터 안 사라짐)
            if(!_facMigTried){_facMigTried=true;try{DB.s('facilities',_fs[k]);}catch(e){}} // 건별 문서로 이관(실패 시 큐 보존)
          }
          try{_invalidateSignCache();}catch(e){} // 첫 수신 포함 항상 — 부트캐시 기반 메모를 실데이터로 교체
          // 표지판 시드 판단은 '서버 확정' 스냅샷에서만. 새 기기는 빈 로컬캐시 스냅샷(fromCache)이
          // 먼저 발화해 표지판이 없다고 오판 → 177개 재시드가 동기화 큐(88건+)로 쌓이던 실사고 원인.
          if(!snap.metadata.fromCache||_fs[k].length>0){
            _facSeedReady=true;
            try{_ensureSignSeed();}catch(e){}
          }
          try{_facBootCacheSave();}catch(e){} // 지도 즉시표시용 경량 캐시 갱신(사진 제외 최소 필드)
        }
        if(!loaded.has(k)){loaded.add(k);_checkReady();}
        else{_onRemoteUpdate();}
      },(e)=>{if(e&&(e.code==='permission-denied'||/permission|insufficient/i.test(String(e.message||''))))_sharedReadDenied=true;if(!loaded.has(k)){loaded.add(k);_checkReady();}}); // 리스너 오류 시엔 시드하지 않음(빈 캐시 기준 오판 방지)
    });
    // ── 단일 문서 리스너: appData/{key} ── (온디맨드 문서는 구독 제외 — 화면 열 때 _refreshDoc으로 1회 읽기)
    _SHARED_DOC.filter(k=>!_ONDEMAND_DOC.includes(k)).forEach(k=>{
      _fdb.collection('appData').doc(k).onSnapshot(snap=>{
        _fs[k]=snap.exists?(()=>{try{return JSON.parse(snap.data().d);}catch{return null;}})():null;
        _fsDocBase[k]=_fs[k]; // 서버 확정 상태 = 다음 쓰기의 병합 기준
        // 구역 위치 보정 수신: 켜져 있는 구역 레이어를 즉시 제자리 갱신(부팅 첫 스냅샷 포함, 미로드 시 no-op)
        if(k==='zoneEdits')try{typeof _zoneRemoteRefresh==='function'&&_zoneRemoteRefresh();}catch(e){}
        if(k==='zoneGeom')try{typeof _zoneGeomReload==='function'&&_zoneGeomReload();}catch(e){} // 경계 교체는 점 개수가 달라 제자리 이동 불가 → 전체 재그리기
        if(!loaded.has(k)){loaded.add(k);_checkReady();}
        else{
          // 원격 업데이트: 표지판/시설 캐시 무효화 후 리렌더 (catFacMeta가 표지판 표시에 영향)
          if(k==='catFacMeta')try{_invalidateSignCache();}catch(e){}
          _onRemoteUpdate();
        }
      },(e)=>{if(e&&(e.code==='permission-denied'||/permission|insufficient/i.test(String(e.message||''))))_sharedReadDenied=true;if(!loaded.has(k)){loaded.add(k);_checkReady();}});
    });
    // ── 시설물 레거시(단일문서) 백업 읽기: 컬렉션 비었을 때 폴백·이관 소스 ──
    _fdb.collection('appData').doc('facilities').get().then(snap=>{
      if(snap.exists){try{const a=JSON.parse(snap.data().d);if(Array.isArray(a)&&a.length)_legacyFacBackup=a;}catch(e){}}
      // 백업 확보 후, 이미 빈 컬렉션 스냅샷을 받았다면 폴백 반영
      if(_legacyFacBackup&&(!_fs['facilities']||_fs['facilities'].length===0)){
        _fs['facilities']=_legacyFacBackup.slice();
        if(!_facMigTried){_facMigTried=true;try{DB.s('facilities',_fs['facilities']);}catch(e){}}
        try{_invalidateSignCache();}catch(e){}
        try{if(window.curApp==='inspect'){renderFacList();renderInspectMap();}}catch(e){}
      }
    }).catch(()=>{});
    // ── 구버전 단일 문서 → 개별 문서 마이그레이션 ──
    // ── 기기 간 알림 브로드캐스트 리스너 (준비 체크에 미포함) ──
    _fdb.collection('sharedNotis').orderBy('at','desc').limit(50)
      .onSnapshot(snap=>{
        if(!_sharedNotiInited){
          // 첫 스냅샷: 현재 최신 ts 기록 → 기존 알림은 무시
          _maxSharedNotiAt=snap.docs.reduce((m,d)=>Math.max(m,d.data().at||0),0);
          _sharedNotiInited=true;
          return;
        }
        snap.docChanges().forEach(ch=>{
          if(ch.type!=='added')return;
          const d=ch.doc.data();
          if((d.at||0)<=_maxSharedNotiAt)return;
          if(d.deviceId===_MY_DEVICE_ID)return; // 내가 보낸 것
          _maxSharedNotiAt=Math.max(_maxSharedNotiAt,d.at||0); // watermark는 항상 전진(로그인 후 과거알림 폭주 방지)
          // 중복 방지 키(dk): 내 대기 발송 취소 신호로 기록하고, 같은 키 알림은 한 번만 표시
          if(d.dk){const sk=window._notiSeenDk||(window._notiSeenDk={});if(sk['rx:'+d.dk])return;sk['rx:'+d.dk]=1;sk[d.dk]=1;}
          if(!_notiRecipientReady())return; // 미로그인 상태에는 알림 전달 안 함(로그인 화면만 봐야 함)
          if(d.adminOnly&&!(typeof isAdminUser==='function'&&isAdminUser()))return; // 관리자 전용 알림은 관리자만 수신
          if((d.devOnly||String(d.type||'').indexOf('op_')===0)&&!_amDev())return; // 【임시】특보(op_*)는 개발자만 수신
          if(d.targetKakaoIds&&d.targetKakaoIds.length){ // 대상 지정 알림: 지정된 카카오ID만 수신
            var _myK=String((DB.g('currentUser')||{}).kakaoId||'');
            if(!_myK||d.targetKakaoIds.map(String).indexOf(_myK)<0)return;
          }
          // 수신자 본인이 끈 카테고리는 벨·OS알림 표시 안 함(대상 지정·info 제외) — 개인 알림설정을 수신측에서 적용
          if(!(d.targetKakaoIds&&d.targetKakaoIds.length)&&d.type&&d.type!=='info'&&typeof _notiOn==='function'&&!_notiOn(d.type))return;
          // 앱 내 벨 알림 추가
          const ns=DB.g('notis')||[];
          ns.unshift({id:d.id||Date.now(),msg:d.msg,ico:d.ico,time:d.timeStr||now(),read:false,link:d.link||null});
          if(ns.length>80)ns.splice(80);
          DB.s('notis',ns);updateBell();
          // OS 시스템 알림 (앱이 백그라운드일 때만)
          _showSystemNoti(d.msg,d.ico);
          // 특보(op_*) 알림: 설정 켠 사용자는 본인 카카오톡으로도 수신
          try{if(String(d.type||'').indexOf('op_')===0&&typeof _kakaoMsgOn==='function'&&_kakaoMsgOn()&&typeof _sendKakaoSelf==='function'&&_notiOn(d.type))_sendKakaoSelf(d.msg);}catch(e){}
        });
      },()=>{});
    _migrateLegacyCollections();
    setTimeout(()=>{if(onReady){onReady();onReady=null;}},10000);
  }catch(e){onReady&&onReady();}
}

async function _migrateLegacyCollections(){
  if(!_fdb)return;
  for(const k of _SHARED_COLL){
    try{
      const oldDoc=await _fdb.collection('appData').doc(k).get();
      if(!oldDoc.exists)continue;
      const oldData=JSON.parse(oldDoc.data().d||'[]');
      if(!Array.isArray(oldData)||!oldData.length){
        await _fdb.collection('appData').doc(k).delete();continue;
      }
      // 이미 새 구조에 데이터 있으면 구버전 문서만 삭제
      const existing=await _fdb.collection(k).limit(1).get();
      if(!existing.empty){await _fdb.collection('appData').doc(k).delete();continue;}
      // 배치 마이그레이션 (최대 500건)
      const batch=_fdb.batch();
      oldData.slice(0,500).forEach(r=>batch.set(_fdb.collection(k).doc(String(r.id)),r));
      await batch.commit();
      await _fdb.collection('appData').doc(k).delete();
      console.log(`[마이그레이션] ${k} ${oldData.length}건 개별 문서 이전 완료`);
    }catch(e){console.warn('[마이그레이션 오류]',k,e);}
  }
}

const RES_TYPES={
  '안전사고':{ico:'🤕',pc:'p-acc',color:'#c0392b'},
  '낙석':    {ico:'🪨',pc:'p-rock',color:'#7d3c98'},
  '위험수목':{ico:'🌲',pc:'p-tree',color:'#ca6f1e'},
  '화재':    {ico:'🔥',pc:'p-fire',color:'#a93226'},
  '':    {ico:'🌊',pc:'p-haz', color:'#1a6090'},
  '기타':    {ico:'⚠️',pc:'p-etc', color:'#5d6d7e'},
};
// 관리자가 등록한 커스텀 사고유형 아이콘(공유 customResTypes)을 RES_TYPES에 병합
// — '기타'로 직접 입력한 유형(예: 낙빙)에 전용 아이콘을 줄 수 있음
function _mergeCustomResTypes(){
  try{
    (DB.g('customResTypes')||[]).forEach(t=>{
      if(!t||!t.name)return;
      RES_TYPES[t.name]={ico:t.ico||'⚠️',pc:'p-etc',color:t.color||'#5d6d7e',custom:true};
    });
  }catch(e){}
}

function _ensureSignSeed(){
  // 온라인 모드에서는 인증 완료 + 서버 확정 수신 후에만 — 그 외 어떤 경로로 불려도 시드 금지
  if(_fdb&&(!_authReady||!_facSeedReady))return;
  var _facs=DB.g('facilities')||[];
  var _hasSign=_facs.some(function(f){return f.type&&f.type.indexOf('다목적위치표지판')>=0;});
  if(_hasSign)return;
  var _seed=[{"id":1,"type":"🪧 다목적위치표지판","name":"01-01 청운정 아래500m","lat":38.173718,"lng":128.480326,"loc":"01-01","elev":219,"status":"ok"},{"id":2,"type":"🪧 다목적위치표지판","name":"01-02 청운정","lat":38.173346,"lng":128.47574,"loc":"01-02","elev":239,"status":"ok"},{"id":3,"type":"🪧 다목적위치표지판","name":"01-03 군량장 아래 300m","lat":38.170381,"lng":128.473421,"loc":"01-03","elev":250,"status":"ok"},{"id":4,"type":"🪧 다목적위치표지판","name":"01-04 (와선대 아래 100m","lat":38.166325,"lng":128.471024,"loc":"01-04","elev":267,"status":"ok"},{"id":5,"type":"🪧 다목적위치표지판","name":"01-05 비선대","lat":38.162865,"lng":128.466413,"loc":"01-05","elev":320,"status":"ok"},{"id":6,"type":"🪧 다목적위치표지판","name":"01-06 설악골 위 100m","lat":38.159572,"lng":128.469408,"loc":"01-06","elev":376,"status":"ok"},{"id":7,"type":"🪧 다목적위치표지판","name":"01-07 잦은바위골","lat":38.155681,"lng":128.470476,"loc":"01-07","elev":418,"status":"ok"},{"id":8,"type":"🪧 다목적위치표지판","name":"01-08 귀면암","lat":38.152346,"lng":128.469876,"loc":"01-08","elev":496,"status":"ok"},{"id":9,"type":"🪧 다목적위치표지판","name":"01-09 병풍교","lat":38.150047,"lng":128.472944,"loc":"01-09","elev":530,"status":"ok"},{"id":10,"type":"🪧 다목적위치표지판","name":"01-10 칠선골 아래 100m","lat":38.146238,"lng":128.473648,"loc":"01-10","elev":600,"status":"ok"},{"id":11,"type":"🪧 다목적위치표지판","name":"01-11 오련폭포","lat":38.143603,"lng":128.474455,"loc":"01-11","elev":660,"status":"ok"},{"id":12,"type":"🪧 다목적위치표지판","name":"01-12 양폭대피소","lat":38.139774,"lng":128.47469,"loc":"01-12","elev":709,"status":"ok"},{"id":13,"type":"🪧 다목적위치표지판","name":"01-13 죽음의 계곡 아래 400m","lat":38.136418,"lng":128.473544,"loc":"01-13","elev":798,"status":"ok"},{"id":14,"type":"🪧 다목적위치표지판","name":"01-14 죽음의 계곡 위 100m","lat":38.13374,"lng":128.469714,"loc":"01-14","elev":883,"status":"ok"},{"id":15,"type":"🪧 다목적위치표지판","name":"01-15 무너미고개 아래","lat":38.135076,"lng":128.46466,"loc":"01-15","elev":1069,"status":"ok"},{"id":16,"type":"🪧 다목적위치표지판","name":"01-16 희운각대피소","lat":38.132853,"lng":128.464842,"loc":"01-16","elev":1095,"status":"ok"},{"id":17,"type":"🪧 다목적위치표지판","name":"01-17 사태골 위 200m","lat":38.13034,"lng":128.461456,"loc":"01-17","elev":1251,"status":"ok"},{"id":18,"type":"🪧 다목적위치표지판","name":"01-18 소청 아래 300m","lat":38.12721,"lng":128.458564,"loc":"01-18","elev":1445,"status":"ok"},{"id":19,"type":"🪧 다목적위치표지판","name":"01-19 소청 위 100m","lat":38.12373,"lng":128.457235,"loc":"01-19","elev":1627,"status":"ok"},{"id":20,"type":"🪧 다목적위치표지판","name":"01-20 중청대피소 위 100m","lat":38.120766,"lng":128.462003,"loc":"01-20","elev":1602,"status":"ok"},{"id":21,"type":"🪧 다목적위치표지판","name":"02-01 금강굴 삼거리 위 50m","lat":38.164229,"lng":128.463435,"loc":"02-01","elev":491,"status":"ok"},{"id":22,"type":"🪧 다목적위치표지판","name":"02-02 제1쉼터","lat":38.165649,"lng":128.462028,"loc":"02-02","elev":634,"status":"ok"},{"id":23,"type":"🪧 다목적위치표지판","name":"02-03 제1쉼터 위 500m","lat":38.16608,"lng":128.457469,"loc":"02-03","elev":794,"status":"ok"},{"id":24,"type":"🪧 다목적위치표지판","name":"02-04 샘터 아래500m","lat":38.163876,"lng":128.452519,"loc":"02-04","elev":935,"status":"ok"},{"id":25,"type":"🪧 다목적위치표지판","name":"02-05 샘터","lat":38.161342,"lng":128.447673,"loc":"02-05","elev":963,"status":"ok"},{"id":26,"type":"🪧 다목적위치표지판","name":"02-06 샘터 위500m","lat":38.161155,"lng":128.44155,"loc":"02-06","elev":1129,"status":"ok"},{"id":27,"type":"🪧 다목적위치표지판","name":"02-07 공룡능선 갈림길","lat":38.158086,"lng":128.437903,"loc":"02-07","elev":1209,"status":"ok"},{"id":28,"type":"🪧 다목적위치표지판","name":"02-08 첫능선200m","lat":38.156006,"lng":128.43436,"loc":"02-08","elev":1178,"status":"ok"},{"id":29,"type":"🪧 다목적위치표지판","name":"02-09 오세암 아래400m","lat":38.153822,"lng":128.431494,"loc":"02-09","elev":1024,"status":"ok"},{"id":30,"type":"🪧 다목적위치표지판","name":"02-10 오세암 위100m","lat":38.153225,"lng":128.430556,"loc":"02-10","elev":963,"status":"ok"},{"id":31,"type":"🪧 다목적위치표지판","name":"02-11 만경대 갈림길 아래 100m","lat":38.151083,"lng":128.427951,"loc":"02-11","elev":884,"status":"ok"},{"id":32,"type":"🪧 다목적위치표지판","name":"02-12 원명암터","lat":38.152069,"lng":128.420109,"loc":"02-12","elev":794,"status":"ok"},{"id":33,"type":"🪧 다목적위치표지판","name":"02-13 첫고개쉼터","lat":38.152974,"lng":128.416565,"loc":"02-13","elev":708,"status":"ok"},{"id":34,"type":"🪧 다목적위치표지판","name":"02-14 샘터 위 300m","lat":38.15252,"lng":128.411329,"loc":"02-14","elev":640,"status":"ok"},{"id":35,"type":"🪧 다목적위치표지판","name":"03-01 나한봉","lat":38.154916,"lng":128.438841,"loc":"03-01","elev":1279,"status":"ok"},{"id":36,"type":"🪧 다목적위치표지판","name":"03-02 제3쉼터, 큰바위정상아래100m","lat":38.153187,"lng":128.441108,"loc":"03-02","elev":1201,"status":"ok"},{"id":37,"type":"🪧 다목적위치표지판","name":"03-03 제4쉼지나서 아래100m","lat":38.150306,"lng":128.443895,"loc":"03-03","elev":1203,"status":"ok"},{"id":38,"type":"🪧 다목적위치표지판","name":"03-04 1275고지 아래100m","lat":38.14833,"lng":128.450044,"loc":"03-04","elev":1217,"status":"ok"},{"id":39,"type":"🪧 다목적위치표지판","name":"03-05 샘터입구 위 200m","lat":38.146088,"lng":128.453457,"loc":"03-05","elev":1105,"status":"ok"},{"id":40,"type":"🪧 다목적위치표지판","name":"03-06 강남대 동판","lat":38.142938,"lng":128.454629,"loc":"03-06","elev":1155,"status":"ok"},{"id":41,"type":"🪧 다목적위치표지판","name":"03-07 신선대 아래 500m","lat":38.140757,"lng":128.45799,"loc":"03-07","elev":1129,"status":"ok"},{"id":42,"type":"🪧 다목적위치표지판","name":"03-08 신선대","lat":38.13874,"lng":128.461976,"loc":"03-08","elev":1214,"status":"ok"},{"id":43,"type":"🪧 다목적위치표지판","name":"03-09 무너미정상아래 400m","lat":38.135323,"lng":128.463904,"loc":"03-09","elev":1094,"status":"ok"},{"id":44,"type":"🪧 다목적위치표지판","name":"04-01 안양암","lat":38.177708,"lng":128.483462,"loc":"04-01","elev":239,"status":"ok"},{"id":45,"type":"🪧 다목적위치표지판","name":"04-02 첫교량 끝","lat":38.180858,"lng":128.479667,"loc":"04-02","elev":276,"status":"ok"},{"id":46,"type":"🪧 다목적위치표지판","name":"04-03 가동 휴게소 화장실","lat":38.183441,"lng":128.476513,"loc":"04-03","elev":306,"status":"ok"},{"id":47,"type":"🪧 다목적위치표지판","name":"04-04 전망대","lat":38.187867,"lng":128.475315,"loc":"04-04","elev":388,"status":"ok"},{"id":48,"type":"🪧 다목적위치표지판","name":"04-05 울산바위 유래간판","lat":38.190873,"lng":128.473491,"loc":"04-05","elev":485,"status":"ok"},{"id":49,"type":"🪧 다목적위치표지판","name":"04-06 매점터,철계단 시점","lat":38.20505556,"lng":128.79797222,"loc":"04-06","elev":585,"status":"ok"},{"id":50,"type":"🪧 다목적위치표지판","name":"05-01 가동 휴게소 아래 100m","lat":38.170065,"lng":128.495219,"loc":"05-01","elev":201,"status":"ok"},{"id":51,"type":"🪧 다목적위치표지판","name":"05-02 나동 휴게소 아래 200m","lat":38.168687,"lng":128.500664,"loc":"05-02","elev":179,"status":"ok"},{"id":52,"type":"🪧 다목적위치표지판","name":"05-03 자살탕","lat":38.165785,"lng":128.501889,"loc":"05-03","elev":247,"status":"ok"},{"id":53,"type":"🪧 다목적위치표지판","name":"05-04 비룡폭포","lat":38.162964,"lng":128.502201,"loc":"05-04","elev":281,"status":"ok"},{"id":54,"type":"🪧 다목적위치표지판","name":"06-01 독주골 갈림길 위 250m","lat":38.087797,"lng":128.448537,"loc":"06-01","elev":480,"status":"ok"},{"id":55,"type":"🪧 다목적위치표지판","name":"06-02 돌계단 끝","lat":38.092245,"lng":128.450126,"loc":"06-02","elev":690,"status":"ok"},{"id":56,"type":"🪧 다목적위치표지판","name":"06-03 제1쉼터 위 200m","lat":38.096467,"lng":128.451558,"loc":"06-03","elev":859,"status":"ok"},{"id":57,"type":"🪧 다목적위치표지판","name":"06-04 끝청갈림길 위 300m","lat":38.098362,"lng":128.454893,"loc":"06-04","elev":903,"status":"ok"},{"id":58,"type":"🪧 다목적위치표지판","name":"06-05 설악폭포","lat":38.103345,"lng":128.456638,"loc":"06-05","elev":999,"status":"ok"},{"id":59,"type":"🪧 다목적위치표지판","name":"06-06 물터위 계단 끝","lat":38.105879,"lng":128.459868,"loc":"06-06","elev":1113,"status":"ok"},{"id":60,"type":"🪧 다목적위치표지판","name":"06-07 제2쉼터 아래 200m","lat":38.108556,"lng":128.459998,"loc":"06-07","elev":1256,"status":"ok"},{"id":61,"type":"🪧 다목적위치표지판","name":"06-08 능선끝","lat":38.113456,"lng":128.460649,"loc":"06-08","elev":1492,"status":"ok"},{"id":62,"type":"🪧 다목적위치표지판","name":"06-09 구대청대피소 아래 420m","lat":38.115969,"lng":128.46315,"loc":"06-09","elev":1573,"status":"ok"},{"id":63,"type":"🪧 다목적위치표지판","name":"07-01 매표소 시발 0.5㎞ 지점","lat":38.077336,"lng":128.442598,"loc":"07-01","elev":355,"status":"ok"},{"id":64,"type":"🪧 다목적위치표지판","name":"07-02 오색석사 아래 200m","lat":38.076182,"lng":128.439941,"loc":"07-02","elev":371,"status":"ok"},{"id":65,"type":"🪧 다목적위치표지판","name":"07-03 독주암, 제2약수터 아래 200m","lat":38.078343,"lng":128.437413,"loc":"07-03","elev":385,"status":"ok"},{"id":66,"type":"🪧 다목적위치표지판","name":"07-04 선녀탕 위100m","lat":38.080587,"lng":128.43512,"loc":"07-04","elev":419,"status":"ok"},{"id":67,"type":"🪧 다목적위치표지판","name":"07-05 매표소 시발 2.5㎞ 지점","lat":38.082892,"lng":128.432072,"loc":"07-05","elev":452,"status":"ok"},{"id":68,"type":"🪧 다목적위치표지판","name":"07-06 12폭포 갈림길","lat":38.083242,"lng":128.430483,"loc":"07-06","elev":462,"status":"ok"},{"id":69,"type":"🪧 다목적위치표지판","name":"08-01 12폭포 아래 500m","lat":38.081944,"lng":128.427122,"loc":"08-01","elev":537,"status":"ok"},{"id":70,"type":"🪧 다목적위치표지판","name":"08-02 12폭포","lat":38.07937,"lng":128.42608,"loc":"08-02","elev":602,"status":"ok"},{"id":71,"type":"🪧 다목적위치표지판","name":"08-03 무명폭포 하향 200m","lat":38.08044,"lng":128.423813,"loc":"08-03","elev":620,"status":"ok"},{"id":72,"type":"🪧 다목적위치표지판","name":"08-04 등선폭포","lat":38.080789,"lng":128.419306,"loc":"08-04","elev":769,"status":"ok"},{"id":73,"type":"🪧 다목적위치표지판","name":"08-05 금강문 시발 2.5km(등선대 정상)","lat":38.083671,"lng":128.417325,"loc":"08-05","elev":956,"status":"ok"},{"id":74,"type":"🪧 다목적위치표지판","name":"08-06 칠형제봉 입구","lat":38.086039,"lng":128.416179,"loc":"08-06","elev":839,"status":"ok"},{"id":75,"type":"🪧 다목적위치표지판","name":"08-07 흘림골매표소 상향 제1교량","lat":38.087871,"lng":128.417377,"loc":"08-07","elev":772,"status":"ok"},{"id":76,"type":"🪧 다목적위치표지판","name":"09-01 첫고개 위 100m","lat":38.100203,"lng":128.409455,"loc":"09-01","elev":1085,"status":"ok"},{"id":77,"type":"🪧 다목적위치표지판","name":"09-02 첫고개 위 100m","lat":38.10358,"lng":128.41206,"loc":"09-02","elev":1299,"status":"ok"},{"id":78,"type":"🪧 다목적위치표지판","name":"09-03 상투바 아래 100m","lat":38.108377,"lng":128.410679,"loc":"09-03","elev":1292,"status":"ok"},{"id":79,"type":"🪧 다목적위치표지판","name":"09-04 샘터","lat":38.110374,"lng":128.410132,"loc":"09-04","elev":1268,"status":"ok"},{"id":80,"type":"🪧 다목적위치표지판","name":"09-05 왕주목 아래 100m","lat":38.112063,"lng":128.410236,"loc":"09-05","elev":1353,"status":"ok"},{"id":81,"type":"🪧 다목적위치표지판","name":"09-06 왕주목 위 400m","lat":38.111282,"lng":128.416645,"loc":"09-06","elev":1324,"status":"ok"},{"id":82,"type":"🪧 다목적위치표지판","name":"09-07 1379봉 아래 100m","lat":38.110274,"lng":128.421674,"loc":"09-07","elev":1391,"status":"ok"},{"id":83,"type":"🪧 다목적위치표지판","name":"09-08 헬기장, 제2전망대","lat":38.109432,"lng":128.427041,"loc":"09-08","elev":1450,"status":"ok"},{"id":84,"type":"🪧 다목적위치표지판","name":"09-09 쉼터아래 500m","lat":38.110071,"lng":128.43061,"loc":"09-09","elev":1421,"status":"ok"},{"id":85,"type":"🪧 다목적위치표지판","name":"09-10 1쉼터","lat":38.112214,"lng":128.437488,"loc":"09-10","elev":1461,"status":"ok"},{"id":86,"type":"🪧 다목적위치표지판","name":"09-11 독주골","lat":38.115139,"lng":128.441708,"loc":"09-11","elev":1452,"status":"ok"},{"id":87,"type":"🪧 다목적위치표지판","name":"09-12 끝청아래 400m","lat":38.11617,"lng":128.448039,"loc":"09-12","elev":1496,"status":"ok"},{"id":88,"type":"🪧 다목적위치표지판","name":"09-13 끝청 위 100m","lat":38.116624,"lng":128.451661,"loc":"09-13","elev":1598,"status":"ok"},{"id":89,"type":"🪧 다목적위치표지판","name":"09-14 중청 정상 아래 300m","lat":38.119302,"lng":128.45463,"loc":"09-14","elev":1596,"status":"ok"},{"id":90,"type":"🪧 다목적위치표지판","name":"10-01 셔틀버스 종점 위 500m","lat":38.175507,"lng":128.372925,"loc":"10-01","elev":452,"status":"ok"},{"id":91,"type":"🪧 다목적위치표지판","name":"10-02 셔틀버스 종점 시발1.0㎞ 지점","lat":38.170978,"lng":128.372351,"loc":"10-02","elev":471,"status":"ok"},{"id":92,"type":"🪧 다목적위치표지판","name":"10-03 셔틀버스 종점 시발1.5㎞ 지점","lat":38.168363,"lng":128.371283,"loc":"10-03","elev":489,"status":"ok"},{"id":93,"type":"🪧 다목적위치표지판","name":"10-04 셔틀버스 종점 시발2.0㎞ 지점","lat":38.169578,"lng":128.375608,"loc":"10-04","elev":519,"status":"ok"},{"id":94,"type":"🪧 다목적위치표지판","name":"10-05 셔틀버스 종점 시발2.5㎞ 지점","lat":38.167891,"lng":128.37936,"loc":"10-05","elev":489,"status":"ok"},{"id":95,"type":"🪧 다목적위치표지판","name":"10-06 대피소 아래 500m","lat":38.164905,"lng":128.376207,"loc":"10-06","elev":494,"status":"ok"},{"id":96,"type":"🪧 다목적위치표지판","name":"10-07 백담대피소","lat":38.160108,"lng":128.374905,"loc":"10-07","elev":502,"status":"ok"},{"id":97,"type":"🪧 다목적위치표지판","name":"10-08 길골 아래 200m","lat":38.157452,"lng":128.375296,"loc":"10-08","elev":504,"status":"ok"},{"id":98,"type":"🪧 다목적위치표지판","name":"10-09 길골 위 300m","lat":38.15628,"lng":128.380897,"loc":"10-09","elev":517,"status":"ok"},{"id":99,"type":"🪧 다목적위치표지판","name":"10-10 셔틀버스 종점 시발5.0㎞ 지점","lat":38.156816,"lng":128.386082,"loc":"10-10","elev":492,"status":"ok"},{"id":100,"type":"🪧 다목적위치표지판","name":"10-11 셔틀버스 종점 시발5.5㎞ 지점","lat":38.153276,"lng":128.389078,"loc":"10-11","elev":505,"status":"ok"},{"id":101,"type":"🪧 다목적위치표지판","name":"10-12 셔틀버스 종점 시발6.0㎞ 지점","lat":38.152989,"lng":128.394159,"loc":"10-12","elev":566,"status":"ok"},{"id":102,"type":"🪧 다목적위치표지판","name":"10-13 영시암 아래 500m","lat":38.152579,"lng":128.399891,"loc":"10-13","elev":554,"status":"ok"},{"id":103,"type":"🪧 다목적위치표지판","name":"10-14 영시암","lat":38.153527,"lng":128.405154,"loc":"10-14","elev":564,"status":"ok"},{"id":104,"type":"🪧 다목적위치표지판","name":"10-15 영시암 위 500m","lat":38.150234,"lng":128.408359,"loc":"10-15","elev":582,"status":"ok"},{"id":105,"type":"🪧 다목적위치표지판","name":"10-16 수렴동대피소 밑 200m","lat":38.146899,"lng":128.411954,"loc":"10-16","elev":598,"status":"ok"},{"id":106,"type":"🪧 다목적위치표지판","name":"10-17 수렴동대피소 위 300m","lat":38.145418,"lng":128.415471,"loc":"10-17","elev":583,"status":"ok"},{"id":107,"type":"🪧 다목적위치표지판","name":"10-18 셔틀버스 종점 시발 9.0㎞ 지점","lat":38.143215,"lng":128.415628,"loc":"10-18","elev":595,"status":"ok"},{"id":108,"type":"🪧 다목적위치표지판","name":"10-19 만수담 아래 500m","lat":38.14128,"lng":128.415185,"loc":"10-19","elev":605,"status":"ok"},{"id":109,"type":"🪧 다목적위치표지판","name":"10-20 만수담","lat":38.138748,"lng":128.416747,"loc":"10-20","elev":639,"status":"ok"},{"id":110,"type":"🪧 다목적위치표지판","name":"10-21 백운동 아래 400m","lat":38.136607,"lng":128.419145,"loc":"10-21","elev":688,"status":"ok"},{"id":111,"type":"🪧 다목적위치표지판","name":"10-22 백운동 위 100m","lat":38.135785,"lng":128.423366,"loc":"10-22","elev":715,"status":"ok"},{"id":112,"type":"🪧 다목적위치표지판","name":"10-23 관음폭포 아래 400m","lat":38.133644,"lng":128.425945,"loc":"10-23","elev":756,"status":"ok"},{"id":113,"type":"🪧 다목적위치표지판","name":"10-24 관음폭포 위 100m","lat":38.132595,"lng":128.430374,"loc":"10-24","elev":832,"status":"ok"},{"id":114,"type":"🪧 다목적위치표지판","name":"10-25 쌍폭","lat":38.131196,"lng":128.433501,"loc":"10-25","elev":901,"status":"ok"},{"id":115,"type":"🪧 다목적위치표지판","name":"10-26 쌍폭 위 500m","lat":38.130203,"lng":128.437931,"loc":"10-26","elev":974,"status":"ok"},{"id":116,"type":"🪧 다목적위치표지판","name":"10-27 사자바위 아래 100m","lat":38.128132,"lng":128.444052,"loc":"10-27","elev":1141,"status":"ok"},{"id":117,"type":"🪧 다목적위치표지판","name":"10-28 봉정암 아래 100m","lat":38.128647,"lng":128.44671,"loc":"10-28","elev":1232,"status":"ok"},{"id":118,"type":"🪧 다목적위치표지판","name":"10-29 소청대피소 아래 300m","lat":38.127557,"lng":128.450982,"loc":"10-29","elev":1387,"status":"ok"},{"id":119,"type":"🪧 다목적위치표지판","name":"10-30 소청대피소 위 200m","lat":38.12611111,"lng":128.45611111,"loc":"10-30","elev":1534,"status":"ok"},{"id":120,"type":"🪧 다목적위치표지판","name":"11-01 사중폭포 위 200m","lat":38.121889,"lng":128.344708,"loc":"11-01","elev":584,"status":"ok"},{"id":121,"type":"🪧 다목적위치표지판","name":"11-02 사중폭포 위 100m","lat":38.125471,"lng":128.343197,"loc":"11-02","elev":785,"status":"ok"},{"id":122,"type":"🪧 다목적위치표지판","name":"11-03 마지막 물터 아래 300m","lat":38.129012,"lng":128.34192,"loc":"11-03","elev":788,"status":"ok"},{"id":123,"type":"🪧 다목적위치표지판","name":"11-04 마지막물터 위 200m","lat":38.131772,"lng":128.344916,"loc":"11-04","elev":890,"status":"ok"},{"id":124,"type":"🪧 다목적위치표지판","name":"11-05 대승령 아래 200m","lat":38.135334,"lng":128.346584,"loc":"11-05","elev":1041,"status":"ok"},{"id":125,"type":"🪧 다목적위치표지판","name":"11-06 대승령→ 남교리 300m","lat":38.138627,"lng":128.342389,"loc":"11-06","elev":1242,"status":"ok"},{"id":126,"type":"🪧 다목적위치표지판","name":"11-07 안산갈림길→ 남교리 300m","lat":38.139779,"lng":128.338168,"loc":"11-07","elev":1353,"status":"ok"},{"id":127,"type":"🪧 다목적위치표지판","name":"11-08 분소 시발 4.0㎞ 지점(능선끝 쉼터)","lat":38.14262,"lng":128.338272,"loc":"11-08","elev":1335,"status":"ok"},{"id":128,"type":"🪧 다목적위치표지판","name":"11-09 마지막물터→ 대승령 300m","lat":38.143772,"lng":128.334077,"loc":"11-09","elev":1212,"status":"ok"},{"id":129,"type":"🪧 다목적위치표지판","name":"11-10 마지막물터→ 남교리 200m","lat":38.147519,"lng":128.332045,"loc":"11-10","elev":1102,"status":"ok"},{"id":130,"type":"🪧 다목적위치표지판","name":"11-11 주목→ 남교리 100m","lat":38.151637,"lng":128.332957,"loc":"11-11","elev":1021,"status":"ok"},{"id":131,"type":"🪧 다목적위치표지판","name":"11-12 감투바위","lat":38.155404,"lng":128.331654,"loc":"11-12","elev":975,"status":"ok"},{"id":132,"type":"🪧 다목적위치표지판","name":"11-13 두문폭포→ 대승령 200m","lat":38.157977,"lng":128.327798,"loc":"11-13","elev":863,"status":"ok"},{"id":133,"type":"🪧 다목적위치표지판","name":"11-14 복숭아탕→ 대승령 200m","lat":38.159973,"lng":128.323186,"loc":"11-14","elev":793,"status":"ok"},{"id":134,"type":"🪧 다목적위치표지판","name":"11-15 무명폭포","lat":38.16166,"lng":128.321206,"loc":"11-15","elev":715,"status":"ok"},{"id":135,"type":"🪧 다목적위치표지판","name":"11-16 제6교량→ 대승령 100m","lat":38.164666,"lng":128.318731,"loc":"11-16","elev":678,"status":"ok"},{"id":136,"type":"🪧 다목적위치표지판","name":"11-17 너래반석→ 남교리 200m","lat":38.171418,"lng":128.314666,"loc":"11-17","elev":540,"status":"ok"},{"id":137,"type":"🪧 다목적위치표지판","name":"11-18 응봉폭포","lat":38.174361,"lng":128.312035,"loc":"11-18","elev":476,"status":"ok"},{"id":138,"type":"🪧 다목적위치표지판","name":"11-19 제5교량","lat":38.17541,"lng":128.307736,"loc":"11-19","elev":430,"status":"ok"},{"id":139,"type":"🪧 다목적위치표지판","name":"11-20 4교량→ 남교리 200m","lat":38.174627,"lng":128.305625,"loc":"11-20","elev":419,"status":"ok"},{"id":140,"type":"🪧 다목적위치표지판","name":"11-21 추모비→ 남교리 100m","lat":38.175862,"lng":128.303593,"loc":"11-21","elev":368,"status":"ok"},{"id":141,"type":"🪧 다목적위치표지판","name":"11-22 남교리매표소→ 대승령 300m","lat":38.179465,"lng":128.301717,"loc":"11-22","elev":341,"status":"ok"},{"id":142,"type":"🪧 다목적위치표지판","name":"12-09 대승령 위100m","lat":38.136837,"lng":128.347365,"loc":"12-09","elev":1235,"status":"ok"},{"id":143,"type":"🪧 다목적위치표지판","name":"12-10 백담대피소 시발 5.0㎞ 지점","lat":38.135458,"lng":128.350726,"loc":"12-10","elev":1198,"status":"ok"},{"id":144,"type":"🪧 다목적위치표지판","name":"12-11 백담대피소 시발 5.5㎞ 지점","lat":38.135027,"lng":128.356094,"loc":"12-11","elev":1304,"status":"ok"},{"id":145,"type":"🪧 다목적위치표지판","name":"12-12 백담대피소 시발 6.0㎞ 지점","lat":38.131322,"lng":128.357709,"loc":"12-12","elev":1269,"status":"ok"},{"id":146,"type":"🪧 다목적위치표지판","name":"12-13 백담대피소 시발 6.5㎞ 지점","lat":38.128851,"lng":128.359585,"loc":"12-13","elev":1274,"status":"ok"},{"id":147,"type":"🪧 다목적위치표지판","name":"12-14 1408고지","lat":38.128235,"lng":128.364041,"loc":"12-14","elev":1233,"status":"ok"},{"id":148,"type":"🪧 다목적위치표지판","name":"12-15 백담대피소 시발 7.5㎞ 지점","lat":38.124532,"lng":128.377693,"loc":"12-15","elev":1339,"status":"ok"},{"id":149,"type":"🪧 다목적위치표지판","name":"12-16 백담대피소 시발 8.0㎞ 지점","lat":38.123467,"lng":128.382941,"loc":"12-16","elev":1389,"status":"ok"},{"id":150,"type":"🪧 다목적위치표지판","name":"12-17 백담대피소 시발 8.5㎞ 지점","lat":38.123319,"lng":128.387724,"loc":"12-17","elev":1471,"status":"ok"},{"id":151,"type":"🪧 다목적위치표지판","name":"12-18 백담대피소 시발 9.0㎞ 지점","lat":38.124021,"lng":128.393508,"loc":"12-18","elev":1314,"status":"ok"},{"id":152,"type":"🪧 다목적위치표지판","name":"12-19 백담대피소 시발 9.5㎞ 지점","lat":38.122416,"lng":128.397052,"loc":"12-19","elev":1445,"status":"ok"},{"id":153,"type":"🪧 다목적위치표지판","name":"12-20 백담대피소 시발 10.0㎞ 지점","lat":38.119884,"lng":128.398954,"loc":"12-20","elev":1492,"status":"ok"},{"id":154,"type":"🪧 다목적위치표지판","name":"12-21 백담대피소 시발 10.5㎞ 지점","lat":38.116487,"lng":128.401664,"loc":"12-21","elev":1384,"status":"ok"},{"id":155,"type":"🪧 다목적위치표지판","name":"12-22 백담대피소 시발 11.0㎞ 지점","lat":38.114141,"lng":128.406223,"loc":"12-22","elev":1278,"status":"ok"},{"id":156,"type":"🪧 다목적위치표지판","name":"13-01 오세암 시발 0.5km 지점","lat":38.148634,"lng":128.43165,"loc":"13-01","elev":865,"status":"ok"},{"id":157,"type":"🪧 다목적위치표지판","name":"13-02 오세암 시발 1.0km 지점","lat":38.146721,"lng":128.435845,"loc":"13-02","elev":891,"status":"ok"},{"id":158,"type":"🪧 다목적위치표지판","name":"13-03 오세암 시발 1.5km 지점","lat":38.145281,"lng":128.439232,"loc":"13-03","elev":919,"status":"ok"},{"id":159,"type":"🪧 다목적위치표지판","name":"13-04 고갯마루 쉼터","lat":38.143017,"lng":128.444416,"loc":"13-04","elev":970,"status":"ok"},{"id":160,"type":"🪧 다목적위치표지판","name":"13-05 가야동계곡 사거리","lat":38.141041,"lng":128.445433,"loc":"13-05","elev":858,"status":"ok"},{"id":161,"type":"🪧 다목적위치표지판","name":"13-06 오세암 시발 3.0km 지점","lat":38.137665,"lng":128.445745,"loc":"13-06","elev":936,"status":"ok"},{"id":162,"type":"🪧 다목적위치표지판","name":"13-07 오세암 시발 3.5km 지점","lat":38.132538,"lng":128.446319,"loc":"13-07","elev":1045,"status":"ok"},{"id":163,"type":"🪧 다목적위치표지판","name":"14-01 곰배골지킴터 상단 400m","lat":38.0190743,"lng":128.40738772,"loc":"14-01","elev":632,"status":"ok"},{"id":164,"type":"🪧 다목적위치표지판","name":"14-02 곰배골지킴터 상단 700m","lat":38.01985338,"lng":128.41045271,"loc":"14-02","elev":652,"status":"ok"},{"id":165,"type":"🪧 다목적위치표지판","name":"14-03 곰배골지킴터 상단 1.2km","lat":38.0206789,"lng":128.4155566,"loc":"14-03","elev":720,"status":"ok"},{"id":166,"type":"🪧 다목적위치표지판","name":"14-04 곰배골지킴터 상단 1.7km","lat":38.02159347,"lng":128.42066956,"loc":"14-04","elev":785,"status":"ok"},{"id":167,"type":"🪧 다목적위치표지판","name":"14-05 곰배골지킴터 상단 2.2km","lat":38.02233403,"lng":128.42556115,"loc":"14-05","elev":856,"status":"ok"},{"id":168,"type":"🪧 다목적위치표지판","name":"14-06 곰배골지킴터 상단 2.8km","lat":38.02326768,"lng":128.43052776,"loc":"14-06","elev":940,"status":"ok"},{"id":169,"type":"🪧 다목적위치표지판","name":"14-07 곰배골지킴터 상단 3.2km","lat":38.02692511,"lng":128.43100905,"loc":"14-07","elev":1089,"status":"ok"},{"id":170,"type":"🪧 다목적위치표지판","name":"08-08","lat":38.088614,"lng":128.421311,"loc":"08-08","elev":0,"status":"ok"},{"id":171,"type":"🪧 다목적위치표지판","name":"12-01 흑선동계곡비탐","lat":38.153952,"lng":128.375739,"loc":"12-01","elev":0,"status":"ok"},{"id":172,"type":"🪧 다목적위치표지판","name":"12-02 흑선동계곡비탐","lat":38.153951,"lng":128.372482,"loc":"12-02","elev":0,"status":"ok"},{"id":173,"type":"🪧 다목적위치표지판","name":"12-03 흑선동계곡비탐","lat":38.15045,"lng":128.368105,"loc":"12-03","elev":0,"status":"ok"},{"id":174,"type":"🪧 다목적위치표지판","name":"12-05 흑선동계곡비탐","lat":38.148019,"lng":128.359142,"loc":"12-05","elev":0,"status":"ok"},{"id":175,"type":"🪧 다목적위치표지판","name":"12-06 흑선동계곡비탐","lat":38.145115,"lng":128.355129,"loc":"12-06","elev":0,"status":"ok"},{"id":176,"type":"🪧 다목적위치표지판","name":"12-07 흑선동계곡비탐","lat":38.142191,"lng":128.352446,"loc":"12-07","elev":0,"status":"ok"},{"id":177,"type":"🪧 다목적위치표지판","name":"12-08 흑선동계곡비탐","lat":38.139514,"lng":128.349736,"loc":"12-08","elev":0,"status":"ok"}];
  var _maxId=_facs.reduce(function(mx,f){return Math.max(mx,Number(f.id)||0);},0);
  var _seeded=_seed.map(function(s,i){var o=Object.assign({},s,{id:_maxId+1+i});delete o.status;return o;}); // status는 폐지된 레거시 필드
  DB.s('facilities',_facs.concat(_seeded));
}
function initDB(){
  // ⚠️ 인증(익명/커스텀 토큰) 준비 전에는 시드·마이그레이션 쓰기를 하지 않는다.
  // Firestore onSnapshot은 로컬 캐시에서 인증 완료 전에도 먼저 발화 → initDB가 인증 전에 돌면
  // 없는 문서의 기본값 쓰기가 실패해 '동기화 대기' 큐에 쌓이고, 문서가 안 생겨 매 접속마다 재시드됐다.
  // 인증 완료 후 실행하면 쓰기가 곧바로 성공 → 큐·배지 없음, 문서 생성되어 재시드도 안 됨.
  if(_fdb&&!_authReady){
    window._initDBWaitN=(window._initDBWaitN||0)+1;
    if(window._initDBWaitN<=30){setTimeout(initDB,300);return;} // 최대 ~9초 대기, 그 뒤엔 진행(오프라인 등)
  }
  if(!DB.g('catFac'))     DB.s('catFac',['🪧 다목적위치표지판','📍 장소','🛤️ 데크/계단','🌉 교량','🏠 대피소','🛡️ 안전난간','🪵 목재계단','🚿 계곡시설']);
  // 카테고리 마이그레이션: 위치표지판 제거, 장소 추가
  (function(){var c=DB.g('catFac');if(!c)return;var c2=c.filter(function(x){return x!=='🪧 위치표지판';});if(!c2.includes('📍 장소'))c2.splice(1,0,'📍 장소');if(c2.length!==c.length||!c.includes('📍 장소'))DB.s('catFac',c2);})();
  // 이모지 없는 카테고리명 마이그레이션 (catFac + facilities + catFacMeta)
  (function(){var map={'분소':'🏠 분소','암빙벽':'🧗 암빙벽'};var c=DB.g('catFac');if(c){var changed=false;var c2=c.map(function(x){return map[x]?(changed=true,map[x]):x;});if(changed)DB.s('catFac',c2);}var facs=DB.g('facilities');if(facs){var fc=false;var f2=facs.map(function(f){if(map[f.type]){fc=true;return Object.assign({},f,{type:map[f.type]});}return f;});if(fc)DB.s('facilities',f2);}var m=DB.g('catFacMeta')||{};var mc=false;Object.keys(map).forEach(function(old){if(m[old]){m[map[old]]=m[old];delete m[old];mc=true;}});if(mc)DB.s('catFacMeta',m);})(); // ← 변경 있을 때만 저장(예전엔 무조건 저장 → 매 부팅 서버 쓰기 유발)
  // 탐방지원센터 분리 마이그레이션
  (function(){
    var c=DB.g('catFac')||[];var meta=DB.g('catFacMeta')||{};var changed=false;
    // 1) 결합된 카테고리명(분소+탐방지원센터) 처리: 분소만 남기고 탐방지원센터 분리
    var c2=[];c.forEach(function(x){
      if(x.includes('탐방지원센터')&&x.includes('분소')){
        var boso=x.replace(/\/?탐방지원센터\/?/g,'').trim()||'🏠 분소';
        if(!c2.some(function(v){return v===boso;}))c2.push(boso);
        changed=true;
      } else {c2.push(x);}
    });
    // 2) 탐방지원센터 단독 카테고리 없으면 추가
    if(!c2.some(function(x){return x.includes('탐방지원센터');})){c2.push('🛖 탐방지원센터');changed=true;}
    // 3) 이모지 없는 '탐방지원센터' → '🛖 탐방지원센터'
    c2=c2.map(function(x){if(x==='탐방지원센터'){changed=true;return '🛖 탐방지원센터';}return x;});
    if(changed)DB.s('catFac',c2);
    // 4) facilities type도 동일하게 수정
    var facs=DB.g('facilities');if(facs){var fc=false;var f2=facs.map(function(f){
      if(f.type&&f.type.includes('탐방지원센터')&&f.type.includes('분소')){fc=true;return Object.assign({},f,{type:'🛖 탐방지원센터'});}
      if(f.type==='탐방지원센터'){fc=true;return Object.assign({},f,{type:'🛖 탐방지원센터'});}
      return f;});if(fc)DB.s('facilities',f2);}
    // 5) catFacMeta 키 이전
    if(meta['탐방지원센터']){meta['🛖 탐방지원센터']=meta['탐방지원센터'];delete meta['탐방지원센터'];DB.s('catFacMeta',meta);}
  })();
  // catFacMeta 초기화 (재난지도 표시 여부 + 관리자 전용 여부)
  (function(){var m=DB.g('catFacMeta')||{};var changed=false;var def={'🪧 다목적위치표지판':{rescue:true,adminOnly:false},'📍 장소':{rescue:true,adminOnly:true},'🏠 대피소':{rescue:true,adminOnly:false}};Object.keys(def).forEach(function(k){if(!m[k]){m[k]=def[k];changed=true;}});if(changed)DB.s('catFacMeta',m);})();
  // 사찰 카테고리 마이그레이션: catFac 목록에서 암/사로 끝나는 항목 제거하고 🛕 사찰로 통합 (1회성)
  (function(){
    var TEMPLE='🛕 사찰';
    var isTemple=function(s){var t=s.replace(/^[\s\S]*\s/,'');return /암$|사$/.test(t);};
    var c=DB.g('catFac')||[];var cm=false;
    // 사찰 항목 없으면 추가
    if(!c.includes(TEMPLE)){c.push(TEMPLE);cm=true;}
    // 암/사로 끝나는 catFac 항목 제거 (카테고리 목록만 정리, 시설물 타입은 건드리지 않음)
    var c2=c.filter(function(x){if(x===TEMPLE)return true;var name=x.replace(/^[^\s]+\s/,'');if(isTemple(name)){cm=true;return false;}return true;});
    if(cm)DB.s('catFac',c2);
  })();
  // 다목적위치표지판 시드: 표지판이 하나도 없으면 1회 주입 (null·빈배열·전체삭제 모두 복원)
  if(!_fdb||_facSeedReady)_ensureSignSeed(); // 시드 레이스 방지 + 중복 시드 IIFE 제거(일원화)
  if(!DB.g('rescues'))    DB.s('rescues',[]);
  if(!DB.g('hazards'))    DB.s('hazards',[]);
  if(!DB.g('history'))    DB.s('history',[]);
  // ※ alertOps·alertLog·climbDates·climbCancels 빈 껍데기 시드는 제거 —
  //   모든 읽기가 ||[] / ||{} 폴백을 갖고 있어 서버 문서가 없어도 정상 동작.
  //   (첫 접속 기기가 아무 입력 없이 서버에 빈 문서를 쓰던 불필요 동기화의 원인이었음.
  //    각 문서는 실제 데이터가 처음 생길 때 그 쓰기로 자연 생성됨)
  if(!DB.g('notis'))         DB.s('notis',[]);
  if(!DB.g('notiSetting'))   DB.s('notiSetting',{});
  _ensureNotiDefaults();
  if(!DB.g('currentUser'))   DB.s('currentUser',{name:'',dept:'',rank:'',kakao:null});
  // 인증 대기로 지연 실행됐다면 시드 반영 위해 화면 갱신 (첫 호출이면 부팅 흐름이 이어서 갱신하므로 무해)
  if(window._initDBWaitN){try{updateSummary();}catch(e){}try{updateUserUI();}catch(e){}}
}

// ══════════════════════════════════════════
// 유틸
// ══════════════════════════════════════════
const pad=n=>String(n).padStart(2,'0');
// 생년월일(YYYY...) → 만 나이(연도 기준). 값 없으면 '' 반환
function _ageFromBirth(b){if(!b)return '';const y=parseInt(String(b).slice(0,4));const cy=new Date().getFullYear();if(isNaN(y)||y<1900||y>cy)return '';return cy-y;}
// 생년월일 텍스트 입력 자동 포매팅: 숫자만 입력 → YYYY-MM-DD 삽입
function _fmtBirth(el){
  const c=el.selectionStart;
  let v=el.value.replace(/\D/g,'').slice(0,8);
  let fmt='';
  if(v.length>4)fmt=v.slice(0,4)+'-'+v.slice(4);else fmt=v;
  if(v.length>6)fmt=v.slice(0,4)+'-'+v.slice(4,6)+'-'+v.slice(6);
  el.value=fmt;
  try{el.setSelectionRange(c+(fmt.length-el.value.length+1>0?1:0),c+(fmt.length-el.value.length+1>0?1:0));}catch(e){}
}
function now(){const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+' '+pad(d.getHours())+':'+pad(d.getMinutes());}
function _debounce(fn,ms){let t;return function(...a){clearTimeout(t);t=setTimeout(()=>fn.apply(this,a),ms);};}
// '2026-06-12 14:30' → '2시간 13분 경과' (골든타임 표시용)
function _elapsedStr(dateStr){
  try{
    const t=new Date(String(dateStr).replace(' ','T'));
    let m=Math.floor((Date.now()-t.getTime())/60000);
    if(isNaN(m)||m<0)return'';
    const d=Math.floor(m/1440);m-=d*1440;const h=Math.floor(m/60);m-=h*60;
    return(d?d+'일 ':'')+(h?h+'시간 ':'')+m+'분 경과';
  }catch(e){return'';}
}
function today(){return now().slice(0,10);}
// 진행중 경과시간 라이브 갱신: '.js-elapsed[data-d]' 요소의 텍스트를 주기적으로 다시 계산.
// (경과시간은 분 단위라 30초 간격이면 충분 — 새로고침 없이 자동으로 시간이 올라감)
function _tickElapsed(){
  try{
    document.querySelectorAll('.js-elapsed[data-d]').forEach(function(el){
      var v=_elapsedStr(el.getAttribute('data-d'));
      if(v)el.textContent='⏱ '+v;
    });
  }catch(e){}
}
if(!window._elapsedTimer)window._elapsedTimer=setInterval(_tickElapsed,30000);
function nowDT(){
  const d=new Date();
  return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes());
}
var _toastTimer=null;
// 진행 중 표시(스피너 오버레이) — 작업이 끝날 때까지 유지. _busy(문구) 로 열고 _busyDone() 로 닫는다.
function _busy(msg){
  var el=document.getElementById('_busyOv');
  if(!el){el=document.createElement('div');el.id='_busyOv';
    el.style.cssText='position:fixed;inset:0;z-index:99995;background:rgba(4,10,20,.55);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(1px);';
    el.innerHTML='<div style="background:#1c1c1e;border:1px solid rgba(255,255,255,.3);border-radius:14px;padding:20px 26px;display:flex;flex-direction:column;align-items:center;gap:13px;box-shadow:0 10px 34px rgba(0,0,0,.6);max-width:78vw;"><div style="width:30px;height:30px;border:3px solid rgba(255,255,255,.2);border-top-color:#3182f6;border-radius:50%;animation:spin .8s linear infinite;"></div><div id="_busyMsg" style="font-size:13px;color:#d5d8dc;font-weight:600;text-align:center;line-height:1.5;"></div><button id="_busyClose" onclick="_busyDone()" style="display:none;margin-top:2px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.32);color:#c4c8ce;border-radius:8px;padding:8px 18px;font-size:12px;font-weight:700;cursor:pointer;">닫기</button></div>';
    document.body.appendChild(el);}
  var m=el.querySelector('#_busyMsg');if(m)m.textContent=msg||'처리 중…';
  el.style.display='flex';
  // 작업이 6초 넘게 걸리면 수동 '닫기' 노출 — 어떤 이유로 멈춰도 발견하기 어려운 3연타 대신 바로 빠져나갈 수 있게
  var _cb=el.querySelector('#_busyClose');if(_cb)_cb.style.display='none';
  if(window._busyCloseTimer)clearTimeout(window._busyCloseTimer);
  window._busyCloseTimer=setTimeout(function(){var b=document.getElementById('_busyClose');if(b)b.style.display='block';},6000);
  // 안전장치: 작업이 실패해 _busyDone()이 안 불려도 25초 뒤 자동 해제 — 전체화면 스피너가 앱을 영구 먹통시키는 것 방지
  if(window._busyTimer)clearTimeout(window._busyTimer);
  window._busyTimer=setTimeout(function(){try{_busyDone();console.warn('[busy] 타임아웃 자동 해제');}catch(_){}},25000);
}
function _busyDone(){var el=document.getElementById('_busyOv');if(el)el.style.display='none';if(window._busyTimer){clearTimeout(window._busyTimer);window._busyTimer=null;}if(window._busyCloseTimer){clearTimeout(window._busyCloseTimer);window._busyCloseTimer=null;}}
function toast(m,dur){const t=document.getElementById('toast');t.textContent=m;t.classList.add('on');clearTimeout(_toastTimer);
  // 중요 메시지(실패·경고·오류)는 자동으로 4초간 표시 — 놓치지 않도록
  if(dur===undefined){dur=(/실패|오류|⚠️|에러|불가|없습니다|권한/.test(String(m)))?4000:2200;}
  _toastTimer=setTimeout(()=>t.classList.remove('on'),dur);}
// 햅틱(진동) 피드백 — 제출·발령 등 핵심 액션에서 짧게. 미지원 기기는 조용히 무시(iOS 웹 등)
function _hapt(p){try{if(navigator.vibrate)navigator.vibrate(p||8);}catch(e){}}
// 전화번호 하이픈 포맷(표시용) — 01093608848 → 010-9360-8848. 매칭 안 되면 원본 유지(국제번호·이미 포맷·비전화 안전)
function _fmtTel(s){
  if(s==null)return s;
  var raw=String(s).trim();if(!raw||raw[0]==='+')return raw; // 빈값·국제번호 그대로
  var d=raw.replace(/[^0-9]/g,'');if(!d)return raw;
  if(/^01[016789]\d{7,8}$/.test(d))return d.length===11?d.replace(/^(\d{3})(\d{4})(\d{4})$/,'$1-$2-$3'):d.replace(/^(\d{3})(\d{3})(\d{4})$/,'$1-$2-$3');
  if(/^02\d{7,8}$/.test(d))return d.length===10?d.replace(/^(02)(\d{4})(\d{4})$/,'$1-$2-$3'):d.replace(/^(02)(\d{3})(\d{4})$/,'$1-$2-$3');
  if(/^0\d{9,10}$/.test(d))return d.length===11?d.replace(/^(\d{3})(\d{4})(\d{4})$/,'$1-$2-$3'):d.replace(/^(\d{3})(\d{3})(\d{4})$/,'$1-$2-$3');
  if(/^1[568]\d{6}$/.test(d))return d.replace(/^(\d{4})(\d{4})$/,'$1-$2'); // 15XX/16XX/18XX 대표번호
  return raw;
}
// 숫자 카운트업 — 홈 요약 등에서 값이 바뀔 때 촤르륵 올라가는 연출(숫자 아님/첫 표시면 즉시)
function _countTo(el,v){
  if(!el)return;
  var n=Number(v);
  if(isNaN(n)||!isFinite(n)){el.textContent=v;return;}
  var cur=parseInt(el.textContent,10);
  if(isNaN(cur)||cur===n){el.textContent=String(n);return;}
  if(el._cntRaf)cancelAnimationFrame(el._cntRaf);
  var t0=performance.now(),dur=450,from=cur;
  var step=function(t){
    var p=Math.min(1,(t-t0)/dur);p=1-Math.pow(1-p,3);
    el.textContent=String(Math.round(from+(n-from)*p));
    if(p<1)el._cntRaf=requestAnimationFrame(step);else el._cntRaf=null;
  };
  el._cntRaf=requestAnimationFrame(step);
}
// 되돌리기 스낵바: 삭제 등 위험 작업 후 일정 시간 안에 취소 가능. onUndo=취소 시, onCommit=시간 경과 후 실제 확정.
let _undoTimer=null,_undoCommit=null;
function _undoToast(msg,onUndo,onCommit,dur=5000){
  const bar=document.getElementById('undoBar');if(!bar){onCommit&&onCommit();return;}
  // 직전 대기중인 확정이 있으면 먼저 실행(중첩 방지)
  if(_undoCommit){try{_undoCommit();}catch(e){}_undoCommit=null;}
  clearTimeout(_undoTimer);
  document.getElementById('undoBarMsg').textContent=msg;
  bar.style.display='flex';
  _undoCommit=onCommit||null;
  const close=()=>{bar.style.display='none';};
  document.getElementById('undoBarBtn').onclick=()=>{
    clearTimeout(_undoTimer);_undoCommit=null;close();
    try{onUndo&&onUndo();}catch(e){}
  };
  _undoTimer=setTimeout(()=>{close();_undoCommit=null;try{onCommit&&onCommit();}catch(e){}},dur);
}
// iOS Safari가 100dvh를 실제 창보다 작게 고착시키는 버그 보정:
// #app 높이가 창 높이와 12% 이상 어긋나면 픽셀로 강제(입력 중=키보드일 땐 건드리지 않음)
// ── 시설물 경량 부트 캐시 ─────────────────────────────────────────
// Firestore 수신(사진 데이터URL 포함이라 무겁다)이 끝나기 전에도 지도 핀을 즉시 그릴 수 있도록
// 좌표·이름 등 최소 필드만 localStorage에 저장(사진 제외 → 700개여도 ~100KB). 스냅샷 도착 시 자동 갱신.
var _facBootMemo=null,_facBootSaveT=null;
function _facBootCacheSave(){
  clearTimeout(_facBootSaveT);
  _facBootSaveT=setTimeout(function(){
    try{
      var list=(_fs['facilities']||[]).map(function(f){return {id:f.id,type:f.type,name:f.name,loc:f.loc,lat:f.lat,lng:f.lng,hidden:f.hidden||undefined,warn:f.warn||undefined,grade:f.grade||undefined,mgmt:f.mgmt||undefined};});
      if(list.length){localStorage.setItem('_facBoot',JSON.stringify(list));_facBootMemo=null;}
    }catch(e){}
  },800);
}
function _facBootCache(){
  if(_facBootMemo)return _facBootMemo;
  try{var v=JSON.parse(localStorage.getItem('_facBoot')||'null');if(Array.isArray(v)&&v.length){_facBootMemo=v;return v;}}catch(e){}
  return null;
}
function _fixAppHeight(){
  try{
    var app=document.getElementById('app');if(!app)return;
    if(document.activeElement&&/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName))return;
    // dvh 지원 브라우저(현행 iOS·안드로이드 전부)는 CSS 100dvh가 주소창 접힘까지 항상 정확.
    // 예전처럼 JS가 특정 순간의 innerHeight를 px로 고정하면, iOS 사파리에서 어긋난 값이
    // 그대로 남아 '화면 2/3만 쓰고 아래는 검은 공백 + 하단 메뉴 실종'이 되던 원인 → 고정 해제.
    if(window.CSS&&CSS.supports&&CSS.supports('height','100dvh')){
      if(app.style.height)app.style.height='';
      return;
    }
    // dvh 미지원 구형 브라우저 폴백: 시각적 뷰포트 높이로 맞춤
    var vh=(window.visualViewport&&window.visualViewport.height)||window.innerHeight;if(!vh)return;
    var h=app.getBoundingClientRect().height;
    if(Math.abs(h-vh)>vh*0.02)app.style.height=Math.round(vh)+'px';
  }catch(e){}
}
// 뷰포트 크기 변화(모바일 주소창 접힘/펼침·화면 회전·백그라운드 복귀) 후 카카오 지도 내부 크기 재계산.
// 이걸 빼먹으면 지도 DIV만 새 크기가 되고 카카오 내부 이벤트 레이어는 옛 크기라 터치 좌표가 어긋나
// '지도 터치 먹통'이 된다(그래서 새로고침하면 지도 재생성으로 풀림). relayout은 중심·배율 보존, 멱등.
// relayout은 카카오 내부 크기를 다시 계산(타일 리플로우 유발) → 비용이 있다.
// 화면에 보이는 지도만, 그리고 컨테이너 크기가 실제로 바뀐 경우에만 호출해 스크롤 중 잦은 흰 깜빡임·버벅임을 없앤다.
var _lastMapSize={};
function _relayoutIfChanged(map,elId){
  try{
    if(!map)return;
    var el=document.getElementById(elId);if(!el)return;
    var w=el.offsetWidth,h=el.offsetHeight;
    if(!w||!h)return; // 숨겨진(display:none) 지도는 크기 0 → 건드리지 않음
    var p=_lastMapSize[elId];
    if(p&&p.w===w&&p.h===h)return; // 크기 변화 없으면 relayout 생략
    _lastMapSize[elId]={w:w,h:h};
    map.relayout();
  }catch(e){}
}
function _relayoutMaps(){
  _relayoutIfChanged(typeof mapI!=='undefined'?mapI:null,'mapInspect');
  _relayoutIfChanged(typeof mapR!=='undefined'?mapR:null,'mapRescue');
  try{_relayoutIfChanged((typeof _facNav!=='undefined'&&_facNav.map)?_facNav.map:null,'fnMap');}catch(e){} // 시설물 내비 지도도 뷰포트 변화 시 재계산(좌표 어긋남 방지)
  try{if(typeof _boardMap!=='undefined'&&_boardMap){var be=document.getElementById('boardMap');if(be&&be.offsetWidth)_boardMap.relayout();}}catch(e){}
  try{if(typeof _applyMapVOff==='function')_applyMapVOff();}catch(e){}
}
function _afterViewport(){try{_fixAppHeight();}catch(e){}_relayoutMaps();requestAnimationFrame(_relayoutMaps);}
var _vpTimer=null;
function _onViewportChange(delay){clearTimeout(_vpTimer);_vpTimer=setTimeout(_afterViewport,delay);} // 연속 resize 디바운스
window.addEventListener('resize',function(){_onViewportChange(140);});
window.addEventListener('orientationchange',function(){_onViewportChange(320);});
document.addEventListener('visibilitychange',function(){if(!document.hidden)_onViewportChange(200);});
// iOS 등: 주소창 접힘/펼침이 window.resize를 안 띄우고 visualViewport만 바꾸는 경우 대비
try{if(window.visualViewport)window.visualViewport.addEventListener('resize',function(){_onViewportChange(180);});}catch(e){}
setTimeout(_fixAppHeight,500);setTimeout(_fixAppHeight,2000);
// 화면 진단: 하단 버전 라벨을 5번 연속 탭 → 이 기기의 뷰포트·앱 높이 수치 표시 (아이폰 잘림 등 원인 파악용)
(function(){
  var n=0,t=0;
  document.addEventListener('click',function(e){
    if(!e.target||(e.target.id!=='appVerLabel'&&e.target.id!=='homeDate'))return; // 홈 상단 날짜로도 열림(하단이 잘린 기기 대비)
    var now=Date.now();if(now-t>1500)n=0;t=now;
    if(++n<5)return;n=0;
    try{
      var app=document.getElementById('app');var r=app.getBoundingClientRect();
      var vv=window.visualViewport||{};
      alert('📐 화면 진단\ninner: '+window.innerWidth+'x'+window.innerHeight
        +'\nvisual: '+Math.round(vv.width||0)+'x'+Math.round(vv.height||0)+' · scale '+((vv.scale||1).toFixed(2))
        +'\napp rect: '+Math.round(r.width)+'x'+Math.round(r.height)+' (top '+Math.round(r.top)+')'
        +'\napp style.height: '+(app.style.height||'(없음)')
        +'\ndvh 지원: '+((window.CSS&&CSS.supports&&CSS.supports('height','100dvh'))?'예':'아니오')
        +'\nscreen: '+screen.width+'x'+screen.height+' · dpr '+devicePixelRatio
        +'\n버전: '+(typeof OTA_VER!=='undefined'?OTA_VER:'?'));
    }catch(err){alert('진단 실패: '+err);}
  });
})();

// ── 실시간 회복 워치독 — '새로고침해야 새 정보가 보이는' 문제의 근본 대응 ──────────
// 폰에서 화면이 꺼지거나 앱이 백그라운드로 가면 JS가 얼면서 Firestore 수신 스트림이 끊기는데,
// 복귀 후 SDK가 알아서 다시 붙기까지 수십 초 걸리거나 가끔 끊긴 채 방치된다(그동안 화면이 옛 데이터).
// 복귀 즉시 네트워크를 재사이클(disable→enable)하면 스트림이 바로 재수립되어 밀린 변경이 즉시 들어오고,
// 각 리스너가 화면을 자동 갱신하므로 '새로고침 없이' 카톡처럼 이어진다.
var _rtHiddenAt=0,_rtKickBusy=false,_rtKickLast=0;
function _fsKick(){
  if(!_fdb||_rtKickBusy)return;
  if(Date.now()-_rtKickLast<8000)return; // 과도 재사이클 방지
  _rtKickBusy=true;_rtKickLast=Date.now();
  try{
    _fdb.disableNetwork().then(function(){return _fdb.enableNetwork();}).catch(function(){})
      .then(function(){_rtKickBusy=false;});
  }catch(e){_rtKickBusy=false;}
}
document.addEventListener('visibilitychange',function(){
  if(document.visibilityState==='hidden'){_rtHiddenAt=Date.now();return;}
  // 복귀: 15초 이상 떠나 있었으면 스트림 재수립 + 홈 요약 즉시 갱신(로컬 상태로 우선 페인트)
  if(Date.now()-_rtHiddenAt>15000)_fsKick();
  try{if(typeof updateSummary==='function')updateSummary();}catch(e){}
});
window.addEventListener('online',function(){_fsKick();}); // 통신 복구 시에도 즉시 재수립


// ── 유령 오버레이 방어(전역 터치 먹통 자가복구) ─────────────────────────
// 팝업/바텀시트의 반투명 배경(백드롭)이 닫히며 '투명'해진 뒤 요소가 미처 제거되지 않으면,
// 보이지 않는 전체화면 레이어가 모든 탭을 삼켜 앱 전체(지도·목록·뒤로가기)가 먹통이 된다(→새로고침 필요).
// 자가복구: 탭 지점의 최상위 요소가 'body 직속 + 전체화면급 + 사실상 투명'이면 pointer-events를 꺼서 통과시킨다.
// body 직속만 대상이라 카카오 지도 내부 이벤트 레이어(맵 컨테이너 하위)는 절대 건드리지 않는다.
function _ghostOverlayGuard(e){
  try{
    var pt=(e&&e.touches&&e.touches[0])||e;if(!pt||pt.clientX==null)return;
    var t=document.elementFromPoint(pt.clientX,pt.clientY);if(!t)return;
    var node=t;while(node&&node.parentElement&&node.parentElement!==document.body)node=node.parentElement; // body 직속 조상
    if(!node||node.parentElement!==document.body)return;
    if(node.id==='app'||node.tagName==='SCRIPT'||node.tagName==='STYLE')return;
    var cs=getComputedStyle(node);
    if((cs.position!=='fixed'&&cs.position!=='absolute')||cs.display==='none'||cs.visibility==='hidden')return;
    if(cs.pointerEvents==='none')return; // 이미 통과 상태
    var r=node.getBoundingClientRect();
    if(r.width<window.innerWidth*0.95||r.height<window.innerHeight*0.85)return; // 전체화면급만
    var bg=cs.backgroundColor||'',a=1,mm=bg.match(/rgba?\(([^)]+)\)/);
    if(mm){var p=mm[1].split(',');a=p.length>=4?parseFloat(p[3]):1;}else if(bg==='transparent')a=0;
    if(cs.opacity!=='0'&&a>=0.03){
      // 보이는 전체화면 레이어: 대개 정상 모달이라 손대지 않되, '전환용 오버레이'(스피너·로딩화면)가
      // 작업 실패 등으로 안 사라지고 막고 있으면 → 연속 3탭(먹통이라 사용자가 반복 탭)으로 강제 복구
      if(node.id==='_busyOv'||node.id==='loadingScreen'){
        var _n=Date.now();
        if(_n-(window._ghT||0)<1600)window._ghN=(window._ghN||1)+1;else window._ghN=1;
        window._ghT=_n;
        if(window._ghN>=3){node.style.display='none';node.style.pointerEvents='none';window._ghN=0;try{if(typeof toast==='function')toast('🔄 화면 잠금 해제됨');}catch(_){}}
      }
      return;
    }
    node.style.pointerEvents='none'; // 투명 유령 → 터치 통과(요소는 남겨둬도 무해)
    try{console.warn('[ghostGuard] 투명 전체화면 레이어 무력화:',node.id||node.className||node.tagName);}catch(_){}
  }catch(_){}
}
document.addEventListener('pointerdown',_ghostOverlayGuard,true);
document.addEventListener('touchstart',_ghostOverlayGuard,true);

function closeDB(){document.querySelectorAll('.dbcard').forEach(c=>c.classList.remove('on'));try{if(typeof _clearPopupDim==='function')_clearPopupDim();}catch(e){}try{if(typeof _facPinUnhighlight==='function')_facPinUnhighlight();}catch(e){}}
// dbcard(하단 조회 카드): X버튼 대신 손잡이를 아래로 내려서 닫기
function _bindDbcardDrag(p){
  if(!p||p._dbDrag)return;p._dbDrag=true;
  const h=p.querySelector('.dbgrab')||p;
  let y0=null,t0=0;
  const start=y=>{y0=y;t0=Date.now();p.style.transition='none';};
  const move=y=>{if(y0==null)return;p.style.transform='translateY('+Math.max(0,y-y0)+'px)';};
  const end=y=>{
    if(y0==null)return;
    const dy=y-y0,dt=Date.now()-t0,vel=dt>0?dy/dt:0;y0=null;
    if(dy>40||(dy>12&&vel>0.4)){
      p.style.transition='transform .18s ease-in';
      p.style.transform='translateY(130%)';
      setTimeout(()=>{closeDB();p.style.transition='';p.style.transform='';},180);
    }else{
      p.style.transition='transform .2s cubic-bezier(.4,0,.2,1)';
      p.style.transform='translateY(0)';
      setTimeout(()=>{p.style.transition='';},210);
    }
  };
  h.addEventListener('touchstart',e=>start(e.touches[0].clientY),{passive:true});
  h.addEventListener('touchmove',e=>move(e.touches[0].clientY),{passive:true});
  h.addEventListener('touchend',e=>end(e.changedTouches[0].clientY));
  h.addEventListener('mousedown',e=>{start(e.clientY);const mv=ev=>move(ev.clientY);const up=ev=>{end(ev.clientY);document.removeEventListener('mousemove',mv);document.removeEventListener('mouseup',up);};document.addEventListener('mousemove',mv);document.addEventListener('mouseup',up);e.preventDefault();});
}
document.querySelectorAll('.dbcard').forEach(_bindDbcardDrag);
function closeM(id){document.getElementById(id).classList.remove('on');}
// 모달 배경(backdrop) 클릭 시 닫기
document.querySelectorAll('.modal').forEach(m=>{
  if(m.id==='modalUser')return; // 필수입력 검증 때문에 별도처리
  m.addEventListener('click',function(e){if(e.target===this)closeM(this.id);});
});
// ── 오프라인 사진 업로드 큐 (IndexedDB 영속 — 앱 재시작에도 유지) ──
const _offlinePhotoQueue=[];
function _photoIDB(){
  return new Promise((ok,no)=>{
    const rq=indexedDB.open('seorak_photoQ',1);
    rq.onupgradeneeded=()=>{rq.result.createObjectStore('q',{keyPath:'id'});};
    rq.onsuccess=()=>ok(rq.result);rq.onerror=()=>no(rq.error);
  });
}
async function _photoQPut(item){
  try{const db=await _photoIDB();const tx=db.transaction('q','readwrite');tx.objectStore('q').put(item);}catch(e){}
}
async function _photoQDel(id){
  try{const db=await _photoIDB();const tx=db.transaction('q','readwrite');tx.objectStore('q').delete(id);}catch(e){}
}
async function _photoQAll(){
  try{
    const db=await _photoIDB();
    return await new Promise((ok)=>{
      const rq=db.transaction('q','readonly').objectStore('q').getAll();
      rq.onsuccess=()=>ok(rq.result||[]);rq.onerror=()=>ok([]);
    });
  }catch(e){return[];}
}
// 제출 시 호출: 업로드 대기 중(pending)인 미리보기 사진을 저장된 레코드에 연결
function _registerPendingPhoto(pid,dest){
  const it=_offlinePhotoQueue.find(x=>x.pid===pid&&!x.dest);
  if(!it)return;
  it.dest=dest;
  if(it.dataUrlMode)return; // dataURL은 메모리에서 압축 완료 시 dest로 반영 — IDB 지속 불필요
  _photoQPut({id:it.id,pid:it.pid,file:it.file,dest});
}
// 업로드 완료된 URL을 레코드 필드에 반영
function _applyPhotoDest(dest,url){
  if(!dest)return;
  const arr=DB.g(dest.key)||[];const i=arr.findIndex(x=>x.id===dest.id);
  if(i<0)return;
  if(dest.append){
    if(!arr[i][dest.field])arr[i][dest.field]=[];
    arr[i][dest.field].push({url,time:now(),by:dest.by||''});
  }else{
    arr[i][dest.field]=url;
  }
  DB.s(dest.key,arr);
}
// ── 레거시 대기 사진 정리·구제 ──
// 예전 방식(Firebase Storage 업로드)의 대기 항목이 IndexedDB에 남으면, Storage가 프로비저닝돼
// 있지 않아 업로드가 영원히 실패 → 부팅마다 '대기 중인 사진 N장' 토스트가 무한 반복됐다.
// 현행 방식(dataURL을 기록에 직접 저장)으로 변환해 원래 기록에 심어 구제하고,
// 성공 여부와 무관하게 큐에서 제거해 재시도를 끝낸다. (메모리 dataUrlMode 항목은 prevImg가 처리)
async function _processPhotoQueue(){
  const idb=await _photoQAll();
  if(!idb.length)return;
  let ok=0,drop=0,defer=0;
  for(const item of idb){
    try{
      const arr=item.dest?DB.g(item.dest.key):null;
      if(item.dest&&!Array.isArray(arr)){defer++;continue;} // 해당 데이터 아직 미로딩 — 삭제하지 않고 다음 기회에
      const durl=item.file?await _compressToDataUrl(item.file,1000,380000):'';
      const i=item.dest?arr.findIndex(x=>x.id===item.dest.id):-1;
      if(durl&&i>=0){
        if(item.dest.append){(arr[i][item.dest.field]=arr[i][item.dest.field]||[]).push({url:durl,time:now(),by:item.dest.by||''});DB.s(item.dest.key,arr);ok++;}
        else if(!arr[i][item.dest.field]){arr[i][item.dest.field]=durl;DB.s(item.dest.key,arr);ok++;}
        else drop++; // 기록에 이미 다른 사진이 있음 — 덮어쓰지 않고 정리
      }else drop++;   // 연결된 기록 없음/삭제됨/변환 실패
    }catch(e){drop++;}
    _photoQDel(item.id);
  }
  if(ok)toast('✅ 대기 중이던 사진 '+ok+'장을 기록에 저장했습니다');
  else if(drop)toast('🧹 오래된 대기 사진 '+drop+'장을 정리했습니다',3500);
}
window.addEventListener('online',()=>setTimeout(_processPhotoQueue,2000));
// ── 이미지 압축 (긴 축 1200px, 82% JPEG) ─────────
async function _compressImage(file,maxPx=1200,quality=0.82){
  if(file.size<300*1024)return file; // 300KB 이하 압축 생략
  return new Promise(resolve=>{
    const img=new Image();
    img.onload=()=>{
      URL.revokeObjectURL(img.src);
      let w=img.width,h=img.height;
      if(w<=maxPx&&h<=maxPx&&file.size<800*1024){resolve(file);return;}
      if(w>h){if(w>maxPx){h=Math.round(h*maxPx/w);w=maxPx;}}
      else{if(h>maxPx){w=Math.round(w*maxPx/h);h=maxPx;}}
      const c=document.createElement('canvas');c.width=w;c.height=h;
      c.getContext('2d').drawImage(img,0,0,w,h);
      c.toBlob(b=>resolve(b||file),'image/jpeg',quality);
    };
    img.onerror=()=>resolve(file);
    img.src=URL.createObjectURL(file);
  });
}
async function uploadImageToStorage(file,path){
  if(!_fst)throw new Error('Storage 미초기화');
  const ref=_fst.ref().child(path+'/'+Date.now()+'_'+(file.name||'photo').replace(/[^a-zA-Z0-9._-]/g,'_'));
  const snap=await ref.put(file);
  return await snap.ref.getDownloadURL();
}
// ── 사진을 데이터URL(JPEG)로 압축 ─────────────────────────────
// Firebase Storage 미프로비저닝 → 사진을 Storage 대신 기록(Firestore 문서)에 직접 저장.
// Firestore 문서 1MB 한계가 있으므로 데이터URL 문자열 길이를 maxLen 이하로 (초과 시 품질↓→해상도↓ 재인코딩).
// facIssues·rescues는 항목별 개별 문서라 사진 1~수장이면 안전.
async function _compressToDataUrl(file,maxPx,maxLen){
  maxPx=maxPx||1000;maxLen=maxLen||500000; // maxLen≈문자수(base64) → 500k자 ≈ 원본 약 365KB
  return new Promise(resolve=>{
    const img=new Image();
    img.onload=()=>{
      let w=img.width,h=img.height;
      if(w>h){if(w>maxPx){h=Math.round(h*maxPx/w);w=maxPx;}}
      else{if(h>maxPx){w=Math.round(w*maxPx/h);h=maxPx;}}
      const draw=(ww,hh,q)=>{const c=document.createElement('canvas');c.width=ww;c.height=hh;c.getContext('2d').drawImage(img,0,0,ww,hh);return c.toDataURL('image/jpeg',q);};
      let q=0.72,url=draw(w,h,q),guard=0;
      while(url.length>maxLen&&q>0.35&&guard<5){q-=0.1;url=draw(w,h,q);guard++;} // 품질 낮춰 재인코딩
      if(url.length>maxLen)url=draw(Math.round(w*0.72),Math.round(h*0.72),0.6); // 그래도 크면 해상도까지 축소
      try{URL.revokeObjectURL(img.src);}catch(e){}
      resolve(url);
    };
    img.onerror=()=>{try{URL.revokeObjectURL(img.src);}catch(e){}resolve('');};
    img.src=URL.createObjectURL(file);
  });
}
// dataset.url이 'pending'이면 빈 문자열 반환
const _photoUrl=id=>{const u=document.getElementById(id)?.dataset?.url||'';return u==='pending'?'':u;};
async function prevImg(inp,pid){
  if(!inp.files||!inp.files[0])return;
  const file=inp.files[0];
  const prev=document.getElementById(pid);
  const objUrl=URL.createObjectURL(file);
  prev.innerHTML=`<img src="${objUrl}" style="opacity:.6"><div class="up-badge" style="font-size:10px;color:#3182f6;background:rgba(0,0,0,.75);padding:2px 6px;border-radius:4px;margin-top:3px;text-align:center;">사진 처리 중...</div>`;
  // Storage 미사용 — 사진을 데이터URL로 압축해 기록에 직접 저장(오프라인·동기화 모두 이걸로 해결).
  // 압축 완료 전 제출돼도 붙도록 dest 연결용 큐 항목 등록(메모리 전용, dataUrlMode).
  prev.dataset.url='pending';
  const qItem={id:Date.now()+'_'+pid,pid,dataUrlMode:true};
  _offlinePhotoQueue.push(qItem);
  try{
    const dataUrl=await _compressToDataUrl(file,1000,380000); // 한 기록에 사진 여러 필드(부상·이송)일 수 있어 여유 있게
    if(!dataUrl)throw new Error('encode fail');
    prev.dataset.url=dataUrl;
    prev.innerHTML=`<img src="${dataUrl}">`;
    try{URL.revokeObjectURL(objUrl);}catch(e){}
    // 압축 중 이미 제출됐으면(dest 연결됨) 저장된 레코드에 반영
    const qi=_offlinePhotoQueue.find(x=>x.id===qItem.id);
    if(qi&&qi.dest)_applyPhotoDest(qi.dest,dataUrl);
    const qidx=_offlinePhotoQueue.findIndex(x=>x.id===qItem.id);
    if(qidx>=0)_offlinePhotoQueue.splice(qidx,1);
  }catch(e){
    prev.dataset.url='';
    const qidx=_offlinePhotoQueue.findIndex(x=>x.id===qItem.id);
    if(qidx>=0)_offlinePhotoQueue.splice(qidx,1);
    prev.innerHTML=`<img src="${objUrl}"><div class="up-badge" style="font-size:10px;color:#e67e22;background:rgba(0,0,0,.75);padding:2px 6px;border-radius:4px;margin-top:3px;text-align:center;">⚠️ 사진 처리 실패 — 다시 시도</div>`;
    toast('⚠️ 사진 처리 실패 — 다시 촬영해 주세요');
  }
}
function fillSel(id,arr){document.getElementById(id).innerHTML=arr.map(v=>`<option value="${v}">${v}</option>`).join('');}
const SC=s=>s==='ok'?'#27ae60':s==='warn'?'#e67e22':'#c0392b';
const SL=s=>s==='ok'?'양호':s==='warn'?'보수필요':'파손위험';
// ── 시설물 경고표시 ──
// warn={on,reason,from,until(ms|null=무제한),by,at}. 활성=on이고 (무제한 또는 종료일 이전).
// 종료일이 지나면 자동으로 비활성(깜빡임 자동 중단).
function _facWarn(f){var w=f&&f.warn;if(!w||!w.on)return null;if(w.until&&Date.now()>w.until)return null;return w;}
function _warnPeriodStr(w){
  if(!w)return '';
  var fr=w.from?String(new Date(w.from).toLocaleDateString('ko-KR')).replace(/\. /g,'.').replace(/\.$/,''):'';
  if(!w.until)return (fr?fr+' ~ ':'')+'무제한';
  var un=String(new Date(w.until).toLocaleDateString('ko-KR')).replace(/\. /g,'.').replace(/\.$/,'');
  var days=Math.ceil((w.until-Date.now())/86400000);
  return (fr?fr+' ~ ':'~ ')+un+(days>=0?' (D-'+days+')':'');
}

function getAuthor(){const u=DB.g('currentUser')||{};return u.name||'미지정';}
// ── 목록 이전/다음 순회 (사고·특보·시설 상세에서 위/아래 항목으로 빠르게 이동) ──
// 각 목록 렌더 시 화면에 보이는 순서대로 id 배열을 저장 → 상세에서 그 순서대로 ◀▶ 이동
var _navOrder={rescue:[],fac:[],alert:[]};
function _navBtns(type,curId,fn){
  var a=(_navOrder[type]||[]).map(String),i=a.indexOf(String(curId));
  if(i<0||a.length<2)return '';
  var prev=i>0?a[i-1]:'',next=i<a.length-1?a[i+1]:'';
  // 배경·색은 style.css .navbtn(!important)이 강제 — 일부 웹뷰가 인라인 스타일을 무시하고 기본(흰) 배경으로 그리던 문제 차단
  return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:11px;">'
    +'<button class="navbtn" '+(prev?'onclick="'+fn+'('+prev+')"':'disabled')+'>◀ 이전</button>'
    +'<span style="font-size:11px;color:#8b95a1;font-weight:800;white-space:nowrap;">'+(i+1)+' / '+a.length+'</span>'
    +'<button class="navbtn" '+(next?'onclick="'+fn+'('+next+')"':'disabled')+'>다음 ▶</button></div>';
}
function getSelPills(id){return [...document.querySelectorAll(`#${id} .pill.on`)].map(p=>p.textContent);}
function tPill(el){el.classList.toggle('on');}
function sPill(el,wrId){document.querySelectorAll(`#${wrId} .pill`).forEach(p=>p.classList.remove('on'));el.classList.add('on');
  // 음주 버튼 → hidden input 동기화
  if(wrId==='alcPills'){const val=el.textContent.replace(/[🚫⚠️🍺]/g,'').trim();const h=document.getElementById('r_alc');if(h)h.value=val;}
}
// 여러 핀 그룹의 선택(.on) 일괄 해제
function _resetPills(...ids){ids.forEach(id=>document.querySelectorAll(`#${id} .pill`).forEach(p=>p.classList.remove('on')));}
// 암벽=지구별 그룹(암벽 이용관리와 동일 분류) / 빙벽=단일 목록 — 위치 선택 버튼 HTML (폼 템플릿·chkIllegal 공용)
function _climbLocBtnsHtml(kind,cur){
  cur=String(cur||'').trim();
  const btn=l=>`<button class="tog-btn${cur===l?' on':''}" onclick="selClimbLoc('${l.replace(/'/g,"\\'")}',this)">${l}</button>`;
  if(kind==='암벽'&&typeof CLIMB_DISTRICTS!=='undefined'){
    return Object.keys(CLIMB_DISTRICTS).map(d=>`<div style="margin-top:7px;"><div style="font-size:10px;color:#a5abb3;font-weight:800;margin-bottom:4px;">🏔️ ${d.replace('지구','')}</div><div style="display:flex;flex-wrap:wrap;gap:5px;">${CLIMB_DISTRICTS[d].map(btn).join('')}</div></div>`).join('');
  }
  const locs=kind==='빙벽'?_ICE_LOCS:_ROCK_LOCS;
  return `<div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:6px;" id="climbLocBtns">${locs.map(btn).join('')}</div>`;
}
function chkIllegal(sel){
  document.getElementById('fineWrap').style.display=sel.value.includes('비법정')?'block':'none';
  const isClimb=sel.value==='암벽'||sel.value==='빙벽';
  // 암빙벽이면 명단 찾기 버튼(=허가 블록)을 바로 노출 — '허가자 있음'을 먼저 고를 필요 없음
  {const pr=document.getElementById('permitRoster');if(pr)pr.style.display=isClimb?'block':'none';}
  const pw=document.getElementById('permitWrap');if(pw)pw.style.display='none'; // 구 드롭다운 블록은 사용 안 함
  // 인적사항 탭의 '암벽 명단 불러오기' — 암벽 사고일 때만 (신청명단은 암벽 전용)
  {const cp3=document.getElementById('climbPickWrap3');if(cp3)cp3.style.display=sel.value==='암벽'?'block':'none';}
  const clw=document.getElementById('climbLocWrap');
  if(clw){
    clw.style.display=isClimb?'block':'none';
    if(isClimb){
      const curVal=(document.getElementById('r_loc')?.value||'').trim();
      clw.innerHTML=`<span class="fl">📍 ${sel.value} 위치 선택 <span style="font-size:9px;color:#8b95a1;font-weight:400;">${sel.value==='암벽'?'지구별':''}</span></span>${_climbLocBtnsHtml(sel.value,curVal)}`;
    }
  }
}
function selClimbLoc(loc,btn){
  const inp=document.getElementById('r_loc');
  if(inp){inp.value=loc;autoGenTitle();}
  // 지구별 여러 그룹에 걸쳐 하나만 선택되도록 climbLocWrap 전체에서 해제 (십자선 모달 등 다른 곳은 자기 그룹만)
  const wrap=btn?(btn.closest('#climbLocWrap')||btn.parentElement):document.getElementById('climbLocBtns');
  if(wrap)wrap.querySelectorAll('.tog-btn').forEach(b=>b.classList.remove('on'));
  if(btn)btn.classList.add('on');
}
// 출동폰·당직폰은 사람이 아님 — 인원수(명)에서 제외 (명단·연락처로는 그대로 표시)
function _isNonPerson(nm){return /출동폰|당직폰/.test(String(nm||''));}
function _personCount(members){return (members||[]).filter(function(m){return !_isNonPerson(m);}).length;}
// (구) 허가 드롭다운 핸들러 — 이제 허가상태는 명단에서 찾으면 자동 설정되므로 미사용(하위호환 유지)
function chkPermit(sel){}
// 암빙벽 허가 상태 설정 + 상태문구 갱신 ('허가자 있음'=명단확인 / '무허가'=명단에 없음)
function _setPermit(v){
  const h=document.getElementById('r_permit');if(h)h.value=v;
  const s=document.getElementById('permitStatus');
  if(s){
    s.textContent=v==='허가자 있음'?'✅ 허가자(신청명단 확인됨)':(v==='무허가'?'⛔ 무허가(명단에 없음)':'명단에서 찾거나, 없으면 명단 창의 「허가자 아님」을 누르세요');
    s.style.color=v==='허가자 있음'?'#5fcf8f':(v==='무허가'?'#ff8a73':'#8b95a1');
  }
}
let _companionCount=(window._companionCount)||0;
function addCompanion(){
  _companionCount++;
  const list=document.getElementById('companionList');
  if(!list)return;
  const idx=list.children.length;
  const div=document.createElement('div');
  div.className='companion-item';
  div.dataset.idx=idx;
  div.style.cssText='background:#0f0f11;border-radius:8px;padding:10px;margin-bottom:6px;border:1px solid rgba(255,255,255,.07);';
  div.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;"><span style="font-size:11px;color:#3182f6;font-weight:700;">동반자 ${idx+1}</span><button onclick="this.closest('.companion-item').remove();renumberCompanions()" style="background:rgba(192,57,43,.15);color:#c0392b;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;">삭제</button></div>
  <div class="frow"><div class="fg"><span class="fl">성명</span><input type="text" class="fi comp-name" placeholder="이름"></div><div class="fg"><span class="fl">연락처</span><input type="tel" class="fi comp-tel" placeholder="연락처"></div></div>`;
  list.appendChild(div);
}
function removeCompanion(idx){
  const items=document.querySelectorAll('#companionList .companion-item');
  if(items[idx])items[idx].remove();
  renumberCompanions();
}
function renumberCompanions(){
  document.querySelectorAll('#companionList .companion-item').forEach((el,i)=>{
    const label=el.querySelector('span');
    if(label)label.textContent='동반자 '+(i+1);
    el.dataset.idx=i;
  });
}
function getCompanions(){
  return [...document.querySelectorAll('#companionList .companion-item')].map(el=>({
    name:el.querySelector('.comp-name')?.value||'',
    tel:el.querySelector('.comp-tel')?.value||''
  })).filter(c=>c.name||c.tel);
}
// 추가 사고자(다수 사상자) — 기본 사고자(vName 등)는 유지하고 추가분만 배열로 보관
const _V2_SEV=['','KTAS 1 (소생)','KTAS 2 (긴급)','KTAS 3 (응급)','KTAS 4 (준응급)','KTAS 5 (비응급)'];
function _victim2CardHtml(v){
  v=v||{};
  const sevOpts=_V2_SEV.map(o=>`<option value="${o}"${(v.severity||'')===o?' selected':''}>${o||'중증도 선택'}</option>`).join('');
  const genOpts=['알수없음','남','여'].map(o=>`<option${(v.gender||'알수없음')===o?' selected':''}>${o}</option>`).join('');
  return `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;"><span style="font-size:11px;color:#e9897e;font-weight:700;">🧑 추가 사고자</span><button onclick="this.closest('.victim2-item').remove()" style="background:rgba(192,57,43,.15);color:#c0392b;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;">삭제</button></div>
  <div class="frow"><div class="fg"><span class="fl">성명</span><input type="text" class="fi v2-name" placeholder="이름" value="${(v.name||'').replace(/"/g,'&quot;')}"></div><div class="fg"><span class="fl">성별</span><select class="fsel v2-gender">${genOpts}</select></div></div>
  <div class="frow"><div class="fg"><span class="fl">나이</span><input type="number" inputmode="numeric" class="fi v2-age" placeholder="세" value="${v.age||''}"></div><div class="fg"><span class="fl">중증도</span><select class="fsel v2-sev">${sevOpts}</select></div></div>
  <div class="fg"><span class="fl">연락처</span><input type="tel" class="fi v2-tel" placeholder="010-0000-0000" value="${(v.tel||'').replace(/"/g,'&quot;')}"></div>
  <div class="fg"><span class="fl">부상/상태</span><input type="text" class="fi v2-note" placeholder="예: 우측 발목 골절, 의식 명료" value="${(v.note||'').replace(/"/g,'&quot;')}"></div>`;
}
function addVictim2(){
  const list=document.getElementById('victim2List');if(!list)return;
  const div=document.createElement('div');
  div.className='victim2-item';
  div.style.cssText='background:#0f0f11;border-radius:8px;padding:10px;margin-bottom:6px;border:1px solid rgba(231,76,60,.15);';
  div.innerHTML=_victim2CardHtml({});
  list.appendChild(div);
}
function getVictims2(){
  return [...document.querySelectorAll('#victim2List .victim2-item')].map(el=>({
    name:el.querySelector('.v2-name')?.value||'',
    gender:el.querySelector('.v2-gender')?.value||'',
    age:el.querySelector('.v2-age')?.value||'',
    severity:el.querySelector('.v2-sev')?.value||'',
    tel:el.querySelector('.v2-tel')?.value||'',
    note:el.querySelector('.v2-note')?.value||''
  })).filter(v=>v.name||v.note||v.age||v.tel);
}
function _victims2Str(arr){
  return (arr||[]).map(v=>[v.name||'미상',v.gender&&v.gender!=='알수없음'?v.gender:'',v.age?v.age+'세':'',v.severity,v.note].filter(Boolean).join(' · ')).join(' / ');
}
function chkNation(sel){
  const wrap=document.getElementById('r_vNatWrap_extra');
  if(wrap)wrap.style.display=sel.value==='외국인'?'block':'none';
  autoGenTitle();
}

// ══════════════════════════════════════════
// 알림
// ══════════════════════════════════════════
// ── 알림 카테고리(세분화) ── def: 기본 켜짐 여부 / push: OS 푸시 여부(false면 앱 내 종만)
const NOTI_GROUPS=[
  {title:'🚨 현장 위험상황·구조', items:[
    {k:'안전사고',l:'안전사고',sub:'실족·추락·부상',def:true,push:true},
    {k:'낙석',l:'낙석',sub:'낙석 발생',def:true,push:true},
    {k:'위험수목',l:'위험수목',sub:'쓰러짐·낙목',def:true,push:true},
    {k:'화재',l:'화재·산불',sub:'산불·시설 화재',def:true,push:true},
    {k:'기타',l:'기타 위험',sub:'기타 위험상황',def:true,push:true},
    {k:'rescue_mobilize',l:'응소 요청',sub:'야간·산불 응소·재알림',def:true,push:true},
    {k:'progress',l:'진행중 경과 알림',sub:'24시간 무소식 시 종료 확인 — 최초 작성자에게 (하루 1회)',def:true,push:true},
    {k:'rescue_update',l:'추가보고·댓글',sub:'구조 추가보고·댓글',def:false,push:false},
    {k:'rescue_close',l:'상황 종료',sub:'구조 상황 종료',def:false,push:false},
  ]},
  {title:'🏗️ 시설물 점검', items:[
    {k:'fac_bad',l:'위험 시설물',sub:'파손 심각 등록',def:true,push:true},
    {k:'fac_warn',l:'보수 필요',sub:'보수필요 판정',def:false,push:false},
    {k:'fac_issue',l:'시설물 점검',sub:'점검 등록·검토·현장확인 (담당자 위주)',def:true,push:true},
  ]},
  {title:'🌀 재난대응 (특보·위기경보)', items:[
    {k:'op_start',l:'특보운영 시작',sub:'특보운영 개시',def:true,push:true},
    {k:'op_change',l:'특보 상향·하향',sub:'단계 변경·추가 발령',def:true,push:true},
    {k:'op_end',l:'특보운영 종료',sub:'운영 종료',def:true,push:true},
    {k:'op_kma',l:'기상특보 수신',sub:'기상청 자동 특보',def:true,push:true},
    {k:'crisis',l:'재난위기경보',sub:'관심·주의·경계·심각',def:true,push:true},
    {k:'trail',l:'탐방로 통제',sub:'구간 통제·개방',def:true,push:true},
    {k:'weather',l:'기상 브리핑',sub:'정기 기상 브리핑',def:true,push:false},
  ]},
];
const NOTI_PUSH=(()=>{const m={};NOTI_GROUPS.forEach(g=>g.items.forEach(it=>{m[it.k]=it.push;}));return m;})();
const _NOTI_DEF=(()=>{const m={};NOTI_GROUPS.forEach(g=>g.items.forEach(it=>{m[it.k]=it.def;}));return m;})();
// 알림 수준: 'all'(전체) / 'recommended'(추천=내가 준 기본값) / 'min'(최소·생명안전 위주)
const _NOTI_MIN=new Set(['안전사고','낙석','위험수목','화재','기타','rescue_mobilize','crisis','op_kma','trail']);
const _NOTI_LEVELS=[{v:'all',l:'전체',d:'모든 알림 받기'},{v:'recommended',l:'추천',d:'중요 알림 위주(기본)'},{v:'min',l:'최소',d:'생명·안전 핵심만'}];
// 관리자가 정한 기본 정책(전원/관리자/멤버/소속별) — 개인이 직접 끈/켠 항목은 개인설정이 우선
function _getNotiPolicy(){const p=DB.g('notiPolicy')||{};return{전원:p['전원']||'recommended',관리자:p['관리자']||'recommended',멤버:p['멤버']||'recommended',depts:p.depts||{}};}
function _myNotiLevel(){
  const p=_getNotiPolicy(),u=DB.g('currentUser')||{};
  let lv=p['전원'];
  if(typeof isAdminUser==='function'&&isAdminUser())lv=p['관리자'];else lv=p['멤버'];
  if(u.dept&&p.depts[u.dept])lv=p.depts[u.dept]; // 소속 지정이 있으면 최우선
  return lv||'recommended';
}
// 기본은 '모두에게'(내가 준 def 그대로). 개인이 끄면 그 사람만 안 받음.
function _notiDefaultOn(k){return _NOTI_DEF[k]!==false;}
// 이 알림(k)이 나에게 켜져 있는가: ① 개인이 직접 켠/끈 항목 최우선 → ② 없으면 관리자 알림수준 정책 적용
//  정책: all=전체 수신 / min=생명·안전 핵심(_NOTI_MIN)만 / recommended=내가 준 기본값(_notiDefaultOn)
//  기본 정책이 recommended라 관리자가 바꾸지 않으면 종전과 동일하게 동작.
function _notiOn(k){
  const s=DB.g('notiSetting')||{};if(s[k]!==undefined)return s[k]!==false;
  var lv=(typeof _myNotiLevel==='function')?_myNotiLevel():'recommended';
  if(lv==='all')return true;
  if(lv==='min')return _NOTI_MIN.has(k);
  return _notiDefaultOn(k);
}
// 서버 푸시 필터용: 정책+개인설정을 합친 실효 설정(전 항목 bool)
function _effectiveNotiSettings(){const m={};NOTI_GROUPS.forEach(g=>g.items.forEach(it=>{m[it.k]=_notiOn(it.k);}));return m;}
// 신규 카테고리를 기존 사용자 설정에 기본값으로 보강
// 더 이상 기본값을 강제 저장하지 않음(정책 기본값이 적용되도록). 명시적으로 켠/끈 것만 notiSetting에 남김.
function _ensureNotiDefaults(){return DB.g('notiSetting')||{};}
// 알림 수신 자격: 로그인·입장을 마친 사용자에게만 알림(벨·OS배너·진동)을 전달한다.
// 로그인 전(로그인 화면만 봐야 하는 상태)에 남의 알림이 벨에 쌓이거나 진동/배너가 뜨던 문제 방지.
function _notiRecipientReady(){
  try{if(typeof _isAppUnlocked==='function')return _isAppUnlocked();}catch(e){}
  // 폴백(로드 타이밍상 _isAppUnlocked 미정의): 최소한 로그인 완료 여부로 판단
  try{
    var at=DB.g('authType');
    if(at==='external')return true;
    if(localStorage.getItem('_adminAuthed')==='1'||localStorage.getItem('_masterAuthed')==='1')return true;
    var u=DB.g('currentUser')||{};
    if(at==='kakao'&&u.dept&&(u.realName||u.name))return true;
  }catch(e){}
  return false;
}
// 개발자(마스터 포함) 여부 — 특보 알림 임시 제한용
function _amDev(){
  try{
    const u=DB.g('currentUser')||{};
    return (typeof _isDeveloper==='function'&&_isDeveloper(u.kakaoId))||(typeof _isMasterAdmin==='function'&&_isMasterAdmin());
  }catch(e){return false;}
}
// 🔕 검증 모드(관리자 전용·기기 로컬): 이 기기에서 발생시키는 알림의 공유 브로드캐스트·OS푸시를 차단.
//  - 관리자가 기능 검증할 때 전 직원에게 알림이 가는 것 방지. 60분 후 자동 해제(끄는 걸 잊어도 안전).
//  - 로컬 키(testSilentUntil)라 다른 기기·다른 직원에게는 영향 없음. 내 기기 벨 표시는 유지(동작 확인용).
function _testSilentOn(){
  try{
    const t=+DB.g('testSilentUntil')||0;
    if(!t)return false;
    if(Date.now()>t){DB.s('testSilentUntil',0);return false;} // 만료 자동 해제
    return (typeof isAdminUser==='function'&&isAdminUser())||_amDev();
  }catch(e){return false;}
}
function pushNoti(msg,ico,type='info',link=null,pushCat=null,opts){
  const adminOnly=!!(opts&&opts.adminOnly); // 관리자에게만 보낼 알림(권한 요청 등)
  const _silent=_testSilentOn(); // 🔕 검증 모드: 아래에서 공유 브로드캐스트·OS푸시만 건너뜀
  // 【임시】 특보운영(op_*) 알림은 안정화 전까지 개발자 전용 — 전 직원 발송·푸시 중단 (2026-07 윤태종 지시)
  const devOnly=String(type).indexOf('op_')===0;
  // 특정 카카오ID들에게만 보낼 알림(시설물 담당자 등) — 전체 진동·푸시 없이 대상자 기기에서만 표시
  const targets=(opts&&Array.isArray(opts.targetKakaoIds))?opts.targetKakaoIds.map(String).filter(Boolean):null;
  // ※ 발신자 개인 알림설정으로 '전체 브로드캐스트'를 막지 않는다.
  //   (옛 버그: 발신자가 그 카테고리를 꺼두면 그 행동으로 생긴 알림이 팀 전원에게 아예 안 가던 문제 —
  //    알림 발송 여부가 '누가 그 행동을 했는지'에 좌우됐다.)
  //   개인설정은 아래 두 곳에서 각자 적용한다: ① 발신자 '내 벨 추가'  ② 수신측 리스너(수신자 본인 설정).
  // pushCat 미지정 시: 카테고리 정의에 push:false면 OS 푸시 끔(앱 내 종만)
  if(pushCat===null)pushCat=(NOTI_PUSH[type]===false)?'info':type;
  const id=Date.now();
  // 중복 방지 키(SOS 등 공유 이벤트): 같은 키는 전 기기에서 1회만 표시·발송
  const dk=(opts&&opts.dedupeKey)?String(opts.dedupeKey):null;
  if(dk){const sk=window._notiSeenDk||(window._notiSeenDk={});sk[dk]=1;}
  const _myK=String((DB.g('currentUser')||{}).kakaoId||'');
  const _iAmTarget=!targets||(_myK&&targets.indexOf(_myK)>=0);
  // 내 벨에 추가 — 관리자 전용인데 관리자 아니거나 / 대상 지정인데 내가 대상 아니면 추가 안 함 / 개발자 전용은 개발자만
  if((!adminOnly||(typeof isAdminUser==='function'&&isAdminUser()))&&_iAmTarget&&(!devOnly||_amDev())&&(type==='info'||!!targets||_notiOn(type))){
    const ns=DB.g('notis')||[];ns.unshift({id,msg,ico,time:now(),read:false,link});
    if(ns.length>80)ns.splice(80);DB.s('notis',ns);updateBell();
  }
  // 꺼진 폰까지 OS 푸시 — 관리자 전용·대상 지정·개발자 전용·검증 모드는 전체 OS푸시를 보내지 않음
  if(!adminOnly&&!targets&&!devOnly&&!_silent)_sendFcmPush('설악산 현장관리',msg,pushCat||type,link);
  // 특보(op_*) 알림은 설정 켠 사용자의 카카오톡(나와의 채팅)으로도 발송 — 【임시】개발자만
  try{if(String(type).indexOf('op_')===0&&_amDev()&&typeof _kakaoMsgOn==='function'&&_kakaoMsgOn()&&typeof _sendKakaoSelf==='function')_sendKakaoSelf(msg);}catch(e){}
  // 기기 간 Firestore 브로드캐스트 (adminOnly·targetKakaoIds면 수신측에서 필터) — 🔕검증 모드는 발송 안 함
  if(_fdb&&!_silent){
    _fdb.collection('sharedNotis').doc(String(id)).set({
      id,msg,ico,type:type||'info',link:link||null,adminOnly:adminOnly,targetKakaoIds:targets||null,
      at:id,timeStr:now(),deviceId:_MY_DEVICE_ID,dk:dk||null,devOnly:devOnly||false
    }).catch(()=>{});
  }
}
function _cleanOldSharedNotis(){
  if(!_fdb)return;
  const cutoff=Date.now()-24*60*60*1000;
  // 한 번에 최대 100건만 삭제(여러 기기가 동시에 돌려도 부담 적게) — 200명 동시접속 시 폭주 방지
  _fdb.collection('sharedNotis').where('at','<',cutoff).limit(100).get()
    .then(snap=>snap.docs.forEach(d=>d.ref.delete())).catch(()=>{});
  // SOS 알림 1회발송 선점표(claim)도 48시간 지나면 정리
  _fdb.collection('sosNotiClaims').where('at','<',Date.now()-48*3600000).limit(50).get()
    .then(snap=>snap.docs.forEach(d=>d.ref.delete())).catch(()=>{});
  // 만료된 SOS 링크 문서 축소: 팀 발급(issuedAt) 후 48h 지나고 활동 없는 것만.
  //  ⚠️ 하드삭제 금지 — 옛 문자 링크를 다시 연 조난자가 '종료됨' 안내(active:false 경로)를 계속 받아야 하므로
  //  무거운 필드(위치·메시지 등)만 떨군 묘비문서로 교체. issuedAt을 없애 다음 세션 쿼리에 다시 안 걸림.
  //  활성(active===true)·최근 활동(위치 ts/종료 closedAt/접속 openedAt 48h내) 문서는 절대 건드리지 않음.
  const _sosCut=Date.now()-48*3600000;
  _fdb.collection('sos').where('issuedAt','<',_sosCut).limit(50).get()
    .then(snap=>snap.docs.forEach(d=>{
      const p=d.data()||{};
      if(p.active===true)return; // 발급이 오래돼도 활성 링크는 보호(다일 구조 등)
      const last=Math.max(p.issuedAt||0,p.ts||0,p.closedAt||0,p.openedAt||0);
      if(last>_sosCut)return;    // 최근 활동 있으면 보호
      d.ref.set({id:p.id||d.id,active:false,closedAt:p.closedAt||last||_sosCut,gc:1}).catch(()=>{});
    })).catch(()=>{});
}
function _vibeOn(){return DB.g('notiVibrate')!==false;} // 진동 설정(기본 켜짐)
function _showSystemNoti(body,ico){
  if(!_notiRecipientReady())return; // 미로그인 상태에는 진동·OS배너 없음(처음 로그인 경험을 깔끔하게)
  // 새 알림이 오면 진동(설정 켜져 있고 기기 지원 시) — 앱이 켜져 있어도 울림
  try{if(_vibeOn()&&navigator.vibrate)navigator.vibrate([200,100,200]);}catch(e){}
  if(document.visibilityState==='visible')return; // 화면 보이는 중엔 OS 배너는 생략(진동은 위에서 함)
  if(typeof Notification==='undefined'||Notification.permission!=='granted')return; // 인앱 브라우저 등 Notification 미지원 환경 보호
  const title='설악산 현장관리 '+(ico||'🔔');
  const _vib=_vibeOn()?[200,100,200]:[];
  if(_swReg){
    _swReg.showNotification(title,{body,icon:'icons/icon-192.png',vibrate:_vib});
  }else if('Notification' in window){
    try{new Notification(title,{body});}catch(e){}
  }
}
function toggleHiContrast(){
  const on=document.body.classList.toggle('hi-contrast');
  localStorage.setItem('_hiContrast',on?'1':'');
  const btn=document.getElementById('hiContrastBtn');
  if(btn)btn.style.opacity=on?'1':'.5';
  toast(on?'🌞 야외 고대비 모드 켜짐':'🌙 고대비 모드 꺼짐');
}
// VAPID 키 설정 후 FCM 토큰 등록 (Firebase Console > Project Settings > Cloud Messaging > Web Push 인증서)
// 키는 관리자 → 시스템 화면에서 입력(전 기기 동기화, appData/fcmVapidKey) — 하드코딩 상수는 폴백용
const _FCM_VAPID='BCJmgN8TB7vPJbECQeZqeY8MpuuLHzpkov5rrT3ZcgG3xc47DZG7KGCqOKfWanxhRNKB9-B18B8cRievEXZti_g'; // 웹푸시(아이폰 PWA) 공개키
async function _initFCM(){
  const vk=String(_FCM_VAPID||DB.g('fcmVapidKey')||'').trim();
  if(!_fmsg||!_fdb||!_swReg||typeof Notification==='undefined'||Notification.permission!=='granted'||!vk)return;
  try{
    const token=await _fmsg.getToken({vapidKey:vk,serviceWorkerRegistration:_swReg});
    if(token)_saveFcmToken(token,'web');
  }catch(e){}
}
const _FCM_PUSH_URL='https://script.google.com/macros/s/AKfycbwp4JWCBkLC-LlSqiPOmyUEIO3uhv9w0ReJhEaJcXvlK0NWWwIrEK3Jo-DTaBWRHqJW/exec';
const _FCM_PUSH_SECRET='설악산119';

// ══ 네이티브 푸시 (Capacitor / 안드로이드 APK) ══
// 웹 VAPID와 달리 OS 차원 푸시 → 앱이 완전히 꺼져 있어도 수신.
let _pnListenersSet=false;
async function _initNativePush(){
  const Cap=window.Capacitor;
  if(!Cap||!Cap.isNativePlatform||!Cap.isNativePlatform())return; // 웹은 _initFCM 사용
  const PN=Cap.Plugins&&Cap.Plugins.PushNotifications;
  if(!PN)return;
  try{
    // 긴급 알림 채널(안드로이드 8+, 헤드업 표시)
    if(PN.createChannel){try{await PN.createChannel({id:'seoraksan_alerts',name:'긴급 알림',description:'구조·위험상황 푸시',importance:5,visibility:1,vibration:true,sound:'default'});}catch(e){}}
    let perm=await PN.checkPermissions();
    if(perm.receive!=='granted')perm=await PN.requestPermissions();
    if(perm.receive!=='granted')return;
    if(!_pnListenersSet){
      _pnListenersSet=true;
      PN.addListener('registration',t=>{_saveFcmToken(t.value,'android');});
      PN.addListener('registrationError',()=>{});
      PN.addListener('pushNotificationActionPerformed',act=>{
        const d=(act.notification&&act.notification.data)||{};
        if(d.app){try{goNotiLink({app:d.app,tab:d.tab?+d.tab:0,id:d.id||null});}catch(e){}}
      });
    }
    await PN.register();
  }catch(e){}
}
// 네이티브(APK)에서 알림 권한처럼 위치 권한도 최초 실행 시 자동으로 요청.
// AndroidManifest에 위치 권한이 선언돼 있으면 Capacitor WebView가
// navigator.geolocation 호출 시 OS 권한창을 띄운다.
// (@capacitor/geolocation 플러그인은 play-services-location의 구버전 Kotlin이
//  KGP와 충돌해 릴리스 빌드를 깨뜨려 사용하지 않음)
function _initNativeLocationPerm(){
  const Cap=window.Capacitor;
  if(!Cap||!Cap.isNativePlatform||!Cap.isNativePlatform())return; // 웹은 화면 하단 배너로 요청
  if(!navigator.geolocation)return;
  if(localStorage.getItem('_locPermAsked'))return;
  localStorage.setItem('_locPermAsked','1');
  navigator.geolocation.getCurrentPosition(()=>{},()=>{},{enableHighAccuracy:true,timeout:15000});
}
let _fcmTokenCache=null;
function _saveFcmToken(token,platform){
  if(!token)return;
  _fcmTokenCache={token,platform:platform||'web'};   // Firebase 준비 전이면 캐시 후 재시도
  if(!_fdb)return;
  const u=DB.g('currentUser')||{};
  _fdb.collection('fcmTokens').doc(_MY_DEVICE_ID).set({
    token,userId:u.id||'',name:u.name||'',dept:u.dept||'',kakaoId:String(u.kakaoId||''),
    notiSetting:_effectiveNotiSettings(),platform:_fcmTokenCache.platform,updatedAt:Date.now()
  },{merge:true}).catch(()=>{});
}
function _flushFcmToken(){if(_fcmTokenCache)_saveFcmToken(_fcmTokenCache.token,_fcmTokenCache.platform);}
// 알림 설정 변경 시 내 토큰 문서에도 반영 (받는 사람별 필터용)
function _updateFcmTokenSettings(){
  if(!_fdb)return;
  _fdb.collection('fcmTokens').doc(_MY_DEVICE_ID).set(
    {notiSetting:_effectiveNotiSettings(),updatedAt:Date.now()},{merge:true}
  ).catch(()=>{});
}
// GAS 요청 인증 필드 — 공유 시크릿 + (로그인 상태면) Firebase ID토큰 동봉.
// 서버(Apps Script)가 REQUIRE_AUTH=1로 전환하면 ID토큰 검증을 통과한 요청만 발송 허용(시크릿 유출 대비 2중 잠금).
async function _gasAuth(){
  const a={secret:_FCM_PUSH_SECRET||(DB.g('fcmPushSecret')||'')};
  try{const u=(typeof firebase!=='undefined'&&firebase.auth)?firebase.auth().currentUser:null;if(u)a.idToken=await u.getIdToken();}catch(e){}
  return a;
}
// 중요 알림을 꺼진 폰까지 발송 (Apps Script 경유). cat=알림설정 키, 'info'면 발송 안 함.
async function _sendFcmPush(title,body,cat,link){
  if(!_fdb)return;
  if(_testSilentOn())return; // 🔕 검증 모드: OS푸시 발송 차단
  const url=_FCM_PUSH_URL||(DB.g('fcmPushUrl')||'').trim();
  if(!url||!cat||cat==='info')return;
  try{
    const snap=await _fdb.collection('fcmTokens').get();
    const targets=[];
    snap.forEach(d=>{
      const v=d.data()||{};
      if(!v.token||d.id===_MY_DEVICE_ID)return;        // 내 폰엔 안 보냄
      if(((v.notiSetting||{})[cat])===false)return;     // 그 사람이 끈 알림
      targets.push({id:d.id,token:v.token});
    });
    if(!targets.length)return;
    const res=await fetch(url,{
      method:'POST',
      headers:{'content-type':'text/plain;charset=utf-8'}, // Apps Script preflight 회피
      body:JSON.stringify(Object.assign(await _gasAuth(),{
        title,body,
        data:link?{app:link.app||'',tab:String(link.tab||''),id:String(link.id||'')}:{},
        tokens:targets.map(t=>t.token)
      }))
    });
    const out=await res.json().catch(()=>({}));
    if(out&&Array.isArray(out.invalid)){                // 무효 토큰 정리
      out.invalid.forEach(tok=>{
        const hit=targets.find(t=>t.token===tok);
        if(hit)_fdb.collection('fcmTokens').doc(hit.id).delete().catch(()=>{});
      });
    }
  }catch(e){}
}
// 특정 카카오ID의 기기에만 OS 푸시 — 계정 탈퇴 통보 등 '필수' 알림용(개인 알림설정 무시, 앱 꺼져 있어도 수신).
// 웹은 VAPID 미설정으로 토큰 없음 → 실질적으로 안드로이드 APK 기기에 도달.
async function _sendFcmPushToKakao(kakaoId,title,body,link){
  if(!_fdb)return;
  if(_testSilentOn())return; // 🔕 검증 모드: 대상지정 필수푸시도 검증 중에는 발송 차단
  const url=_FCM_PUSH_URL||(DB.g('fcmPushUrl')||'').trim();
  kakaoId=String(kakaoId||'');
  if(!url||!kakaoId)return;
  try{
    const snap=await _fdb.collection('fcmTokens').where('kakaoId','==',kakaoId).get();
    const tokens=[];
    snap.forEach(d=>{const v=d.data()||{};if(v.token)tokens.push(v.token);});
    if(!tokens.length)return;
    await fetch(url,{
      method:'POST',
      headers:{'content-type':'text/plain;charset=utf-8'}, // Apps Script preflight 회피
      body:JSON.stringify(Object.assign(await _gasAuth(),{
        title,body,
        data:link?{app:link.app||'',tab:String(link.tab||''),id:String(link.id||'')}:{},
        tokens
      }))
    });
  }catch(e){}
}
function updateBell(){
  const cnt=(DB.g('notis')||[]).filter(n=>!n.read).length;
  ['bellCnt','bellCntHome'].forEach(id=>{const e=document.getElementById(id);if(!e)return;e.textContent=cnt>9?'9+':cnt;e.classList.toggle('on',cnt>0);});
}
// 알림 보관 7일 — 일주일 지난 알림은 자동 삭제 (id = Date.now() 기반)
const _NOTI_KEEP_MS=7*24*60*60*1000;
function _pruneOldNotis(){
  try{
    const ns=DB.g('notis')||[];if(!ns.length)return;
    const cutoff=Date.now()-_NOTI_KEEP_MS;
    const kept=ns.filter(n=>!(Number(n.id)>0&&Number(n.id)<cutoff));
    if(kept.length!==ns.length){DB.s('notis',kept);updateBell();}
  }catch(e){}
}
setTimeout(_pruneOldNotis,3000); // 부팅 후 1회 정리(벨 카운트 정확화)
function openNoti(){
  _pruneOldNotis();
  const ns=DB.g('notis')||[];
  document.getElementById('notiList').innerHTML=ns.length
    ?ns.map(n=>{
      const hasLink=n.link&&n.link.app;
      const linkStr=hasLink?`goNotiLink(${JSON.stringify(n.link).replace(/"/g,"'")})`:'';
      return `<div class="ni ${n.read?'read':'unread'}" style="${hasLink?'cursor:pointer;':''}" ${hasLink?`onclick="${linkStr}"`:''}  >
        <div style="position:relative;flex-shrink:0;">
          <div class="ni-ico">${_esc(n.ico)}</div>
          ${n.read?'':'<div style="position:absolute;top:-2px;right:-3px;width:6px;height:6px;background:#e05050;border-radius:50%;border:1px solid #1c1c1e;"></div>'}
        </div>
        <div style="flex:1;min-width:0;">
          <div class="ni-msg">${_esc(n.msg)}</div>
          <div class="ni-t">${_esc(n.time)}${hasLink?' · <span style="color:#3182f6;">탭하여 이동 →</span>':''}</div>
        </div>
      </div>`;
    }).join('')
    :'<div class="noti-empty">✅ 새 알림 없음</div>';
  DB.s('notis',(ns).map(n=>({...n,read:true})));updateBell();
  document.getElementById('notiPanel').classList.add('on');document.getElementById('notiBg').classList.add('on');
}
function goNotiLink(link){
  closeNoti();
  if(!link||!link.app) return;
  openApp(link.app);
  if(link.tab) setTimeout(()=>switchTab(link.tab,document.getElementById('nv'+link.tab)),200);
  if(link.issue) setTimeout(()=>{try{openFacIssueDetail(link.issue);}catch(e){}},300);
  else if(link.id) setTimeout(()=>{
    if(link.app==='rescue') openResPopup(link.id,'rescue');
    else if(link.app==='inspect') openFacDetail(link.id);
  },300);
}
function closeNoti(){document.getElementById('notiPanel').classList.remove('on');document.getElementById('notiBg').classList.remove('on');}
function markAllRead(){DB.s('notis',(DB.g('notis')||[]).map(n=>({...n,read:true})));updateBell();openNoti();}
function clearNotis(){DB.s('notis',[]);updateBell();closeNoti();toast('🗑️ 알림 삭제');}

